package com.dmk.ostweaks;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Suggestion row above the dock (OxygenOS launcher). Shows the apps most recently opened from the
 * launcher, newest first (the app you just left is first), skipping apps already in the dock.
 * The row is a plain view added to the launcher's root layout: the dock and the launcher's layout
 * data are not touched.
 */
final class DockSuggest {
    private DockSuggest() {}
    private static final String PREF = "ostweaks_dock";
    private static final String KEY = "recent";
    private static WeakReference<LinearLayout> rowRef;
    private static boolean done;

    static void handle(LoadPackageParam lp) {
        if (!"com.android.launcher".equals(lp.packageName) || !lp.packageName.equals(lp.processName)) return;
        synchronized (DockSuggest.class) { if (done) return; done = true; }
        final ClassLoader cl = lp.classLoader;
        Cfg.whenReady(new Runnable() { public void run() { install(cl); } });
    }

    private static void install(ClassLoader cl) {
        if (!Cfg.get("ostweaks_dock_sug", false)) { XposedBridge.log(Hook.TAG + "dock suggestions: off"); return; }
        try {
            // 1) remember apps opened from the launcher
            int n = XposedBridge.hookAllMethods(Instrumentation.class, "execStartActivity", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    for (Object a : p.args) {
                        if (a instanceof Intent) { record((Intent) a); break; }
                    }
                }
            }).size();
            // 2) show the row when the launcher resumes
            final Class<?> launcher = XposedHelpers.findClass("com.android.launcher3.Launcher", cl);
            n += XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (!launcher.isInstance(p.thisObject)) return;
                    final Activity act = (Activity) p.thisObject;
                    act.getWindow().getDecorView().post(new Runnable() {
                        public void run() { try { show(act); } catch (Throwable t) { XposedBridge.log(Hook.TAG + "dock row: " + t); } }
                    });
                }
            }).size();
            XposedBridge.log(Hook.TAG + "dock suggestions on (" + n + " hooks)");
        } catch (Throwable t) {
            XposedBridge.log(Hook.TAG + "dock suggestions: " + t);
        }
    }

    // ---- recent apps ----
    private static void record(Intent it) {
        try {
            ComponentName cn = it.getComponent();
            if (cn == null) return;
            String pkg = cn.getPackageName();
            if (pkg.equals("com.android.launcher") || pkg.equals("com.android.systemui")) return;
            Context c = Cfg.ctx();
            if (c == null) return;
            if (c.getPackageManager().getLaunchIntentForPackage(pkg) == null) return;
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            List<String> l = load(sp);
            l.remove(pkg);
            l.add(0, pkg);
            while (l.size() > 12) l.remove(l.size() - 1);
            sp.edit().putString(KEY, join(l)).apply();
        } catch (Throwable ignored) {}
    }

    private static List<String> load(SharedPreferences sp) {
        List<String> l = new ArrayList<>();
        String s = sp.getString(KEY, "");
        if (s != null) for (String x : s.split(",")) if (!x.isEmpty()) l.add(x);
        return l;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append(','); sb.append(s); }
        return sb.toString();
    }

    // ---- row ----
    private static int id(Activity a, String name) {
        return a.getResources().getIdentifier(name, "id", a.getPackageName());
    }

    private static void show(final Activity act) {
        final View hotseat = act.findViewById(id(act, "hotseat"));
        if (hotseat == null || !(hotseat.getParent() instanceof FrameLayout)) {
            XposedBridge.log(Hook.TAG + "dock suggestions: hotseat parent "
                    + (hotseat == null ? "missing" : hotseat.getParent().getClass().getName()));
            return;
        }
        final FrameLayout parent = (FrameLayout) hotseat.getParent();
        final View indicator = act.findViewById(id(act, "page_indicator"));
        final float d = act.getResources().getDisplayMetrics().density;
        LinearLayout row = rowRef == null ? null : rowRef.get();
        if (row == null || row.getParent() != parent) {
            row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0x30FFFFFF);
            bg.setCornerRadius(40 * d);
            row.setBackground(bg);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Math.round(56 * d));
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            parent.addView(row, lp);
            rowRef = new WeakReference<>(row);
            final LinearLayout r = row;
            hotseat.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                @Override public boolean onPreDraw() {
                    float top = hotseat.getTop() + hotseat.getTranslationY();
                    if (indicator != null && indicator.getTop() > 0 && indicator.getTop() < top) top = indicator.getTop();
                    r.setTranslationY(top - r.getHeight() - 6 * d);
                    r.setAlpha(hotseat.getAlpha());
                    r.setVisibility(hotseat.getVisibility() == View.VISIBLE && r.getChildCount() > 0 ? View.VISIBLE : View.INVISIBLE);
                    return true;
                }
            });
        }
        fill(act, row, hotseat, d);
    }

    private static void fill(final Activity act, LinearLayout row, View hotseat, float d) {
        row.removeAllViews();
        int max = Settings.System.getInt(act.getContentResolver(), "ostweaks_dock_sug_n", 4);
        if (max < 1) max = 1;
        if (max > 5) max = 5;
        final PackageManager pm = act.getPackageManager();
        SharedPreferences sp = act.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        List<String> inDock = new ArrayList<>();
        dockPackages(hotseat, inDock);
        int shown = 0;
        for (String pkg : load(sp)) {
            if (shown >= max) break;
            if (inDock.contains(pkg)) continue;
            final Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch == null) continue;
            ImageView iv = new ImageView(act);
            try { iv.setImageDrawable(pm.getApplicationIcon(pkg)); } catch (Throwable t) { continue; }
            int s = Math.round(44 * d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
            lp.setMargins(Math.round(8 * d), 0, Math.round(8 * d), 0);
            iv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(launch);
                }
            });
            row.addView(iv, lp);
            shown++;
        }
        row.setPadding(Math.round(10 * d), 0, Math.round(10 * d), 0);
        row.setVisibility(shown > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private static void dockPackages(View v, List<String> out) {
        try {
            Object tag = v.getTag();
            if (tag != null) {
                Object cn = XposedHelpers.callMethod(tag, "getTargetComponent");
                if (cn instanceof ComponentName) out.add(((ComponentName) cn).getPackageName());
            }
        } catch (Throwable ignored) {}
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dockPackages(g.getChildAt(i), out);
        }
    }
}
