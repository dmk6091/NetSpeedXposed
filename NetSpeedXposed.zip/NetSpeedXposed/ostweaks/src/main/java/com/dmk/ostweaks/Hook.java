package com.dmk.ostweaks;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * VoNR / VoLTE icons instead of "HD".
 *
 * OplusStatusBarSignalPolicy.updateVo5GIcon picks the icon set for HD voice: the VoNR/VoLTE set
 * (stat_signal_vonr..., e.g. "VoNR 1 / VoLTE 2") when CustomizeFeatureOption.sIsSupportShowVoNR is set
 * for either SIM, otherwise the HD set. That flag comes from the per-carrier app feature
 * "com.android.systemui.show_vonr", which is off for Jio / Vi. It is forced on for both SIM slots.
 */
public class Hook implements IXposedHookLoadPackage {
    static final String TAG = "OSTweaks: ";
    static final String CFO = "com.oplusos.systemui.common.feature.CustomizeFeatureOption";

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        if (lp.processName != null && !"com.android.systemui".equals(lp.processName)) return;
        Class<?> cfo = XposedHelpers.findClassIfExists(CFO, lp.classLoader);
        if (cfo == null) { XposedBridge.log(TAG + "not an OxygenOS / ColorOS System UI"); return; }
        int n = XposedBridge.hookAllMethods(cfo, "loadAppFeatureForSlotId", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) { forceVoNr(cfo); }
        }).size();
        forceVoNr(cfo);
        XposedBridge.log(TAG + "VoNR/VoLTE icons on (" + n + " hook)");
    }

    static void forceVoNr(Class<?> cfo) {
        try {
            boolean[] a = (boolean[]) XposedHelpers.findField(cfo, "sIsSupportShowVoNR").get(null);
            for (int i = 0; i < a.length; i++) a[i] = true;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "show_vonr: " + t);
        }
    }
}
