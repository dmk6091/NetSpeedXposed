package com.dmk.ostweaks;

import android.content.Context;
import android.provider.Settings;

/** Feature switches written by the OxygenOS Tweaks app into Settings.System (default: on). */
final class Cfg {
    private Cfg() {}

    static boolean on(String key) { return get(key, true); }

    static boolean get(String key, boolean def) {
        try {
            Context c = ctx();
            if (c == null) return def;
            return Settings.System.getInt(c.getContentResolver(), key, def ? 1 : 0) != 0;
        } catch (Throwable t) {
            return def;
        }
    }

    static Context ctx() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) return (Context) app;
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            return (Context) at.getMethod("getSystemContext").invoke(thread);
        } catch (Throwable t) {
            return null;
        }
    }
}
