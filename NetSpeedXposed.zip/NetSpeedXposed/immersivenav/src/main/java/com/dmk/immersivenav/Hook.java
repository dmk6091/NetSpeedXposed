package com.dmk.immersivenav;

import android.graphics.Insets;
import android.view.WindowInsets;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Immersive navigation.
 *
 * System UI's NavigationBar window tells the window manager how much space to keep clear at
 * the bottom through an InsetsFrameProvider (type navigationBars). On this HyperOS build that
 * strip is 52 px and ignores the framework navigation_bar_height overlay, so we zero the size
 * where System UI sets it. The pill window itself is untouched and keeps drawing on top of
 * apps; gestures (launcher GestureStub windows) are unaffected.
 *
 * Only the navigationBars size is changed. Keyboard (IME) overrides are left alone.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "ImmersiveNav: ";

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        try {
            Class<?> ifp = XposedHelpers.findClass("android.view.InsetsFrameProvider", lp.classLoader);
            int n = XposedBridge.hookAllMethods(ifp, "setInsetsSize", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.args.length > 0 && p.args[0] instanceof Insets)) return;
                    Insets in = (Insets) p.args[0];
                    if (in.equals(Insets.NONE)) return;
                    int type;
                    try {
                        type = (int) XposedHelpers.callMethod(p.thisObject, "getType");
                    } catch (Throwable t) {
                        return;
                    }
                    if (type == WindowInsets.Type.navigationBars()) p.args[0] = Insets.NONE;
                }
            }).size();
            XposedBridge.log(TAG + "hooked setInsetsSize (" + n + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "failed: " + t);
        }
    }
}
