package com.dmk.immersivenav;

import android.graphics.Insets;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Immersive navigation for CLO / Android 17.
 *
 * Diagnosis from the A17 logs: the NavigationBar window is created during early SystemUI
 * startup, BEFORE Vector injects this module, so the addView / setInsetsSize hooks never
 * see it (only the StatusBar, created later, came through). The reserved strip is the nav
 * bar window's own navigationBars InsetsFrameProvider, already registered with the window
 * manager.
 *
 * So three layers:
 *   1. setInsetsSize hook — zero any future navigationBars provider (rotations, rebuilds).
 *   2. addView / updateViewLayout hook — zero nav providers on windows added/updated later.
 *   3. A post-install SWEEP of WindowManagerGlobal's already-attached windows: find the nav
 *      bar, zero its navigationBars provider, and call updateViewLayout so the window manager
 *      recomputes the inset. Run a few times (boot timing) to be safe.
 *
 * Everything is wrapped so a miss only means "no effect", never a SystemUI crash.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "ImmersiveNav: ";
    private static boolean installed;
    private static Object wmgInstance;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) {
            if (lp.packageName.equals(lp.processName)) hideImeNavBar(lp.packageName);
            return;
        }
        synchronized (Hook.class) {
            if (installed) return;
            installed = true;
        }
        final int navType = WindowInsets.Type.navigationBars();

        // 1) InsetsFrameProvider.setInsetsSize — zero nav-type providers set from now on
        try {
            Class<?> ifp = XposedHelpers.findClass("android.view.InsetsFrameProvider", null);
            XposedBridge.hookAllMethods(ifp, "setInsetsSize", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.args.length > 0 && p.args[0] instanceof Insets)) return;
                    if (Insets.NONE.equals(p.args[0])) return;
                    if ((typeOf(p.thisObject) & navType) != 0) p.args[0] = Insets.NONE;
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setInsetsSize hook failed: " + t);
        }

        // 2) WindowManagerGlobal addView/updateViewLayout — zero nav providers + grab the singleton
        try {
            Class<?> wmg = XposedHelpers.findClass("android.view.WindowManagerGlobal", null);
            try { wmgInstance = XposedHelpers.callStaticMethod(wmg, "getInstance"); } catch (Throwable ignored) {}
            XC_MethodHook fix = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    for (Object a : p.args) {
                        if (a instanceof WindowManager.LayoutParams) {
                            zeroNav((WindowManager.LayoutParams) a, navType, false);
                        }
                    }
                }
            };
            XposedBridge.hookAllMethods(wmg, "addView", fix);
            XposedBridge.hookAllMethods(wmg, "updateViewLayout", fix);
            XposedBridge.log(TAG + "hooks installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "window hook failed: " + t);
        }

        // 3) Sweep windows that already exist (the nav bar, created before we loaded)
        final Handler h = new Handler(Looper.getMainLooper());
        for (int delay : new int[]{1500, 4000, 9000}) {
            h.postDelayed(new Runnable() { public void run() { sweep(navType); } }, delay);
        }
    }

    /** Walk WindowManagerGlobal's attached views, zero nav insets, push a relayout. */
    private static void sweep(int navType) {
        if (wmgInstance == null) return;
        List<View> views = new ArrayList<>();
        try {
            Object mViews = XposedHelpers.getObjectField(wmgInstance, "mViews");
            if (mViews instanceof List) {
                for (Object o : (List<?>) mViews) if (o instanceof View) views.add((View) o);
            } else if (mViews != null && mViews.getClass().isArray()) {
                for (int i = 0; i < Array.getLength(mViews); i++) {
                    Object o = Array.get(mViews, i);
                    if (o instanceof View) views.add((View) o);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "sweep: can't read mViews: " + t);
            return;
        }
        int navWindows = 0, pushed = 0;
        for (View v : views) {
            ViewGroup.LayoutParams p;
            try { p = v.getLayoutParams(); } catch (Throwable t) { continue; }
            if (!(p instanceof WindowManager.LayoutParams)) continue;
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) p;
            String title = String.valueOf(lp.getTitle());
            int navSize = navProviderInfo(lp, navType);
            if (navSize == Integer.MIN_VALUE) continue;          // no nav provider on this window
            navWindows++;
            if (navSize == 0) continue;                           // already zero
            if (zeroNav(lp, navType, true)) {
                try {
                    XposedHelpers.callMethod(wmgInstance, "updateViewLayout", v, lp);
                    pushed++;
                    XposedBridge.log(TAG + "sweep: zeroed+pushed '" + title + "' (was bottom=" + navSize + ")");
                } catch (Throwable e) {
                    XposedBridge.log(TAG + "sweep: push failed '" + title + "': " + e);
                }
            }
        }
        XposedBridge.log(TAG + "sweep: scanned " + views.size() + " windows, nav-providing=" + navWindows + ", pushed=" + pushed);
    }

    /** bottom px of the window's nav provider, 0 if NONE, MIN_VALUE if it has none. */
    private static int navProviderInfo(WindowManager.LayoutParams lp, int navType) {
        Object[] provs = providers(lp);
        if (provs == null) return Integer.MIN_VALUE;
        boolean found = false;
        for (Object prov : provs) {
            if (prov == null || (typeOf(prov) & navType) == 0) continue;
            found = true;
            try {
                Object size = XposedHelpers.callMethod(prov, "getInsetsSize");
                if (size == null) return 1;                       // null = whole frame → reserves
                if (Insets.NONE.equals(size)) return 0;
                return ((Insets) size).bottom != 0 ? ((Insets) size).bottom : 1;
            } catch (Throwable t) { return 1; }
        }
        return found ? 1 : Integer.MIN_VALUE;
    }

    private static boolean zeroNav(WindowManager.LayoutParams lp, int navType, boolean quiet) {
        Object[] provs = providers(lp);
        if (provs == null) return false;
        boolean changed = false;
        for (Object prov : provs) {
            if (prov == null || (typeOf(prov) & navType) == 0) continue;
            Object size = null;
            try { size = XposedHelpers.callMethod(prov, "getInsetsSize"); } catch (Throwable ignored) {}
            if (Insets.NONE.equals(size)) continue;
            try {
                XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                changed = true;
                if (!quiet) XposedBridge.log(TAG + "zeroed nav provider on '" + lp.getTitle() + "' (was " + size + ")");
            } catch (Throwable ignored) {}
        }
        return changed;
    }

    private static Object[] providers(WindowManager.LayoutParams lp) {
        try {
            Object v = XposedHelpers.getObjectField(lp, "providedInsets");
            if (v instanceof Object[]) return (Object[]) v;
        } catch (Throwable ignored) {}
        return null;
    }

    private static boolean imeHooked;

    private static void hideImeNavBar(String pkg) {
        synchronized (Hook.class) {
            if (imeHooked) return;
            imeHooked = true;
        }
        XC_MethodHook clear = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Integer) {
                    p.args[0] = ((Integer) p.args[0]) & ~1;
                }
            }
        };
        int n = 0;
        for (String c : new String[]{"android.inputmethodservice.NavigationBarController",
                "android.inputmethodservice.NavigationBarController$Impl"}) {
            Class<?> k = XposedHelpers.findClassIfExists(c, null);
            if (k != null) n += XposedBridge.hookAllMethods(k, "onNavButtonFlagsChanged", clear).size();
        }
        XposedBridge.log(TAG + (n == 0 ? "no keyboard nav bar code found in " : "keyboard bar hidden in ") + pkg);
    }

    private static int typeOf(Object provider) {
        try {
            return (int) XposedHelpers.callMethod(provider, "getType");
        } catch (Throwable t) {
            return -1;
        }
    }
}
