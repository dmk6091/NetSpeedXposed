package com.dmk.immersivenav;

import android.graphics.Insets;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Immersive navigation — diagnostic v2 for CLO / Android 17.
 *
 * Previous finding: no SystemUI window provides a navigationBars (type=2) inset, and
 * setInsetsSize is never called with type=2. So the reserved strip comes from somewhere
 * other than a SystemUI window provider. This build dumps every window's title + providers
 * (from addView/updateViewLayout AND a sweep of already-attached windows), and logs the
 * first setInsetsSize call of each type, so we can see exactly where the bottom inset lives.
 * It still zeroes any nav provider it does find. All wrapped — never crashes SystemUI.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "ImmersiveNav: ";
    private static boolean installed;
    private static Object wmgInstance;
    private static final Set<String> dumped = new HashSet<>();
    private static final Set<Integer> loggedTypes = new HashSet<>();

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) {
            if (lp.packageName.equals(lp.processName)) hideImeNavBar(lp.packageName);
            return;
        }
        synchronized (Hook.class) {
            if (installed) return;
            installed = true;
        }
        final int navType = WindowInsets.Type.navigationBars();
        XposedBridge.log(TAG + "navigationBars bit=" + navType);

        try {
            Class<?> ifp = XposedHelpers.findClass("android.view.InsetsFrameProvider", null);
            XposedBridge.hookAllMethods(ifp, "setInsetsSize", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.args.length > 0 && p.args[0] instanceof Insets)) return;
                    int t = typeOf(p.thisObject);
                    if (loggedTypes.add(t)) XposedBridge.log(TAG + "setInsetsSize first type=" + t + " size=" + p.args[0]);
                    if ((t & navType) != 0 && !Insets.NONE.equals(p.args[0])) p.args[0] = Insets.NONE;
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setInsetsSize hook failed: " + t);
        }

        try {
            Class<?> wmg = XposedHelpers.findClass("android.view.WindowManagerGlobal", null);
            XC_MethodHook fix = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (wmgInstance == null) wmgInstance = p.thisObject;
                    for (Object a : p.args) {
                        if (a instanceof WindowManager.LayoutParams) {
                            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) a;
                            dump("add", lp);
                            zeroNav(lp, navType);
                        }
                    }
                }
            };
            XposedBridge.hookAllMethods(wmg, "addView", fix);
            XposedBridge.hookAllMethods(wmg, "updateViewLayout", fix);
            XposedBridge.log(TAG + "hooks installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "window hook failed: " + t);
        }

        final Handler h = new Handler(Looper.getMainLooper());
        for (int delay : new int[]{1500, 4000, 9000, 18000}) {
            h.postDelayed(new Runnable() { public void run() { sweep(navType); } }, delay);
        }
    }

    private static void sweep(int navType) {
        if (wmgInstance == null) { XposedBridge.log(TAG + "sweep: no WMG singleton yet"); return; }
        List<View> views = new ArrayList<>();
        try {
            Object mViews = XposedHelpers.getObjectField(wmgInstance, "mViews");
            if (mViews instanceof List) {
                for (Object o : (List<?>) mViews) if (o instanceof View) views.add((View) o);
            } else if (mViews != null && mViews.getClass().isArray()) {
                for (int i = 0; i < Array.getLength(mViews); i++) {
                    Object o = Array.get(mViews, i);
                    if (o instanceof View) views.add((View) o);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "sweep: can't read mViews: " + t);
            return;
        }
        int pushed = 0;
        for (View v : views) {
            ViewGroup.LayoutParams p;
            try { p = v.getLayoutParams(); } catch (Throwable t) { continue; }
            if (!(p instanceof WindowManager.LayoutParams)) continue;
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) p;
            dump("sweep", lp);
            if (zeroNav(lp, navType)) {
                try { XposedHelpers.callMethod(wmgInstance, "updateViewLayout", v, lp); pushed++; }
                catch (Throwable e) { XposedBridge.log(TAG + "sweep push failed: " + e); }
            }
        }
        XposedBridge.log(TAG + "sweep: " + views.size() + " windows, pushed=" + pushed);
    }

    /** one-line dump of a window's title + every inset provider (type:size), once per where|title */
    private static void dump(String where, WindowManager.LayoutParams lp) {
        String title;
        try { title = String.valueOf(lp.getTitle()); } catch (Throwable t) { title = "?"; }
        if (!dumped.add(where + "|" + title)) return;
        Object[] provs = providers(lp);
        StringBuilder sb = new StringBuilder(TAG).append(where).append(" '").append(title).append("' ");
        if (provs == null) {
            sb.append("providedInsets=null");
        } else {
            sb.append(provs.length).append(" providers [");
            for (Object prov : provs) {
                if (prov == null) continue;
                Object size = null;
                try { size = XposedHelpers.callMethod(prov, "getInsetsSize"); } catch (Throwable ignored) {}
                sb.append(typeOf(prov)).append(":").append(size).append(" ");
            }
            sb.append("]");
        }
        XposedBridge.log(sb.toString());
    }

    private static boolean zeroNav(WindowManager.LayoutParams lp, int navType) {
        Object[] provs = providers(lp);
        if (provs == null) return false;
        boolean changed = false;
        for (Object prov : provs) {
            if (prov == null || (typeOf(prov) & navType) == 0) continue;
            Object size = null;
            try { size = XposedHelpers.callMethod(prov, "getInsetsSize"); } catch (Throwable ignored) {}
            if (Insets.NONE.equals(size)) continue;
            try {
                XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                changed = true;
                XposedBridge.log(TAG + "zeroed nav provider on '" + lp.getTitle() + "' (was " + size + ")");
            } catch (Throwable ignored) {}
        }
        return changed;
    }

    private static Object[] providers(WindowManager.LayoutParams lp) {
        try {
            Object v = XposedHelpers.getObjectField(lp, "providedInsets");
            if (v instanceof Object[]) return (Object[]) v;
        } catch (Throwable ignored) {}
        return null;
    }

    private static boolean imeHooked;

    private static void hideImeNavBar(String pkg) {
        synchronized (Hook.class) {
            if (imeHooked) return;
            imeHooked = true;
        }
        XC_MethodHook clear = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Integer) {
                    p.args[0] = ((Integer) p.args[0]) & ~1;
                }
            }
        };
        int n = 0;
        for (String c : new String[]{"android.inputmethodservice.NavigationBarController",
                "android.inputmethodservice.NavigationBarController$Impl"}) {
            Class<?> k = XposedHelpers.findClassIfExists(c, null);
            if (k != null) n += XposedBridge.hookAllMethods(k, "onNavButtonFlagsChanged", clear).size();
        }
        XposedBridge.log(TAG + (n == 0 ? "no keyboard nav bar code found in " : "keyboard bar hidden in ") + pkg);
    }

    private static int typeOf(Object provider) {
        try {
            return (int) XposedHelpers.callMethod(provider, "getType");
        } catch (Throwable t) {
            return -1;
        }
    }
}
