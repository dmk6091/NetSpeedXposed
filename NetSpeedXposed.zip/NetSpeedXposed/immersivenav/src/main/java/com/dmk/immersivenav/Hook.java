package com.dmk.immersivenav;

import android.graphics.Insets;
import android.view.WindowInsets;
import android.view.WindowManager;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Immersive navigation (diagnostic + widened build for CLO / Android 17).
 *
 * The HyperOS build zeroed the navigationBars InsetsFrameProvider and that was enough.
 * On CLO/A17 the hooks attach but the reserved strip stays, so this build:
 *   - logs every setInsetsSize call (type + value), not just nav ones;
 *   - on the first window seen, dumps every LayoutParams field whose name mentions
 *     "inset"/"provid" so we can see which field actually holds the providers on A17;
 *   - reads the providers from several possible field names;
 *   - matches nav providers by (type & navigationBars) != 0 and zeroes them even when
 *     their current size is null (null = "use the whole window frame", which reserves it);
 *   - logs each provider's type + size and every zeroing.
 * Everything is wrapped so a miss only means "no effect", never a SystemUI crash.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "ImmersiveNav: ";
    private static boolean installed;
    private static boolean dumpedFields;
    private static final Set<String> loggedWindows = new HashSet<>();

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) {
            if (lp.packageName.equals(lp.processName)) hideImeNavBar(lp.packageName);
            return;
        }
        synchronized (Hook.class) {
            if (installed) return;
            installed = true;
        }
        final int navType = WindowInsets.Type.navigationBars();
        XposedBridge.log(TAG + "navigationBars type bit = " + navType);

        // 1) InsetsFrameProvider.setInsetsSize — log every call, zero nav-type ones
        try {
            Class<?> ifp = XposedHelpers.findClass("android.view.InsetsFrameProvider", null);
            int n = XposedBridge.hookAllMethods(ifp, "setInsetsSize", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.args.length > 0 && p.args[0] instanceof Insets)) return;
                    int t = typeOf(p.thisObject);
                    if (Insets.NONE.equals(p.args[0])) return; // our own / already-zero calls
                    XposedBridge.log(TAG + "setInsetsSize type=" + t + " size=" + p.args[0]);
                    if ((t & navType) != 0) {
                        p.args[0] = Insets.NONE;
                        XposedBridge.log(TAG + "  -> forced nav size NONE");
                    }
                }
            }).size();
            XposedBridge.log(TAG + "hooked setInsetsSize (" + n + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setInsetsSize hook failed: " + t);
        }

        // 2) WindowManagerGlobal addView/updateViewLayout — inspect + zero provided insets
        try {
            Class<?> wmg = XposedHelpers.findClass("android.view.WindowManagerGlobal", null);
            XC_MethodHook fix = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    for (Object a : p.args) {
                        if (a instanceof WindowManager.LayoutParams) {
                            inspectAndZero((WindowManager.LayoutParams) a, navType);
                        }
                    }
                }
            };
            int a = XposedBridge.hookAllMethods(wmg, "addView", fix).size();
            int u = XposedBridge.hookAllMethods(wmg, "updateViewLayout", fix).size();
            XposedBridge.log(TAG + "hooked addView (" + a + "), updateViewLayout (" + u + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "window hook failed: " + t);
        }
    }

    private static void inspectAndZero(WindowManager.LayoutParams lp, int navType) {
        String title;
        try { title = String.valueOf(lp.getTitle()); } catch (Throwable t) { title = "?"; }

        // one-time: dump every LayoutParams field that might hold inset providers
        if (!dumpedFields) {
            synchronized (Hook.class) {
                if (!dumpedFields) {
                    dumpedFields = true;
                    XposedBridge.log(TAG + "=== LayoutParams inset/provider fields (window '" + title + "') ===");
                    for (Field f : WindowManager.LayoutParams.class.getDeclaredFields()) {
                        String fn = f.getName().toLowerCase();
                        if (!(fn.contains("inset") || fn.contains("provid"))) continue;
                        try {
                            f.setAccessible(true);
                            Object v = f.get(lp);
                            String desc;
                            if (v == null) desc = "null";
                            else if (v.getClass().isArray())
                                desc = v.getClass().getComponentType().getSimpleName() + "[" + Array.getLength(v) + "]";
                            else desc = v.getClass().getSimpleName() + "=" + v;
                            XposedBridge.log(TAG + "FIELD " + f.getName() + " (" + f.getType().getSimpleName() + ") = " + desc);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "FIELD " + f.getName() + " read fail: " + t);
                        }
                    }
                    XposedBridge.log(TAG + "=== end fields ===");
                }
            }
        }

        Object arr = null;
        for (String fn : new String[]{"providedInsets", "providedInternalInsets", "mProvidedInsets", "paramsForRotation"}) {
            try {
                Object v = XposedHelpers.getObjectField(lp, fn);
                if (v != null && v.getClass().isArray() && Array.getLength(v) > 0) { arr = v; break; }
            } catch (Throwable ignored) {}
        }
        if (!(arr instanceof Object[])) return;
        Object[] provs = (Object[]) arr;

        boolean logWin = loggedWindows.add(title);
        if (logWin) XposedBridge.log(TAG + "window '" + title + "' providers=" + provs.length);
        for (Object prov : provs) {
            if (prov == null) continue;
            int t = typeOf(prov);
            Object size = null;
            try { size = XposedHelpers.callMethod(prov, "getInsetsSize"); } catch (Throwable ignored) {}
            if (logWin) XposedBridge.log(TAG + "  provider type=" + t + " size=" + size);
            if ((t & navType) != 0 && !Insets.NONE.equals(size)) {
                try {
                    XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                    XposedBridge.log(TAG + "  zeroed nav provider on '" + title + "' (was " + size + ")");
                } catch (Throwable e) {
                    XposedBridge.log(TAG + "  zero failed on '" + title + "': " + e);
                }
            }
        }
    }

    private static boolean imeHooked;

    private static void hideImeNavBar(String pkg) {
        synchronized (Hook.class) {
            if (imeHooked) return;
            imeHooked = true;
        }
        XC_MethodHook clear = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Integer) {
                    p.args[0] = ((Integer) p.args[0]) & ~1;
                }
            }
        };
        int n = 0;
        for (String c : new String[]{"android.inputmethodservice.NavigationBarController",
                "android.inputmethodservice.NavigationBarController$Impl"}) {
            Class<?> k = XposedHelpers.findClassIfExists(c, null);
            if (k != null) n += XposedBridge.hookAllMethods(k, "onNavButtonFlagsChanged", clear).size();
        }
        XposedBridge.log(TAG + (n == 0 ? "no keyboard nav bar code found in " : "keyboard bar hidden in ") + pkg);
    }

    private static int typeOf(Object provider) {
        try {
            return (int) XposedHelpers.callMethod(provider, "getType");
        } catch (Throwable t) {
            return -1;
        }
    }
}
