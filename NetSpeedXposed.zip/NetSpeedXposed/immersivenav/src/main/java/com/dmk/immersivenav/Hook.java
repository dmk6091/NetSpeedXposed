package com.dmk.immersivenav;

import android.graphics.Insets;
import android.view.WindowInsets;
import android.view.WindowManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Immersive navigation.
 *
 * System UI's NavigationBar window tells the window manager how much space to keep clear at
 * the bottom through InsetsFrameProviders (type navigationBars) in its LayoutParams. On this
 * HyperOS build that strip is 52 px and ignores the framework navigation_bar_height overlay.
 *
 * Two layers:
 *  1. setInsetsSize() is forced to Insets.NONE for navigationBars providers.
 *  2. Every time System UI adds a window or updates its layout (WindowManagerGlobal addView /
 *     updateViewLayout), the providedInsets in those LayoutParams are re-checked and zeroed,
 *     so a nav bar rebuilt by another path (overlay change, rotation, theme refresh) is caught
 *     right before it reaches the window manager.
 *
 * The pill window itself is untouched and keeps drawing on top of apps; gestures (launcher
 * GestureStub windows) are unaffected. Keyboard (IME) overrides are left alone.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "ImmersiveNav: ";
    private static boolean installed;
    private static boolean loggedFix;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) {
            hideImeNavBar(lp.packageName);   // keyboard apps added to the scope
            return;
        }
        synchronized (Hook.class) {
            if (installed) return;
            installed = true;
        }
        int navType = WindowInsets.Type.navigationBars();

        try {
            Class<?> ifp = XposedHelpers.findClass("android.view.InsetsFrameProvider", null);
            int n = XposedBridge.hookAllMethods(ifp, "setInsetsSize", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.args.length > 0 && p.args[0] instanceof Insets)) return;
                    if (Insets.NONE.equals(p.args[0])) return;
                    if (typeOf(p.thisObject) == navType) p.args[0] = Insets.NONE;
                }
            }).size();
            XposedBridge.log(TAG + "hooked setInsetsSize (" + n + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setInsetsSize hook failed: " + t);
        }

        try {
            Class<?> wmg = XposedHelpers.findClass("android.view.WindowManagerGlobal", null);
            XC_MethodHook fix = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    for (Object a : p.args) {
                        if (a instanceof WindowManager.LayoutParams) {
                            zeroNavInsets((WindowManager.LayoutParams) a, navType);
                        }
                    }
                }
            };
            int a = XposedBridge.hookAllMethods(wmg, "addView", fix).size();
            int u = XposedBridge.hookAllMethods(wmg, "updateViewLayout", fix).size();
            XposedBridge.log(TAG + "hooked addView (" + a + "), updateViewLayout (" + u + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "window hook failed: " + t);
        }
    }

    private static boolean imeHooked;

    /**
     * In gesture mode the keyboard draws its own bar under the keys (the hide-keyboard arrow and
     * the IME switcher). The system tells it to through InputMethodNavButtonFlags.IME_DRAWS_IME_NAV_BAR
     * (bit 1). Clearing that bit makes the keyboard skip the bar, so the keys reach the bottom edge;
     * the back swipe still closes the keyboard.
     */
    private static void hideImeNavBar(String pkg) {
        synchronized (Hook.class) {
            if (imeHooked) return;
            imeHooked = true;
        }
        XC_MethodHook clear = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Integer) {
                    p.args[0] = ((Integer) p.args[0]) & ~1;
                }
            }
        };
        int n = 0;
        for (String c : new String[]{"android.inputmethodservice.NavigationBarController",
                "android.inputmethodservice.NavigationBarController$Impl"}) {
            Class<?> k = XposedHelpers.findClassIfExists(c, null);
            if (k != null) n += XposedBridge.hookAllMethods(k, "onNavButtonFlagsChanged", clear).size();
        }
        XposedBridge.log(TAG + (n == 0 ? "no keyboard nav bar code found in " : "keyboard bar hidden in ") + pkg);
    }

    private static int typeOf(Object provider) {
        try {
            return (int) XposedHelpers.callMethod(provider, "getType");
        } catch (Throwable t) {
            return -1;
        }
    }

    private static void zeroNavInsets(WindowManager.LayoutParams lp, int navType) {
        Object arr;
        try {
            arr = XposedHelpers.getObjectField(lp, "providedInsets");
        } catch (Throwable t) {
            return;
        }
        if (!(arr instanceof Object[])) return;
        for (Object prov : (Object[]) arr) {
            if (prov == null || typeOf(prov) != navType) continue;
            try {
                Object size = XposedHelpers.callMethod(prov, "getInsetsSize");
                if (Insets.NONE.equals(size)) continue;
                // null size means "use the whole window frame", which also reserves the strip
                XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                if (!loggedFix) {
                    loggedFix = true;
                    XposedBridge.log(TAG + "zeroed nav bar inset on " + lp.getTitle()
                            + " (was " + size + ")");
                }
            } catch (Throwable ignored) {
            }
        }
    }
}
