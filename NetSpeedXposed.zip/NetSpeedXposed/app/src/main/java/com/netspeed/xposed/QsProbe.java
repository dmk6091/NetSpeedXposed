package com.netspeed.xposed;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/** Read-only probe: records how this ROM builds the quick settings (classes + view tree). Changes nothing. */
final class QsProbe {
    private static final String TAG = "NetSpeedXposed: [qsprobe] ";
    private static int tiles, headers;

    private QsProbe() {}

    static void install(ClassLoader cl) {
        String[] known = {
                "com.android.systemui.qs.tileimpl.QSTileViewImpl",
                "com.android.systemui.qs.tileimpl.QSTileViewHorizontal",
                "com.android.systemui.qs.tileimpl.QSTileImpl",
                "com.android.systemui.qs.QuickStatusBarHeader",
                "com.android.systemui.shade.QuickStatusBarHeader",
                "com.android.systemui.shade.ShadeHeaderController",
                "com.android.systemui.qs.QSPanel",
                "com.android.systemui.qs.QSContainerImpl",
                "com.android.systemui.qs.ui.compose.QuickSettingsContainer",
                "com.android.systemui.qs.panels.ui.compose.PaginatedGridLayout",
                "com.android.systemui.qs.panels.ui.compose.InfiniteGridLayout",
                "com.android.systemui.qs.tiles.base.ui.compose.TileComposable",
        };
        for (String k : known) {
            boolean ok;
            try { XposedHelpers.findClass(k, cl); ok = true; } catch (Throwable t) { ok = false; }
            XposedBridge.log(TAG + (ok ? "class present: " : "class missing: ") + k);
        }
        watch(cl, "com.android.systemui.qs.tileimpl.QSTileViewImpl", true);
        watch(cl, "com.android.systemui.qs.QuickStatusBarHeader", false);
        watch(cl, "com.android.systemui.shade.QuickStatusBarHeader", false);
    }

    private static void watch(ClassLoader cl, String cn, final boolean tile) {
        try {
            Class<?> c = XposedHelpers.findClass(cn, cl);
            XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (!(p.thisObject instanceof View)) return;
                    final View v = (View) p.thisObject;
                    if (tile ? tiles >= 2 : headers >= 1) return;
                    if (tile) tiles++; else headers++;
                    v.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            StringBuilder sb = new StringBuilder();
                            dump(v, 0, sb);
                            XposedBridge.log(TAG + (tile ? "tile tree:\n" : "header tree:\n") + sb);
                        }
                    }, 4000);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "watch " + cn + ": " + t);
        }
    }

    private static void dump(View v, int depth, StringBuilder sb) {
        if (depth > 5 || sb.length() > 6000) return;
        String id = "";
        try { if (v.getId() != View.NO_ID) id = v.getResources().getResourceEntryName(v.getId()); } catch (Throwable ignored) { }
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName()).append(" #").append(id).append(' ').append(v.getWidth()).append('x').append(v.getHeight());
        if (v instanceof TextView) sb.append(" \"").append(((TextView) v).getText()).append('"');
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dump(g.getChildAt(i), depth + 1, sb);
        }
    }
}
