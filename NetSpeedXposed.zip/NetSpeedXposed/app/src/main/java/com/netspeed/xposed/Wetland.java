package com.netspeed.xposed;

import java.util.Locale;

/**
 * Nearest wetland / water body (OpenStreetMap, natural=wetland and named natural=water within 25 km) and the nearest
 * Ramsar site of India (matched by name against the official list; position from OpenStreetMap, within 220 km).
 * Only what mappers have drawn, and a Ramsar site only when OSM has it under a matching name.
 */
final class Wetland {
    private Wetland() {}

    static final class Hit {
        String name, type, dir;
        double km;
        boolean ramsar, unnamed;
        String text() { return name + (unnamed ? "" : " · " + type) + " · " + (km < 10 ? String.format(Locale.US, "%.1f", km) : String.valueOf(Math.round(km))) + " km " + dir; }
    }

    static volatile Hit wetland, marsh, ramsar;
    static volatile double[] at = null;          // where they were looked up
    static volatile long okAt = 0, triedAt = 0;
    static volatile boolean running = false;
    static volatile String why = "not looked up yet";

    /** Ramsar sites of India, as name starts (case-insensitive, anchored at the start of the OSM name). */
    private static final String[] RAMSAR = {"Kolleru", "Deepor", "Kanwar", "Kabar", "Nanda Lake", "Thol ", "Wadhvana", "Khijadiya", "Nalsarovar",
            "Sultanpur", "Bhindawas", "Pong Dam", "Maharana Pratap Sagar", "Chandra Taal", "Chandratal", "Renuka", "Ashtamudi", "Loktak", "East Kolkata Wetland",
            "Nandur Madhameshwar", "Nandur Madhmeshwar", "Nangal", "Nawabganj Bird", "Parvati Arga", "Point Calimere", "Keshopur", "Keoladeo", "Ropar Wetland",
            "Rudrasagar", "Saman Bird", "Samaspur", "Sambhar", "Sandi Bird", "Sarsai Nawar", "Sasthamkotta", "Haiderpur", "Sundarban", "Sunderban", "Surinsar",
            "Mansar", "Tsomoriri", "Tso Moriri", "Vembanad", "Wular", "Asan Barrage", "Asan Conservation", "Bhitarkanika", "Sur Sarovar", "Keetham", "Lonar", "Tso Kar",
            "Hokera", "Hokersar", "Kanjli", "Chilika", "Chilka", "Beas Conservation", "Bakhira", "Harike", "Karikili", "Pallikaranai", "Pichavaram", "Pala Wetland",
            "Sakhya Sagar", "Satkosia", "Bhoj Wetland", "Upper Lake", "Gulf of Mannar", "Ranganathittu", "Vembannur", "Vellode", "Udhayamarthandapuram", "Vedanthangal",
            "Sirpur", "Koonthankulam", "Tampara", "Hirakud", "Ansupa", "Yashwant Sagar", "Chitrangudi", "Suchindram", "Vaduvur", "Kanjirankulam", "Thane Creek",
            "Hygam", "Shallabugh", "Ankasamudra", "Aghanashini", "Magadi Kere", "Karaivetti", "Longwood Shola", "Nagi Bird", "Nakti Bird", "Tawa Reservoir",
            "Nanjarayan", "Kazhuveli", "Sakkarakottai", "Therthangal", "Khecheopalri", "Khecheopalli", "Udhwa", "Khichan", "Menar", "Udaypur Lake", "Gokul Reservoir",
            "Gogabeel", "Kopra Reservoir", "Siliserh", "Patna Bird", "Chhari", "Shekha", "Surha Tal", "Jai Prakash Narayan Bird", "Glaw Lake", "Brijghat", "Narora"};

    private static String ramsarRegex() {
        StringBuilder sb = new StringBuilder("^(");
        for (int i = 0; i < RAMSAR.length; i++) sb.append(i > 0 ? "|" : "").append(RAMSAR[i].replace(".", "\\\\."));
        return sb.append(")").toString();
    }

    private static boolean isRamsarName(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        for (String r : RAMSAR) if (l.startsWith(r.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    static String q1(double lat, double lon) {
        double d = 0.23, e = 0.25;   // about 25 km each way
        String b = String.format(Locale.US, "(%.4f,%.4f,%.4f,%.4f)", lat - d, lon - e, lat + d, lon + e);
        return "[out:json][timeout:50];(nwr[\"natural\"=\"wetland\"]" + b + ";nwr[\"natural\"=\"water\"][\"name\"]" + b + ";);out center tags 600;";
    }

    static String q2(double lat, double lon) {
        String re = ramsarRegex();
        String a = String.format(Locale.US, "(%.3f,%.3f,%.3f,%.3f)", lat - 2.0, lon - 2.0, lat + 2.0, lon + 2.0);   // about 220 km each way
        return "[out:json][timeout:60];(nwr[\"natural\"~\"^(wetland|water|bay)$\"][\"name\"~\"" + re + "\",i]" + a + ";nwr[\"leisure\"=\"nature_reserve\"][\"name\"~\"" + re + "\",i]" + a
                + ";nwr[\"boundary\"=\"protected_area\"][\"name\"~\"" + re + "\",i]" + a + ";);out center tags 200;";
    }

    private static String typeOf(org.json.JSONObject tg) {
        String n = tg.optString("natural", "");
        if (n.equals("wetland")) {
            String w = tg.optString("wetland", "");
            switch (w) {
                case "marsh": return "marsh"; case "swamp": return "swamp"; case "mangrove": return "mangrove"; case "tidalflat": return "tidal flat";
                case "reedbed": return "reedbed"; case "wet_meadow": return "wet meadow"; case "bog": return "bog"; case "fen": return "fen";
                case "saltmarsh": return "salt marsh"; default: return "wetland";
            }
        }
        String w = tg.optString("water", "");
        switch (w) {
            case "lake": return "lake"; case "pond": return "pond"; case "reservoir": return "reservoir"; case "lagoon": return "lagoon"; case "river": return "river";
            case "canal": return "canal"; default: return "water";
        }
    }

    private static double[] center(org.json.JSONObject e) {
        if (e.has("lat")) return new double[]{e.optDouble("lat"), e.optDouble("lon")};
        org.json.JSONObject c = e.optJSONObject("center");
        return c == null ? null : new double[]{c.optDouble("lat"), c.optDouble("lon")};
    }

    /** Parses both answers (json2 may be null) into wetland / marsh / ramsar for the point. */
    static void parse(String json1, String json2, double lat, double lon, long now) throws Exception {
        Hit nw = null, nm = null, nr = null;
        org.json.JSONArray el = new org.json.JSONObject(json1).getJSONArray("elements");
        for (int i = 0; i < el.length(); i++) {
            org.json.JSONObject e = el.getJSONObject(i);
            org.json.JSONObject tg = e.optJSONObject("tags");
            double[] c = center(e);
            if (tg == null || c == null || Double.isNaN(c[0])) continue;
            Hit h = new Hit();
            String nmv = tg.optString("name:en", tg.optString("name", "")).trim();
            h.type = typeOf(tg);
            h.name = nmv.isEmpty() ? "Unnamed " + h.type : nmv;
            h.unnamed = nmv.isEmpty();
            h.km = Beach.km(lat, lon, c[0], c[1]);
            h.dir = Beach.dir(lat, lon, c[0], c[1]);
            if (nw == null || h.km < nw.km) nw = h;
            boolean wet = "wetland".equals(tg.optString("natural", ""));
            if (wet && (nm == null || h.km < nm.km)) nm = h;
        }
        if (json2 != null) {
            org.json.JSONArray e2 = new org.json.JSONObject(json2).getJSONArray("elements");
            for (int i = 0; i < e2.length(); i++) {
                org.json.JSONObject e = e2.getJSONObject(i);
                org.json.JSONObject tg = e.optJSONObject("tags");
                double[] c = center(e);
                if (tg == null || c == null || Double.isNaN(c[0])) continue;
                String nmv = tg.optString("name:en", tg.optString("name", "")).trim();
                if (nmv.isEmpty() || !isRamsarName(nmv)) continue;
                Hit h = new Hit();
                h.name = nmv; h.type = "wetland"; h.ramsar = true;
                h.km = Beach.km(lat, lon, c[0], c[1]);
                h.dir = Beach.dir(lat, lon, c[0], c[1]);
                if (nr == null || h.km < nr.km) nr = h;
            }
        }
        wetland = nw; marsh = nm; ramsar = nr;
        at = new double[]{lat, lon};
        okAt = now;
        why = "ok: " + (nw == null ? "no wetland within 25 km" : nw.text()) + (nr == null ? "; no Ramsar site matched" : "; " + nr.text());
    }

    /** Full lookup (blocking, two Overpass requests; the Ramsar one may fail without losing the wetland answer). */
    static void lookup(double lat, double lon, long now) throws Exception {
        String j1 = Geo.overpass(q1(lat, lon), 40_000), j2 = null;
        try { j2 = Geo.overpass(q2(lat, lon), 60_000); } catch (Throwable t) { why = "Ramsar lookup failed: " + t.getClass().getSimpleName(); }
        parse(j1, j2, lat, lon, now);
    }

    static boolean due(double lat, double lon, long now) {
        if (now - triedAt < 15 * 60_000L) return false;
        double[] a = at;
        return a == null || now - okAt > 12 * 3600_000L || Beach.km(lat, lon, a[0], a[1]) > 5;
    }
}
