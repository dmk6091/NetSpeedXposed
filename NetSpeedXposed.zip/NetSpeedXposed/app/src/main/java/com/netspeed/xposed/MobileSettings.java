package com.netspeed.xposed;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Settings > Network & internet > SIM > (a SIM): makes these rows visible even when the ROM hides them:
 * Data roaming, CDMA "System select" and "CDMA subscription". Only the "is this row shown" answer is changed;
 * the rows themselves are the ROM's own and keep working as before.
 */
final class MobileSettings {
    private static final String TAG = "NetSpeedXposed: [mobilesettings] ";
    private static final String PKG = "com.android.settings.network.telephony.";
    private static final String[] ROWS = {
            "cdma.CdmaSystemSelectPreferenceController",
            "cdma.CdmaSubscriptionPreferenceController",
            "CdmaSystemSelectPreferenceController",
            "CdmaSubscriptionPreferenceController",
            "RoamingPreferenceController",
    };

    private MobileSettings() {}

    /** 0 = AVAILABLE: the row is shown. */
    private static final XC_MethodHook SHOW = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            p.setResult(0);
        }
    };

    static void install(ClassLoader cl) {
        for (String n : ROWS) {
            try {
                Class<?> k = XposedHelpers.findClassIfExists(PKG + n, cl);
                if (k == null) {
                    XposedBridge.log(TAG + n + " not found on this ROM");
                    continue;
                }
                int cnt = XposedBridge.hookAllMethods(k, "getAvailabilityStatus",
                        SHOW).size();
                XposedBridge.log(TAG + n + " shown (" + cnt + " hook)");
            } catch (Throwable t) {
                XposedBridge.log(TAG + n + " failed: " + t);
            }
        }
    }
}
