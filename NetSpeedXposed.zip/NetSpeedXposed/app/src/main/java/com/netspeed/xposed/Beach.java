package com.netspeed.xposed;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Named beaches near a place, from OpenStreetMap (live, cached a week per 0.1 degree cell). */
final class Beach {
    private Beach() {}

    static final class Hit { String name; double km, lat, lon; String dir; }

    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    static double km(double a1, double o1, double a2, double o2) {
        double p = Math.toRadians(a2 - a1), q = Math.toRadians(o2 - o1);
        double h = Math.sin(p / 2) * Math.sin(p / 2) + Math.cos(Math.toRadians(a1)) * Math.cos(Math.toRadians(a2)) * Math.sin(q / 2) * Math.sin(q / 2);
        return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(h)));
    }

    static String dir(double a1, double o1, double a2, double o2) {
        double y = Math.sin(Math.toRadians(o2 - o1)) * Math.cos(Math.toRadians(a2));
        double x = Math.cos(Math.toRadians(a1)) * Math.sin(Math.toRadians(a2)) - Math.sin(Math.toRadians(a1)) * Math.cos(Math.toRadians(a2)) * Math.cos(Math.toRadians(o2 - o1));
        double b = (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
        return DIRS[(int) Math.round(b / 45.0) % 8];
    }

    /** The n nearest named beaches within about 150 km (one entry per name); throws when the server can't be reached. */
    static List<Hit> nearest(android.content.Context c, double lat, double lon, int n) throws Exception {
        android.content.SharedPreferences sp = c.getSharedPreferences("beach", android.content.Context.MODE_PRIVATE);
        String key = String.format(Locale.US, "%.1f,%.1f", lat, lon);
        String json = sp.getString(key, null);
        if (json == null || System.currentTimeMillis() - sp.getLong(key + "@", 0) > 7 * 86400_000L) {
            String q = String.format(Locale.US, "[out:json][timeout:40];nwr[\"natural\"=\"beach\"][\"name\"](around:150000,%.4f,%.4f);out center tags;", lat, lon);
            try {
                json = Geo.get("https://overpass-api.de/api/interpreter?data=" + java.net.URLEncoder.encode(q, "UTF-8"), 45_000);
            } catch (Exception e) {
                if (json == null) throw e;   // an old copy is better than nothing
            }
            if (json != null && json.contains("elements")) sp.edit().putString(key, json).putLong(key + "@", System.currentTimeMillis()).apply();
        }
        org.json.JSONArray el = new org.json.JSONObject(json).getJSONArray("elements");
        java.util.Map<String, Hit> best = new java.util.HashMap<>();
        for (int i = 0; i < el.length(); i++) {
            org.json.JSONObject e = el.getJSONObject(i);
            double la = e.has("lat") ? e.getDouble("lat") : e.has("center") ? e.getJSONObject("center").getDouble("lat") : Double.NaN;
            double lo = e.has("lon") ? e.getDouble("lon") : e.has("center") ? e.getJSONObject("center").getDouble("lon") : Double.NaN;
            if (Double.isNaN(la)) continue;
            String nm = e.getJSONObject("tags").optString("name:en", e.getJSONObject("tags").optString("name", "")).trim();
            if (nm.isEmpty()) continue;
            double d = km(lat, lon, la, lo);
            Hit h = best.get(nm.toLowerCase(Locale.ROOT));
            if (h == null || d < h.km) {
                h = new Hit(); h.name = nm; h.km = d; h.lat = la; h.lon = lo; h.dir = dir(lat, lon, la, lo);
                best.put(nm.toLowerCase(Locale.ROOT), h);
            }
        }
        List<Hit> out = new ArrayList<>(best.values());
        java.util.Collections.sort(out, (a, b) -> Double.compare(a.km, b.km));
        return out.size() > n ? new ArrayList<>(out.subList(0, n)) : out;
    }
}
