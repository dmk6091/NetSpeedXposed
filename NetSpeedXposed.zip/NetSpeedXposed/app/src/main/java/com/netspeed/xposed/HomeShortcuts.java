package com.netspeed.xposed;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the shortcuts you placed on the home screen (needs root). The launcher keeps them in its
 * database; the shortcut service knows what each one starts. Blocking: call off the main thread.
 */
final class HomeShortcuts {

    static final class Item {
        String label;
        String pkg;
        String id;      // pinned shortcut id (null for an old-style shortcut)
        String uri;     // fallback intent (may be null)
        String detail;
    }

    private HomeShortcuts() { }

    private static final Pattern P_HEADER = Pattern.compile("^\\s*Package:\\s+([A-Za-z0-9_.]+)");
    private static final Pattern P_HEAD = Pattern.compile("ShortcutInfo \\{id=([^,}]+),\\s*flags=0x[0-9a-fA-F]+\\s*\\[([^\\]]*)\\]?");
    private static final Pattern P_PKG3 = Pattern.compile("^\\s*packageName=(\\S+)\\s*$");
    private static final Pattern P_PKG2 = Pattern.compile("\\bpkg=([A-Za-z0-9_.]+)");
    private static final Pattern P_PKG = Pattern.compile("packageName=([^,]+),");
    private static final Pattern P_ID = Pattern.compile("\\bid=([^\\s,}]+)");
    private static final Pattern P_SHORT = Pattern.compile("shortLabel=(.*?), resId=");
    private static final Pattern P_LONG = Pattern.compile("longLabel=(.*?), resId=");
    private static final Pattern P_FLAGS = Pattern.compile("flags=0x([0-9a-fA-F]+)\\s*(?:\\[([^\\]]*)\\])?");
    private static final Pattern P_INTENT = Pattern.compile("intents=\\[Intent \\{([^}]*)\\}");

    /** Why the list may be empty, for the dialog. */
    static String note = "";
    /** What was seen while reading, shown when nothing is found. */
    static String diag = "";

    static List<Item> read() {
        note = "";
        diag = "";
        int infoLines = 0;
        List<Item> guesses = new ArrayList<>();       // scan / qr / pay looking shortcuts of any app
        Map<String, String> uris = new HashMap<>();   // pkg/id -> intent from the shortcut service
        Map<String, String> labels = new HashMap<>();
        List<Item> pinned = new ArrayList<>();         // pinned according to the shortcut service
        try {
            String curPkg = null;
            Set<String> pinnedIds = new HashSet<>();
            List<String[]> entries = new ArrayList<>(); // pkg, id, label, uri, flagsPinned
            String eId = null, ePkg = null, eShort = null, eLong = null, eUri = null;
            boolean ePin = false;
            for (String l : (ScanFinder.suOut("dumpsys shortcut") + "\nShortcutInfo {id=END,").split("\n")) {
                Matcher mp = P_HEADER.matcher(l);
                if (mp.find()) curPkg = mp.group(1);
                int pi = l.indexOf("Pinned:");
                if (pi >= 0) {
                    for (String t : l.substring(pi + 7).trim().split("[\\s,\\[\\]]+")) {
                        if (!t.isEmpty()) pinnedIds.add(t);
                    }
                }
                Matcher mh = P_HEAD.matcher(l);
                if (mh.find()) { // a new shortcut starts: finish the previous one
                    if (eId != null && ePkg != null) {
                        infoLines++;
                        String lab = eLong != null && !eLong.equals("null") ? eLong
                                : eShort != null && !eShort.equals("null") ? eShort : eId;
                        lab = lab.trim();
                        String key = ePkg + "/" + eId;
                        labels.put(key, lab);
                        if (eUri != null) uris.put(key, eUri);
                        entries.add(new String[]{ePkg, eId, lab, eUri, ePin ? "1" : "0"});
                    }
                    eId = mh.group(1);
                    ePkg = null;
                    eShort = null;
                    eLong = null;
                    eUri = null;
                    String fl = mh.group(2);
                    ePin = fl != null && fl.toLowerCase().contains("pin");
                    continue;
                }
                if (eId == null) continue;
                String v = first(P_PKG, l);
                if (v == null) v = first(P_PKG3, l);
                if (v != null && ePkg == null) ePkg = v;
                v = first(P_SHORT, l);
                if (v != null && eShort == null) eShort = v;
                v = first(P_LONG, l);
                if (v != null && eLong == null) eLong = v;
                Matcher mi = P_INTENT.matcher(l);
                if (mi.find() && eUri == null) eUri = toUri(mi.group(1).trim(), ePkg != null ? ePkg : curPkg);
            }
            for (String[] e : entries) {
                String low = (e[2] + " " + e[1]).toLowerCase();
                if (low.contains("scan") || low.contains("qr") || low.contains("pay")) {
                    Item g = new Item();
                    g.pkg = e[0];
                    g.id = e[1];
                    g.label = e[2];
                    g.uri = e[3];
                    g.detail = "app shortcut (not sure it is on your home screen)";
                    guesses.add(g);
                }
                if ("1".equals(e[4]) || pinnedIds.contains(e[1])) {
                    Item it = new Item();
                    it.pkg = e[0];
                    it.id = e[1];
                    it.label = e[2];
                    it.uri = e[3];
                    it.detail = "pinned shortcut";
                    pinned.add(it);
                }
            }
            diag += "pinned ids in the dump: " + pinnedIds.size() + ", entries: " + entries.size() + "\n";
        } catch (Throwable t) {
            note = "root not available (" + t.getMessage() + ")";
            return new ArrayList<>();
        }

        List<Item> out = new ArrayList<>();
        boolean dbOk = false;
        try {
            String cmd = "for f in /data/data/*/databases/launcher*.db; do [ -f \"$f\" ] || continue; "
                    + "S=$(command -v sqlite3 || ls /system/bin/sqlite3 /system/xbin/sqlite3 /data/adb/*/bin/sqlite3 "
                    + "2>/dev/null | head -n1); [ -n \"$S\" ] || { echo NOSQLITE; break; }; "
                    + "echo \"DB $f\"; $S -separator '~~' \"$f\" "
                    + "\"select itemType,title,intent from favorites where itemType in (1,6)\" 2>&1; done";
            String txt = ScanFinder.suOut(cmd);
            int dbs = 0, rows = 0;
            String err = "";
            for (String l : txt.split("\n")) {
                if (l.startsWith("DB ")) dbs++;
                else if (l.contains("~~")) rows++;
                else if (!l.trim().isEmpty() && err.isEmpty()) err = l.trim();
            }
            diag += "launcher databases: " + dbs + ", shortcut rows: " + rows
                    + (err.isEmpty() ? "" : ", first message: " + ScanLaunch.shorten(err)) + "\n";
            if (txt.contains("NOSQLITE")) note = "no sqlite3 tool on the phone, using the system's list instead";
            for (String l : txt.split("\n")) {
                if (l.startsWith("DB ")) {
                    dbOk = true;
                    continue;
                }
                String[] f = l.split("~~", 3);
                if (f.length < 3) continue;
                Item it = new Item();
                it.label = f[1].trim();
                try {
                    Intent in = Intent.parseUri(f[2].trim(), 0);
                    String sid = in.getStringExtra("shortcut_id");
                    it.pkg = in.getPackage() != null ? in.getPackage()
                            : in.getComponent() != null ? in.getComponent().getPackageName() : null;
                    if ("6".equals(f[0].trim()) && sid != null) {
                        it.id = sid;
                        String key = it.pkg + "/" + sid;
                        it.uri = uris.get(key);
                        if (labels.get(key) != null && it.label.isEmpty()) it.label = labels.get(key);
                        it.detail = "shortcut on your home screen";
                    } else {
                        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        it.uri = in.toUri(Intent.URI_INTENT_SCHEME);
                        it.detail = "shortcut on your home screen (old style)";
                    }
                } catch (Throwable t) {
                    continue;
                }
                if (it.pkg == null || it.pkg.isEmpty()) continue;
                if (it.label.isEmpty()) it.label = it.id != null ? it.id : it.pkg;
                out.add(it);
            }
        } catch (Throwable t) {
            note = "couldn't read the launcher (" + t.getMessage() + ")";
        }
        try {
            diag += "root: " + ScanLaunch.shorten(ScanFinder.suOut("id")) + "\n";
            diag += "launcher folders: " + ScanLaunch.shorten(ScanFinder.suOut(
                    "ls -d /data/data/*aunch* /data/user_de/0/*aunch* 2>&1; "
                    + "ls /data/data/com.android.launcher3/databases 2>&1")) + "\n";
            diag += "shortcut dump: " + longer(ScanFinder.suOut(
                    "dumpsys shortcut > /data/local/tmp/ns_sc.txt 2>&1; wc -l < /data/local/tmp/ns_sc.txt; "
                    + "grep -n -m3 -B1 -A2 'id=scan_pay' /data/local/tmp/ns_sc.txt | cut -c1-420; "
                    + "rm -f /data/local/tmp/ns_sc.txt")) + "\n";
        } catch (Throwable t) {
            diag += "diag failed: " + t + "\n";
        }
        diag += "shortcut service lines: " + infoLines + ", pinned: " + pinned.size() + "\n";
        if (!dbOk || out.isEmpty()) {
            // Fall back to what the shortcut service says is pinned.
            for (Item p : pinned) {
                boolean dup = false;
                for (Item o : out) if (p.pkg.equals(o.pkg) && p.id.equals(o.id)) dup = true;
                if (!dup) out.add(p);
            }
        }
        if (out.isEmpty()) {
            out.addAll(guesses);
            if (!out.isEmpty()) note = "Couldn't tell which shortcuts are on the home screen, so these are all "
                    + "scan / QR / pay shortcuts the apps offer.";
        }
        return out;
    }

    private static String toUri(String body, String pkg) {
        String act = null, dat = null, cmp = null;
        for (String t : body.split("\\s+")) {
            if (t.startsWith("act=")) act = t.substring(4);
            else if (t.startsWith("dat=")) dat = t.substring(4);
            else if (t.startsWith("cmp=")) cmp = t.substring(4);
        }
        if (dat != null && dat.endsWith("/...")) return null; // cut short by Android: unusable
        if (act == null && dat == null && cmp == null) return null;
        Intent in = new Intent();
        if (act != null) in.setAction(act);
        if (dat != null) in.setData(Uri.parse(dat));
        ComponentName cn = cmp != null ? ComponentName.unflattenFromString(cmp) : null;
        if (cn != null) in.setComponent(cn);
        else in.setPackage(pkg);
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return in.toUri(Intent.URI_INTENT_SCHEME);
    }

    private static String longer(String s) {
        s = s.replace('\n', ' ').trim();
        return s.length() > 900 ? s.substring(0, 900) + "…" : s;
    }

    private static String first(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1).trim() : null;
    }
}
