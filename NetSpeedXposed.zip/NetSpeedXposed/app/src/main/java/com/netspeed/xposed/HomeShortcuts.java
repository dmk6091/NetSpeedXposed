package com.netspeed.xposed;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the shortcuts you placed on the home screen (needs root). The launcher keeps them in its
 * database; the shortcut service knows what each one starts. Blocking: call off the main thread.
 */
final class HomeShortcuts {

    static final class Item {
        String label;
        String pkg;
        String id;      // pinned shortcut id (null for an old-style shortcut)
        String uri;     // fallback intent (may be null)
        String detail;
    }

    private HomeShortcuts() { }

    private static final Pattern P_PKG = Pattern.compile("packageName=([^,]+),");
    private static final Pattern P_ID = Pattern.compile("\\bid=([^,]+),");
    private static final Pattern P_SHORT = Pattern.compile("shortLabel=(.*?), resId=");
    private static final Pattern P_LONG = Pattern.compile("longLabel=(.*?), disabledMessage=");
    private static final Pattern P_FLAGS = Pattern.compile("flags=0x([0-9a-fA-F]+)\\s*(?:\\[([^\\]]*)\\])?");
    private static final Pattern P_INTENT = Pattern.compile("intents=\\[Intent \\{([^}]*)\\}");

    /** Why the list may be empty, for the dialog. */
    static String note = "";
    /** What was seen while reading, shown when nothing is found. */
    static String diag = "";

    static List<Item> read() {
        note = "";
        diag = "";
        int infoLines = 0;
        List<Item> guesses = new ArrayList<>();       // scan / qr / pay looking shortcuts of any app
        Map<String, String> uris = new HashMap<>();   // pkg/id -> intent from the shortcut service
        Map<String, String> labels = new HashMap<>();
        List<Item> pinned = new ArrayList<>();         // pinned according to the shortcut service
        try {
            for (String l : ScanFinder.suOut("dumpsys shortcut").split("\n")) {
                if (!l.contains("ShortcutInfo") || !l.contains("packageName=")) continue;
                String pkg = first(P_PKG, l), id = first(P_ID, l);
                if (pkg == null || id == null) continue;
                infoLines++;
                String key = pkg + "/" + id;
                String lab = first(P_LONG, l);
                if (lab == null || lab.equals("null")) lab = first(P_SHORT, l);
                if (lab == null || lab.equals("null")) lab = id;
                labels.put(key, lab);
                Matcher mi = P_INTENT.matcher(l);
                if (mi.find()) {
                    String u = toUri(mi.group(1).trim(), pkg);
                    if (u != null) uris.put(key, u);
                }
                String low = (lab + " " + id).toLowerCase();
                if (low.contains("scan") || low.contains("qr") || low.contains("pay")) {
                    Item g = new Item();
                    g.pkg = pkg;
                    g.id = id;
                    g.label = lab;
                    g.uri = uris.get(key);
                    g.detail = "app shortcut (not sure it is on your home screen)";
                    guesses.add(g);
                }
                Matcher mf = P_FLAGS.matcher(l);
                if (mf.find()) {
                    boolean pin = mf.group(2) != null && mf.group(2).toLowerCase().contains("pin");
                    try {
                        if ((Long.parseLong(mf.group(1), 16) & (1L << 10)) != 0) pin = true;
                    } catch (NumberFormatException ignored) { }
                    if (pin) {
                        Item it = new Item();
                        it.pkg = pkg;
                        it.id = id;
                        it.label = lab;
                        it.uri = uris.get(key);
                        it.detail = "pinned shortcut";
                        pinned.add(it);
                    }
                }
            }
        } catch (Throwable t) {
            note = "root not available (" + t.getMessage() + ")";
            return new ArrayList<>();
        }

        List<Item> out = new ArrayList<>();
        boolean dbOk = false;
        try {
            String cmd = "for f in /data/data/*/databases/launcher*.db; do [ -f \"$f\" ] || continue; "
                    + "S=$(command -v sqlite3 || ls /system/bin/sqlite3 /system/xbin/sqlite3 /data/adb/*/bin/sqlite3 "
                    + "2>/dev/null | head -n1); [ -n \"$S\" ] || { echo NOSQLITE; break; }; "
                    + "echo \"DB $f\"; $S -separator '~~' \"$f\" "
                    + "\"select itemType,title,intent from favorites where itemType in (1,6)\" 2>&1; done";
            String txt = ScanFinder.suOut(cmd);
            int dbs = 0, rows = 0;
            String err = "";
            for (String l : txt.split("\n")) {
                if (l.startsWith("DB ")) dbs++;
                else if (l.contains("~~")) rows++;
                else if (!l.trim().isEmpty() && err.isEmpty()) err = l.trim();
            }
            diag += "launcher databases: " + dbs + ", shortcut rows: " + rows
                    + (err.isEmpty() ? "" : ", first message: " + ScanLaunch.shorten(err)) + "\n";
            if (txt.contains("NOSQLITE")) note = "no sqlite3 tool on the phone, using the system's list instead";
            for (String l : txt.split("\n")) {
                if (l.startsWith("DB ")) {
                    dbOk = true;
                    continue;
                }
                String[] f = l.split("~~", 3);
                if (f.length < 3) continue;
                Item it = new Item();
                it.label = f[1].trim();
                try {
                    Intent in = Intent.parseUri(f[2].trim(), 0);
                    String sid = in.getStringExtra("shortcut_id");
                    it.pkg = in.getPackage() != null ? in.getPackage()
                            : in.getComponent() != null ? in.getComponent().getPackageName() : null;
                    if ("6".equals(f[0].trim()) && sid != null) {
                        it.id = sid;
                        String key = it.pkg + "/" + sid;
                        it.uri = uris.get(key);
                        if (labels.get(key) != null && it.label.isEmpty()) it.label = labels.get(key);
                        it.detail = "shortcut on your home screen";
                    } else {
                        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        it.uri = in.toUri(Intent.URI_INTENT_SCHEME);
                        it.detail = "shortcut on your home screen (old style)";
                    }
                } catch (Throwable t) {
                    continue;
                }
                if (it.pkg == null || it.pkg.isEmpty()) continue;
                if (it.label.isEmpty()) it.label = it.id != null ? it.id : it.pkg;
                out.add(it);
            }
        } catch (Throwable t) {
            note = "couldn't read the launcher (" + t.getMessage() + ")";
        }
        try {
            diag += "root: " + ScanLaunch.shorten(ScanFinder.suOut("id")) + "\n";
            diag += "launcher folders: " + ScanLaunch.shorten(ScanFinder.suOut(
                    "ls -d /data/data/*aunch* /data/user_de/0/*aunch* 2>&1; "
                    + "ls /data/data/com.android.launcher3/databases 2>&1")) + "\n";
            diag += "shortcut dump: " + ScanLaunch.shorten(ScanFinder.suOut(
                    "dumpsys shortcut > /data/local/tmp/ns_sc.txt 2>&1; wc -l < /data/local/tmp/ns_sc.txt; "
                    + "grep -i -m4 'scan' /data/local/tmp/ns_sc.txt | cut -c1-260; "
                    + "rm -f /data/local/tmp/ns_sc.txt")) + "\n";
        } catch (Throwable t) {
            diag += "diag failed: " + t + "\n";
        }
        diag += "shortcut service lines: " + infoLines + ", pinned: " + pinned.size() + "\n";
        if (!dbOk || out.isEmpty()) {
            // Fall back to what the shortcut service says is pinned.
            for (Item p : pinned) {
                boolean dup = false;
                for (Item o : out) if (p.pkg.equals(o.pkg) && p.id.equals(o.id)) dup = true;
                if (!dup) out.add(p);
            }
        }
        if (out.isEmpty()) {
            out.addAll(guesses);
            if (!out.isEmpty()) note = "Couldn't tell which shortcuts are on the home screen, so these are all "
                    + "scan / QR / pay shortcuts the apps offer.";
        }
        return out;
    }

    private static String toUri(String body, String pkg) {
        String act = null, dat = null, cmp = null;
        for (String t : body.split("\\s+")) {
            if (t.startsWith("act=")) act = t.substring(4);
            else if (t.startsWith("dat=")) dat = t.substring(4);
            else if (t.startsWith("cmp=")) cmp = t.substring(4);
        }
        if (dat != null && dat.endsWith("/...")) return null; // cut short by Android: unusable
        if (act == null && dat == null && cmp == null) return null;
        Intent in = new Intent();
        if (act != null) in.setAction(act);
        if (dat != null) in.setData(Uri.parse(dat));
        ComponentName cn = cmp != null ? ComponentName.unflattenFromString(cmp) : null;
        if (cn != null) in.setComponent(cn);
        else in.setPackage(pkg);
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return in.toUri(Intent.URI_INTENT_SCHEME);
    }

    private static String first(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1).trim() : null;
    }
}
