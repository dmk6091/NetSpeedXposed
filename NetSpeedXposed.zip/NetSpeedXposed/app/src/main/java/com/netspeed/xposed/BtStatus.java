package com.netspeed.xposed;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * What System UI's back-tap service has been doing, for the settings screen. System UI reports to
 * the app through {@link SettingsProvider#call}; the app keeps the last few lines here.
 */
final class BtStatus {
    private static final String PREFS = "backtap_status";

    private BtStatus() { }

    private static SharedPreferences prefs(Context c) {
        return c.createDeviceProtectedStorageContext().getSharedPreferences(PREFS, 0);
    }

    private static String now() {
        return new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
    }

    /** An event line (double tap seen, launch result ...). Keeps the last 12. */
    static synchronized void add(Context c, String msg) {
        SharedPreferences sp = prefs(c);
        String old = sp.getString("events", "");
        String[] arr = old.isEmpty() ? new String[0] : old.split("\n");
        StringBuilder b = new StringBuilder();
        for (int i = Math.max(0, arr.length - 11); i < arr.length; i++) b.append(arr[i]).append('\n');
        b.append(now()).append("  ").append(msg.replace('\n', ' '));
        sp.edit().putString("events", b.toString()).commit();
    }

    /** The latest "listening" report of System UI. */
    static synchronized void listening(Context c, String msg) {
        prefs(c).edit().putString("listen", now() + "  " + msg.replace('\n', ' ')).commit();
    }

    static synchronized String read(Context c) {
        SharedPreferences sp = prefs(c);
        String l = sp.getString("listen", "");
        String e = sp.getString("events", "");
        if (l.isEmpty() && e.isEmpty()) {
            return "System UI hasn't reported yet. Turn the gesture on, restart System UI, then lock and unlock the phone.";
        }
        return "Listening: " + (l.isEmpty() ? "no report yet" : l) + (e.isEmpty() ? "" : "\n\n" + e);
    }
}
