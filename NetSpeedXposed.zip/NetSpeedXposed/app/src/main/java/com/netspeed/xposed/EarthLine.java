package com.netspeed.xposed;

import java.util.Locale;

/**
 * Extra earth-science facts for the rotating place line: rain and soil, slope and nearest peak, nearest dam,
 * last quake, ground temperature and district. Worker thread; every lookup is cached and failures leave the old text.
 * The status bar reads the strings and skips any that are empty.
 */
final class EarthLine {
    private EarthLine() {}

    static volatile String rain = "", peak = "", slope = "", dam = "", quake = "", ground = "", district = "";
    static volatile float dew = Float.NaN;
    static volatile String why = "not fetched yet";
    private static String key = "";
    private static long okAt, triedAt;
    private static String quakeKey = "";
    private static long quakeAt;

    static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    static String dir(double fromLat, double fromLon, double toLat, double toLon) {
        double y = Math.sin(Math.toRadians(toLon - fromLon)) * Math.cos(Math.toRadians(toLat));
        double x = Math.cos(Math.toRadians(fromLat)) * Math.sin(Math.toRadians(toLat))
                - Math.sin(Math.toRadians(fromLat)) * Math.cos(Math.toRadians(toLat)) * Math.cos(Math.toRadians(toLon - fromLon));
        double b = (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
        return DIRS[(int) Math.round(b / 45) % 8];
    }

    static double km(double la1, double lo1, double la2, double lo2) {
        double dx = (lo2 - lo1) * 111.32 * Math.cos(Math.toRadians((la1 + la2) / 2)), dy = (la2 - la1) * 110.54;
        return Math.sqrt(dx * dx + dy * dy);
    }

    static String dist(double km) {
        return km < 1 ? (Math.round(km * 100) * 10) + "m" : km < 10 ? String.format(Locale.US, "%.1fkm", km) : Math.round(km) + "km";
    }

    /** Sun's height above the horizon in degrees (negative = below), simple solar-position formula. */
    static double sunElevation(double lat, double lon, long ms) {
        double d = ms / 86400000.0 + 2440587.5 - 2451545.0;
        double g = Math.toRadians((357.529 + 0.98560028 * d) % 360);
        double q = (280.459 + 0.98564736 * d) % 360;
        double L = Math.toRadians((q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) % 360);
        double e = Math.toRadians(23.439 - 0.00000036 * d);
        double ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L));
        double dec = Math.asin(Math.sin(e) * Math.sin(L));
        double gmst = (280.46061837 + 360.98564736629 * d) % 360;
        double ha = Math.toRadians(gmst + lon) - ra;
        double la = Math.toRadians(lat);
        return Math.toDegrees(Math.asin(Math.sin(la) * Math.sin(dec) + Math.cos(la) * Math.cos(dec) * Math.cos(ha)));
    }

    static String overpass(String q) {
        for (String ep : new String[]{"https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter",
                "https://overpass.kumi.systems/api/interpreter", "https://maps.mail.ru/osm/tools/overpass/api/interpreter"}) {
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(ep + "?data="
                        + java.net.URLEncoder.encode(q, "UTF-8")).openConnection();
                c.setConnectTimeout(8_000);
                c.setReadTimeout(28_000);
                c.setRequestProperty("User-Agent", "NetSpeedXposed/1.0 (status bar module; github.com/dmk6091/NetSpeedXposed)");
                if (c.getResponseCode() != 200) continue;
                StringBuilder sb = new StringBuilder();
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
                    String ln;
                    while ((ln = r.readLine()) != null) sb.append(ln);
                }
                if (sb.length() > 0) return sb.toString();
            } catch (Throwable ignored) { }
        }
        return "";
    }

    private static String num(double v) { return String.format(Locale.US, "%,d", Math.round(v)); }

    static void tick(Hazards.Http http, double lat, double lon, boolean wantRain, boolean wantLand, boolean wantQuake,
                     boolean wantEarth, boolean wantDam) {
        long now = System.currentTimeMillis();
        String k = String.format(Locale.US, "%.2f,%.2f", lat, lon);
        boolean same = k.equals(key);
        if (same && now - okAt < 30 * 60_000L) return;
        if (now - triedAt < 5 * 60_000L) return;
        triedAt = now;
        String w = "";
        // rain, soil, ground temperature, dew point: one Open-Meteo call
        if (wantRain || wantEarth) try {
            org.json.JSONObject h = new org.json.JSONObject(http.get(String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                            + "&hourly=precipitation,soil_moisture_0_to_7cm,soil_temperature_0cm,dew_point_2m&past_hours=24&forecast_hours=25&timezone=auto",
                    lat, lon))).getJSONObject("hourly");
            org.json.JSONArray pr = h.getJSONArray("precipitation");
            int n = pr.length(), nowI = Math.min(24, n - 1);
            double past = 0, next = 0;
            for (int i = 0; i < n; i++) if (!pr.isNull(i)) { if (i <= nowI) past += pr.getDouble(i); else next += pr.getDouble(i); }
            org.json.JSONArray sm = h.optJSONArray("soil_moisture_0_to_7cm");
            String soil = sm != null && nowI < sm.length() && !sm.isNull(nowI) ? " · soil " + Math.round(sm.getDouble(nowI) * 100) + "%" : "";
            rain = "🌧 24h " + fmtMm(past) + " · next 24h " + fmtMm(next) + soil;
            org.json.JSONArray st = h.optJSONArray("soil_temperature_0cm");
            ground = st != null && nowI < st.length() && !st.isNull(nowI) ? "ground " + Math.round(st.getDouble(nowI)) + "°" : "";
            org.json.JSONArray dw = h.optJSONArray("dew_point_2m");
            dew = dw != null && nowI < dw.length() && !dw.isNull(nowI) ? (float) dw.getDouble(nowI) : Float.NaN;
            w += "rain ok; ";
        } catch (Throwable t) { w += "rain " + t.getClass().getSimpleName() + "; "; }
        // slope from three ground heights 200 m apart, nearest named peak within 30 km
        if (wantLand) {
            try {
                String r = overpass(String.format(Locale.US, "[out:json][timeout:25];node(around:30000,%.5f,%.5f)[\"natural\"=\"peak\"][\"name\"];out 40;", lat, lon));
                org.json.JSONArray els = r.isEmpty() ? null : new org.json.JSONObject(r).optJSONArray("elements");
                String best = "";
                double bd = 1e9;
                for (int i = 0; els != null && i < els.length(); i++) {
                    org.json.JSONObject e = els.getJSONObject(i);
                    double d = km(lat, lon, e.getDouble("lat"), e.getDouble("lon"));
                    if (d < bd) {
                        bd = d;
                        org.json.JSONObject tg = e.optJSONObject("tags");
                        String nm = tg == null ? "" : tg.optString("name:en", tg.optString("name", ""));
                        String ele = tg == null ? "" : tg.optString("ele", "");
                        double ev = 0;
                        try { ev = Double.parseDouble(ele.replaceAll("[^0-9.]", "")); } catch (Throwable ignored) { }
                        best = nm.isEmpty() || nm.length() > 24 ? "" : "⛰ " + nm + " " + dist(d) + " " + dir(lat, lon, e.getDouble("lat"), e.getDouble("lon"))
                                + (ev > 0 ? " " + num(ev) + "m" : "");
                    }
                }
                if (els != null) peak = best;
                w += (els == null ? "peak lookup failed; " : els.length() + " peaks; ");
            } catch (Throwable t) { w += "peak " + t.getClass().getSimpleName() + "; "; }
        }
        // nearest dam within 10 km
        if (wantDam) try {
            String r = overpass(String.format(Locale.US, "[out:json][timeout:25];(way(around:10000,%1$.5f,%2$.5f)[\"waterway\"=\"dam\"];"
                    + "way(around:10000,%1$.5f,%2$.5f)[\"man_made\"=\"dam\"];node(around:10000,%1$.5f,%2$.5f)[\"waterway\"=\"dam\"];);out center tags 30;", lat, lon));
            org.json.JSONArray els = r.isEmpty() ? null : new org.json.JSONObject(r).optJSONArray("elements");
            String best = "";
            double bd = 1e9;
            for (int i = 0; els != null && i < els.length(); i++) {
                org.json.JSONObject e = els.getJSONObject(i);
                org.json.JSONObject ce = e.optJSONObject("center");
                double la = ce != null ? ce.getDouble("lat") : e.optDouble("lat", Double.NaN), lo = ce != null ? ce.getDouble("lon") : e.optDouble("lon", Double.NaN);
                if (Double.isNaN(la)) continue;
                double d = km(lat, lon, la, lo);
                org.json.JSONObject tg = e.optJSONObject("tags");
                String nm = tg == null ? "" : tg.optString("name:en", tg.optString("name", ""));
                if (nm.length() > 26) nm = "";
                double sc = d - (nm.isEmpty() ? 0 : 2);
                if (sc < bd) {
                    bd = sc;
                    nm = nm.replaceAll("(?i)\\s+(dam|barrage)$", "").trim();
                    best = "🏞 " + (nm.isEmpty() ? "Dam" : nm + " Dam") + " " + dist(d) + " " + dir(lat, lon, la, lo);
                }
            }
            if (els != null) dam = best;
            w += (els == null ? "dam lookup failed; " : els.length() + " dams; ");
        } catch (Throwable t) { w += "dam " + t.getClass().getSimpleName() + "; "; }
        // last quake within 300 km, 30 days (USGS)
        if (wantQuake && (!k.equals(quakeKey) || now - quakeAt > 30 * 60_000L)) try {
            String from = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date(now - 30L * 86400_000L));
            org.json.JSONArray fs = new org.json.JSONObject(http.get(String.format(Locale.US,
                    "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=%.3f&longitude=%.3f&maxradiuskm=300"
                            + "&minmagnitude=2.5&limit=1&orderby=time&starttime=%s", lat, lon, from))).getJSONArray("features");
            if (fs.length() == 0) quake = "no quake M2.5+ within 300km in 30 days";
            else {
                org.json.JSONObject f = fs.getJSONObject(0);
                org.json.JSONArray co = f.getJSONObject("geometry").getJSONArray("coordinates");
                double la = co.getDouble(1), lo = co.getDouble(0);
                long age = (now - f.getJSONObject("properties").getLong("time")) / 3600_000L;
                quake = String.format(Locale.US, "last quake M%.1f %s %s · %s ago", f.getJSONObject("properties").optDouble("mag", 0),
                        dist(km(lat, lon, la, lo)), dir(lat, lon, la, lo), age < 48 ? age + "h" : (age / 24) + "d");
            }
            quakeKey = k;
            quakeAt = now;
            w += "quake ok; ";
        } catch (Throwable t) { w += "quake " + t.getClass().getSimpleName() + "; "; }
        // district / taluka name
        if (wantEarth) try {
            org.json.JSONObject a = new org.json.JSONObject(http.get(String.format(Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=en&lat=%.4f&lon=%.4f", lat, lon))).optJSONObject("address");
            String d = a == null ? "" : a.optString("county", a.optString("state_district", a.optString("city", "")));
            district = d.replaceAll("(?i)\\s+district$", "") + (d.isEmpty() ? "" : " dist.");
            w += "district " + (district.isEmpty() ? "none" : "ok") + "; ";
        } catch (Throwable t) { w += "district " + t.getClass().getSimpleName() + "; "; }
        key = k;
        okAt = now;
        why = w;
    }

    private static String fmtMm(double mm) { return mm < 0.1 ? "0mm" : mm < 10 ? String.format(Locale.US, "%.1fmm", mm) : Math.round(mm) + "mm"; }
}
