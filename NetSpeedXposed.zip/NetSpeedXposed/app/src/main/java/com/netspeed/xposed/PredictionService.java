package com.netspeed.xposed;

import android.app.prediction.AppPredictionContext;
import android.app.prediction.AppPredictionSessionId;
import android.app.prediction.AppTarget;
import android.app.prediction.AppTargetEvent;
import android.app.prediction.AppTargetId;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.CancellationSignal;
import android.os.Process;
import android.service.appprediction.AppPredictionService;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * App suggestions for the launcher (Pixel-style "Suggestions"): the launcher opens sessions
 * ("hotseat" = empty dock slots, "home" = the row at the top of the app drawer) and we answer
 * with a ranked list of apps. Ranking uses this phone's own usage history only.
 *
 * Build A: simple ranking (time used in the last 7 days + a boost for recently used apps).
 */
public class PredictionService extends AppPredictionService {
    static final String TAG = "NetSpeedPredict";
    static final String STATUS_PREFS = "predict_status";

    private final Map<AppPredictionSessionId, AppPredictionContext> sessions = new ConcurrentHashMap<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    /** Backup trigger: every 2 s, if an app went to the background, refresh the suggestions. */
    private final java.util.concurrent.ScheduledExecutorService ticker =
            Executors.newSingleThreadScheduledExecutor();
    private long lastCheck = System.currentTimeMillis();
    private long lastBeat = 0;

    private void watchApps() {
        ticker.scheduleWithFixedDelay(() -> {
            try {
                if (sessions.isEmpty()) {
                    long n0 = System.currentTimeMillis();
                    if (n0 - lastBeat > 60_000) {
                        lastBeat = n0;
                        status("alive", now() + " (no launcher session)");
                    }
                    return;
                }
                UsageStatsManager usm = getSystemService(UsageStatsManager.class);
                long now = System.currentTimeMillis();
                android.app.usage.UsageEvents ev = usm.queryEvents(lastCheck, now);
                lastCheck = now;
                android.app.usage.UsageEvents.Event e = new android.app.usage.UsageEvents.Event();
                boolean changed = false;
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e);
                    if (e.getEventType() == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED) changed = true;
                }
                if (changed) exec.execute(this::pushAll);
                // Heartbeat in the settings status: shows the service is awake (not frozen).
                if (now - lastBeat > 60_000) {
                    lastBeat = now;
                    status("alive", now());
                }
            } catch (Throwable ignored) { }
        }, 2, 2, java.util.concurrent.TimeUnit.SECONDS);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        watchApps();
        status("service", "started " + now());
        Log.i(TAG, "prediction service started");
    }

    @Override
    public void onCreatePredictionSession(AppPredictionContext context, AppPredictionSessionId id) {
        sessions.put(id, context);
        String s = context.getUiSurface() + " (" + context.getPredictedTargetCount() + " apps) for "
                + context.getPackageName();
        Log.i(TAG, "session opened: " + s);
        status("session_" + context.getUiSurface(), s + " at " + now());
    }

    @Override
    public void onRequestPredictionUpdate(AppPredictionSessionId id) {
        // The launcher only asks again for the app drawer row when you come back home; the dock
        // only changes when we push. So any request refreshes every surface.
        exec.execute(this::pushAll);
    }

    private long lastPushAll = 0;

    private void pushAll() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastPushAll < 300) return;
        lastPushAll = now;
        for (AppPredictionSessionId s : sessions.keySet()) push(s);
    }

    @Override
    public void onStartPredictionUpdates() {
        exec.execute(() -> {
            for (AppPredictionSessionId id : sessions.keySet()) push(id);
        });
    }

    @Override
    public void onAppTargetEvent(AppPredictionSessionId id, AppTargetEvent event) {
        try {
            AppTarget t = event.getTarget();
            Log.i(TAG, "event " + event.getAction() + " " + (t != null ? t.getPackageName() : "?")
                    + " at " + event.getLaunchLocation());
        } catch (Throwable ignored) { }
        // Something was launched: refresh every surface so the next time home shows, it's current.
        exec.execute(() -> {
            for (AppPredictionSessionId s : sessions.keySet()) push(s);
        });
    }

    @Override
    public void onLaunchLocationShown(AppPredictionSessionId id, String launchLocation, List<AppTargetId> ids) {
    }

    @Override
    public void onSortAppTargets(AppPredictionSessionId id, List<AppTarget> targets,
            CancellationSignal cancel, Consumer<List<AppTarget>> callback) {
        exec.execute(() -> {
            Map<String, Double> score = scores();
            List<AppTarget> sorted = new ArrayList<>(targets);
            sorted.sort((a, b) -> Double.compare(
                    score.getOrDefault(b.getPackageName(), 0d), score.getOrDefault(a.getPackageName(), 0d)));
            callback.accept(sorted);
        });
    }

    @Override
    public void onDestroyPredictionSession(AppPredictionSessionId id) {
        sessions.remove(id);
    }

    // ------------------------------------------------------------ ranking

    private void push(AppPredictionSessionId id) {
        AppPredictionContext ctx = sessions.get(id);
        if (ctx == null) return;
        String surface = String.valueOf(ctx.getUiSurface());
        List<AppTarget> out = new ArrayList<>();
        try {
            // Only app surfaces; the launcher also asks for widget suggestions, which we don't do.
            if (surface.equals("hotseat") || surface.equals("home")) {
                int n = Math.max(1, ctx.getPredictedTargetCount());
                // A few extra, so apps already pinned in the dock can be skipped by the launcher.
                List<String[]> apps = ranked(n + 6);
                int rank = 0;
                StringBuilder names = new StringBuilder();
                for (String[] a : apps) {
                    out.add(new AppTarget.Builder(new AppTargetId("app:" + a[0] + "/" + a[1]), a[0],
                            Process.myUserHandle()).setClassName(a[1]).setRank(rank++).build());
                    if (names.length() > 0) names.append(", ");
                    names.append(a[0]);
                }
                status("last_" + surface, now() + ": " + names);
                Log.i(TAG, surface + " -> " + names);
            }
            updatePredictions(id, out);
        } catch (Throwable t) {
            Log.w(TAG, "prediction failed", t);
            status("error", now() + ": " + t);
        }
    }

    /** Launchable apps, best first: {package, activity class}. */
    private List<String[]> ranked(int max) {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Map<String, String> launchable = new LinkedHashMap<>();
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            launchable.putIfAbsent(pkg, ri.activityInfo.name);
        }
        Map<String, Double> score = scores();
        List<String> pkgs = new ArrayList<>(launchable.keySet());
        if (score.isEmpty()) {
            // No usage access yet: alphabetical, so at least something shows.
            Collections.sort(pkgs);
        } else {
            pkgs.sort((a, b) -> Double.compare(score.getOrDefault(b, 0d), score.getOrDefault(a, 0d)));
        }
        List<String[]> out = new ArrayList<>();
        for (String p : pkgs) {
            if (out.size() >= max) break;
            out.add(new String[]{p, launchable.get(p)});
        }
        return out;
    }

    /**
     * Usage score per package. Apps you closed in the last 30 minutes come first, most recent
     * first (so an app you just left shows up in the dock); after them, minutes used in 7 days.
     */
    private Map<String, Double> scores() {
        Map<String, Double> m = new HashMap<>();
        try {
            UsageStatsManager usm = getSystemService(UsageStatsManager.class);
            long now = System.currentTimeMillis();
            // Precise "last left" times from the event log of the last 30 minutes.
            Map<String, Long> left = new HashMap<>();
            try {
                android.app.usage.UsageEvents ev = usm.queryEvents(now - 30 * 60_000L, now);
                android.app.usage.UsageEvents.Event e = new android.app.usage.UsageEvents.Event();
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e);
                    int t = e.getEventType();
                    if (t == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED
                            || t == android.app.usage.UsageEvents.Event.ACTIVITY_STOPPED
                            || t == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                        left.merge(e.getPackageName(), e.getTimeStamp(), Math::max);
                    }
                }
            } catch (Throwable ignored) { }
            for (Map.Entry<String, Long> e : left.entrySet()) {
                double agoMin = (now - e.getValue()) / 60_000d;
                m.put(e.getKey(), 10_000 + (30 - Math.min(30, agoMin)) * 100);
            }
            Map<String, UsageStats> all = usm.queryAndAggregateUsageStats(now - 7L * 24 * 3600_000, now);
            for (Map.Entry<String, UsageStats> e : all.entrySet()) {
                UsageStats u = e.getValue();
                double s = u.getTotalTimeInForeground() / 60_000d;
                long ago = now - u.getLastTimeUsed();
                if (ago < 6 * 3600_000) s += 10;
                if (s > 0) m.merge(e.getKey(), s, Double::sum);
            }
            if (m.isEmpty()) status("usage", "no usage history readable (usage access not granted?)");
            else status("usage", m.size() + " apps with history");
        } catch (Throwable t) {
            status("usage", "can't read usage: " + t);
        }
        return m;
    }

    // ------------------------------------------------------------ status (shown in settings)

    private void status(String key, String value) {
        try {
            SharedPreferences sp = createDeviceProtectedStorageContext().getSharedPreferences(STATUS_PREFS, 0);
            sp.edit().putString(key, value).apply();
        } catch (Throwable ignored) { }
    }

    private static String now() {
        return new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
    }
}
