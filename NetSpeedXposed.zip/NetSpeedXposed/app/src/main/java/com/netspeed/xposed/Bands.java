package com.netspeed.xposed;

import android.content.Context;
import android.telephony.CellIdentity;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityNr;
import android.telephony.CellInfo;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoNr;
import android.telephony.NetworkRegistrationInfo;
import android.telephony.ServiceState;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.robv.android.xposed.XposedBridge;

/**
 * Which band each SIM is on right now ("B3", "n78"), read inside System UI.
 * Only the main (serving) cell's band is reported; for 4G+ that is the primary band.
 */
final class Bands {
    private static final String TAG = "NetSpeedXposed: [band] ";
    private static boolean sLoggedError = false;

    /** One SIM: its slot number (1 or 2) and band label, or null if unknown. */
    static final class Sim {
        final int slot;
        final String band;

        Sim(int slot, String band) {
            this.slot = slot;
            this.band = band;
        }
    }

    private Bands() {}

    /** Active SIMs in slot order, each with its band (null when not known). */
    static List<Sim> read(Context ctx) {
        List<Sim> out = new ArrayList<>();
        try {
            SubscriptionManager sm = ctx.getSystemService(SubscriptionManager.class);
            TelephonyManager base = ctx.getSystemService(TelephonyManager.class);
            if (sm == null || base == null) return out;
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs == null) return out;
            List<SubscriptionInfo> sorted = new ArrayList<>(subs);
            Collections.sort(sorted, (a, b) -> a.getSimSlotIndex() - b.getSimSlotIndex());
            for (SubscriptionInfo si : sorted) {
                String band = null;
                try {
                    TelephonyManager tm = base.createForSubscriptionId(si.getSubscriptionId());
                    // 1) This SIM's own registration (data first, then voice).
                    band = fromServiceState(tm.getServiceState());
                    // 2) Cell list (covers all SIMs): only cells of this SIM's operator.
                    if (band == null) band = fromCells(tm.getAllCellInfo(), si);
                } catch (Throwable t) {
                    if (!sLoggedError) {
                        sLoggedError = true;
                        XposedBridge.log(TAG + "reading cells failed: " + t);
                    }
                }
                out.add(new Sim(si.getSimSlotIndex() + 1, band));
            }
        } catch (Throwable t) {
            if (!sLoggedError) {
                sLoggedError = true;
                XposedBridge.log(TAG + "reading SIMs failed: " + t);
            }
        }
        return out;
    }

    /** Serving cell from this SIM's registration info: data first, then voice. */
    static String fromServiceState(android.telephony.ServiceState ss) {
        if (ss == null) return null;
        for (int domain : new int[]{android.telephony.NetworkRegistrationInfo.DOMAIN_PS,
                android.telephony.NetworkRegistrationInfo.DOMAIN_CS}) {
            for (android.telephony.NetworkRegistrationInfo nri : ss.getNetworkRegistrationInfoList()) {
                if (nri.getTransportType() != android.telephony.AccessNetworkConstants.TRANSPORT_TYPE_WWAN) continue;
                if ((nri.getDomain() & domain) == 0 || !nri.isRegistered()) continue;
                android.telephony.CellIdentity id = nri.getCellIdentity();
                String b = id instanceof CellIdentityNr ? nrBand((CellIdentityNr) id)
                        : id instanceof CellIdentityLte ? lteBand((CellIdentityLte) id) : null;
                if (b != null) return b;
            }
        }
        return null;
    }

    /** Serving cell from the combined cell list, matched to this SIM by operator code. */
    static String fromCells(List<CellInfo> cells, SubscriptionInfo si) {
        if (cells == null) return null;
        String mcc = si.getMccString(), mnc = si.getMncString();
        for (int pass = 0; pass < 2; pass++) {
            for (CellInfo ci : cells) {
                if (!ci.isRegistered()) continue;
                if (pass == 0 && ci instanceof CellInfoNr) {
                    CellIdentityNr id = (CellIdentityNr) ((CellInfoNr) ci).getCellIdentity();
                    if (sameOperator(id.getMccString(), id.getMncString(), mcc, mnc)) {
                        String b = nrBand(id);
                        if (b != null) return b;
                    }
                } else if (pass == 1 && ci instanceof CellInfoLte) {
                    CellIdentityLte id = ((CellInfoLte) ci).getCellIdentity();
                    if (sameOperator(id.getMccString(), id.getMncString(), mcc, mnc)) {
                        String b = lteBand(id);
                        if (b != null) return b;
                    }
                }
            }
        }
        return null;
    }

    private static boolean sameOperator(String cMcc, String cMnc, String mcc, String mnc) {
        if (cMcc == null || cMnc == null || mcc == null || mnc == null) return false;
        try {
            return Integer.parseInt(cMcc) == Integer.parseInt(mcc)
                    && Integer.parseInt(cMnc) == Integer.parseInt(mnc);
        } catch (NumberFormatException e) {
            return cMcc.equals(mcc) && cMnc.equals(mnc);
        }
    }

    private static String fromServiceState(ServiceState ss) {
        if (ss == null) return null;
        String voice = null;
        for (NetworkRegistrationInfo nri : ss.getNetworkRegistrationInfoList()) {
            if (nri.getTransportType() != android.telephony.AccessNetworkConstants.TRANSPORT_TYPE_WWAN) continue;
            if (!nri.isRegistered()) continue;
            String b = label(nri.getCellIdentity());
            if (b == null) continue;
            if ((nri.getDomain() & NetworkRegistrationInfo.DOMAIN_PS) != 0) return b;
            if (voice == null) voice = b;
        }
        return voice;
    }

    private static String fromCells(List<CellInfo> cells, SubscriptionInfo si) {
        if (cells == null) return null;
        String mcc = si.getMccString(), mnc = si.getMncString();
        String nr = null, lte = null;
        for (CellInfo ci : cells) {
            if (!ci.isRegistered()) continue;
            CellIdentity id = ci.getCellIdentity();
            if (mcc != null && mnc != null && id.getMccString() != null
                    && !(mcc.equals(id.getMccString()) && mnc.equals(id.getMncString()))) continue;
            if (ci instanceof CellInfoNr && nr == null) nr = label(id);
            if (ci instanceof CellInfoLte && lte == null) lte = label(id);
        }
        return nr != null ? nr : lte;
    }

    static String label(CellIdentity id) {
        if (id instanceof CellIdentityNr) return nrBand((CellIdentityNr) id);
        if (id instanceof CellIdentityLte) return lteBand((CellIdentityLte) id);
        return null;
    }

    static String lteBand(CellIdentityLte id) {
        try {
            int[] b = id.getBands();
            if (b != null && b.length > 0 && b[0] > 0) return "B" + b[0];
        } catch (Throwable ignored) { }
        int band = lteBandFromEarfcn(id.getEarfcn());
        return band > 0 ? "B" + band : null;
    }

    static String nrBand(CellIdentityNr id) {
        try {
            int[] b = id.getBands();
            if (b != null && b.length > 0 && b[0] > 0) return "n" + b[0];
        } catch (Throwable ignored) { }
        int band = nrBandFromArfcn(id.getNrarfcn());
        return band > 0 ? "n" + band : null;
    }

    /** Downlink EARFCN to LTE band (3GPP TS 36.101). */
    static int lteBandFromEarfcn(int e) {
        if (e < 0 || e == CellInfo.UNAVAILABLE) return -1;
        int[][] t = {
                {1, 0, 599}, {2, 600, 1199}, {3, 1200, 1949}, {4, 1950, 2399}, {5, 2400, 2649},
                {7, 2750, 3449}, {8, 3450, 3799}, {12, 5010, 5179}, {13, 5180, 5279},
                {14, 5280, 5379}, {17, 5730, 5849}, {18, 5850, 5999}, {19, 6000, 6149},
                {20, 6150, 6449}, {25, 8040, 8689}, {26, 8690, 9039}, {28, 9210, 9659},
                {29, 9660, 9769}, {30, 9770, 9869}, {32, 9920, 10359}, {34, 36200, 36349},
                {38, 37750, 38249}, {39, 38250, 38649}, {40, 38650, 39649}, {41, 39650, 41589},
                {42, 41590, 43589}, {43, 43590, 45589}, {46, 46790, 54539}, {48, 55240, 56739},
                {66, 66436, 67335}, {71, 68586, 68935},
        };
        for (int[] r : t) if (e >= r[1] && e <= r[2]) return r[0];
        return -1;
    }

    /** NR-ARFCN to the usual NR band for that frequency (3GPP TS 38.104). */
    static int nrBandFromArfcn(int a) {
        if (a < 0 || a == CellInfo.UNAVAILABLE) return -1;
        if (a >= 151600 && a <= 160600) return 28;
        if (a >= 173800 && a <= 178800) return 5;
        if (a >= 185000 && a <= 192000) return 8;
        if (a >= 361000 && a <= 376000) return 3;
        if (a >= 422000 && a <= 434000) return 1;
        if (a >= 460000 && a <= 480000) return 40;
        if (a >= 499200 && a <= 537999) return 41;
        if (a >= 620000 && a <= 653333) return 78;
        if (a >= 653334 && a <= 680000) return 77;
        if (a >= 693334 && a <= 733333) return 79;
        return -1;
    }

}
