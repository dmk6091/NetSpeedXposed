package com.netspeed.xposed;

import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.lang.ref.WeakReference;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Pixel-style lock screen exit. System UI already scales the launcher in behind the lock screen
 * while you unlock (that is the "surface behind" appear amount, 0..1, driven by the swipe or by
 * the canned fingerprint / face unlock animation). On its own the lock screen just vanishes at the
 * end. Here the same 0..1 value also drives the lock screen window: it grows a little and fades
 * out, so lock screen and launcher cross-fade like on a Pixel.
 *
 * Switch: Cfg.UNLOCK_ANIM (off by default). Log tag "[unlock]".
 */
final class UnlockAnim {
    private static final String TAG = "NetSpeedXposed: [unlock] ";
    private static final float GROW = 0.06f;      // lock screen ends 6 % larger
    private static final float FADE_END = 0.62f;  // gone by 62 % of the unlock animation

    private static WeakReference<View> sRoot = new WeakReference<>(null);
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static boolean sActive, sLoggedNoWindow, sLoggedOff;
    private static final Runnable RESET = new Runnable() {
        @Override public void run() { reset(); }
    };

    private UnlockAnim() {}

    static void install(ClassLoader cl) {
        try {
            Class<?> shade = XposedHelpers.findClass("com.android.systemui.shade.NotificationShadeWindowView", cl);
            XposedBridge.hookAllConstructors(shade, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    sRoot = new WeakReference<>((View) p.thisObject);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "shade window hook failed: " + t);
        }
        int n = 0;
        try {
            Class<?> c = XposedHelpers.findClass("com.android.systemui.keyguard.KeyguardUnlockAnimationController", cl);
            n = XposedBridge.hookAllMethods(c, "setSurfaceBehindAppearAmount", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length < 1 || !(p.args[0] instanceof Float)) return;
                        apply((Float) p.args[0]);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "hook error " + t);
                    }
                }
            }).size();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "install failed: " + t);
        }
        // Fingerprint / face unlock plays a canned animation that may not go through the swipe path:
        // log these calls and run our own 0..1 sweep alongside.
        try {
            Class<?> c = XposedHelpers.findClass("com.android.systemui.keyguard.KeyguardUnlockAnimationController", cl);
            for (final String name : new String[]{"notifyStartSurfaceBehindRemoteAnimation", "playCannedUnlockAnimation",
                    "prepareForInWindowLauncherAnimations", "unlockToLauncherWithInWindowAnimations"}) {
                int k = XposedBridge.hookAllMethods(c, name, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            View v = sRoot.get();
                            boolean on = v != null && Cfg.b(Cfg.UNLOCK_ANIM, Cfg.D_UNLOCK_ANIM);
                            XposedBridge.log(TAG + name + " called, window=" + (v != null) + " switch=" + on);
                            if (on && name.equals("notifyStartSurfaceBehindRemoteAnimation")) sweep();
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + name + " error " + t);
                        }
                    }
                }).size();
                n += k;
                XposedBridge.log(TAG + name + ": " + k + " hook");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "extra hooks failed: " + t);
        }
        XposedBridge.log(TAG + "installed (" + n + " hooks)");
    }

    private static float sMax;
    private static android.animation.ValueAnimator sSweep;

    /** Own 0..1 sweep (300 ms) for unlocks that do not drive the appear amount. */
    private static void sweep() {
        H.post(() -> {
            if (sSweep != null) sSweep.cancel();
            sSweep = android.animation.ValueAnimator.ofFloat(0f, 1f);
            sSweep.setDuration(300);
            sSweep.setInterpolator(new android.view.animation.DecelerateInterpolator(1.4f));
            sSweep.addUpdateListener(a -> apply((Float) a.getAnimatedValue()));
            sSweep.start();
        });
    }

    private static void apply(float amount) {
        View v = sRoot.get();
        if (v == null) {
            if (!sLoggedNoWindow) { sLoggedNoWindow = true; XposedBridge.log(TAG + "no lock screen window captured"); }
            return;
        }
        Cfg.init(v.getContext());
        if (!Cfg.b(Cfg.UNLOCK_ANIM, Cfg.D_UNLOCK_ANIM)) {
            if (!sLoggedOff) { sLoggedOff = true; XposedBridge.log(TAG + "switch is off"); }
            if (sActive) reset();
            return;
        }
        float a = Math.max(0f, Math.min(1f, amount));
        if (a <= 0.001f) {
            if (sActive) reset();
            return;
        }
        if (a > sMax) sMax = a; else a = sMax;
        H.removeCallbacks(RESET);
        if (!sActive) {
            sActive = true;
            XposedBridge.log(TAG + "lock screen exit started");
        }
        float s = 1f + GROW * a;
        v.setPivotX(v.getWidth() / 2f);
        v.setPivotY(v.getHeight() * 0.5f);
        v.setScaleX(s);
        v.setScaleY(s);
        v.setAlpha(1f - Math.min(1f, a / FADE_END));
        // Always give the window back (the shade must work after unlocking, and the next lock needs it whole).
        H.postDelayed(RESET, a >= 0.999f ? 250 : 900);
    }

    private static void reset() {
        View v = sRoot.get();
        sActive = false;
        sMax = 0f;
        sLoggedOff = false;
        if (v == null) return;
        v.setScaleX(1f);
        v.setScaleY(1f);
        v.setAlpha(1f);
        XposedBridge.log(TAG + "lock screen restored");
    }
}
