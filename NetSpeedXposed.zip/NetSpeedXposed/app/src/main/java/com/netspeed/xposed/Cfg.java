package com.netspeed.xposed;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;

import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

/**
 * Settings shared between the settings screen (module app) and System UI.
 * The app stores them and serves them through {@link SettingsProvider};
 * System UI reads them here and reloads whenever the app reports a change.
 */
final class Cfg {
    static final String AUTHORITY = "com.netspeed.xposed.settings";
    static final Uri URI = Uri.parse("content://" + AUTHORITY + "/all");

    // ---- keys and defaults (int values are dp / sp)
    static final String ROW_GAP = "row_gap_dp";        static final int D_ROW_GAP = 1;
    static final String ROW2_H = "row2_dp";            static final int D_ROW2_H = 20;
    static final String EXTRA = "extra_dp";            static final int D_EXTRA = 0;
    static final String TEMP_SP = "temps_sp";          static final int D_TEMP_SP = 8;
    static final String WEATHER_SP = "weather_sp";     static final int D_WEATHER_SP = 12;
    static final String SPEED_SP = "speed_sp";         static final int D_SPEED_SP = 8;
    static final String BOLD = "bold_small";           static final boolean D_BOLD = true;
    static final String SHOW_CPU = "show_cpu";         static final boolean D_SHOW_CPU = true;
    static final String SHOW_BAT = "show_bat";         static final boolean D_SHOW_BAT = true;
    static final String SHOW_WEATHER = "show_weather"; static final boolean D_SHOW_WEATHER = true;
    static final String HIDE_IDLE = "hide_idle";       static final boolean D_HIDE_IDLE = false;
    static final String DUAL = "dual_row";             static final boolean D_DUAL = true;
    static final String SPEED_LEFT = "speed_after_weather"; static final boolean D_SPEED_LEFT = true;

    private static final String TAG = "NetSpeedXposed: [cfg] ";
    private static volatile Map<String, String> sValues = new HashMap<>();
    private static volatile int sVersion = 0;
    private static boolean sInit = false;

    private Cfg() {}

    /** Loads settings once (synchronously) and then follows changes. Safe to call repeatedly. */
    static synchronized void init(Context ctx) {
        if (sInit) return;
        sInit = true;
        final Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        load(app);
        try {
            HandlerThread t = new HandlerThread("netspeed-cfg");
            t.start();
            app.getContentResolver().registerContentObserver(URI, true,
                    new ContentObserver(new Handler(t.getLooper())) {
                        @Override
                        public void onChange(boolean selfChange) {
                            load(app);
                        }
                    });
        } catch (Throwable th) {
            XposedBridge.log(TAG + "observer failed: " + th);
        }
    }

    private static void load(Context ctx) {
        Map<String, String> m = new HashMap<>();
        try (Cursor c = ctx.getContentResolver().query(URI, null, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) m.put(c.getString(0), c.getString(1));
            }
            sValues = m;
            sVersion++;
            XposedBridge.log(TAG + "loaded " + m.size() + " settings");
        } catch (Throwable th) {
            XposedBridge.log(TAG + "load failed (using defaults): " + th);
        }
    }

    /** Increases every time settings are reloaded. */
    static int version() {
        return sVersion;
    }

    static int i(String key, int def) {
        String v = sValues.get(key);
        if (v == null) return def;
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static boolean b(String key, boolean def) {
        String v = sValues.get(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }
}
