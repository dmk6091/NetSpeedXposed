package com.netspeed.xposed;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;

import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

/**
 * Settings shared between the settings screen (module app) and System UI.
 * The app stores them and serves them through {@link SettingsProvider};
 * System UI reads them here and reloads whenever the app reports a change.
 */
final class Cfg {
    static final String AUTHORITY = "com.netspeed.xposed.settings";
    static final Uri URI = Uri.parse("content://" + AUTHORITY + "/all");

    // ---- keys and defaults (int values are dp / sp)
    static final String WEATHER_GAP = "weather_gap_dp"; static final int D_WEATHER_GAP = 2;
    static final String ROW_GAP = "row_gap_dp";        static final int D_ROW_GAP = 1;
    static final String ROW2_H = "row2_dp";            static final int D_ROW2_H = 20;
    static final String EXTRA = "extra_dp";            static final int D_EXTRA = 0;
    static final String TEMP_SP = "temps_sp";          static final int D_TEMP_SP = 8;
    static final String WEATHER_SP = "weather_sp";     static final int D_WEATHER_SP = 12;
    static final String SPEED_SP = "speed_sp";         static final int D_SPEED_SP = 8;
    static final String BOLD = "bold_small";           static final boolean D_BOLD = true;
    static final String SHOW_CPU = "show_cpu";         static final boolean D_SHOW_CPU = true;
    static final String SHOW_BAT = "show_bat";         static final boolean D_SHOW_BAT = true;
    static final String SHOW_WEATHER = "show_weather"; static final boolean D_SHOW_WEATHER = true;
    static final String SHOW_POWER = "show_power";     static final boolean D_SHOW_POWER = true;
    static final String BATT_CELL = "batt_cell";       static final boolean D_BATT_CELL = false;
    static final String BATT_PCT_IN = "batt_pct_inside"; static final boolean D_BATT_PCT_IN = true;
    static final String BATT_TEXT = "batt_text";       static final boolean D_BATT_TEXT = true;
    static final String CLOCK_SECONDS = "clock_seconds"; static final boolean D_CLOCK_SECONDS = true;
    static final String WX_DETAILS = "wx_details";     static final boolean D_WX_DETAILS = true;
    static final String CLOCK_INFO = "clock_info";     static final boolean D_CLOCK_INFO = true;
    static final String CLOCK_SP = "clock_sp";         static final int D_CLOCK_SP = 12;
    static final String DATE_INFO = "date_info";       static final boolean D_DATE_INFO = false;
    static final String SPEED_GAUGE = "speed_gauge";   static final boolean D_SPEED_GAUGE = true;
    static final String SINR_MAST = "sinr_mast";       static final boolean D_SINR_MAST = true;
    static final String COMBINE_TEMPS = "combine_temps"; static final boolean D_COMBINE_TEMPS = true;
    static final String TOWER_ICON = "tower_icon";     static final boolean D_TOWER_ICON = true;
    static final String TOWER_PCT = "tower_pct";       static final int D_TOWER_PCT = 100;
    static final String SHOW_SNR = "show_snr";         static final boolean D_SHOW_SNR = false;
    static final String CELL_TABLE = "cell_table";     static final boolean D_CELL_TABLE = true;
    static final String TABLE_SP = "table_sp";         static final int D_TABLE_SP = 7;
    static final String MAST_PCT = "mast_pct";         static final int D_MAST_PCT = 140;
    static final String POWER_SP = "power_sp";         static final int D_POWER_SP = 8;
    static final String SHOW_BAND = "show_band";       static final boolean D_SHOW_BAND = true;
    static final String BAND_SP = "band_sp";           static final int D_BAND_SP = 8;
    static final String SHOW_DBM = "show_dbm";         static final boolean D_SHOW_DBM = true;
    static final String SHOW_DIST = "show_dist";       static final boolean D_SHOW_DIST = true;
    static final String TOWER_DB = "tower_db";         static final boolean D_TOWER_DB = true;
    static final String SHOW_CELLS = "show_cells";     static final boolean D_SHOW_CELLS = true;
    static final String VO_BADGE = "vo_badge";         static final boolean D_VO_BADGE = true;
    static final String NAV_IMMERSIVE = "nav_immersive"; static final boolean D_NAV_IMMERSIVE = false;
    static final String PREDICT = "app_suggestions";   static final boolean D_PREDICT = false;
    static final String NET_TYPE = "net_type_arrows";  static final boolean D_NET_TYPE = true;
    static final String LEARN = "learn_towers";        static final boolean D_LEARN = true;
    /** OpenCelliD access token (pk.…), stored only on the phone. Empty = not used. */
    static final String OCID_KEY = "ocid_key";
    /** Custom operator name per SIM (empty = real name). */
    static final String OP_NAME1 = "op_name_1";
    static final String OP_NAME2 = "op_name_2";
    static final String HIDE_IDLE = "hide_idle";       static final boolean D_HIDE_IDLE = false;
    static final String DUAL = "dual_row";             static final boolean D_DUAL = true;
    static final String SPEED_LEFT = "speed_after_weather"; static final boolean D_SPEED_LEFT = true;

    private static final String TAG = "NetSpeedXposed: [cfg] ";
    private static volatile Map<String, String> sValues = new HashMap<>();
    private static volatile int sVersion = 0;
    private static boolean sInit = false;

    private Cfg() {}

    private static Handler sBg;
    private static Context sApp;
    private static volatile boolean sLoaded = false;
    private static volatile long sLastTry = 0;

    /**
     * Starts loading settings in the background and follows changes. Never blocks the
     * calling thread (System UI's main thread). Safe to call repeatedly.
     */
    static synchronized void init(Context ctx) {
        if (sInit) return;
        sInit = true;
        final Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        sApp = app;
        try {
            HandlerThread t = new HandlerThread("netspeed-cfg");
            t.start();
            sBg = new Handler(t.getLooper());
            sBg.post(() -> load(app));
            app.getContentResolver().registerContentObserver(URI, true,
                    new ContentObserver(sBg) {
                        @Override
                        public void onChange(boolean selfChange) {
                            load(app);
                        }
                    });
        } catch (Throwable th) {
            XposedBridge.log(TAG + "observer failed: " + th);
        }
    }

    /** Retries loading every few seconds until it has worked once (e.g. right after boot). */
    static void retryIfNeeded() {
        if (sLoaded || sBg == null || sApp == null) return;
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - sLastTry < 5000) return;
        sLastTry = now;
        sBg.post(() -> load(sApp));
    }

    private static void load(Context ctx) {
        sLastTry = android.os.SystemClock.elapsedRealtime();
        Map<String, String> m = new HashMap<>();
        try (Cursor c = ctx.getContentResolver().query(URI, null, null, null, null)) {
            if (c == null) {
                XposedBridge.log(TAG + "settings app not reachable yet, using defaults");
                return;
            }
            while (c.moveToNext()) m.put(c.getString(0), c.getString(1));
            sLoaded = true;
            sValues = m;
            sVersion++;
            XposedBridge.log(TAG + "loaded " + m.size() + " settings");
        } catch (Throwable th) {
            XposedBridge.log(TAG + "load failed (using defaults): " + th);
        }
    }

    /** Increases every time settings are reloaded. */
    static int version() {
        return sVersion;
    }

    static int i(String key, int def) {
        String v = sValues.get(key);
        if (v == null) return def;
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static String s(String key) {
        String v = sValues.get(key);
        return v == null ? "" : v.trim();
    }

    static boolean b(String key, boolean def) {
        String v = sValues.get(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }
}
