package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RadialGradient;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

import java.util.Calendar;
import java.util.Random;

/**
 * A live sky behind the whole status bar: colours follow sunrise / sunset, the sun or the moon crosses the bar,
 * stars come out at night, and clouds, rain or snow follow the weather (OmniJaws condition code).
 * Switch: Cfg.SKY. Redraws ~15 times a second while the screen is on, once a second otherwise.
 */
final class SkyView extends View {
    /** OmniJaws / Yahoo condition code, set by DualRow when the weather updates (-1 = unknown). */
    static volatile int wx = -1;

    private static final int[] RAIN = {5, 6, 7, 8, 9, 10, 11, 12, 35, 40, 0, 1, 2, 3, 4, 37, 38, 39, 45, 47};
    private static final int[] SNOW = {13, 14, 15, 16, 41, 42, 43, 46};
    private static final int[] FOG = {19, 20, 21, 22};
    private static final int[] CLOUDY = {26, 27, 28};
    private static final int[] PARTLY = {29, 30, 44};

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), cut = new Path();
    private final RectF rf = new RectF();
    private final long t0 = SystemClock.uptimeMillis();
    private final float[] sx = new float[48], sy = new float[48], sph = new float[48];
    private final float[] cx = new float[8], cy = new float[8], cs = new float[8], cv = new float[8];
    private final float[] rx = new float[90], ry = new float[90];
    private double lat = 18.62, lon = 73.80;
    private long locAt;
    private final Paint cp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Bitmap[] clouds = new Bitmap[4];
    private int cloudTint;
    private android.graphics.ColorFilter cloudFilter;
    private LinearGradient grad;
    private int gTop, gBot, gH;
    private final float dens;

    SkyView(Context ctx) {
        super(ctx);
        dens = ctx.getResources().getDisplayMetrics().density;
        Random r = new Random(11);
        for (int i = 0; i < sx.length; i++) { sx[i] = r.nextFloat(); sy[i] = r.nextFloat(); sph[i] = r.nextFloat() * 6.28f; }
        for (int i = 0; i < cx.length; i++) { cx[i] = r.nextFloat(); cy[i] = 0.15f + r.nextFloat() * 0.6f; cs[i] = 0.8f + r.nextFloat() * 0.6f; cv[i] = 5 + r.nextFloat() * 9; }
        for (int i = 0; i < rx.length; i++) { rx[i] = r.nextFloat(); ry[i] = r.nextFloat(); }
        for (int i = 0; i < clouds.length; i++) clouds[i] = makeCloud(100 + i * 17);
        setWillNotDraw(false);
    }

    /** One cloud as a soft white-and-grey puff pile (grey underside), later multiplied by the tint colour. */
    private static Bitmap makeCloud(long seed) {
        final int W = 280, H = 110;
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random r = new Random(seed);
        int n = 34;
        float[] px = new float[n], py = new float[n], pr = new float[n];
        for (int i = 0; i < n; i++) {
            float f = r.nextFloat();
            px[i] = W * (0.16f + 0.68f * f);
            float dome = (float) Math.sin(Math.PI * f);
            pr[i] = 14 + dome * 24 * (0.6f + 0.6f * r.nextFloat());
            py[i] = H * 0.74f - dome * H * 0.30f * (0.4f + 0.8f * r.nextFloat()) - pr[i] * 0.2f;
        }
        // shaded underside
        for (int i = 0; i < n; i++) {
            float rr = pr[i] * 1.15f;
            q.setShader(new RadialGradient(px[i], py[i] + rr * 0.30f, rr,
                    new int[]{0xB09AA3B2, 0x709AA3B2, 0x00,}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(px[i], py[i] + rr * 0.30f, rr, q);
        }
        // lit tops
        for (int i = 0; i < n; i++) {
            float rr = pr[i] * 0.95f;
            q.setShader(new RadialGradient(px[i], py[i] - rr * 0.22f, rr,
                    new int[]{0xE0FFFFFF, 0x90FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(px[i], py[i] - rr * 0.22f, rr, q);
        }
        // soft flat base: fade out the bottom
        q.setShader(new LinearGradient(0, H * 0.66f, 0, H * 0.95f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
        q.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN));
        c.drawRect(0, 0, W, H, q);
        return bm;
    }

    /** The bar has side padding (corners / cutout); stretch the sky over it so it reaches both screen edges. */
    private void fitEdges() {
        try {
            android.view.ViewParent vp = getParent();
            if (!(vp instanceof android.view.ViewGroup)) return;
            android.view.ViewGroup g = (android.view.ViewGroup) vp;
            g.setClipToPadding(false);
            g.setClipChildren(false);
            android.view.ViewGroup.MarginLayoutParams lp = (android.view.ViewGroup.MarginLayoutParams) getLayoutParams();
            int l = -g.getPaddingLeft(), r = -g.getPaddingRight();
            if (lp.leftMargin != l || lp.rightMargin != r) {
                lp.leftMargin = l; lp.rightMargin = r;
                setLayoutParams(lp);
            }
        } catch (Throwable ignored) { }
    }

    private static boolean in(int[] a, int v) {
        for (int x : a) if (x == v) return true;
        return false;
    }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static float sm(double x) {
        x = Math.max(0, Math.min(1, x));
        return (float) (x * x * (3 - 2 * x));
    }

    private static int alpha(int c, float a) {
        return (c & 0x00FFFFFF) | (Math.round(Math.max(0f, Math.min(1f, a)) * 255) << 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!Cfg.b(Cfg.SKY, Cfg.D_SKY)) {
            postInvalidateDelayed(3000);
            return;
        }
        fitEdges();
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        long now = SystemClock.uptimeMillis();
        float t = (now - t0) / 1000f;
        if (now - locAt > 600_000) {
            locAt = now;
            try {
                android.location.Location l = TowerDb.myLocation(getContext());
                if (l != null) { lat = l.getLatitude(); lon = l.getLongitude(); }
            } catch (Throwable ignored) { }
        }
        Calendar cal = Calendar.getInstance();
        double nowM = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60.0;
        double[] sun = SunTimes.today(lat, lon);
        double rise = Double.isNaN(sun[0]) ? 360 : sun[0], set = Double.isNaN(sun[1]) ? 1080 : sun[1];
        float d = nowM < 720 ? sm((nowM - (rise - 30)) / 60) : 1 - sm((nowM - (set - 30)) / 60);
        float warm = 4 * d * (1 - d);

        if (Cfg.b(Cfg.NIGHT, Cfg.D_NIGHT)) {
            drawNight(c, w, h, t, nowM, rise, set);
            postInvalidateDelayed(ScreenState.on() ? 200 : 3000);
            return;
        }
        int code = wx;
        boolean rain = in(RAIN, code), snow = in(SNOW, code), fog = in(FOG, code);
        int nClouds = in(CLOUDY, code) || rain || snow ? 7 : in(PARTLY, code) || fog ? 4 : 2;
        float oc = rain ? 0.75f : snow ? 0.6f : in(CLOUDY, code) ? 0.55f : fog ? 0.5f : in(PARTLY, code) ? 0.2f : 0f;

        int top = lerp(0xFF080A20, 0xFF4696EB, d), bot = lerp(0xFF1C2250, 0xFF96CDFA, d);
        top = lerp(top, 0xFF463C78, warm);
        bot = lerp(bot, 0xFFFA965A, warm);
        top = lerp(top, lerp(0xFF14161E, 0xFF69737F, d), oc);
        bot = lerp(bot, lerp(0xFF1E212B, 0xFF7F8A98, d), oc);
        if (grad == null || gTop != top || gBot != bot || gH != h) {
            grad = new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP);
            gTop = top; gBot = bot; gH = h;
        }
        p.setShader(grad);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // sun or moon along an arc
        float r0 = h * 0.17f;
        if (nowM >= rise - 10 && nowM <= set + 10) {
            double fr = Math.max(0, Math.min(1, (nowM - rise) / (set - rise)));
            float x = (float) (w * (0.08 + 0.84 * fr)), y = (float) (h * 0.92 - Math.sin(Math.PI * fr) * h * 0.55);
            float vis = 1f - oc * 0.8f;
            for (int i = 4; i >= 1; i--) { p.setColor(alpha(0xFFFFDC78, 0.07f * vis * (5 - i))); c.drawCircle(x, y, r0 * (1 + i * 0.5f), p); }
            p.setColor(alpha(0xFFFFE182, vis));
            p.setStrokeWidth(Math.max(1.2f, h * 0.012f));
            for (int k = 0; k < 12; k++) {
                double a = k * Math.PI / 6 + t * 0.3;
                c.drawLine((float) (x + Math.cos(a) * r0 * 1.35), (float) (y + Math.sin(a) * r0 * 1.35),
                        (float) (x + Math.cos(a) * r0 * 1.75), (float) (y + Math.sin(a) * r0 * 1.75), p);
            }
            p.setColor(alpha(0xFFFFD65A, vis));
            c.drawCircle(x, y, r0, p);
        }
        float night = 1f - d;
        if (night > 0.02f) {
            double nm = nowM >= set ? nowM - set : nowM + 1440 - set, len = rise + 1440 - set;
            double fr = Math.max(0, Math.min(1, nm / len));
            float x = (float) (w * (0.08 + 0.84 * fr)), y = (float) (h * 0.92 - Math.sin(Math.PI * fr) * h * 0.5);
            float vis = night * (1f - oc * 0.7f);
            for (int i = 3; i >= 1; i--) { p.setColor(alpha(0xFFD2E1FF, 0.06f * vis * (4 - i))); c.drawCircle(x, y, r0 * (1 + i * 0.5f), p); }
            path.reset(); path.addCircle(x, y, r0, Path.Direction.CW);
            cut.reset(); cut.addCircle(x + r0 * 0.55f, y - r0 * 0.15f, r0 * 0.92f, Path.Direction.CW);
            path.op(cut, Path.Op.DIFFERENCE);
            p.setColor(alpha(0xFFEEF0E2, vis));
            c.drawPath(path, p);
            // stars
            float sa = night * (1f - oc);
            if (sa > 0.05f) {
                for (int i = 0; i < sx.length; i++) {
                    float b = 0.5f + 0.5f * (float) Math.sin(t * 2.2f + sph[i]);
                    p.setColor(alpha(0xFFFFFFFF, sa * (0.35f + 0.65f * b)));
                    c.drawCircle(sx[i] * w, 2 + sy[i] * (h - 8), dens * (0.5f + 0.6f * b), p);
                }
            }
        }

        // clouds: soft pre-rendered puffs, lit on top and shaded underneath, tinted by the sky
        int cc = lerp(0xFF7C86AE, 0xFFFFFFFF, d);
        cc = lerp(cc, 0xFFFFD2B4, warm * 0.5f);
        cc = lerp(cc, lerp(0xFF4A5060, 0xFFA2AAB6, d), oc * 0.75f);
        if (cloudTint != cc) { cloudTint = cc; cloudFilter = new android.graphics.PorterDuffColorFilter(cc, android.graphics.PorterDuff.Mode.MULTIPLY); }
        cp.setColorFilter(cloudFilter);
        cp.setAlpha(oc > 0.4f ? 235 : 200);
        float u = h / 96f;
        for (int i = 0; i < nClouds; i++) {
            Bitmap bm = clouds[i % clouds.length];
            float sc = cs[i] * u * (oc > 0.4f ? 1.5f : 1.1f);
            float bw = bm.getWidth() * sc * 0.9f, bh = bm.getHeight() * sc * 0.9f;
            float x = ((cx[i] * (w + bw) + t * cv[i] * dens * 0.6f) % (w + bw)) - bw, y = cy[i] * h - bh * 0.55f;
            rf.set(x, y, x + bw, y + bh);
            c.drawBitmap(bm, null, rf, cp);
        }
        if (fog) {
            p.setColor(alpha(0xFFC8CDD4, 0.18f));
            c.drawRect(0, 0, w, h, p);
        }
        if (rain) {
            p.setColor(alpha(0xFFBED2EB, 0.55f));
            p.setStrokeWidth(Math.max(1f, dens * 0.8f));
            for (int i = 0; i < rx.length; i++) {
                float y = (ry[i] * h + t * 260f * dens) % h, x = rx[i] * w;
                c.drawLine(x, y, x - 3 * dens, y + 9 * dens, p);
            }
        } else if (snow) {
            p.setColor(alpha(0xFFFFFFFF, 0.8f));
            for (int i = 0; i < rx.length; i++) {
                float y = (ry[i] * h + t * 40f * dens) % h, x = rx[i] * w + (float) Math.sin(t + i) * 4 * dens;
                c.drawCircle(x, y, dens * 1.2f, p);
            }
        }
        // darken a little so the status bar text stays readable
        p.setColor(0x30000000);
        c.drawRect(0, 0, w, h, p);

        if (ScreenState.on()) postInvalidateDelayed(66);
        else postInvalidateDelayed(1000);
    }

    // ---- Night sky: real moon phase and position, clouds from the weather, aurora, ISS pass, shooting stars. ~5 fps.
    private Bitmap aurora;

    private Bitmap makeAurora() {
        final int W = 512, H = 96;
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        double tw = 2 * Math.PI / W;
        for (int x = 0; x < W; x++) {
            double n = 0.5 + 0.25 * Math.sin(tw * 2 * x + 1) + 0.15 * Math.sin(tw * 5 * x + 2) + 0.10 * Math.sin(tw * 11 * x + 4);
            double band = Math.max(0, Math.sin(tw * 1 * x + 0.6) * 0.6 + 0.5);
            double top = H * (0.05 + 0.45 * (1 - n * band));
            float amp = (float) Math.min(1, Math.max(0, n * (0.4 + band)));
            for (int y = (int) top; y < H; y++) {
                float tt = (y - (float) top) / (H - (float) top);
                float a = (float) Math.pow(1 - tt, 1.6) * amp * 0.55f * Math.min(1f, tt * 6f + 0.15f);
                int col = lerp(0xFF3CFFA0, 0xFF9060FF, Math.max(0f, 1f - tt * 1.3f) < 0.5f ? 1f - Math.max(0f, 1f - tt * 1.3f) * 2f : 0f);
                bm.setPixel(x, y, alpha(col, a));
            }
        }
        return bm;
    }

    private void drawNight(Canvas c, int w, int h, float t, double nowM, double rise, double set) {
        float u = h / 96f;
        p.setStyle(Paint.Style.FILL);
        if (grad == null || gTop != 0x02030A || gH != h) {
            grad = new LinearGradient(0, 0, 0, h, 0xFF02030A, 0xFF0C1030, Shader.TileMode.CLAMP);
            gTop = 0x02030A; gBot = 0; gH = h;
        }
        p.setShader(grad);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
        // aurora (pre-rendered, drifting slowly, breathing)
        if (aurora == null) aurora = makeAurora();
        float sh = (t * 5f * dens) % w;
        cp.setColorFilter(null);
        cp.setAlpha((int) (255 * (0.55f + 0.2f * Math.sin(t * 0.35))));
        rf.set(-sh, 0, w - sh, h);
        c.drawBitmap(aurora, null, rf, cp);
        rf.set(w - sh, 0, 2 * w - sh, h);
        c.drawBitmap(aurora, null, rf, cp);
        // stars
        for (int i = 0; i < sx.length; i++) {
            float b = 0.5f + 0.5f * (float) Math.sin(t * 0.9f + sph[i]);
            p.setColor(alpha(0xFFFFFFFF, 0.3f + 0.6f * b));
            c.drawCircle(sx[i] * w, 2 + sy[i] * (h - 6), dens * (0.45f + 0.55f * b), p);
        }
        // shooting star every ~40 s
        float cyc = t % 40f;
        if (cyc < 0.8f) {
            int k = (int) (t / 40f);
            float x0 = w * (0.15f + ((k * 37) % 70) / 100f), y0 = h * (0.05f + ((k * 53) % 30) / 100f), f = cyc / 0.8f;
            p.setStrokeWidth(dens * 1.2f);
            p.setColor(alpha(0xFFFFFFFF, 1f - f));
            float hx = x0 + f * 90 * dens, hy = y0 + f * 40 * dens;
            c.drawLine(hx - 28 * dens, hy - 12 * dens, hx, hy, p);
        }
        // moon: real phase, real-ish position (rises/sets ~50 min later each day)
        double days = System.currentTimeMillis() / 86400000.0 - 10957.5 + 0.25;
        double fPh = (days / 29.530588) % 1.0;
        if (fPh < 0) fPh += 1;
        double transit = ((rise + set) / 2 + fPh * 1440) % 1440;
        double dtm = ((nowM - transit + 2160) % 1440) - 720;
        if (Math.abs(dtm) < 360) {
            double fr = (dtm + 360) / 720;
            float r0 = h * 0.17f;
            float x = (float) (w * (0.1 + 0.8 * fr)), y = (float) (h * 0.66 - Math.sin(Math.PI * fr) * h * 0.30);
            float lit = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * fPh));
            for (int i = 3; i >= 1; i--) { p.setColor(alpha(0xFFC8D7FF, 0.05f * (0.3f + lit) * (4 - i))); c.drawCircle(x, y, r0 * (1 + i * 0.55f), p); }
            p.setColor(alpha(0xFF3A4058, 0.9f));
            c.drawCircle(x, y, r0, p);
            c.save();
            boolean waning = fPh >= 0.5;
            double ff = waning ? 1 - fPh : fPh;
            if (waning) c.scale(-1f, 1f, x, y);
            float rt = (float) (r0 * Math.abs(Math.cos(2 * Math.PI * ff)));
            path.reset();
            rf.set(x - r0, y - r0, x + r0, y + r0);
            path.arcTo(rf, -90, 180);
            rf.set(x - rt, y - r0, x + rt, y + r0);
            path.arcTo(rf, 90, ff < 0.25 ? -180 : 180);
            path.close();
            p.setColor(0xFFF2F0E2);
            c.drawPath(path, p);
            c.restore();
        }
        // clouds, tinted dim for night
        int code = wx;
        int nClouds = in(CLOUDY, code) || in(RAIN, code) || in(SNOW, code) ? 6 : in(PARTLY, code) || in(FOG, code) ? 4 : 2;
        int cc = 0xFF565E80;
        if (cloudTint != cc) { cloudTint = cc; cloudFilter = new android.graphics.PorterDuffColorFilter(cc, android.graphics.PorterDuff.Mode.MULTIPLY); }
        cp.setColorFilter(cloudFilter);
        cp.setAlpha(nClouds > 4 ? 215 : 170);
        for (int i = 0; i < nClouds; i++) {
            Bitmap bm = clouds[i % clouds.length];
            float sc = cs[i] * u * 1.2f;
            float bw = bm.getWidth() * sc * 0.9f, bh = bm.getHeight() * sc * 0.9f;
            float x = ((cx[i] * (w + bw) + t * cv[i] * dens * 0.6f) % (w + bw)) - bw, y = cy[i] * h - bh * 0.55f;
            rf.set(x, y, x + bw, y + bh);
            c.drawBitmap(bm, null, rf, cp);
        }
        // ISS: crosses the bar for ~6 min of every 92.7 min orbit (illustrative timing, not live tracking)
        double orb = (System.currentTimeMillis() / 60000.0) % 92.68;
        if (orb < 6.0) {
            float f = (float) (orb / 6.0);
            float x = w * f, y = h * (0.62f - 0.34f * (float) Math.sin(Math.PI * f));
            p.setStrokeWidth(dens * 1.3f);
            p.setColor(0x55FFFFFF);
            c.drawLine(x - 26 * dens, y + 4 * dens * (1 - 2 * f), x, y, p);
            p.setColor(0x30FFF0C8);
            c.drawCircle(x, y, 6 * dens, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(x, y, 2.2f * dens, p);
            p.setStrokeWidth(dens * 1.8f);
            c.drawLine(x - 4.5f * dens, y, x + 4.5f * dens, y, p);
        }
    }
}
