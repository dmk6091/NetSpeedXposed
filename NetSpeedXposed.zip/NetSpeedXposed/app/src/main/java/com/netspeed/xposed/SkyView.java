package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

import java.util.Random;

/**
 * A live sky behind the whole status bar.
 *
 *  - Sun and Moon at their real positions for your place and time (Astro). The camera hole is the
 *    plumb line: straight overhead is at the hole, the horizon is the bottom and the outer edges, east
 *    on the left, west on the right. Below the horizon = not drawn.
 *  - The Moon shows its real phase, lit side turned towards the Sun.
 *  - Behind clouds, rain, fog ... the Sun / Moon is drawn very faint, still in its true place.
 *  - The background follows the weather: sunny / clear, cloudy, overcast, rain, drizzle, windy, storm,
 *    snow, sleet, hail, fog, mist. Clear sky = no clouds at all.
 *
 * Weather: OmniJaws condition code (your weather app, same as the icon), refined by Open-Meteo's
 * WMO code, cloud cover, wind and visibility when they're fresh. Switch: Cfg.SKY.
 */
final class SkyView extends View {
    /** OmniJaws / Yahoo condition code, set by DualRow when the weather updates (-1 = unknown). */
    static volatile int wx = -1;
    /** Open-Meteo extras, set by DualRow every 15 min. */
    static volatile int wmo = -1, cloudPct = -1;
    static volatile float windKmh = Float.NaN, visM = Float.NaN;
    /** US AQI from Open-Meteo (-1 unknown): poor air makes the Sun hazy. */
    static volatile int aqi = -1;
    static volatile long wmoAt = 0;
    /** Real weather observed at the nearest airport (METAR): weather string ("-RA", "HZ", "TS"...), when, how far. */
    static volatile String obsWx = null, obsStation = "";
    static volatile long obsAt = 0;
    static volatile float obsKm = Float.NaN, obsTemp = Float.NaN;
    private static final int OBS_DRY = 100;

    /** What the airport actually reports: STORM / RAIN / DRIZZLE / SNOW / HAIL, OBS_DRY, or -1 (none, old or too far). */
    static int obsKind() {
        if (obsWx == null || System.currentTimeMillis() - obsAt > 150 * 60_000L || !(obsKm <= 60)) return -1;
        String w = obsWx.toUpperCase(java.util.Locale.US);
        if (w.contains("TS")) return STORM;
        if (w.contains("GR") || w.contains("GS")) return HAIL;
        if (w.contains("SN")) return SNOW;
        if (w.contains("RA") || w.contains("SH")) return RAIN;
        if (w.contains("DZ")) return DRIZZLE;
        return OBS_DRY;
    }

    static final int CLEAR = 0, CLOUDY = 1, OVERCAST = 2, RAIN = 3, DRIZZLE = 4, WINDY = 5, STORM = 6, SNOW = 7,
            SLEET = 8, HAIL = 9, FOG = 10, MIST = 11;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), cut = new Path();
    private final RectF rf = new RectF();
    private final long t0 = SystemClock.uptimeMillis();
    private final float[] sx = new float[48], sy = new float[48], sph = new float[48];
    private final float[] cx = new float[8], cy = new float[8], cs = new float[8], cv = new float[8];
    private final float[] rx = new float[90], ry = new float[90];
    private final float[] wlx = new float[14], wly = new float[14], wll = new float[14];
    private double lat = 18.62, lon = 73.80;
    private long locAt;
    private final Paint cp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Bitmap[] clouds = new Bitmap[4];
    private int cloudTint;
    private android.graphics.ColorFilter cloudFilter;
    private LinearGradient grad;
    private int gTop, gBot, gH;
    private final float dens;

    // sun / moon, recomputed every 20 s
    private long astroAt;
    private Astro.Pos sunPos;
    private Astro.Moon moonPos;
    // camera hole centre in this view's pixels, rechecked every 10 s
    private long camAt;
    private float camX = Float.NaN, camY = Float.NaN;

    /** Outside opacity requests seen (the ROM fades the first status bar layer, where the sky sits). */
    static volatile int alphaAsks = 0;
    static volatile float lastAsk = 1f;

    /** The sky stays opaque: whoever fades the bar's first layer must not fade the sky with it. */
    @Override
    protected boolean onSetAlpha(int alpha) {
        if (alpha >= 255) return false;   // full opacity goes through normally
        alphaAsks++;
        lastAsk = alpha / 255f;
        return true;      // "handled": the framework then leaves the sky at full opacity
    }

    SkyView(Context ctx) {
        super(ctx);
        dens = ctx.getResources().getDisplayMetrics().density;
        Random r = new Random(11);
        for (int i = 0; i < sx.length; i++) { sx[i] = r.nextFloat(); sy[i] = r.nextFloat(); sph[i] = r.nextFloat() * 6.28f; }
        for (int i = 0; i < cx.length; i++) { cx[i] = r.nextFloat(); cy[i] = 0.15f + r.nextFloat() * 0.6f; cs[i] = 0.8f + r.nextFloat() * 0.6f; cv[i] = 5 + r.nextFloat() * 9; }
        for (int i = 0; i < rx.length; i++) { rx[i] = r.nextFloat(); ry[i] = r.nextFloat(); }
        for (int i = 0; i < wlx.length; i++) { wlx[i] = r.nextFloat(); wly[i] = 0.1f + r.nextFloat() * 0.8f; wll[i] = 0.06f + r.nextFloat() * 0.1f; }
        for (int i = 0; i < clouds.length; i++) clouds[i] = makeCloud(100 + i * 17);
        setWillNotDraw(false);
    }

    /** One cloud as a soft white-and-grey puff pile (grey underside), later multiplied by the tint colour. */
    private static Bitmap makeCloud(long seed) {
        final int W = 280, H = 110;
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random r = new Random(seed);
        int n = 34;
        float[] px = new float[n], py = new float[n], pr = new float[n];
        for (int i = 0; i < n; i++) {
            float f = r.nextFloat();
            px[i] = W * (0.16f + 0.68f * f);
            float dome = (float) Math.sin(Math.PI * f);
            pr[i] = 14 + dome * 24 * (0.6f + 0.6f * r.nextFloat());
            py[i] = H * 0.74f - dome * H * 0.30f * (0.4f + 0.8f * r.nextFloat()) - pr[i] * 0.2f;
        }
        for (int i = 0; i < n; i++) {
            float rr = pr[i] * 1.15f;
            q.setShader(new RadialGradient(px[i], py[i] + rr * 0.30f, rr,
                    new int[]{0xB09AA3B2, 0x709AA3B2, 0x00,}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(px[i], py[i] + rr * 0.30f, rr, q);
        }
        for (int i = 0; i < n; i++) {
            float rr = pr[i] * 0.95f;
            q.setShader(new RadialGradient(px[i], py[i] - rr * 0.22f, rr,
                    new int[]{0xE0FFFFFF, 0x90FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(px[i], py[i] - rr * 0.22f, rr, q);
        }
        q.setShader(new LinearGradient(0, H * 0.66f, 0, H * 0.95f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
        q.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN));
        c.drawRect(0, 0, W, H, q);
        return bm;
    }

    /** The bar has side padding (corners / cutout); stretch the sky over it so it reaches both screen edges. */
    private void fitEdges() {
        try {
            android.view.ViewParent vp = getParent();
            if (!(vp instanceof android.view.ViewGroup)) return;
            android.view.ViewGroup g = (android.view.ViewGroup) vp;
            g.setClipToPadding(false);
            g.setClipChildren(false);
            android.view.ViewGroup.MarginLayoutParams lp = (android.view.ViewGroup.MarginLayoutParams) getLayoutParams();
            int l = -g.getPaddingLeft(), r = -g.getPaddingRight();
            if (lp.leftMargin != l || lp.rightMargin != r) {
                lp.leftMargin = l; lp.rightMargin = r;
                setLayoutParams(lp);
            }
        } catch (Throwable ignored) { }
    }

    private long txtAt;
    private boolean darkText;

    /** Status bar text turns dark over light apps; then wash the sky lighter so it stays readable. */
    private void contrast(Canvas c, int w, int h, int base, boolean clearDay) {
        long now = SystemClock.uptimeMillis();
        if (now - txtAt > 2000) {
            txtAt = now;
            try {
                int id = getResources().getIdentifier("clock", "id", "com.android.systemui");
                android.view.ViewParent vp = getParent();
                View ck = id != 0 && vp instanceof View ? ((View) vp).findViewById(id) : null;
                if (ck instanceof android.widget.TextView) {
                    int col = ((android.widget.TextView) ck).getCurrentTextColor();
                    double lum = (0.299 * ((col >> 16) & 255) + 0.587 * ((col >> 8) & 255) + 0.114 * (col & 255)) / 255.0;
                    darkText = lum < 0.5;
                }
            } catch (Throwable ignored) { }
        }
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        // dark text: lighten (a clear day is already pale blue, so only a touch); light text: darken a little
        int wash = darkText ? (clearDay ? 0x30F2F8FF : 0x78FFFFFF) : base;
        p.setColor(wash);
        if ((wash >>> 24) != 0) c.drawRect(0, 0, w, h, p);
    }

    private long battAt;
    private boolean low;

    /** True when the battery is at or below the chosen level and not charging: the sky then redraws only every 30 s (looks still). */
    private boolean lowBatt() {
        long now = SystemClock.uptimeMillis();
        if (now - battAt > 30_000) {
            battAt = now;
            low = false;
            int lim = Cfg.i(Cfg.SKY_LOW, Cfg.D_SKY_LOW);
            if (lim > 0) {
                try {
                    android.content.Intent b = getContext().registerReceiver(null, new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
                    if (b != null) {
                        int lvl = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, 100) * 100 / Math.max(1, b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100));
                        boolean chg = b.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
                        low = !chg && lvl <= lim;
                    }
                } catch (Throwable ignored) { }
            }
        }
        return low;
    }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static float sm(double x) {
        x = Math.max(0, Math.min(1, x));
        return (float) (x * x * (3 - 2 * x));
    }

    private static int alpha(int c, float a) {
        return (c & 0x00FFFFFF) | (Math.round(Math.max(0f, Math.min(1f, a)) * 255) << 24);
    }

    // ------------------------------------------------------------------ weather condition

    private static int fromYahoo(int c) {
        switch (c) {
            case 0: case 1: case 2: case 3: case 4: case 37: case 38: case 39: case 45: case 47: return STORM;
            case 5: case 6: case 7: case 10: case 18: return SLEET;
            case 8: case 9: return DRIZZLE;
            case 11: case 12: case 40: return RAIN;
            case 13: case 14: case 15: case 16: case 41: case 42: case 43: case 46: return SNOW;
            case 17: case 35: return HAIL;
            case 19: case 21: case 22: return MIST;
            case 20: return FOG;
            case 23: case 24: return WINDY;
            case 26: return OVERCAST;
            case 27: case 28: case 29: case 30: case 44: return CLOUDY;
            case 25: case 31: case 32: case 33: case 34: case 36: return CLEAR;
            default: return -1;
        }
    }

    private static int fromWmo(int c) {
        if (c == 0 || c == 1) return CLEAR;
        if (c == 2) return CLOUDY;
        if (c == 3) return OVERCAST;
        if (c == 45 || c == 48) return FOG;
        if (c >= 51 && c <= 57) return DRIZZLE;
        if ((c >= 61 && c <= 65) || (c >= 80 && c <= 82)) return RAIN;
        if (c == 66 || c == 67) return SLEET;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return SNOW;
        if (c == 95) return STORM;
        if (c == 96 || c == 99) return HAIL;
        return -1;
    }

    static boolean wet(int k) {
        return k == RAIN || k == DRIZZLE || k == STORM || k == SNOW || k == SLEET || k == HAIL;
    }

    /** Icon code for the status bar: the weather app's, unless the sky we paint disagrees with it about rain. */
    static int iconCode(boolean day) {
        int k = condition(), a = fromYahoo(wx);
        if (a >= 0 && wet(a) == wet(k)) return wx;
        switch (k) {
            case STORM: return 4;
            case HAIL: return 17;
            case RAIN: return wmo >= 80 ? 11 : 12;
            case DRIZZLE: return 9;
            case SLEET: return 5;
            case SNOW: return 16;
            case FOG: return 20;
            case MIST: return 21;
            case OVERCAST: return 26;
            case WINDY: return 24;
        }
        int cl = cloudPct;
        if (k == CLOUDY) return cl >= 0 && cl < 70 ? (day ? 30 : 29) : (day ? 28 : 27);
        return cl >= 10 ? (day ? 34 : 33) : (day ? 32 : 31);
    }

    /** The condition to paint, from your weather app first, sharpened by Open-Meteo when that is fresh. */
    static int condition() {
        boolean fresh = System.currentTimeMillis() - wmoAt < 60 * 60_000L;
        int a = fromYahoo(wx), b = fresh ? fromWmo(wmo) : -1;
        int k = a >= 0 ? a : b >= 0 ? b : CLEAR;
        if (a >= 0 && b >= 0) {
            // the weather app and Open-Meteo disagree about rain: trust Open-Meteo (15-minute data, same as the rain %)
            if (wet(a) != wet(b)) k = b;
            if (a == RAIN && (b == DRIZZLE || b == SLEET)) k = b;      // finer kind of the same wet weather
            if (a == STORM && b == HAIL) k = HAIL;
        }
        // what the nearest airport really sees beats both forecasts on "is it raining"
        int o = obsKind();
        if (o == OBS_DRY && wet(k)) k = CLOUDY;
        else if (o >= 0 && o != OBS_DRY && !wet(k)) k = o;
        if (fresh) {
            int cl = cloudPct;
            float vis = visM, wind = windKmh;
            // measured cloud cover decides between clear / cloudy / overcast (codes alone are often off)
            if ((k == CLEAR || k == CLOUDY || k == OVERCAST) && cl >= 0) k = cl >= 85 ? OVERCAST : cl >= 40 ? CLOUDY : CLEAR;   // up to ~40 % is 'mostly clear'
            if ((k == CLEAR || k == CLOUDY || k == OVERCAST) && !Float.isNaN(vis)) {
                if (vis < 1000) k = FOG;
                else if (vis < 4000) k = MIST;
            }
            if ((k == CLEAR || k == CLOUDY) && !Float.isNaN(wind) && wind >= 35) k = WINDY;
        }
        return k;
    }

    /** How clearly you'd see the Sun / Moon: 1 clear, ~0.16 hidden behind weather (drawn very faint). */
    private static float clarity(int k) {
        switch (k) {
            case CLEAR: return 1f;
            case WINDY: return cloudPct >= 0 ? Math.max(0.4f, 1f - cloudPct / 100f * 0.7f) : 1f;
            case CLOUDY: return cloudPct >= 0 ? Math.max(0.4f, 1f - cloudPct / 100f * 0.7f) : 0.6f;
            case MIST: return 0.5f;
            default: return 0.28f;
        }
    }

    private static volatile int diagK = -1;
    private static volatile float diagVis = Float.NaN;
    private static final String[] COND = {"clear", "cloudy", "overcast", "rain", "drizzle", "windy", "storm", "snow",
            "sleet", "hail", "fog", "mist"};

    /** For the NetSpeed app: what the sky is drawing and why. */
    static String diag(double lat, double lon) {
        long ms = System.currentTimeMillis();
        StringBuilder b = new StringBuilder("SKY\n");
        int k = diagK;
        b.append("  showing: ").append(k >= 0 && k < COND.length ? COND[k] : "not drawn yet")
                .append(k == CLEAR && cloudPct >= 10 ? " (a few light clouds)" : "")
                .append(Float.isNaN(diagVis) ? "" : String.format(java.util.Locale.US, ", sun/moon clarity %.0f%%", diagVis * 100))
                .append('\n');
        boolean fresh = ms - wmoAt < 60 * 60_000L;
        b.append("  weather app code ").append(wx).append(" -> ").append(name(fromYahoo(wx))).append('\n');
        b.append("  Open-Meteo ").append(fresh ? "" : "(stale) ").append("WMO ").append(wmo).append(" -> ").append(name(fromWmo(wmo)))
                .append(", cloud ").append(cloudPct).append("%, vis ")
                .append(Float.isNaN(visM) ? "?" : String.format(java.util.Locale.US, "%.1f km", visM / 1000f))
                .append(", wind ").append(Float.isNaN(windKmh) ? "?" : Math.round(windKmh) + " km/h").append('\n');
        if (obsWx != null) {
            int o = obsKind();
            b.append(String.format(java.util.Locale.US, "  airport %s %.0f km, %d min ago: %s%s -> %s%n", obsStation, obsKm,
                    (ms - obsAt) / 60_000L, obsWx.isEmpty() ? "no weather" : obsWx,
                    Float.isNaN(obsTemp) ? "" : String.format(java.util.Locale.US, ", %.0f°", obsTemp),
                    o < 0 ? "too old / far, not used" : o == OBS_DRY ? "dry" : name(o)));
        } else b.append("  airport report: none yet\n");
        try {
            Astro.Pos s = Astro.sun(ms, lat, lon);
            Astro.Moon m = Astro.moon(ms, lat, lon);
            b.append(String.format(java.util.Locale.US, "  sun %.1f° high, az %.0f°%s%n", s.alt, s.az, s.alt < -0.6 ? " (set, not drawn)" : ""));
            b.append(String.format(java.util.Locale.US, "  moon %.1f° high, az %.0f°, %.0f%% lit%s%n", m.alt, m.az, m.illum * 100,
                    m.alt < -0.3 ? " (set, not drawn)" : ""));
        } catch (Throwable ignored) { }
        b.append("  outside fade requests ignored: ").append(alphaAsks)
                .append(alphaAsks > 0 ? String.format(java.util.Locale.US, " (last %.0f%%)", lastAsk * 100) : "").append('\n');
        return b.toString();
    }

    private static String name(int k) {
        return k >= 0 && k < COND.length ? COND[k] : "unknown";
    }

    // ------------------------------------------------------------------ geometry

    /** Camera hole centre in this view's pixels (top centre if the phone reports none). */
    private void cam(int w, int h) {
        long now = SystemClock.uptimeMillis();
        if (now - camAt < 10_000 && !Float.isNaN(camX)) return;
        camAt = now;
        camX = w / 2f;
        camY = h * 0.38f;
        try {
            android.view.WindowInsets wi = getRootWindowInsets();
            android.view.DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc == null) return;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            for (android.graphics.Rect r : dc.getBoundingRects()) {
                if (r.top > loc[1] + h || r.width() <= 0) continue;
                camX = r.exactCenterX() - loc[0];
                camY = Math.max(0, Math.min(h * 0.6f, r.exactCenterY() - loc[1]));
                break;
            }
        } catch (Throwable ignored) { }
    }

    /**
     * Sky position to bar pixels: the camera hole is straight overhead, the bottom edge and the far
     * left / right are the horizon; east to the left, west to the right. Height above the horizon decides
     * how far down the bar it sits, the east-west part of its direction how far to the side.
     */
    private long setMs, riseMs;

    /** Sun's horizon crossings around now (last set, next rise), found by stepping the real sun position. */
    private void nightSpan(long ms) {
        if (setMs > 0 && ms >= setMs && ms < riseMs) return;
        long st = 0, rs = 0;
        try {
            for (long t = ms; t > ms - 20 * 3600_000L; t -= 5 * 60_000L)
                if (Astro.sun(t, lat, lon).alt > -0.833) { st = t; break; }
            for (long t = ms; t < ms + 20 * 3600_000L; t += 5 * 60_000L)
                if (Astro.sun(t, lat, lon).alt > -0.833) { rs = t; break; }
        } catch (Throwable ignored) { }
        setMs = st;
        riseMs = rs;
    }

    /**
     * Night: a small dim dot along the bottom edge for the Sun under the horizon, sliding from the right
     * (where it set, west) to the left (where it rises, east) with the time of night.
     */
    private void drawSunBelow(Canvas c, int w, int h) {
        long ms = System.currentTimeMillis();
        nightSpan(ms);
        if (setMs <= 0 || riseMs <= setMs) return;
        float f = Math.max(0f, Math.min(1f, (ms - setMs) / (float) (riseMs - setMs)));
        float m = 6 * dens;
        float x = (w - m) - f * (w - 2 * m);
        float y = h - 2.5f * dens;
        float r = 2.2f * dens;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(x, y, r * 3.5f, new int[]{0x55FF9A40, 0}, null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r * 3.5f, p);
        p.setShader(null);
        p.setColor(0xCCFFB060);
        c.drawCircle(x, y, r, p);
    }

    private float[] place(double alt, double az, int w, int h, float r) {
        double rho = Math.max(0, Math.min(1, (90 - alt) / 90));
        double side = Math.sin(Math.toRadians(az));           // +1 due east, -1 due west
        float m = r * 1.1f;
        float reachL = Math.max(1, camX - m), reachR = Math.max(1, w - m - camX);
        float x = (float) (camX - side * rho * (side > 0 ? reachL : reachR));
        float y = (float) (camY + rho * Math.max(1, h - m - camY));
        return new float[]{x, y};
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        if (!Cfg.b(Cfg.SKY, Cfg.D_SKY)) {
            postInvalidateDelayed(3000);
            return;
        }
        fitEdges();
        if (getAlpha() < 0.99f) {          // faded by an animation (skips onSetAlpha): put it back
            alphaAsks++;
            lastAsk = getAlpha();
            setAlpha(1f);
        }
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        long now = SystemClock.uptimeMillis();
        float t = (now - t0) / 1000f;
        if (now - locAt > 600_000) {
            locAt = now;
            try {
                android.location.Location l = TowerDb.myLocation(getContext());
                if (l != null) { lat = l.getLatitude(); lon = l.getLongitude(); }
            } catch (Throwable ignored) { }
            astroAt = 0;
        }
        if (sunPos == null || now - astroAt > 20_000) {
            astroAt = now;
            long ms = System.currentTimeMillis();
            try {
                sunPos = Astro.sun(ms, lat, lon);
                moonPos = Astro.moon(ms, lat, lon);
            } catch (Throwable ignored) { }
        }
        cam(w, h);
        double sunAlt = sunPos == null ? 0 : sunPos.alt;
        float d = sm((sunAlt + 8) / 14.0);                     // 0 night (sun 8° down) .. 1 day (6° up)
        int k = condition();
        float vis = clarity(k);
        boolean night = d < 0.4f;
        diagK = k; diagVis = vis;
        boolean moving;

        if (night && Cfg.b(Cfg.NIGHT, Cfg.D_NIGHT) && (k == CLEAR || k == CLOUDY || k == WINDY)) {
            drawNightClear(c, w, h, t, k);
            moving = true;
        } else {
            background(c, w, h, k, d);
            if (night && (k == CLOUDY || k == WINDY || k == CLEAR)) stars(c, w, h, t, k == CLOUDY ? 0.45f : 1f);
            moving = night;
        }
        // readability wash under the Sun / Moon / weather, so it never bleaches them
        // white text: a firmer dark veil by day (stronger under clouds); dark text: the light wash in contrast()
        contrast(c, w, h, d > 0.4f ? (k == CLEAR && cloudPct < 10 ? 0x38000000 : 0x58000000) : 0x18000000, k == CLEAR && d > 0.4f);
        // bodies: real places, faint when the weather hides them; the Moon is paler by day
        if (moonPos != null && moonPos.alt > -0.3) {
            float mv = vis * (d > 0.5f ? 0.55f + 0.45f * (1 - d) : 1f);
            drawMoon(c, w, h, mv, vis < 0.35f);
        }
        if (sunPos != null && sunPos.alt > -0.6) drawSun(c, w, h, vis, vis < 0.35f, k);
        else if (sunPos != null) drawSunBelow(c, w, h);
        // weather on top
        moving |= weather(c, w, h, t, k, d);
        if (!darkText && d > 0.4f && k != CLEAR) {             // white text over clouds / rain: a light veil on top too
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x26000000);
            c.drawRect(0, 0, w, h, p);
        }

        long next = lowBatt() ? 30000 : !ScreenState.on() ? 3000 : moving ? (night ? 200 : 66) : 5000;
        postInvalidateDelayed(next);
    }

    /** {top, bottom} colours for a condition, day and night, blended by daylight d. */
    private void background(Canvas c, int w, int h, int k, float d) {
        int dayT, dayB, nT, nB;
        float warmK = 0;
        switch (k) {
            case OVERCAST: dayT = 0xFF8A929C; dayB = 0xFFB4BAC2; nT = 0xFF15171C; nB = 0xFF23262E; break;
            case RAIN:     dayT = 0xFF5B6573; dayB = 0xFF7D8794; nT = 0xFF0E1116; nB = 0xFF1A1E26; break;
            case DRIZZLE:  dayT = 0xFF7A8591; dayB = 0xFFA3ACB6; nT = 0xFF12151B; nB = 0xFF20242C; break;
            case STORM:    dayT = 0xFF2E3240; dayB = 0xFF4A4458; nT = 0xFF07080C; nB = 0xFF15121E; break;
            case SNOW:     dayT = 0xFFB9C4D0; dayB = 0xFFDDE4EC; nT = 0xFF1A1F2A; nB = 0xFF2B3240; break;
            case SLEET:    dayT = 0xFF8E99A6; dayB = 0xFFB7C0CA; nT = 0xFF141820; nB = 0xFF252A34; break;
            case HAIL:     dayT = 0xFF4E5663; dayB = 0xFF7A8290; nT = 0xFF0D1015; nB = 0xFF1E222B; break;
            case FOG:      dayT = 0xFFA9AEB4; dayB = 0xFFC9CDD1; nT = 0xFF1C1E22; nB = 0xFF2C2F34; break;
            case MIST:     dayT = 0xFF8FAAC6; dayB = 0xFFC3D2E0; nT = 0xFF141A26; nB = 0xFF262D3A; warmK = 0.5f; break;
            case CLOUDY:   dayT = 0xFF6F98C8; dayB = 0xFFAFCBE6; nT = 0xFF0B0E22; nB = 0xFF1C2244; warmK = 0.7f; break;
            default:
                // clear: a pale blue tint over the whole bar (deeper when the bar's text is white)
                dayT = darkText ? 0xFFB9DAF7 : 0xFF4A8FD8;
                dayB = darkText ? 0xFFE0EFFC : 0xFF7DB4E8;
                nT = 0xFF080A20; nB = 0xFF1C2250; warmK = 1f; break;
        }
        int top = lerp(nT, dayT, d), bot = lerp(nB, dayB, d);
        float warm = 4 * d * (1 - d) * warmK;                 // sunrise / sunset glow
        top = lerp(top, 0xFF463C78, warm);
        bot = lerp(bot, 0xFFFA965A, warm);
        if (grad == null || gTop != top || gBot != bot || gH != h) {
            grad = new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP);
            gTop = top; gBot = bot; gH = h;
        }
        p.setShader(grad);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }

    private void stars(Canvas c, int w, int h, float t, float amount) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < sx.length; i++) {
            if (amount < 1f && (i % 2 == 1)) continue;
            float b = 0.5f + 0.5f * (float) Math.sin(t * 0.9f + sph[i]);
            p.setColor(alpha(0xFFFFFFFF, amount * (0.3f + 0.6f * b)));
            c.drawCircle(sx[i] * w, 2 + sy[i] * (h - 6), dens * (0.45f + 0.55f * b), p);
        }
    }

    /**
     * Realistic sun: limb-darkened disc and a glow that follows the sky.
     *  clear      - crisp warm-yellow disc, tight bright glow
     *  clouds     - the glow spreads wide and turns whiter (light scattered by the cloud), the disc softens
     *  haze/dust  - (low visibility, mist, poor air) the disc turns pale orange, the glow goes wide and dull
     *  overcast.. - only a broad, soft bright patch with a faint disc outline where the Sun is
     * Low in the sky everything shifts to orange-red.
     */
    private void drawSun(Canvas c, int w, int h, float vis, boolean faint, int k) {
        float r = h * 0.12f;
        float[] xy = place(sunPos.alt, sunPos.az, w, h, r);
        float x = xy[0], y = xy[1];
        float hi = sm((sunPos.alt - 1) / 20.0);               // 0 at the horizon .. 1 high
        boolean fresh = System.currentTimeMillis() - wmoAt < 60 * 60_000L;
        // cloud cover 0..1
        float cover = fresh && cloudPct >= 0 ? cloudPct / 100f
                : k == CLEAR ? 0f : k == CLOUDY || k == WINDY ? 0.55f : k == MIST || k == FOG ? 0.3f : 0.95f;
        // haze 0..1: visibility under ~15 km, mist / fog, or poor air
        float haze = 0f;
        if (fresh && !Float.isNaN(visM)) haze = Math.max(haze, Math.min(1f, (15000f - visM) / 11000f));
        if (k == MIST) haze = Math.max(haze, 0.6f);
        if (k == FOG) haze = 1f;
        if (aqi > 100) haze = Math.max(haze, Math.min(0.8f, (aqi - 100) / 150f));
        haze = Math.max(0f, haze);

        int core = lerp(0xFFFFB066, 0xFFFFE680, hi);          // deep yellow-orange, stands out on a pale sky
        int limb = lerp(0xFFFF5A10, 0xFFFFA41C, hi);
        int glow = lerp(0xFFFF6A1C, 0xFFFFB81A, hi);
        // haze: paler, more orange disc and a duller glow; clouds: whiter glow
        core = lerp(core, 0xFFFFE2C0, haze * 0.7f);
        limb = lerp(limb, 0xFFFF9A5A, haze * 0.6f);
        glow = lerp(glow, 0xFFFFC8A0, haze * 0.6f);
        glow = lerp(glow, 0xFFFFF6E6, cover * 0.85f);

        p.setStyle(Paint.Style.FILL);
        // wide soft bloom: grows with cloud and haze (light spread across the sky)
        float bloom = cover * 0.9f + haze * 0.6f;
        if (bloom > 0.08f) {
            float br = r * (5f + 4f * Math.min(1f, bloom));
            float ba = Math.min(0.32f, 0.12f + 0.2f * bloom) * Math.max(0.5f, vis + 0.3f);
            p.setShader(new RadialGradient(x, y, br, new int[]{alpha(glow, ba), alpha(glow, ba * 0.4f), 0},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, br, p);
        }
        // inner glow: tight and bright when clear, weaker and wider with cloud / haze
        float gr = r * (3.6f + 1.6f * cover + 1.2f * haze) * (faint ? 0.8f : 1f);
        float ga = (0.9f - 0.35f * cover - 0.25f * haze) * (faint ? 0.6f : 1f);
        p.setShader(new RadialGradient(x, y, gr, new int[]{alpha(glow, Math.max(0.12f, ga) * Math.max(vis, 0.4f)),
                alpha(glow, 0.18f * Math.max(vis, 0.4f)), 0}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, gr, p);
        if (faint) {                                           // behind rain / storm cloud: only a soft bright patch, no disc
            p.setShader(new RadialGradient(x, y, r * 1.6f, new int[]{alpha(core, 0.5f), alpha(glow, 0.22f), 0},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, r * 1.6f, p);
            p.setShader(null);
            return;
        }
        // disc with limb darkening; edge softer through haze / thin cloud
        float edge = Math.min(0.6f, 0.15f * cover + 0.35f * haze);
        p.setShader(new RadialGradient(x, y, r * (1f + edge * 0.25f),
                new int[]{alpha(core, vis), alpha(core, vis), alpha(limb, vis * (0.95f - edge * 0.5f)), alpha(limb, 0)},
                new float[]{0f, 0.5f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r * (1f + edge * 0.25f), p);
        p.setShader(null);
    }

    /** The Moon with its real phase, lit side turned to the Sun, faint grey seas; very faint behind weather. */
    private void drawMoon(Canvas c, int w, int h, float vis, boolean faint) {
        float r = h * 0.12f;
        float[] xy = place(moonPos.alt, moonPos.az, w, h, r);
        float x = xy[0], y = xy[1];
        float k = (float) moonPos.illum;
        // which way is "up" (towards overhead = the camera) from the Moon, then turn by the bright limb angle
        float ux = camX - x, uy = camY - y;
        float ul = (float) Math.hypot(ux, uy);
        if (ul < r) { ux = 0; uy = -1; } else { ux /= ul; uy /= ul; }
        double th = Math.toRadians(-moonPos.limbFromZenith);  // east is to the left on this map
        float lx = (float) (ux * Math.cos(th) - uy * Math.sin(th)), ly = (float) (ux * Math.sin(th) + uy * Math.cos(th));
        float rot = (float) Math.toDegrees(Math.atan2(ly, lx));

        // glow, stronger near full
        p.setStyle(Paint.Style.FILL);
        float gr = r * 3f;
        p.setShader(new RadialGradient(x, y, gr, new int[]{alpha(0xFFDCE6FF, (faint ? 0.10f : 0.30f) * vis * (0.2f + k)), 0},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, gr, p);
        p.setShader(null);
        // dark side (earthshine)
        p.setColor(alpha(0xFF2C3244, (faint ? 0.25f : 0.6f) * Math.min(1f, vis * 1.6f)));
        c.drawCircle(x, y, r, p);
        // lit part, drawn with the lit side on +x, then rotated into place
        c.save();
        c.rotate(rot, x, y);
        path.reset();
        rf.set(x - r, y - r, x + r, y + r);
        path.addArc(rf, -90, 180);
        path.close();
        float ew = Math.abs(1 - 2 * k) * r;
        cut.reset();
        cut.addOval(new RectF(x - ew, y - r, x + ew, y + r), Path.Direction.CW);
        path.op(cut, k < 0.5f ? Path.Op.DIFFERENCE : Path.Op.UNION);
        p.setColor(alpha(0xFFF4F1E4, vis));
        c.drawPath(path, p);
        // a few grey seas inside the lit part, so it reads as the Moon
        if (!faint && r > 6) {
            c.save();
            c.clipPath(path);
            c.rotate(-rot, x, y);                              // seas stay fixed to the Moon's face, not the light
            p.setColor(alpha(0xFF9A9A92, 0.35f * vis));
            c.drawCircle(x - r * 0.25f, y - r * 0.30f, r * 0.30f, p);
            c.drawCircle(x + r * 0.20f, y - r * 0.05f, r * 0.24f, p);
            c.drawCircle(x - r * 0.05f, y + r * 0.35f, r * 0.18f, p);
            c.restore();
        }
        c.restore();
        if (faint) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, dens * 0.7f));
            p.setColor(alpha(0xFFE6EBF5, 0.32f));
            c.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    /** Clouds, rain, snow, fog ... Returns true when something on screen moves. */
    private boolean weather(Canvas c, int w, int h, float t, int k, float d) {
        boolean moving = false;
        int n;
        switch (k) {
            case CLOUDY: n = 4; break;
            case WINDY: n = cloudPct >= 25 ? 3 : 0; break;
            case OVERCAST: case RAIN: case STORM: case SLEET: case HAIL: n = 7; break;
            case DRIZZLE: case SNOW: n = 6; break;
            case CLEAR:                                        // a few light clouds from 10 % cover; none below
                n = cloudPct >= 10 && System.currentTimeMillis() - wmoAt < 60 * 60_000L ? Math.min(3, 1 + (cloudPct - 10) / 10) : 0;
                break;
            default: n = 0;                                    // fog, mist: no clouds drifting
        }
        if (n > 0) {
            moving = true;
            boolean dark = k == STORM || k == RAIN || k == HAIL;
            int cc = lerp(0xFF565E80, 0xFFFFFFFF, d);
            if (k != CLOUDY && k != WINDY && k != CLEAR) cc = lerp(cc, dark ? lerp(0xFF2A2E38, 0xFF6E7684, d) : lerp(0xFF4A5060, 0xFFA2AAB6, d), 0.75f);
            if (cloudTint != cc) { cloudTint = cc; cloudFilter = new android.graphics.PorterDuffColorFilter(cc, android.graphics.PorterDuff.Mode.MULTIPLY); }
            cp.setColorFilter(cloudFilter);
            int ca = k == CLEAR ? 150 : n > 4 ? 235 : 200;      // light, see-through puffs on a clear day
            if (!darkText && d > 0.4f) ca = ca * 2 / 3;            // white text: softer clouds so it stays readable
            cp.setAlpha(ca);
            float u = h / 96f, speed = k == WINDY || k == STORM ? 4f : 1f;
            for (int i = 0; i < n; i++) {
                Bitmap bm = clouds[i % clouds.length];
                float sc = cs[i] * u * (k == CLEAR ? 0.8f : n > 4 ? 1.5f : 1.1f);
                float bw = bm.getWidth() * sc * 0.9f, bh = bm.getHeight() * sc * 0.9f;
                float x = ((cx[i] * (w + bw) + t * cv[i] * speed * dens * 0.6f) % (w + bw)) - bw, y = cy[i] * h - bh * 0.55f;
                rf.set(x, y, x + bw, y + bh);
                c.drawBitmap(bm, null, rf, cp);
            }
        }
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        switch (k) {
            case RAIN: rain(c, w, h, t, 90, 260, 9, 0.55f, 0.8f); moving = true; break;
            case DRIZZLE: rain(c, w, h, t, 50, 150, 4, 0.40f, 0.6f); moving = true; break;
            case STORM:
                rain(c, w, h, t, 90, 320, 11, 0.6f, 0.9f);
                lightning(c, w, h, t);
                moving = true;
                break;
            case SNOW: flakes(c, w, h, t, rx.length, 40, 1.2f); moving = true; break;
            case SLEET:
                rain(c, w, h, t, 45, 220, 6, 0.5f, 0.7f);
                flakes(c, w, h, t, 45, 90, 0.9f);
                moving = true;
                break;
            case HAIL: hail(c, w, h, t); moving = true; break;
            case FOG: fog(c, w, h, t, 0.42f, 3); moving = true; break;
            case MIST: fog(c, w, h, t, 0.18f, 1); moving = true; break;
            case WINDY: wind(c, w, h, t); moving = true; break;
            default: break;
        }
        return moving;
    }

    private void rain(Canvas c, int w, int h, float t, int n, float speed, float len, float a, float width) {
        p.setColor(alpha(0xFFBED2EB, a));
        p.setStrokeWidth(Math.max(1f, dens * width));
        for (int i = 0; i < Math.min(n, rx.length); i++) {
            float y = (ry[i] * h + t * speed * dens) % h, x = rx[i] * w;
            c.drawLine(x, y, x - len * 0.33f * dens, y + len * dens, p);
        }
    }

    private void flakes(Canvas c, int w, int h, float t, int n, float speed, float size) {
        p.setColor(alpha(0xFFFFFFFF, 0.8f));
        for (int i = 0; i < Math.min(n, rx.length); i++) {
            int j = rx.length - 1 - i;
            float y = (ry[j] * h + t * speed * dens) % h, x = rx[j] * w + (float) Math.sin(t + j) * 4 * dens;
            c.drawCircle(x, y, dens * size, p);
        }
    }

    /** White pellets falling fast, bouncing off the bottom edge. */
    private void hail(Canvas c, int w, int h, float t) {
        p.setColor(alpha(0xFFF4F8FF, 0.9f));
        for (int i = 0; i < 60; i++) {
            float cyc = (ry[i] + t * 1.6f) % 1.2f, x = rx[i] * w;
            float y;
            if (cyc < 1f) y = cyc * h;
            else { float b = (cyc - 1f) / 0.2f; y = h - (float) Math.sin(Math.PI * b) * h * 0.18f; x += b * 6 * dens; }
            c.drawCircle(x, y, dens * 1.6f, p);
        }
    }

    /** Soft drifting grey bands. */
    private void fog(Canvas c, int w, int h, float t, float a, int bands) {
        p.setColor(alpha(0xFFC8CDD4, a * 0.6f));
        c.drawRect(0, 0, w, h, p);
        for (int i = 0; i < bands; i++) {
            float yc = h * (0.3f + 0.25f * i), bh = h * 0.35f;
            float shift = (float) Math.sin(t * 0.08f + i * 1.7f) * w * 0.15f;
            p.setShader(new LinearGradient(0, yc - bh, 0, yc + bh, new int[]{0, alpha(0xFFD5D9DE, a), 0},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(-w * 0.2f + shift, yc - bh, w * 1.2f + shift, yc + bh, p);
        }
        p.setShader(null);
    }

    /** Fast thin streaks blowing across. */
    private void wind(Canvas c, int w, int h, float t) {
        p.setStrokeWidth(Math.max(1f, dens * 0.8f));
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < wlx.length; i++) {
            float len = wll[i] * w;
            float x = ((wlx[i] * (w + len) + t * (220 + i * 9) * dens) % (w + len)) - len;
            float y = wly[i] * h + (float) Math.sin(t * 2 + i) * 2 * dens;
            p.setColor(alpha(0xFFFFFFFF, 0.28f));
            c.drawLine(x, y, x + len, y, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    /** A flash and a jagged bolt every 6-9 seconds. */
    private void lightning(Canvas c, int w, int h, float t) {
        float period = 7.5f;
        int n = (int) (t / period);
        float ph = t - n * period - (n * 37 % 3);
        if (ph < 0 || ph > 0.35f) return;
        float a = ph < 0.08f ? 1f : ph < 0.14f ? 0.3f : ph < 0.2f ? 0.8f : 1f - (ph - 0.2f) / 0.15f;
        p.setColor(alpha(0xFFE6E9FF, 0.35f * a));
        c.drawRect(0, 0, w, h, p);
        Random r = new Random(n * 7919L);
        float x = w * (0.1f + 0.8f * r.nextFloat()), y = 0;
        path.reset();
        path.moveTo(x, y);
        while (y < h) {
            y += h * (0.12f + 0.12f * r.nextFloat());
            x += (r.nextFloat() - 0.5f) * 14 * dens;
            path.lineTo(x, Math.min(y, h));
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.2f, dens * 1.3f));
        p.setColor(alpha(0xFFFFFFFF, a));
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
    }

    // ---- Clear (or partly cloudy) night: dark sky, stars, shooting stars. The Moon is drawn by onDraw.
    private void drawNightClear(Canvas c, int w, int h, float t, int k) {
        p.setStyle(Paint.Style.FILL);
        if (grad == null || gTop != 0x02030A || gH != h) {
            grad = new LinearGradient(0, 0, 0, h, 0xFF02030A, 0xFF0C1030, Shader.TileMode.CLAMP);
            gTop = 0x02030A; gBot = 0; gH = h;
        }
        p.setShader(grad);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
        stars(c, w, h, t, k == CLOUDY ? 0.45f : 1f);
        if (k == CLEAR) {
            // shooting star every ~40 s
            float cyc = t % 40f;
            if (cyc < 0.8f) {
                int n = (int) (t / 40f);
                float x0 = w * (0.15f + ((n * 37) % 70) / 100f), y0 = h * (0.05f + ((n * 53) % 30) / 100f), f = cyc / 0.8f;
                p.setStrokeWidth(dens * 1.2f);
                p.setColor(alpha(0xFFFFFFFF, 1f - f));
                float hx = x0 + f * 90 * dens, hy = y0 + f * 40 * dens;
                c.drawLine(hx - 28 * dens, hy - 12 * dens, hx, hy, p);
            }
        }
    }
}
