package com.netspeed.xposed;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

/** Network nodes: your phone (centre) linked to three cells around it. */
final class NodesDrawable extends Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int size;

    NodesDrawable(int color, int sizePx) {
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        size = sizePx;
        setBounds(0, 0, size, size);
    }

    @Override
    public void draw(Canvas c) {
        float l = getBounds().left, t = getBounds().top, s = getBounds().width();
        float cx = l + s / 2f, cy = t + s * 0.56f;
        float[][] pts = {{l + s * 0.12f, t + s * 0.86f}, {l + s * 0.88f, t + s * 0.86f}, {cx, t + s * 0.12f}};
        p.setStrokeWidth(Math.max(1f, s * 0.09f));
        for (float[] q : pts) c.drawLine(cx, cy, q[0], q[1], p);
        for (float[] q : pts) c.drawCircle(q[0], q[1], s * 0.13f, p);
        c.drawCircle(cx, cy, s * 0.16f, p);
    }

    @Override public int getIntrinsicWidth() { return size; }
    @Override public int getIntrinsicHeight() { return size; }
    @Override public void setAlpha(int a) { p.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
