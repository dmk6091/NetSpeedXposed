package com.netspeed.xposed;

import java.util.Locale;

/**
 * Maharashtra dams that CWC does not list (Kasarsai, Jadhavwadi, ...): the nearest named dam or weir from OpenStreetMap,
 * then its page on mumbailakewaterlevel.in (an independent site that republishes Maharashtra WRD's daily live storage:
 * /maharashtra-dams/&lt;district&gt;/&lt;dam&gt;). Used by {@link Dam#refresh}; a failure leaves the CWC dam as it was.
 */
final class DamMh {
    private DamMh() {}

    static final class Hit {
        Dam.Res res;
        Dam.Reading rd;
        double km;
    }

    static volatile String why = "not tried yet";
    private static String key = "";
    private static long at;
    private static Hit last;

    private static String district() {
        String d = EarthLine.district == null ? "" : EarthLine.district;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("([A-Za-z .'-]+?)\\s+district").matcher(d);
        String s = "";
        while (m.find()) s = m.group(1);
        s = s.replaceAll("^.*,\\s*", "").trim().toLowerCase(Locale.ROOT);
        return s.replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
    }

    private static String slug(String name) {
        String s = name.toLowerCase(Locale.ROOT).trim();
        s = s.replaceAll("\\b(dam|reservoir|lake|project|barrage)\\b", " ").replaceAll("[^a-z0-9]+", " ").trim();
        return s.replace(' ', '-');
    }

    private static String get(String url, int timeout) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(8_000);
        c.setReadTimeout(timeout);
        c.setRequestProperty("User-Agent", "NetSpeedXposed/1.0 (status bar module; github.com/dmk6091/NetSpeedXposed)");
        int rc = c.getResponseCode();
        if (rc != 200) throw new java.io.IOException("HTTP " + rc);
        StringBuilder sb = new StringBuilder();
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String ln;
            while ((ln = r.readLine()) != null) sb.append(ln).append('\n');
        }
        return sb.toString();
    }

    private static double num(String s) {
        return Double.parseDouble(s.replace(",", ""));
    }

    /** Percent, stored ML and capacity ML from a dam page; null when the page does not carry a percentage. */
    static Dam.Reading parse(String html) {
        String pct = null, date = "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?is)<title>[^<]*?([0-9]+(?:\\.[0-9]+)?)\\s*%\\s*\\((\\d{4}-\\d{2}-\\d{2})\\)").matcher(html);
        if (m.find()) { pct = m.group(1); date = m.group(2); }
        String txt = html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ").replaceAll("(?s)<[^>]+>", " ").replaceAll("&nbsp;", " ").replaceAll("\\s+", " ");
        if (pct == null) {
            m = java.util.regex.Pattern.compile("(?i)today'?s storage\\s*([0-9]+(?:\\.[0-9]+)?)\\s*%").matcher(txt);
            if (m.find()) pct = m.group(1);
        }
        if (pct == null) return null;
        double p = num(pct);
        double stored = Double.NaN, cap = Double.NaN;
        m = java.util.regex.Pattern.compile("(?i)stored\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*ML").matcher(txt);
        if (m.find()) stored = num(m.group(1));
        m = java.util.regex.Pattern.compile("(?i)capacity\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*ML").matcher(txt);
        if (m.find()) cap = num(m.group(1));
        if (Double.isNaN(cap) && !Double.isNaN(stored) && p > 0) cap = stored / p * 100;
        if (Double.isNaN(stored) && !Double.isNaN(cap)) stored = cap * p / 100;
        if (Double.isNaN(stored) || Double.isNaN(cap) || cap <= 0) return null;
        Dam.Reading g = new Dam.Reading();
        g.storage = stored / 1e6;     // ML -> BCM
        g.liveCap = cap / 1e6;
        g.pct = p;
        g.date = date;
        return g;
    }

    /** Nearest dam on the site within 30 km of here, or null. Cached 3 h per spot (30 min after a miss). */
    static synchronized Hit find(double lat, double lon, long now) throws Exception {
        String dist = district();
        String k = String.format(Locale.US, "%.2f,%.2f,%s", lat, lon, dist);
        if (k.equals(key) && now - at < (last != null ? 3 * 3600_000L : 30 * 60_000L)) return last;
        key = k; at = now; last = null;
        if (dist.isEmpty()) { why = "no district known yet"; return null; }
        String q = String.format(Locale.US, "[out:json][timeout:25];(way[\"waterway\"=\"dam\"][\"name\"](around:30000,%1$.5f,%2$.5f);"
                + "way[\"natural\"=\"water\"][\"water\"=\"reservoir\"][\"name\"](around:30000,%1$.5f,%2$.5f););out tags center 60;", lat, lon);
        String body = null;
        String codes = "";
        for (String ep : new String[]{"https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter", "https://overpass.kumi.systems/api/interpreter"}) {
            try {
                String r = get(ep + "?data=" + java.net.URLEncoder.encode(q, "UTF-8"), 30_000);
                if (r.trim().startsWith("{") && r.contains("\"elements\"")) { body = r; break; }
                codes += "(not json) ";
            } catch (Throwable t) { codes += t.getClass().getSimpleName() + " "; }
        }
        if (body == null) { why = "OpenStreetMap lookup failed: " + codes; return null; }
        org.json.JSONArray els = new org.json.JSONObject(body).optJSONArray("elements");
        java.util.List<Object[]> cand = new java.util.ArrayList<>();   // {name, lat, lon, km}
        for (int i = 0; els != null && i < els.length(); i++) {
            org.json.JSONObject e = els.optJSONObject(i);
            if (e == null) continue;
            org.json.JSONObject tg = e.optJSONObject("tags"), ce = e.optJSONObject("center");
            if (tg == null || ce == null) continue;
            String nm = tg.optString("name:en", "");
            if (nm.isEmpty()) nm = tg.optString("name", "");
            if (slug(nm).isEmpty() || !slug(nm).matches("[a-z0-9-]+")) continue;   // no Latin-letter name: skip
            double la = ce.optDouble("lat"), lo = ce.optDouble("lon");
            cand.add(new Object[]{nm, la, lo, Dam.km(lat, lon, la, lo)});
        }
        java.util.Collections.sort(cand, (a, b) -> Double.compare((Double) a[3], (Double) b[3]));
        int tried = 0;
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        StringBuilder log = new StringBuilder();
        for (Object[] c : cand) {
            String sl = slug((String) c[0]);
            if (!seen.add(sl)) continue;
            if (++tried > 6) break;
            try {
                Dam.Reading g = parse(get("https://mumbailakewaterlevel.in/maharashtra-dams/" + dist + "/" + sl, 15_000));
                if (g == null) { log.append(sl).append(": no figure; "); continue; }
                Hit h = new Hit();
                Dam.Res r = new Dam.Res();
                r.uid = "MH:" + dist + "/" + sl;
                String nm = (String) c[0];
                r.name = nm.replaceAll("(?i)\\s+(dam|reservoir)$", "").trim();
                r.lat = (Double) c[1]; r.lon = (Double) c[2];
                r.liveCap = g.liveCap;
                h.res = r; h.rd = g; h.km = (Double) c[3];
                last = h;
                why = r.name + " " + Math.round(g.pct) + "% from mumbailakewaterlevel.in/" + dist + "/" + sl + " (" + g.date + ")";
                return h;
            } catch (Throwable t) {
                log.append(sl).append(": ").append(t.getClass().getSimpleName()).append(' ').append(t.getMessage() == null ? "" : t.getMessage()).append("; ");
            }
        }
        why = cand.isEmpty() ? "no named dam within 30 km in OpenStreetMap" : "no page found for " + cand.size() + " dams: " + log;
        return null;
    }
}
