package com.netspeed.xposed;

import android.content.res.Resources;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Immersive gesture navigation: the bottom inset reserved for the gesture pill
 * (navigation_bar_height) becomes 0, so apps draw to the bottom edge and the pill floats
 * over them. The pill's own window (navigation_bar_frame_height) and the gesture area
 * (navigation_bar_gesture_height) are left alone, so the pill and swipes keep working.
 *
 * Switched by the system property persist.sys.netspeed.immersive (set by the settings app
 * with root), because the system server starts long before any app's settings are readable.
 * Needs a reboot to apply.
 */
final class NavImmersive {
    static final String PROP = "persist.sys.netspeed.immersive";
    private static final String TAG = "NetSpeedXposed: [nav] ";

    private NavImmersive() {}

    static boolean enabled() {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            return (Boolean) sp.getMethod("getBoolean", String.class, boolean.class).invoke(null, PROP, false);
        } catch (Throwable t) {
            return false;
        }
    }

    static void install(final String where) {
        if (!enabled()) return;
        Resources sys = Resources.getSystem();
        final Set<Integer> ids = new HashSet<>();
        for (String n : new String[]{"navigation_bar_height", "navigation_bar_height_landscape"}) {
            int id = sys.getIdentifier(n, "dimen", "android");
            if (id != 0) ids.add(id);
        }
        if (ids.isEmpty()) {
            XposedBridge.log(TAG + "[" + where + "] navigation bar height not found");
            return;
        }
        XC_MethodHook zero = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (!(p.args[0] instanceof Integer) || !ids.contains(p.args[0])) return;
                Object r = p.getResult();
                if (r instanceof Integer) p.setResult(0);
                else if (r instanceof Float) p.setResult(0f);
            }
        };
        int n = 0;
        for (String m : new String[]{"getDimensionPixelSize", "getDimensionPixelOffset", "getDimension"}) {
            try {
                XposedHelpers.findAndHookMethod(Resources.class, m, int.class, zero);
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "[" + where + "] hook " + m + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "[" + where + "] immersive navigation on (" + n + " hooks)");
    }
}
