package com.netspeed.xposed;

import android.content.Context;
import android.location.Location;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

/**
 * Self-learning tower map, for cells no database knows (mostly 5G). While you move, it
 * records your position and the signal strength (RSRP) of the cell each SIM is on. Once a
 * cell has enough readings spread over an area, it estimates where the tower is by fitting
 * the usual signal-loss curve (signal falls ~30 dB per 10× distance), and the distance to
 * that estimate is shown with "~". Everything stays on the phone.
 */
final class TowerLearn {
    private static final String TAG = "NetSpeedXposed: [learn] ";
    private static final int MAX_SAMPLES = 150;
    private static final int MIN_SAMPLES = 8;
    /** Readings must cover at least this much ground (bounding box diagonal). */
    private static final double MIN_SPREAD_M = 300;
    private static final double MIN_MOVE_M = 40;

    /** Per cell key: samples {lat, lon, rsrp}. */
    private static final Map<String, List<double[]>> SAMPLES = new HashMap<>();
    /** Per cell key: estimated tower {lat, lon} (null = not enough data yet). */
    private static final Map<String, double[]> ESTIMATE = new HashMap<>();
    private static boolean sLoaded = false;
    private static long sLastSave = 0;

    private TowerLearn() {}

    /** Adds a reading for this cell if you've moved since the last one. */
    static void sample(Context ctx, String key, int rsrp) {
        if (key == null || rsrp < -150 || rsrp > -30) return;
        Location me = TowerDb.freshLocation(ctx, 30_000, 60);
        if (me == null) return;
        load(ctx);
        boolean changed = false;
        synchronized (SAMPLES) {
            List<double[]> list = SAMPLES.get(key);
            if (list == null) {
                list = new ArrayList<>();
                SAMPLES.put(key, list);
            }
            if (!list.isEmpty()) {
                double[] last = list.get(list.size() - 1);
                float[] d = new float[1];
                Location.distanceBetween(last[0], last[1], me.getLatitude(), me.getLongitude(), d);
                if (d[0] < MIN_MOVE_M) return;
            }
            list.add(new double[]{me.getLatitude(), me.getLongitude(), rsrp});
            if (list.size() > MAX_SAMPLES) list.remove(0);
            changed = true;
            double[] est = estimate(list);
            if (est != null && ESTIMATE.get(key) == null) {
                XposedBridge.log(TAG + key + " tower position learned from " + list.size() + " readings");
            }
            ESTIMATE.put(key, est);
        }
        if (changed && System.currentTimeMillis() - sLastSave > 60_000) save(ctx);
    }

    /** Distance from the phone to this cell's learned tower, or -1 if not learned yet. */
    /** Self-learned tower position {lat, lon}, or null while there isn't enough data. */
    static double[] position(Context ctx, String key) {
        if (key == null) return null;
        load(ctx);
        synchronized (SAMPLES) {
            double[] e = ESTIMATE.get(key);
            return e == null ? null : new double[]{e[0], e[1]};
        }
    }

    static int distance(Context ctx, String key) {
        if (key == null) return -1;
        load(ctx);
        double[] est;
        synchronized (SAMPLES) {
            est = ESTIMATE.get(key);
        }
        if (est == null) return -1;
        Location me = TowerDb.myLocation(ctx);
        if (me == null) return -1;
        float[] d = new float[1];
        Location.distanceBetween(me.getLatitude(), me.getLongitude(), est[0], est[1], d);
        return Math.round(d[0]);
    }

    /**
     * Grid search for the tower position that best explains the readings with
     * rsrp = A - 30·log10(distance), solving A in closed form for each candidate.
     */
    static double[] estimate(List<double[]> s) {
        if (s.size() < MIN_SAMPLES) return null;
        double lat0 = 0, lon0 = 0;
        for (double[] p : s) {
            lat0 += p[0];
            lon0 += p[1];
        }
        lat0 /= s.size();
        lon0 /= s.size();
        double mLat = 111_320, mLon = 111_320 * Math.cos(Math.toRadians(lat0));
        int n = s.size();
        double[] x = new double[n], y = new double[n], r = new double[n];
        double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        for (int i = 0; i < n; i++) {
            x[i] = (s.get(i)[1] - lon0) * mLon;
            y[i] = (s.get(i)[0] - lat0) * mLat;
            r[i] = s.get(i)[2];
            minX = Math.min(minX, x[i]); maxX = Math.max(maxX, x[i]);
            minY = Math.min(minY, y[i]); maxY = Math.max(maxY, y[i]);
        }
        if (Math.hypot(maxX - minX, maxY - minY) < MIN_SPREAD_M) return null;

        double bestErr = Double.MAX_VALUE, bx = 0, by = 0;
        double span = 2_500, step = 50;
        for (double gx = minX - span; gx <= maxX + span; gx += step) {
            for (double gy = minY - span; gy <= maxY + span; gy += step) {
                double sum = 0;
                double[] l = new double[n];
                for (int i = 0; i < n; i++) {
                    double d = Math.max(20, Math.hypot(x[i] - gx, y[i] - gy));
                    l[i] = 30 * Math.log10(d);
                    sum += r[i] + l[i];
                }
                double a = sum / n;
                double err = 0;
                for (int i = 0; i < n; i++) {
                    double e = r[i] - (a - l[i]);
                    err += e * e;
                }
                if (err < bestErr) {
                    bestErr = err;
                    bx = gx;
                    by = gy;
                }
            }
        }
        return new double[]{lat0 + by / mLat, lon0 + bx / mLon};
    }

    // ------------------------------------------------------------ disk

    private static File file(Context ctx) {
        return new File(ctx.getCacheDir(), "netspeed_learn.txt");
    }

    private static void load(Context ctx) {
        synchronized (SAMPLES) {
            if (sLoaded) return;
            sLoaded = true;
            try (BufferedReader rd = new BufferedReader(new FileReader(file(ctx)))) {
                String line;
                while ((line = rd.readLine()) != null) {
                    String[] p = line.split(" ");
                    if (p.length != 4) continue;
                    List<double[]> list = SAMPLES.get(p[0]);
                    if (list == null) {
                        list = new ArrayList<>();
                        SAMPLES.put(p[0], list);
                    }
                    list.add(new double[]{Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                            Double.parseDouble(p[3])});
                }
            } catch (Throwable ignored) { }
            for (Map.Entry<String, List<double[]>> e : SAMPLES.entrySet()) {
                ESTIMATE.put(e.getKey(), estimate(e.getValue()));
            }
        }
    }

    private static void save(Context ctx) {
        synchronized (SAMPLES) {
            sLastSave = System.currentTimeMillis();
            try (FileWriter w = new FileWriter(file(ctx))) {
                for (Map.Entry<String, List<double[]>> e : SAMPLES.entrySet()) {
                    for (double[] v : e.getValue()) {
                        w.write(e.getKey() + " " + v[0] + " " + v[1] + " " + (int) v[2] + "\n");
                    }
                }
            } catch (Throwable ignored) { }
        }
    }
}
