package com.netspeed.xposed;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** A radio mast sending out waves (pole on an A-frame, beacon on top, two arcs each side). */
final class MastDrawable extends Drawable {
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    private final int w, h;

    MastDrawable(int color, int widthPx, int heightPx) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(color);
        fill.setColor(color);
        w = widthPx;
        h = heightPx;
        setBounds(0, 0, w, h);
    }

    @Override
    public void draw(Canvas c) {
        float l = getBounds().left, t = getBounds().top;
        float bw = getBounds().width(), bh = getBounds().height();
        float cx = l + bw / 2f, top = t + bh * 0.30f, bottom = t + bh * 0.97f;
        stroke.setStrokeWidth(Math.max(1f, bw * 0.085f));
        // A-frame legs + cross bars
        float foot = bw * 0.20f;
        c.drawLine(cx, top, cx - foot, bottom, stroke);
        c.drawLine(cx, top, cx + foot, bottom, stroke);
        float y1 = top + (bottom - top) * 0.45f, y2 = top + (bottom - top) * 0.75f;
        float k1 = foot * 0.45f, k2 = foot * 0.75f;
        c.drawLine(cx - k1, y1, cx + k1, y1, stroke);
        c.drawLine(cx - k2, y2, cx + k2, y2, stroke);
        // beacon
        c.drawCircle(cx, top, bw * 0.085f, fill);
        // waves on both sides of the beacon
        for (float r : new float[]{bw * 0.20f, bw * 0.36f}) {
            arc.set(cx - r, top - r, cx + r, top + r);
            c.drawArc(arc, 140, 80, false, stroke);   // left
            c.drawArc(arc, -40, 80, false, stroke);   // right
        }
    }

    @Override public int getIntrinsicWidth() { return w; }
    @Override public int getIntrinsicHeight() { return h; }
    @Override public void setAlpha(int a) { stroke.setAlpha(a); fill.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { stroke.setColorFilter(cf); fill.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
