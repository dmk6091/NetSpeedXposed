package com.netspeed.xposed;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * System UI asks for this when the chosen scanner can't be started directly (the screen isn't
 * exported). It starts the saved target with root. It never takes the target from the broadcast,
 * only from the saved settings, so other apps can't make it run anything.
 */
public class LaunchReceiver extends BroadcastReceiver {
    static final String ACTION = "com.netspeed.xposed.BACKTAP_LAUNCH";

    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || !ACTION.equals(i.getAction())) return;
        SharedPreferences sp = SettingsProvider.prefs(c);
        if (!sp.getBoolean(Cfg.BT_ON, Cfg.D_BT_ON)) return;
        String uri = sp.getString(Cfg.BT_URI, "");
        if (uri.isEmpty()) return;
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                ScanFinder.Out o = ScanFinder.rootStartOut(uri);
                BtStatus.add(c.getApplicationContext(), "root start from the app: " + (o.ok ? "accepted" : "FAILED")
                        + (o.text.isEmpty() ? "" : " - " + ScanLaunch.shorten(o.text)));
            } finally {
                pr.finish();
            }
        }).start();
    }
}
