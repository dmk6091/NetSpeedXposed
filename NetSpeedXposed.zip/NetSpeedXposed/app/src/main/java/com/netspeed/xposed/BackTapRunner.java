package com.netspeed.xposed;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;

/**
 * Feeds the accelerometer (200 Hz) and gyroscope (100 Hz) into a {@link BackTapDetector} on its own
 * thread. Used by System UI (while the screen is on) and by the test screen.
 */
final class BackTapRunner implements SensorEventListener {
    final BackTapDetector det = new BackTapDetector();

    private final Context ctx;
    private HandlerThread thread;
    private SensorManager sm;
    private volatile boolean running;

    BackTapRunner(Context ctx) {
        this.ctx = ctx;
    }

    boolean isRunning() {
        return running;
    }

    /** @return false when the phone has no accelerometer */
    synchronized boolean start() {
        if (running) return true;
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return false;
        Sensor acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (acc == null) return false;
        Sensor gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        thread = new HandlerThread("netspeed-backtap", Process.THREAD_PRIORITY_URGENT_DISPLAY);
        thread.start();
        Handler h = new Handler(thread.getLooper());
        det.reset();
        // 5000 µs = 200 Hz, the most an app may ask for without the high-rate permission.
        sm.registerListener(this, acc, 5000, 0, h);
        if (gyro != null) sm.registerListener(this, gyro, 10000, 0, h);
        running = true;
        return true;
    }

    synchronized void stop() {
        if (!running) return;
        running = false;
        try {
            sm.unregisterListener(this);
        } catch (Throwable ignored) { }
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
    }

    /** One line about the sensor, for the test screen. */
    String sensorInfo() {
        try {
            SensorManager m = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            Sensor a = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a == null) return "No accelerometer found";
            Sensor g = m.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            int hz = a.getMinDelay() > 0 ? 1000000 / a.getMinDelay() : 0;
            return a.getName() + (hz > 0 ? ", up to " + hz + " Hz" : "")
                    + (g != null ? " + gyroscope" : ", no gyroscope");
        } catch (Throwable t) {
            return "";
        }
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (!running) return;
        float[] v = e.values;
        if (e.sensor.getType() == Sensor.TYPE_ACCELEROMETER) det.onAccel(e.timestamp, v[0], v[1], v[2]);
        else if (e.sensor.getType() == Sensor.TYPE_GYROSCOPE) det.onGyro(e.timestamp, v[0], v[1], v[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
