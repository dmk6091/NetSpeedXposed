package com.netspeed.xposed;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/** Samsung-style data activity arrows: a thick ↓ and ↑ side by side, each with its own color. */
final class ArrowsDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final int w, h, gap;
    private int inColor, outColor;

    /** w = width of one arrow, h = height, gap = space between them (px). */
    ArrowsDrawable(int w, int h, int gap) {
        this.w = w;
        this.h = h;
        this.gap = gap;
        paint.setStyle(Paint.Style.FILL);
    }

    void setColors(int in, int out) {
        if (in == inColor && out == outColor) return;
        inColor = in;
        outColor = out;
        invalidateSelf();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float sx = b.width() / (float) (2 * w + gap), sy = b.height() / (float) h;
        c.save();
        c.translate(b.left, b.top);
        c.scale(sx, sy);
        arrow(c, 0, true, inColor);
        arrow(c, w + gap, false, outColor);
        c.restore();
    }

    /** A thick arrow: shaft about 40% of the width, head as wide as the arrow. */
    private void arrow(Canvas c, float x, boolean down, int color) {
        float shaft = w * 0.42f, head = h * 0.5f, cx = x + w / 2f;
        path.reset();
        if (down) {
            path.moveTo(cx - shaft / 2, 0);
            path.lineTo(cx + shaft / 2, 0);
            path.lineTo(cx + shaft / 2, h - head);
            path.lineTo(x + w, h - head);
            path.lineTo(cx, h);
            path.lineTo(x, h - head);
            path.lineTo(cx - shaft / 2, h - head);
        } else {
            path.moveTo(cx, 0);
            path.lineTo(x + w, head);
            path.lineTo(cx + shaft / 2, head);
            path.lineTo(cx + shaft / 2, h);
            path.lineTo(cx - shaft / 2, h);
            path.lineTo(cx - shaft / 2, head);
            path.lineTo(x, head);
        }
        path.close();
        paint.setColor(color);
        c.drawPath(path, paint);
    }

    @Override public int getIntrinsicWidth() { return 2 * w + gap; }
    @Override public int getIntrinsicHeight() { return h; }
    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
