package com.netspeed.xposed;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.net.Uri;
import android.os.Bundle;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds what to start for "open this payment app's QR scanner": the app's own shortcuts (the ones
 * you get by long-pressing its icon - read from its manifest, and with root also the ones it adds
 * while running), then screens whose name says scan / QR, then the plain app.
 */
final class ScanFinder {

    static final class Cand {
        String label;     // shown to the user
        String detail;    // where it came from
        String uri;       // Intent.toUri(URI_INTENT_SCHEME)
        int score;        // higher = more likely the scanner
    }

    private ScanFinder() { }

    static List<Cand> find(Context c, String pkg) {
        List<Cand> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        PackageManager pm = c.getPackageManager();
        try {
            manifestShortcuts(c, pm, pkg, out, seen);
        } catch (Throwable ignored) { }
        try {
            liveShortcuts(pkg, out, seen);
        } catch (Throwable ignored) { }
        try {
            scanActivities(pm, pkg, out, seen);
        } catch (Throwable ignored) { }
        Intent launch = pm.getLaunchIntentForPackage(pkg);
        if (launch != null) {
            Cand k = new Cand();
            k.label = "Just open the app";
            k.detail = "no direct scanner - you tap its scan button";
            k.uri = launch.toUri(Intent.URI_INTENT_SCHEME);
            k.score = 0;
            out.add(k);
        }
        Collections.sort(out, (a, b) -> b.score - a.score);
        return out;
    }

    static int score(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        int s = 0;
        if (t.contains("scan")) s += 10;
        if (t.contains("qr")) s += 8;
        if (t.contains("pay")) s += 1;
        return s;
    }

    // ---------------------------------------------------------------- manifest shortcuts

    private static void manifestShortcuts(Context c, PackageManager pm, String pkg, List<Cand> out,
                                          Set<String> seen) throws Exception {
        PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES | PackageManager.GET_META_DATA);
        if (pi.activities == null) return;
        Resources res = pm.getResourcesForApplication(pkg);
        Set<Integer> done = new HashSet<>();
        for (ActivityInfo ai : pi.activities) {
            Bundle md = ai.metaData;
            if (md == null) continue;
            int id = md.getInt("android.app.shortcuts", 0);
            if (id == 0 || !done.add(id)) continue;
            XmlResourceParser xp = res.getXml(id);
            try {
                String sid = null, label = null;
                Intent cur = null;
                int ev;
                while ((ev = xp.next()) != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        String n = xp.getName();
                        if ("shortcut".equals(n)) {
                            sid = attr(xp, res, "shortcutId");
                            label = attr(xp, res, "shortcutLongLabel");
                            if (label == null) label = attr(xp, res, "shortcutShortLabel");
                            cur = null;
                        } else if ("intent".equals(n)) {
                            Intent in = new Intent();
                            String act = attr(xp, res, "action");
                            String data = attr(xp, res, "data");
                            String tp = attr(xp, res, "targetPackage");
                            String tc = attr(xp, res, "targetClass");
                            String mime = attr(xp, res, "mimeType");
                            if (act != null) in.setAction(act);
                            if (data != null && mime != null) in.setDataAndType(Uri.parse(data), mime);
                            else if (data != null) in.setData(Uri.parse(data));
                            else if (mime != null) in.setType(mime);
                            if (tp != null && tc != null) {
                                in.setClassName(tp, tc.startsWith(".") ? tp + tc : tc);
                            } else if (tp != null) {
                                in.setPackage(tp);
                            }
                            cur = in;
                        } else if ("extra".equals(n) && cur != null) {
                            putExtra(xp, res, cur);
                        }
                    } else if (ev == XmlPullParser.END_TAG && "shortcut".equals(xp.getName())) {
                        if (cur != null) {
                            addShortcut(out, seen, sid, label, cur, "shortcut of the app (manifest)");
                        }
                        cur = null;
                    }
                }
            } finally {
                xp.close();
            }
        }
    }

    /** An <extra> of a shortcut keeps its type (int / boolean / string): apps read them with getIntExtra etc. */
    private static void putExtra(XmlResourceParser xp, Resources res, Intent in) {
        String name = attr(xp, res, "name");
        if (name == null) return;
        for (int i = 0; i < xp.getAttributeCount(); i++) {
            if (!"value".equals(xp.getAttributeName(i))) continue;
            int rid = xp.getAttributeResourceValue(i, 0);
            if (rid != 0) {
                try {
                    String type = res.getResourceTypeName(rid);
                    if ("bool".equals(type)) in.putExtra(name, res.getBoolean(rid));
                    else if ("integer".equals(type)) in.putExtra(name, res.getInteger(rid));
                    else in.putExtra(name, res.getString(rid));
                } catch (Throwable ignored) { }
                return;
            }
            String raw = xp.getAttributeValue(i);
            int iv = xp.getAttributeIntValue(i, Integer.MIN_VALUE);
            if (iv != Integer.MIN_VALUE) { // a number or a boolean in the XML, not text
                if ("true".equals(raw) || "false".equals(raw)) in.putExtra(name, "true".equals(raw));
                else in.putExtra(name, iv);
            } else if (raw != null) {
                in.putExtra(name, raw);
            }
            return;
        }
    }

    /** Reads an android: attribute by name; resource references are resolved to their text. */
    private static String attr(XmlResourceParser xp, Resources res, String name) {
        for (int i = 0; i < xp.getAttributeCount(); i++) {
            if (!name.equals(xp.getAttributeName(i))) continue;
            int rid = xp.getAttributeResourceValue(i, 0);
            if (rid != 0) {
                try {
                    return res.getString(rid);
                } catch (Throwable t) {
                    return null;
                }
            }
            return xp.getAttributeValue(i);
        }
        return null;
    }

    private static void addShortcut(List<Cand> out, Set<String> seen, String id, String label, Intent in,
                                    String detail) {
        // Launchers start a shortcut in a fresh task; otherwise an already open app just comes to the front.
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        String uri = in.toUri(Intent.URI_INTENT_SCHEME);
        if (!seen.add(uri)) return;
        Cand k = new Cand();
        k.label = label != null && !label.isEmpty() ? label : (id != null ? id : "shortcut");
        k.detail = detail;
        k.uri = uri;
        k.score = 20 + score(k.label + " " + (id == null ? "" : id) + " " + uri);
        out.add(k);
    }

    // ---------------------------------------------------------------- live shortcuts (root)

    private static final Pattern P_ID = Pattern.compile("\\bid=([^,]+),");
    private static final Pattern P_SHORT = Pattern.compile("shortLabel=(.*?), resId=");
    private static final Pattern P_LONG = Pattern.compile("longLabel=(.*?), disabledMessage=");
    private static final Pattern P_INTENT = Pattern.compile("intents=\\[Intent \\{([^}]*)\\}");

    /** With root: `dumpsys shortcut` also lists the shortcuts the app adds while it runs. */
    private static void liveShortcuts(String pkg, List<Cand> out, Set<String> seen) throws Exception {
        Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "dumpsys shortcut"});
        final List<String> lines = new ArrayList<>();
        Thread rd = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l;
                String needle = "packageName=" + pkg + ",";
                while ((l = r.readLine()) != null) {
                    if (l.contains("ShortcutInfo") && l.contains(needle)) lines.add(l);
                }
            } catch (Exception ignored) { }
        });
        rd.start();
        rd.join(12000);
        p.destroy();
        for (String l : lines) {
            Matcher mi = P_INTENT.matcher(l);
            if (!mi.find()) continue;
            String body = mi.group(1).trim();
            String act = field(body, "act="), dat = field(body, "dat="), cmp = field(body, "cmp=");
            if (dat != null && dat.endsWith("/...")) continue; // cut short by Android for privacy: unusable
            Intent in = new Intent();
            if (act != null) in.setAction(act);
            if (dat != null) in.setData(Uri.parse(dat));
            if (cmp != null) {
                ComponentName cn = ComponentName.unflattenFromString(cmp);
                if (cn != null) in.setComponent(cn);
            } else {
                in.setPackage(pkg);
            }
            if (act == null && dat == null && cmp == null) continue;
            String id = first(P_ID, l);
            String label = first(P_LONG, l);
            if (label == null || label.equals("null")) label = first(P_SHORT, l);
            if (label == null || label.equals("null")) label = id;
            addShortcut(out, seen, id, label, in, "shortcut of the app (live)");
        }
    }

    private static String first(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group(1).trim() : null;
    }

    private static String field(String body, String key) {
        for (String t : body.split("\\s+")) {
            if (t.startsWith(key)) return t.substring(key.length());
        }
        return null;
    }

    // ---------------------------------------------------------------- scan-looking screens

    private static void scanActivities(PackageManager pm, String pkg, List<Cand> out, Set<String> seen)
            throws Exception {
        PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES);
        if (pi.activities == null) return;
        List<Cand> found = new ArrayList<>();
        for (ActivityInfo ai : pi.activities) {
            String simple = ai.name.substring(ai.name.lastIndexOf('.') + 1);
            String t = simple.toLowerCase(Locale.ROOT);
            if (!(t.contains("scan") || t.contains("qr"))) continue;
            Intent in = new Intent().setClassName(pkg, ai.name);
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            String uri = in.toUri(Intent.URI_INTENT_SCHEME);
            if (!seen.add(uri)) continue;
            Cand k = new Cand();
            CharSequence lab = ai.loadLabel(pm);
            k.label = simple + (lab != null && !lab.toString().equals(pkg) ? " (" + lab + ")" : "");
            k.detail = "only a guess from the screen's name - internal screens often crash when started directly";
            k.uri = uri;
            k.score = 1 + score(simple) / 8; // a name guess is the last resort
            found.add(k);
        }
        Collections.sort(found, (a, b) -> b.score - a.score);
        for (int i = 0; i < Math.min(6, found.size()); i++) out.add(found.get(i));
    }

    // ---------------------------------------------------------------- starting with root

    static final class Out {
        boolean ok;
        String text = "";
    }

    /** `am start` as root: works for screens that are not exported. */
    static boolean rootStart(String intentUri) {
        return rootStartOut(intentUri).ok;
    }

    static Out rootStartOut(String intentUri) {
        Out o = new Out();
        try {
            String q = intentUri.replace("'", "'\\''");
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c",
                    "am start --user current '" + q + "' 2>&1"});
            StringBuilder b = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) b.append(l).append('\n');
            }
            o.text = b.toString().trim();
            // `am` exits 0 even when it could not start the screen: look at what it printed.
            o.ok = p.waitFor() == 0 && !o.text.contains("Error") && !o.text.contains("Exception");
        } catch (Exception e) {
            o.text = "root not available: " + e.getMessage();
        }
        return o;
    }

    static String suOut(String cmd) throws Exception {
        Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String l;
            while ((l = r.readLine()) != null) b.append(l).append('\n');
        }
        p.waitFor();
        return b.toString();
    }

    /** Which window has focus right now (needs root); null = couldn't ask. */
    static String focus() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c",
                    "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'"});
            StringBuilder b = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) b.append(l).append('\n');
            }
            p.waitFor();
            return b.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
