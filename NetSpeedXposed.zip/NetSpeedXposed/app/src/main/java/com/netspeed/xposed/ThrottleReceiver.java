package com.netspeed.xposed;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Heat throttle, run with root by this app (System UI has none). System UI sends
 * com.netspeed.xposed.THROTTLE with on=true/false and pct (CPU cap as a share of each cluster's top speed).
 * ON: caps every CPU cluster, drops the screen to 60 Hz and clears background apps.
 * OFF: puts the CPU limits and refresh rate back to what they were.
 */
public final class ThrottleReceiver extends BroadcastReceiver {
    private static final String ON =
            "S=/data/local/tmp/throttle.state; PCT=%PCT%\n"
            + "if [ ! -f $S ]; then { echo \"peak $(settings get system peak_refresh_rate)\"; echo \"min $(settings get system min_refresh_rate)\"; } > $S; fi\n"
            + "for p in /sys/devices/system/cpu/cpufreq/policy*; do\n"
            + "  max=$(cat $p/cpuinfo_max_freq); lim=$((max*PCT/100)); best=0\n"
            + "  for f in $(cat $p/scaling_available_frequencies); do [ $f -le $lim ] && [ $f -gt $best ] && best=$f; done\n"
            + "  [ $best -gt 0 ] && echo $best > $p/scaling_max_freq\n"
            + "done\n"
            + "settings put system peak_refresh_rate 60.0; settings put system min_refresh_rate 60.0\n"
            + "am kill-all\n";
    private static final String OFF =
            "S=/data/local/tmp/throttle.state\n"
            + "for p in /sys/devices/system/cpu/cpufreq/policy*; do cat $p/cpuinfo_max_freq > $p/scaling_max_freq; done\n"
            + "if [ -f $S ]; then\n"
            + "  while read k v; do\n"
            + "    n=peak_refresh_rate; [ $k = min ] && n=min_refresh_rate\n"
            + "    if [ \"$v\" = null ] || [ -z \"$v\" ]; then settings delete system $n; else settings put system $n $v; fi\n"
            + "  done < $S; rm -f $S\n"
            + "fi\n";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        final boolean on = intent.getBooleanExtra("on", false);
        final int pct = Math.max(30, Math.min(100, intent.getIntExtra("pct", 60)));
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String script = on ? ON.replace("%PCT%", String.valueOf(pct)) : OFF;
                    Process p = new ProcessBuilder("su", "-c", script).redirectErrorStream(true).start();
                    p.waitFor();
                } catch (Throwable ignored) {
                } finally {
                    pr.finish();
                }
            }
        }, "netspeed-throttle").start();
    }
}
