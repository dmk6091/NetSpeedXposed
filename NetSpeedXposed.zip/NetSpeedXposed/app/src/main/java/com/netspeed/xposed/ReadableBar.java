package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.TrafficStats;
import android.os.SystemClock;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The "readable" status bar: one view that draws four evenly spaced lines of large text.
 *
 *   left   : clock, seconds line, date, sunrise - sunset
 *   next   : CPU / battery temperature, watts, amps
 *   next   : download / upload speed, notification count, Bluetooth device
 *   centre : left empty (camera)
 *   right  : one block per SIM (network, operator, signal, band, distance, voice dot; the SIM that
 *            carries mobile data sits in a highlighted pill with live ↓↑), weather under them,
 *            then the portrait battery
 *
 * Everything is drawn in a 1280 x 124 design space that is scaled to the bar. When a line is too
 * long the least important item drops out instead of anything being cut or squeezed.
 * DualRow.Updater fills in the model fields once a second; the old layout keeps running hidden.
 */
final class ReadableBar extends View {

    /** One SIM's block. */
    static final class SimInfo {
        int slot;
        String rat;        // "5G", "4G+" ... null = unknown
        boolean inService;
        int dbm = Bands.NO_DBM;
        String opLetter;   // operator badge
        int opColor;
        String band;       // "n78"
        String dist;       // "1.0km" or null
        boolean voice;     // VoNR / VoLTE / VoWiFi registered
        boolean data;      // carries mobile data
        boolean inCall;
    }

    // ------------------------------------------------------------------ model (main thread)
    int color = 0xFFFFFFFF;
    Typeface base;
    float cpu = Float.NaN, bat = Float.NaN, amps = Float.NaN, watts = Float.NaN;
    int powerColor = 0xFFFFD60A;
    boolean charging;
    int notifAll = -1, notifSilent;
    boolean btOn;
    List<SysState.Dev> devs = new ArrayList<>();
    int ringer;                    // 0 none, 1 vibrate, 2 silent, 3 DND
    long alarmAt = -1;
    boolean wifiOn;
    int wifiLevel, wifiRssi, wifiFreq;
    List<Bitmap> tray = new ArrayList<>();
    List<SimInfo> sims = new ArrayList<>();
    boolean dataIn, dataOut;
    String wxTemp;
    Drawable wxIcon;
    boolean wxTint = true;
    float wxMax = Float.NaN, wxMin = Float.NaN, wxFeels = Float.NaN, wxWind = Float.NaN, wxUv = Float.NaN;
    int wxHum = -1, wxRain = -1, wxAqi = -1;
    String wxArrow = "";
    int battPct = -1;
    double[] latLon = {18.62, 73.80};

    // ------------------------------------------------------------------ internals
    private static final float DESIGN_W = 1280f, DESIGN_H = 124f;
    private static final float CY1 = 16, CY2 = 46, CY3 = 76, CY4 = 106;   // line centres, design px

    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private Typeface bold = Typeface.DEFAULT_BOLD, semi = Typeface.DEFAULT_BOLD, reg = Typeface.DEFAULT;
    private Typeface builtFrom;
    private boolean dk = true;

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEE d MMM", Locale.getDefault());
    private final SimpleDateFormat t24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat t12 = new SimpleDateFormat("h:mm", Locale.getDefault());
    private final SimpleDateFormat ampm = new SimpleDateFormat("a", Locale.getDefault());
    private boolean h24 = true;
    private long h24CheckedAt;

    private long lastRx = -1, lastTx = -1, lastAt;
    private long down, up;
    private String sunTxt = "";
    private long sunAt;

    private float s = 1f, oy = 0f, vs = 1f, W = DESIGN_W;

    ReadableBar(Context c) {
        super(c);
        setWillNotDraw(false);
    }

    // ------------------------------------------------------------------ tick (seconds hand, clock)

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (isAttachedToWindow()) {
                long now = System.currentTimeMillis();
                postDelayed(this, 1000 - now % 1000 + 5);
            }
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(tick);
        post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    /** Called once a second by the updater: network speed from the traffic counters. */
    void sampleSpeed() {
        long rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        long now = SystemClock.elapsedRealtime();
        if (lastAt > 0 && rx >= 0 && tx >= 0 && lastRx >= 0) {
            long dt = Math.max(1, now - lastAt);
            down = Math.max(0, (rx - lastRx) * 1000 / dt);
            up = Math.max(0, (tx - lastTx) * 1000 / dt);
        }
        lastRx = rx;
        lastTx = tx;
        lastAt = now;
    }

    // ------------------------------------------------------------------ text items

    private static final int G_BELL = 1, G_BT = 2, G_DROP = 3, G_UMB = 4, G_WIFI = 5, G_ALARM = 6,
            G_VIB = 7, G_SIL = 8, G_DND = 9, G_SUN = 10, G_SPACE = 99;

    private static final class Part {
        String text;
        float size;
        Typeface tf;
        int col;
        int glyph;
        float w;
    }

    /** A group that stays together on a line; low priority groups drop out first when it is full. */
    private final class Item {
        final int prio;
        final float ref;
        final List<Part> parts = new ArrayList<>();
        float width = -1;

        Item(int prio, float ref) {
            this.prio = prio;
            this.ref = ref;
        }

        Item t(String text, float size, Typeface tf, int col) {
            Part p = new Part();
            p.text = text;
            p.size = size;
            p.tf = tf;
            p.col = col;
            tp.setTypeface(tf);
            tp.setTextSize(size);
            p.w = tp.measureText(text);
            parts.add(p);
            return this;
        }

        Item g(int glyph, float w, int col) {
            Part p = new Part();
            p.glyph = glyph;
            p.w = w;
            p.col = col;
            parts.add(p);
            return this;
        }

        Item sp(float w) {
            return g(G_SPACE, w, 0);
        }

        float w() {
            if (width < 0) {
                float x = 0;
                for (Part p : parts) x += p.w;
                width = x;
            }
            return width;
        }
    }

    private float drawItem(Canvas c, Item it, float x, float cy) {
        float base = cy + it.ref * 0.36f;
        for (Part p : it.parts) {
            if (p.glyph == 0) {
                tp.setTypeface(p.tf);
                tp.setTextSize(p.size);
                tp.setColor(p.col);
                c.drawText(p.text, x, base, tp);
            } else if (p.glyph != G_SPACE) {
                glyph(c, p.glyph, x, cy, p.w, p.col);
            }
            x += p.w;
        }
        return x;
    }

    /** Draws left to right from x, dropping the lowest priority item until it fits before maxX. */
    private float drawLine(Canvas c, List<Item> items, float x, float cy, float maxX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (use.size() > 1) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (x + total <= maxX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float end = x;
        for (int i = 0; i < use.size(); i++) {
            end = drawItem(c, use.get(i), end, cy);
            if (i < use.size() - 1) end += gap;
        }
        return end;
    }

    /** Right-aligned at rightX, but only as much as fits to the right of minX. */
    private void drawTail(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            x = drawItem(c, use.get(i), x, cy);
            if (i < use.size() - 1) x += gap;
        }
    }

    // ------------------------------------------------------------------ colours

    private int teal() { return SysViews.teal(dk); }
    private int blue() { return SysViews.blue(dk); }
    private int green() { return SysViews.green(dk); }
    private int yellow() { return SysViews.yellow(dk); }
    private int orange() { return SysViews.orange(dk); }
    private int red() { return SysViews.red(dk); }
    private int purple() { return SysViews.purple(dk); }
    private int grey() { return SysViews.dim(color); }

    private static int fade(int col, float k) {
        int a = Math.round(((col >>> 24) & 0xFF) * k);
        return (col & 0x00FFFFFF) | (a << 24);
    }

    private int heat(float t, float warm, float hot, float burn) {
        return t >= burn ? red() : t >= hot ? orange() : t >= warm ? yellow() : teal();
    }

    private int dbmColor(int dbm) {
        return dbm >= -95 ? green() : dbm >= -105 ? yellow() : dbm >= -115 ? orange() : red();
    }

    // ------------------------------------------------------------------ drawing

    private void fonts() {
        if (builtFrom == base && bold != null) return;
        builtFrom = base;
        Typeface b = base != null ? base : Typeface.DEFAULT;
        try {
            bold = Typeface.create(b, 700, false);
            semi = Typeface.create(b, 600, false);
            reg = Typeface.create(b, 500, false);
        } catch (Throwable t) {
            bold = Typeface.create(b, Typeface.BOLD);
            semi = bold;
            reg = b;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        try {
            draw2(c);
        } catch (Throwable t) {
            // never take System UI down over a drawing slip
        }
    }

    private void draw2(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fonts();
        dk = SysViews.dark(color);
        s = Math.min(w / DESIGN_W, h / DESIGN_H);
        W = w / s;
        oy = -3f;
        vs = Math.max(1f, Math.min(1.36f, (h / s) / DESIGN_H));
        c.save();
        try {
            c.scale(s, s);
            // each part on its own, so one slip doesn't blank the others
            try { drawClock(c); } catch (Throwable ignored) { }
            try { drawDevice(c); } catch (Throwable ignored) { }
            try { drawActivity(c); } catch (Throwable ignored) { }
            try { drawSims(c); } catch (Throwable ignored) { }
            try { drawBattery(c); } catch (Throwable ignored) { }
        } finally {
            c.restore();
        }
    }

    private float y(float line) {
        return oy + line * vs;
    }

    /** Plain text, baseline set so that cy is the visual middle of the digits. */
    private float text(Canvas c, String str, float x, float cy, float size, Typeface tf, int col) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(col);
        c.drawText(str, x, cy + size * 0.36f, tp);
        return x + tp.measureText(str);
    }

    private float tw(String str, float size, Typeface tf) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        return tp.measureText(str);
    }

    // ---- clock, seconds line, date, sun

    private void drawClock(Canvas c) {
        long now = System.currentTimeMillis();
        if (now - h24CheckedAt > 30_000) {
            h24CheckedAt = now;
            try {
                h24 = android.text.format.DateFormat.is24HourFormat(getContext());
            } catch (Throwable ignored) { }
        }
        Date d = new Date(now);
        String time = (h24 ? t24 : t12).format(d);
        float x = 6;
        float end = text(c, time, x, y(38), 60, bold, color);
        if (!h24 && end + 4 + 30 < 210) text(c, ampm.format(d).toLowerCase(Locale.getDefault()), end + 4, y(52), 20, semi, grey());
        // seconds line
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(SysViews.faint(color));
        rf.set(8, y(70), 166, y(73));
        c.drawRect(rf, gp);
        gp.setColor(teal());
        rf.set(8, y(70), 8 + 158 * ((now % 60_000L) / 60_000f), y(73));
        c.drawRect(rf, gp);
        text(c, dateFmt.format(d), 8, y(90), 25, semi, color);
        // sunrise - sunset, refreshed every few minutes
        if (now - sunAt > 5 * 60_000L || sunTxt.isEmpty()) {
            sunAt = now;
            try {
                double[] sun = SunTimes.today(latLon[0], latLon[1]);
                sunTxt = SunTimes.hhmm(sun[0]) + " – " + SunTimes.hhmm(sun[1]);
            } catch (Throwable t) {
                sunTxt = "";
            }
        }
        if (!sunTxt.isEmpty()) {
            glyph(c, G_SUN, 8, y(112), 17, orange());
            text(c, sunTxt, 34, y(112), 24, bold, orange());
        }
    }

    // ---- CPU / battery temperature, watts, amps

    private void drawDevice(Canvas c) {
        float x = 214;
        if (!Float.isNaN(cpu)) {
            int col = heat(cpu, 45, 55, 65);
            text(c, "CPU", x, y(CY1), 20, semi, teal());
            text(c, Math.round(cpu) + "°", x + 52, y(CY1), 29, bold, col);
        }
        if (!Float.isNaN(bat)) {
            int col = heat(bat, 38, 42, 45);
            text(c, "BAT", x, y(CY2), 20, semi, teal());
            text(c, Math.round(bat) + "°", x + 52, y(CY2), 29, bold, col);
        }
        if (!Float.isNaN(watts) && !Float.isNaN(amps)) {
            float aw = Math.abs(watts);
            String ws = (amps > 0 ? "+" : "") + String.format(Locale.US, aw < 10 ? "%.1f" : "%.0f", aw);
            float e = text(c, ws, x, y(CY3), 29, bold, powerColor);
            text(c, "W", e + 1, y(CY3), 22, bold, powerColor);
            String as = String.format(Locale.US, "%.2f", Math.abs(amps));
            e = text(c, as, x, y(CY4), 25, semi, powerColor);
            text(c, "A", e + 1, y(CY4), 19, semi, powerColor);
        }
    }

    // ---- speed, notifications, Bluetooth

    private static String[] fmtSpeed(long bps) {
        if (bps < 1024) return new String[]{String.valueOf(bps), "B/s"};
        double kb = bps / 1024.0;
        if (kb < 100) return new String[]{String.format(Locale.US, "%.1f", kb), "K/s"};
        if (kb < 1024) return new String[]{String.format(Locale.US, "%.0f", kb), "K/s"};
        double mb = kb / 1024.0;
        if (mb < 100) return new String[]{String.format(Locale.US, "%.1f", mb), "M/s"};
        return new String[]{String.format(Locale.US, "%.0f", mb), "M/s"};
    }

    private void speedLine(Canvas c, boolean isDown, long bps, float x, float cy) {
        boolean idle = bps < 1024;
        int arrow = idle ? grey() : isDown ? green() : blue();
        int val = idle ? grey() : bps >= (10L << 20) ? teal() : color;
        String[] f = fmtSpeed(bps);
        float e = text(c, isDown ? "↓" : "↑", x, cy, 29, bold, arrow);
        e = text(c, f[0], e + 3, cy, 28, bold, val);
        text(c, f[1], e + 1, cy, 20, semi, grey());
    }

    private void drawActivity(Canvas c) {
        float x = 392;
        float limit = W / 2f - 100;
        speedLine(c, true, down, x, y(CY1));
        speedLine(c, false, up, x, y(CY2));

        // bell + count
        glyph(c, G_BELL, x, y(CY3), 26, color);
        String n = notifAll < 0 ? "?" : String.valueOf(notifAll);
        int ncol = notifAll == 0 ? grey() : color;
        float e = text(c, n, x + 32, y(CY3), 29, bold, ncol);
        if (notifSilent > 0) text(c, "(" + notifSilent + ")", e + 6, y(CY3), 22, semi, grey());

        // Bluetooth
        if (btOn) {
            glyph(c, G_BT, x, y(CY4), 22, devs.isEmpty() ? grey() : blue());
            float dx = x + 32;
            List<Item> items = new ArrayList<>();
            for (int i = 0; i < devs.size() && i < 3; i++) {
                SysState.Dev d = devs.get(i);
                int kc = d.kind == 'W' ? blue() : d.kind == 'H' ? purple() : d.kind == 'P' ? green() : color;
                Item it = new Item(10 - i * 3, 27).t(String.valueOf(d.kind), 27, bold, kc).sp(7);
                if (d.battery >= 0) it.t(d.battery + "%", 27, bold, SysViews.levelColor(d.battery, dk));
                else it.t("--", 27, bold, grey());
                items.add(it);
            }
            if (devs.size() > 3) items.add(new Item(1, 22).t("+" + (devs.size() - 3), 22, semi, grey()));
            drawLine(c, items, dx, y(CY4), limit, 14);
        }
    }

    // ---- SIM blocks, weather, tails

    private void drawSims(Canvas c) {
        float x0 = W / 2f + 98;
        float colW = 230;
        float rightEdge = W - 8;
        float wxMaxX = rightEdge;
        for (int i = 0; i < sims.size() && i < 2; i++) drawSim(c, sims.get(i), x0 + i * colW);

        // weather: line 3 (icon, temp, feels, high/low, rain) and line 4 (humidity, wind, AQI, UV)
        float end3 = x0, end4 = x0;
        if (wxTemp != null) {
            if (wxIcon != null) {
                try {
                    wxIcon.setBounds(Math.round(x0), Math.round(y(CY3) - 17), Math.round(x0 + 34), Math.round(y(CY3) + 17));
                    if (wxTint) wxIcon.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                    else wxIcon.clearColorFilter();
                    wxIcon.draw(c);
                } catch (Throwable ignored) { }
            }
            List<Item> l3 = new ArrayList<>();
            float tempNum = Float.NaN;
            try {
                tempNum = Float.parseFloat(wxTemp);
            } catch (Throwable ignored) { }
            l3.add(new Item(10, 30).t(wxTemp + "°", 30, bold, color));
            if (!Float.isNaN(wxFeels) && !Float.isNaN(tempNum) && Math.abs(wxFeels - tempNum) >= 3f) {
                int fc = wxFeels >= 40 ? red() : wxFeels >= 33 ? orange() : color;
                l3.add(new Item(4, 24).t("feels ", 20, semi, grey()).t(Math.round(wxFeels) + "°", 24, bold, fc));
            }
            if (!Float.isNaN(wxMax) && !Float.isNaN(wxMin)) {
                l3.add(new Item(8, 25).t("↑" + Math.round(wxMax) + "°", 25, bold, orange()).sp(8)
                        .t("↓" + Math.round(wxMin) + "°", 25, bold, teal()));
            }
            if (wxRain >= 0) {
                int rc = wxRain >= 50 ? blue() : wxRain >= 20 ? teal() : color;
                l3.add(new Item(9, 27).g(G_UMB, 28, rc).sp(6).t(wxRain + "%", 27, bold, rc));
            }
            end3 = drawLine(c, l3, x0 + 44, y(CY3), wxMaxX, 16);

            List<Item> l4 = new ArrayList<>();
            if (wxHum >= 0) l4.add(new Item(7, 26).g(G_DROP, 22, teal()).sp(6).t(wxHum + "%", 26, bold, color));
            if (!Float.isNaN(wxWind)) {
                int kt = Math.round(wxWind / 1.852f);
                l4.add(new Item(8, 26).t(wxArrow + " ", 26, bold, color).t(String.valueOf(kt), 26, bold, color)
                        .t(" kt", 19, semi, grey()));
            }
            if (wxAqi >= 0) {
                int a = wxAqi;
                int ac = a <= 50 ? green() : a <= 100 ? yellow() : a <= 150 ? orange() : a <= 200 ? red() : purple();
                l4.add(new Item(9, 28).t("AQI ", 20, semi, grey()).t(String.valueOf(a), 28, bold, ac));
            }
            if (!Float.isNaN(wxUv) && wxUv >= 3f) {
                float u = wxUv;
                int uc = u < 6 ? yellow() : u < 8 ? orange() : u < 11 ? red() : purple();
                l4.add(new Item(5, 26).t("UV ", 20, semi, grey()).t(String.valueOf(Math.round(u)), 26, bold, uc));
            }
            end4 = drawLine(c, l4, x0, y(CY4), wxMaxX, 22);
        }

        // tails: whatever is on, right-aligned on lines 3 and 4, only if there is room
        List<Item> t3 = new ArrayList<>();
        if (alarmAt > 0) {
            String f = alarmAt - System.currentTimeMillis() < 20 * 3600_000L ? "HH:mm" : "EEE HH:mm";
            String lbl = new SimpleDateFormat(f, Locale.US).format(new Date(alarmAt));
            t3.add(new Item(5, 24).g(G_ALARM, 24, color).sp(5).t(lbl, 24, semi, color));
        }
        if (ringer != 0) {
            int g = ringer == 1 ? G_VIB : ringer == 2 ? G_SIL : G_DND;
            t3.add(new Item(7, 24).g(g, 26, ringer == 1 ? orange() : ringer == 2 ? red() : purple()));
        }
        drawTail(c, t3, rightEdge, y(CY3), end3 + 18, 14);

        List<Item> t4 = new ArrayList<>();
        for (int i = 0; i < tray.size() && i < 4; i++) {
            final Bitmap b = tray.get(i);
            float ih = 24, iw = b.getHeight() == 0 ? ih : ih * b.getWidth() / b.getHeight();
            t4.add(new Item(2 + i, 20).g(1000 + i, iw, grey()));
        }
        if (wifiOn) {
            int lc = wifiLevel >= 3 ? green() : wifiLevel == 2 ? yellow() : wifiLevel == 1 ? orange() : red();
            String band = SysState.band(wifiFreq).replace(" GHz", "G");
            Item it = new Item(9, 22).g(G_WIFI, 28, lc).sp(5).t(band, 21, semi, grey()).sp(6);
            it.t(String.valueOf(wifiRssi), 23, bold, lc);
            t4.add(it);
        }
        drawTailWithBitmaps(c, t4, rightEdge, y(CY4), end4 + 18, 12);
    }

    /** Like drawTail, but glyph ids 1000+ are tray bitmaps. */
    private void drawTailWithBitmaps(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            Item it = use.get(i);
            Part p = it.parts.get(0);
            if (p.glyph >= 1000) {
                int bi = p.glyph - 1000;
                if (bi < tray.size()) {
                    Bitmap b = tray.get(bi);
                    ip.setColorFilter(new PorterDuffColorFilter(grey(), PorterDuff.Mode.SRC_IN));
                    rf.set(x, cy - 12, x + p.w, cy + 12);
                    c.drawBitmap(b, null, rf, ip);
                }
                x += p.w;
            } else {
                x = drawItem(c, it, x, cy);
            }
            if (i < use.size() - 1) x += gap;
        }
    }

    private void drawSim(Canvas c, SimInfo si, float x) {
        float k = si.data ? 1f : 0.55f;
        if (si.data) {
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(fade(color, 0.16f));
            rf.set(x - 12, y(2), x + 214, y(64));
            c.drawRoundRect(rf, 14, 14, gp);
        }
        float cy1 = y(CY1), cy2 = y(CY2);
        // line 1: network, operator badge, signal
        String rat = si.inService && si.rat != null && !si.rat.isEmpty() ? si.rat : "—";
        float rs = 36, bs = 28, ds = 28;
        String dbm = si.inService && si.dbm != Bands.NO_DBM ? String.valueOf(si.dbm) : null;
        float total = tw(rat, rs, bold) + (si.opLetter != null ? 6 + bs : 0) + (dbm != null ? 8 + tw(dbm, ds, bold) : 0);
        float f = total > 212 ? 212 / total : 1f;
        float e = text(c, rat, x, cy1, rs * f, bold, fade(color, k));
        if (si.opLetter != null) {
            float r = bs * f / 2f;
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(fade(si.opColor, k));
            c.drawCircle(e + 6 + r, cy1, r, gp);
            tp.setTypeface(bold);
            tp.setTextSize(20 * f);
            tp.setColor(fade(0xFFFFFFFF, k));
            float lw = tp.measureText(si.opLetter);
            c.drawText(si.opLetter, e + 6 + r - lw / 2f, cy1 + 20 * f * 0.36f, tp);
            e += 6 + bs * f;
        }
        if (dbm != null) text(c, dbm, e + 8 * f, cy1, ds * f, bold, fade(dbmColor(si.dbm), k));

        // line 2: voice dot, band + distance, live arrows on the data SIM
        gp.setStyle(Paint.Style.FILL);
        if (si.voice) {
            gp.setColor(fade(green(), k));
            c.drawCircle(x + 9, cy2, 5.5f, gp);
        } else {
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(2f);
            gp.setColor(fade(grey(), k));
            c.drawCircle(x + 9, cy2, 4.5f, gp);
            gp.setStyle(Paint.Style.FILL);
        }
        String band = si.band != null ? si.band : "?";
        float avail = 214 - 22 - (si.data ? 54 : 0);
        String full = si.dist != null ? band + " · " + si.dist : band;
        String shown = tw(full, 22, semi) <= avail ? full : band;
        float fs = 22;
        float sw = tw(shown, fs, semi);
        if (sw > avail) fs = 22 * avail / sw;
        float ex = text(c, shown, x + 22, cy2, fs, semi, fade(blue(), k));
        if (si.data) {
            float ax = ex + 10;
            ax = text(c, "↓", ax, cy2, 24, bold, dataIn ? green() : color);
            text(c, "↑", ax - 2, cy2, 24, bold, dataOut ? blue() : color);
        }
    }

    // ---- battery

    private void drawBattery(Canvas c) {
        float bx = W - 42, by = y(10);
        int lc = battPct < 0 ? grey() : charging ? green() : SysViews.levelColor(battPct, dk);
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(color);
        rf.set(bx + 10, by - 4, bx + 26, by + 1);
        c.drawRoundRect(rf, 2, 2, gp);
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(3f);
        rf.set(bx + 1.5f, by + 1.5f, bx + 34.5f, by + 46.5f);
        c.drawRoundRect(rf, 7, 7, gp);
        if (battPct >= 0) {
            float in0 = by + 5, in1 = by + 43, frac = Math.min(100, battPct) / 100f;
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(lc);
            rf.set(bx + 5, in1 - (in1 - in0) * frac, bx + 31, in1);
            c.drawRoundRect(rf, 4, 4, gp);
            String n = String.valueOf(battPct);
            float ts = battPct >= 100 ? 18 : 24;
            tp.setTypeface(bold);
            tp.setTextSize(ts);
            float nw = tp.measureText(n);
            float tx = bx + 18 - nw / 2f, ty = by + 24 + ts * 0.36f;
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(Math.max(3f, ts * 0.14f));
            tp.setColor(0xCC000000);
            c.drawText(n, tx, ty, tp);
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(0xFFFFFFFF);
            c.drawText(n, tx, ty, tp);
        }
    }

    // ------------------------------------------------------------------ glyphs

    /** Small symbols, drawn around cy, starting at x, w wide. */
    private void glyph(Canvas c, int id, float x, float cy, float w, int col) {
        float cx = x + w / 2f;
        switch (id) {
            case G_BELL: {
                float h = w * 0.92f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float bw = h * 0.78f;
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.66f, cy + h * 0.2f, cx + bw * 0.66f, cy + h * 0.34f, gp);
                c.drawCircle(cx, cy + h * 0.44f, h * 0.1f, gp);
                break;
            }
            case G_BT: {
                float h = 30;
                stroke(3f, col);
                float x0 = x + 2, x1 = x + w - 2, mx = (x0 + x1) / 2f;
                path.reset();
                path.moveTo(x0, cy - h * 0.22f);
                path.lineTo(x1, cy + h * 0.2f);
                path.lineTo(mx, cy + h * 0.45f);
                path.lineTo(mx, cy - h * 0.45f);
                path.lineTo(x1, cy - h * 0.2f);
                path.lineTo(x0, cy + h * 0.22f);
                c.drawPath(path, gp);
                break;
            }
            case G_DROP: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f;
                c.drawCircle(cx, cy + 4, r, gp);
                path.reset();
                path.moveTo(cx, cy - 13);
                path.lineTo(cx - r * 0.95f, cy + 1);
                path.lineTo(cx + r * 0.95f, cy + 1);
                path.close();
                c.drawPath(path, gp);
                break;
            }
            case G_UMB: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(x + 1, cy - 14, x + w - 1, cy + 10);
                c.drawArc(rf, 180, 180, true, gp);
                stroke(3f, col);
                c.drawLine(cx, cy - 2, cx, cy + 12, gp);
                break;
            }
            case G_WIFI: {
                float bx = cx, by = cy + 10;
                stroke(3.2f, col);
                for (int i = 1; i <= 3; i++) {
                    float r = 6.5f * i;
                    rf.set(bx - r, by - r, bx + r, by + r);
                    c.drawArc(rf, 225, 90, false, gp);
                }
                gp.setStyle(Paint.Style.FILL);
                c.drawCircle(bx, by - 0.5f, 2.4f, gp);
                break;
            }
            case G_ALARM: {
                float h = w * 0.8f;
                stroke(2.6f, col);
                c.drawCircle(cx, cy + 2, h * 0.38f, gp);
                c.drawLine(cx, cy + 2, cx, cy - h * 0.18f, gp);
                c.drawLine(cx, cy + 2, cx + h * 0.16f, cy + h * 0.1f, gp);
                c.drawLine(cx - h * 0.44f, cy - h * 0.28f, cx - h * 0.26f, cy - h * 0.46f, gp);
                c.drawLine(cx + h * 0.44f, cy - h * 0.28f, cx + h * 0.26f, cy - h * 0.46f, gp);
                break;
            }
            case G_VIB: {
                float h = w * 0.9f;
                stroke(2.6f, col);
                rf.set(cx - h * 0.2f, cy - h * 0.48f, cx + h * 0.2f, cy + h * 0.48f);
                c.drawRoundRect(rf, h * 0.08f, h * 0.08f, gp);
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    c.drawLine(cx + sgn * h * 0.34f, cy - h * 0.22f, cx + sgn * h * 0.34f, cy + h * 0.22f, gp);
                    c.drawLine(cx + sgn * h * 0.5f, cy - h * 0.12f, cx + sgn * h * 0.5f, cy + h * 0.12f, gp);
                }
                break;
            }
            case G_SIL: {
                float h = w * 0.9f, bw = h * 0.7f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.62f, cy + h * 0.22f, cx + bw * 0.62f, cy + h * 0.34f, gp);
                stroke(3f, col);
                c.drawLine(cx - h * 0.5f, cy - h * 0.5f, cx + h * 0.5f, cy + h * 0.5f, gp);
                break;
            }
            case G_DND: {
                float h = w * 0.9f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                c.drawCircle(cx, cy, h * 0.46f, gp);
                gp.setColor(dk ? 0xFF1C1C1E : 0xFFFFFFFF);
                rf.set(cx - h * 0.26f, cy - h * 0.07f, cx + h * 0.26f, cy + h * 0.07f);
                c.drawRoundRect(rf, h * 0.05f, h * 0.05f, gp);
                break;
            }
            case G_SUN: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f, sx = x + w / 2f + 1;
                c.drawCircle(sx, cy, r, gp);
                for (int a = 0; a < 360; a += 45) {
                    double ra = Math.toRadians(a);
                    c.drawCircle((float) (sx + w * 0.62 * Math.cos(ra)), (float) (cy + w * 0.62 * Math.sin(ra)), 1.7f, gp);
                }
                break;
            }
            default:
                break;
        }
    }

    private void stroke(float width, int col) {
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(width);
        gp.setStrokeCap(Paint.Cap.ROUND);
        gp.setStrokeJoin(Paint.Join.ROUND);
        gp.setColor(col);
    }
}
