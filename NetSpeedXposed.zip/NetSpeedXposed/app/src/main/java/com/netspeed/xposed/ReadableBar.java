package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.TrafficStats;
import android.os.SystemClock;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The "readable" status bar: one view that draws four evenly spaced lines of large text.
 *
 *   left   : clock, seconds line, date, sunrise - sunset
 *   next   : CPU / battery temperature, watts, amps
 *   next   : download / upload speed, notification count, Bluetooth device
 *   centre : left empty (camera)
 *   right  : one block per SIM (network, operator, signal, band, distance, voice dot; the SIM that
 *            carries mobile data sits in a highlighted pill with live ↓↑), weather under them,
 *            then the portrait battery
 *
 * Everything is drawn in a 1280 x 124 design space that is scaled to the bar. When a line is too
 * long the least important item drops out instead of anything being cut or squeezed.
 * DualRow.Updater fills in the model fields once a second; the old layout keeps running hidden.
 */
final class ReadableBar extends View {

    /** One SIM's block. */
    static final class SimInfo {
        int slot;
        String rat;        // "5G", "4G+" ... null = unknown
        boolean inService;
        int dbm = Bands.NO_DBM;
        String opLetter;   // operator badge
        boolean roaming;
        int opColor;
        String band;       // "n78"
        String dist;       // "1.0km" or null
        String voice;      // "NR", "LTE", "WiFi" when calls use IMS, else null
        boolean data;      // carries mobile data
        boolean inCall;
        int cells = -1;
        boolean eco;       // NetSwitch eco mode (5G off to save battery)
        float snr = Float.NaN;
    }

    // ------------------------------------------------------------------ model (main thread)
    int color = 0xFFFFFFFF;
    Typeface base;
    float cpu = Float.NaN, bat = Float.NaN, amps = Float.NaN, watts = Float.NaN;
    int powerColor = 0xFFFFD60A;
    boolean charging;
    int notifAll = -1, notifSilent;
    boolean btOn;
    List<SysState.Dev> devs = new ArrayList<>();
    int ringer;                    // 0 none, 1 vibrate, 2 silent, 3 DND
    long alarmAt = -1;
    boolean wifiOn;
    int wifiLevel, wifiRssi, wifiFreq;
    List<Bitmap> tray = new ArrayList<>();
    List<SimInfo> sims = new ArrayList<>();
    boolean dataIn, dataOut;
    String wxTemp;
    Drawable wxIcon;
    boolean wxTint = true;
    float wxMax = Float.NaN, wxMin = Float.NaN, wxFeels = Float.NaN, wxWind = Float.NaN, wxUv = Float.NaN;
    int wxHum = -1, wxRain = -1, wxAqi = -1;
    String wxArrow = "";
    int battPct = -1;
    double[] latLon = {18.62, 73.80};
    float gpu = Float.NaN;
    float ghz = Float.NaN;
    long ramFree = -1, ramTotal = -1;
    float wxVis = Float.NaN;
    int wxCloud = -1;
    int hz = -1;
    double[] fix;
    float quakeMag = Float.NaN;
    int quakeKm = -1;
    long quakeAt = 0;
    String quakeCc;
    /** Strip above the clock: "ISS over Nagpur", "No ISS pass", plus a satellite in your sky; satLive = something is up. */
    String satText = "";
    boolean satLive;
    /** Where the left row 4 ended and the right (weather) row 4 starts, for the centre item. */
    private float l4End = 0, w4Start = 1e9f;

    // ------------------------------------------------------------------ internals
    private static final float DESIGN_W = 1280f, DESIGN_H = 124f;
    private static final float CY1 = 16, CY2 = 46, CY3 = 76, CY4 = 106;   // line centres, design px

    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private Typeface bold = Typeface.DEFAULT_BOLD, semi = Typeface.DEFAULT_BOLD, reg = Typeface.DEFAULT;
    private Typeface builtFrom;
    private boolean dk = true;

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEE d MMM", Locale.getDefault());
    private final SimpleDateFormat t24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat t12 = new SimpleDateFormat("h:mm", Locale.getDefault());
    private final SimpleDateFormat ampm = new SimpleDateFormat("a", Locale.getDefault());
    private boolean h24 = true;
    private long h24CheckedAt;

    private long lastRx = -1, lastTx = -1, lastAt;
    private long down, up;
    private String sunTxt = "";
    private long sunAt;

    private float s = 1f, oy = 0f, vs = 1f, W = DESIGN_W;

    ReadableBar(Context c) {
        super(c);
        setWillNotDraw(false);
    }

    // ------------------------------------------------------------------ tick (seconds hand, clock)

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (isAttachedToWindow()) {
                long now = System.currentTimeMillis();
                postDelayed(this, 1000 - now % 1000 + 5);
            }
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(tick);
        post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    /** Called once a second by the updater: network speed from the traffic counters. */
    void sampleSpeed() {
        long rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        long now = SystemClock.elapsedRealtime();
        if (lastAt > 0 && rx >= 0 && tx >= 0 && lastRx >= 0) {
            long dt = Math.max(1, now - lastAt);
            down = Math.max(0, (rx - lastRx) * 1000 / dt);
            up = Math.max(0, (tx - lastTx) * 1000 / dt);
        }
        lastRx = rx;
        lastTx = tx;
        lastAt = now;
    }

    // ------------------------------------------------------------------ text items

    private static final int G_BELL = 1, G_BT = 2, G_DROP = 3, G_UMB = 4, G_WIFI = 5, G_ALARM = 6,
            G_VIB = 7, G_SIL = 8, G_DND = 9, G_SUN = 10, G_SPACE = 99;

    private static final class Part {
        String text;
        float size;
        Typeface tf;
        int col;
        int glyph;
        float w;
    }

    /** A group that stays together on a line; low priority groups drop out first when it is full. */
    private final class Item {
        final int prio;
        final float ref;
        final List<Part> parts = new ArrayList<>();
        float width = -1;

        Item(int prio, float ref) {
            this.prio = prio;
            this.ref = ref;
        }

        Item t(String text, float size, Typeface tf, int col) {
            Part p = new Part();
            p.text = text;
            p.size = size;
            p.tf = tf;
            p.col = col;
            tp.setTypeface(tf);
            tp.setTextSize(size);
            p.w = tp.measureText(text);
            parts.add(p);
            return this;
        }

        Item g(int glyph, float w, int col) {
            Part p = new Part();
            p.glyph = glyph;
            p.w = w;
            p.col = col;
            parts.add(p);
            return this;
        }

        Item sp(float w) {
            return g(G_SPACE, w, 0);
        }

        float w() {
            if (width < 0) {
                float x = 0;
                for (Part p : parts) x += p.w;
                width = x;
            }
            return width;
        }
    }

    private float drawItem(Canvas c, Item it, float x, float cy) {
        float base = cy + it.ref * 0.36f;
        for (Part p : it.parts) {
            if (p.glyph == 0) {
                tp.setTypeface(p.tf);
                tp.setTextSize(p.size);
                tp.setColor(p.col);
                c.drawText(p.text, x, base, tp);
            } else if (p.glyph != G_SPACE) {
                glyph(c, p.glyph, x, cy, p.w, p.col);
            }
            x += p.w;
        }
        return x;
    }

    /** Draws left to right from x, dropping the lowest priority item until it fits before maxX. */
    private float drawLine(Canvas c, List<Item> items, float x, float cy, float maxX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (use.size() > 1) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (x + total <= maxX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float end = x;
        for (int i = 0; i < use.size(); i++) {
            end = drawItem(c, use.get(i), end, cy);
            if (i < use.size() - 1) end += gap;
        }
        return end;
    }

    /** Right-aligned at rightX, but only as much as fits to the right of minX. */
    private void drawTail(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            x = drawItem(c, use.get(i), x, cy);
            if (i < use.size() - 1) x += gap;
        }
    }

    /** Where drawTail would start the line (same dropping rule). */
    private float tailStart(List<Item> items, float rightX, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) return rightX - total;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        return rightX;
    }

    // ------------------------------------------------------------------ colours

    private int teal() { return SysViews.teal(dk); }
    private int blue() { return SysViews.blue(dk); }
    private int green() { return SysViews.green(dk); }
    private int yellow() { return SysViews.yellow(dk); }
    private int orange() { return SysViews.orange(dk); }
    private int red() { return SysViews.red(dk); }
    private int purple() { return SysViews.purple(dk); }
    /** Secondary text (units, labels): light grey on a dark bar so it stays readable, dimmed text on a light one. */
    private int grey() { return dk ? 0xFFCDCDCD : SysViews.dim(color); }

    private static int fade(int col, float k) {
        int a = Math.round(((col >>> 24) & 0xFF) * k);
        return (col & 0x00FFFFFF) | (a << 24);
    }

    private int heat(float t, float warm, float hot, float burn) {
        return t >= burn ? red() : t >= hot ? orange() : t >= warm ? yellow() : teal();
    }

    private int dbmColor(int dbm) {
        return dbm >= -95 ? green() : dbm >= -105 ? yellow() : dbm >= -115 ? orange() : red();
    }

    // ------------------------------------------------------------------ drawing

    private void fonts() {
        if (builtFrom == base && bold != null) return;
        builtFrom = base;
        Typeface b = base != null ? base : Typeface.DEFAULT;
        try {
            bold = Typeface.create(b, 700, false);
            semi = Typeface.create(b, 600, false);
            reg = Typeface.create(b, 500, false);
        } catch (Throwable t) {
            bold = Typeface.create(b, Typeface.BOLD);
            semi = bold;
            reg = b;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        try {
            draw2(c);
        } catch (Throwable t) {
            // never take System UI down over a drawing slip
        }
    }

    private void draw2(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fonts();
        dk = SysViews.dark(color);
        if (pro) {
            drawPro(c, w, h);
            return;
        }
        s = Math.min(w / DESIGN_W, h / DESIGN_H);
        W = w / s;
        oy = -3f;
        vs = Math.max(1f, Math.min(1.36f, (h / s) / DESIGN_H));
        c.save();
        try {
            c.scale(s, s);
            // each part on its own, so one slip doesn't blank the others
            try { drawClock(c); } catch (Throwable ignored) { }
            try { drawDevice(c); } catch (Throwable ignored) { }
            try { drawActivity(c); } catch (Throwable ignored) { }
            try { drawSims(c); } catch (Throwable ignored) { }
        } finally {
            c.restore();
        }
    }

    private float y(float line) {
        return oy + line * vs;
    }

    /** Plain text, baseline set so that cy is the visual middle of the digits. */
    private float text(Canvas c, String str, float x, float cy, float size, Typeface tf, int col) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(col);
        c.drawText(str, x, cy + size * 0.36f, tp);
        return x + tp.measureText(str);
    }

    private float tw(String str, float size, Typeface tf) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        return tp.measureText(str);
    }

    // ---- clock, seconds line, date, sun

    private void drawClock(Canvas c) {
        long now = System.currentTimeMillis();
        if (now - h24CheckedAt > 30_000) {
            h24CheckedAt = now;
            try {
                h24 = android.text.format.DateFormat.is24HourFormat(getContext());
            } catch (Throwable ignored) { }
        }
        Date d = new Date(now);
        String time = (h24 ? t24 : t12).format(d);
        float x = 22;
        float end = text(c, time, x, y(38), 60, bold, color);
        if (!h24 && end + 4 + 30 < 210) text(c, ampm.format(d).toLowerCase(Locale.getDefault()), end + 4, y(52), 20, semi, grey());
        // seconds line
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(SysViews.faint(color));
        rf.set(24, y(70), 182, y(73));
        c.drawRect(rf, gp);
        gp.setColor(teal());
        rf.set(24, y(70), 24 + 158 * ((now % 60_000L) / 60_000f), y(73));
        c.drawRect(rf, gp);
        text(c, dateFmt.format(d), 24, y(90), 25, semi, color);
        // sunrise - sunset, refreshed every few minutes
        if (now - sunAt > 5 * 60_000L || sunTxt.isEmpty()) {
            sunAt = now;
            try {
                double[] sun = SunTimes.today(latLon[0], latLon[1]);
                sunTxt = SunTimes.hhmm(sun[0]) + " – " + SunTimes.hhmm(sun[1]);
            } catch (Throwable t) {
                sunTxt = "";
            }
        }
        if (!sunTxt.isEmpty()) {
            glyph(c, G_SUN, 24, y(112), 17, orange());
            text(c, sunTxt, 50, y(112), 24, bold, orange());
        }
    }

    // ---- CPU / battery temperature, watts, amps

    private void drawDevice(Canvas c) {
        float x = 214;
        if (!Float.isNaN(cpu)) {
            int col = heat(cpu, 45, 55, 65);
            text(c, "CPU", x, y(CY1), 20, semi, teal());
            text(c, Math.round(cpu) + "°", x + 52, y(CY1), 29, bold, col);
        }
        if (!Float.isNaN(bat)) {
            int col = heat(bat, 38, 42, 45);
            text(c, "BAT", x, y(CY2), 20, semi, teal());
            text(c, Math.round(bat) + "°", x + 52, y(CY2), 29, bold, col);
        }
        if (!Float.isNaN(watts) && !Float.isNaN(amps)) {
            float aw = Math.abs(watts);
            String ws = (amps > 0 ? "+" : "\u2212") + String.format(Locale.US, aw < 10 ? "%.1f" : "%.0f", aw);
            float e = text(c, ws, x, y(CY3), 29, bold, powerColor);
            text(c, "W", e + 1, y(CY3), 22, bold, powerColor);
            String as = (amps > 0 ? "+" : "\u2212") + String.format(Locale.US, "%.2f", Math.abs(amps));
            e = text(c, as, x, y(CY4), 25, semi, powerColor);
            text(c, "A", e + 1, y(CY4), 19, semi, powerColor);
        }
    }

    // ---- speed, notifications, Bluetooth

    private static String[] fmtSpeed(long bps) {
        if (bps < 1024) return new String[]{String.valueOf(bps), "B/s"};
        double kb = bps / 1024.0;
        if (kb < 100) return new String[]{String.format(Locale.US, "%.1f", kb), "K/s"};
        if (kb < 1024) return new String[]{String.format(Locale.US, "%.0f", kb), "K/s"};
        double mb = kb / 1024.0;
        if (mb < 100) return new String[]{String.format(Locale.US, "%.1f", mb), "M/s"};
        return new String[]{String.format(Locale.US, "%.0f", mb), "M/s"};
    }

    private void speedLine(Canvas c, boolean isDown, long bps, float x, float cy) {
        boolean idle = bps < 1024;
        int arrow = idle ? grey() : isDown ? green() : blue();
        int val = idle ? grey() : bps >= (10L << 20) ? teal() : color;
        String[] f = fmtSpeed(bps);
        float e = text(c, isDown ? "↓" : "↑", x, cy, 29, bold, arrow);
        e = text(c, f[0], e + 3, cy, 28, bold, val);
        text(c, f[1], e + 1, cy, 20, semi, grey());
    }

    private void drawActivity(Canvas c) {
        float x = 344;
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(SysViews.faint(color));
        rf.set(328, y(2), 330.5f, y(118));
        c.drawRect(rf, gp);
        float limit = W / 2f - 100;
        speedLine(c, true, down, x, y(CY1));
        speedLine(c, false, up, x, y(CY2));

        // bell + count
        glyph(c, G_BELL, x, y(CY3), 26, color);
        String n = notifAll < 0 ? "?" : String.valueOf(notifAll);
        int ncol = notifAll == 0 ? grey() : color;
        float e = text(c, n, x + 32, y(CY3), 29, bold, ncol);
        if (notifSilent > 0) text(c, "(" + notifSilent + ")", e + 6, y(CY3), 22, semi, grey());

        // Bluetooth
        if (btOn) {
            glyph(c, G_BT, x, y(CY4), 22, devs.isEmpty() ? grey() : blue());
            float dx = x + 32;
            List<Item> items = new ArrayList<>();
            for (int i = 0; i < devs.size() && i < 3; i++) {
                SysState.Dev d = devs.get(i);
                int kc = d.kind == 'W' ? blue() : d.kind == 'H' ? purple() : d.kind == 'P' ? green() : color;
                Item it = new Item(10 - i * 3, 27).t(String.valueOf(d.kind), 27, bold, kc).sp(7);
                if (d.battery >= 0) it.t(d.battery + "%", 27, bold, SysViews.levelColor(d.battery, dk));
                else it.t("--", 27, bold, grey());
                items.add(it);
            }
            if (devs.size() > 3) items.add(new Item(1, 22).t("+" + (devs.size() - 3), 22, semi, grey()));
            drawLine(c, items, dx, y(CY4), limit, 14);
        }
    }

    // ---- SIM blocks, weather, tails

    private void drawSims(Canvas c) {
        float x0 = W / 2f + 98;
        float colW = 240;
        float rightEdge = W - 18;
        float wxMaxX = rightEdge;
        for (int i = 0; i < sims.size() && i < 2; i++) drawSim(c, sims.get(i), x0 + i * colW);

        // weather: line 3 (icon, temp, feels, high/low, rain) and line 4 (humidity, wind, AQI, UV)
        float end3 = x0, end4 = x0;
        if (wxTemp != null) {
            if (wxIcon != null) {
                try {
                    wxIcon.setBounds(Math.round(x0), Math.round(y(CY3) - 17), Math.round(x0 + 34), Math.round(y(CY3) + 17));
                    if (wxTint) wxIcon.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                    else wxIcon.clearColorFilter();
                    wxIcon.draw(c);
                } catch (Throwable ignored) { }
            }
            List<Item> l3 = new ArrayList<>();
            float tempNum = Float.NaN;
            try {
                tempNum = Float.parseFloat(wxTemp);
            } catch (Throwable ignored) { }
            l3.add(new Item(10, 30).t(wxTemp + "°", 30, bold, color));
            end3 = drawLine(c, l3, x0 + 44, y(CY3), wxMaxX, 16);

            end4 = x0;
        }

        // tails: whatever is on, right-aligned on lines 3 and 4, only if there is room
        List<Item> t3 = new ArrayList<>();
        if (alarmAt > 0) {
            String f = alarmAt - System.currentTimeMillis() < 20 * 3600_000L ? "HH:mm" : "EEE HH:mm";
            String lbl = new SimpleDateFormat(f, Locale.US).format(new Date(alarmAt));
            t3.add(new Item(5, 24).g(G_ALARM, 24, color).sp(5).t(lbl, 24, semi, color));
        }
        if (ringer != 0) {
            int g = ringer == 1 ? G_VIB : ringer == 2 ? G_SIL : G_DND;
            t3.add(new Item(7, 24).g(g, 26, ringer == 1 ? orange() : ringer == 2 ? red() : purple()));
        }
        drawTail(c, t3, rightEdge, y(CY3), end3 + 18, 14);

        List<Item> t4 = new ArrayList<>();
        for (int i = 0; i < tray.size() && i < 4; i++) {
            final Bitmap b = tray.get(i);
            float ih = 24, iw = b.getHeight() == 0 ? ih : ih * b.getWidth() / b.getHeight();
            t4.add(new Item(2 + i, 20).g(1000 + i, iw, grey()));
        }
        if (wifiOn) {
            int lc = wifiLevel >= 3 ? green() : wifiLevel == 2 ? yellow() : wifiLevel == 1 ? orange() : red();
            String band = SysState.band(wifiFreq).replace(" GHz", "G");
            Item it = new Item(9, 22).g(G_WIFI, 28, lc).sp(5).t(band, 21, semi, grey()).sp(6);
            it.t(String.valueOf(wifiRssi), 23, bold, lc);
            t4.add(it);
        }
        drawTailWithBitmaps(c, t4, rightEdge, y(CY4), end4 + 18, 12);
    }

    /** Like drawTail, but glyph ids 1000+ are tray bitmaps. */
    private void drawTailWithBitmaps(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            Item it = use.get(i);
            Part p = it.parts.get(0);
            if (p.glyph >= 1000) {
                int bi = p.glyph - 1000;
                if (bi < tray.size()) {
                    Bitmap b = tray.get(bi);
                    ip.setColorFilter(new PorterDuffColorFilter(grey(), PorterDuff.Mode.SRC_IN));
                    rf.set(x, cy - 12, x + p.w, cy + 12);
                    c.drawBitmap(b, null, rf, ip);
                }
                x += p.w;
            } else {
                x = drawItem(c, it, x, cy);
            }
            if (i < use.size() - 1) x += gap;
        }
    }

    private void drawSim(Canvas c, SimInfo si, float x) {
        float k = si.data ? 1f : 0.55f;
        if (si.data) {
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(fade(color, 0.16f));
            rf.set(x - 12, y(2), x + 228, y(64));
            c.drawRoundRect(rf, 14, 14, gp);
        }
        float cy1 = y(CY1), cy2 = y(CY2);
        // line 1: network, signal (dBm), number of cells heard
        String rat = si.inService && si.rat != null && !si.rat.isEmpty() ? si.rat : "\u2014";
        String dbm = si.inService && si.dbm != Bands.NO_DBM ? String.valueOf(si.dbm) : null;
        String cells = si.cells > 0 ? String.valueOf(si.cells) : null;
        float total = tw(rat, 36, bold) + (si.eco ? 8 + tw("E", 26, bold) : 0)
                + (dbm != null ? 10 + tw(dbm, 28, bold) : 0)
                + (cells != null ? 12 + tw(cells, 26, bold) : 0);
        float f = total > 224 ? 224 / total : 1f;
        float e = text(c, rat, x, cy1, 36 * f, bold, fade(color, k));
        if (si.eco) e = text(c, "E", e + 8 * f, cy1, 26 * f, bold, fade(green(), k));
        if (dbm != null) e = text(c, dbm, e + 10 * f, cy1, 28 * f, bold, fade(dbmColor(si.dbm), k));
        if (cells != null) {
            text(c, cells, e + 12 * f, cy1, 26 * f, bold, fade(color, k));
        }

        // line 2: small boxed Vo badge (VoNR / VoLTE / VoWiFi), band + distance, live arrows on the data SIM
        float bx0 = x;
        if (si.voice != null) {
            String vo = "Vo" + si.voice;
            float vw = tw(vo, 16, bold) + 10;
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(2f);
            gp.setColor(fade(green(), k));
            rf.set(x + 1, cy2 - 11, x + 1 + vw, cy2 + 11);
            c.drawRoundRect(rf, 5, 5, gp);
            text(c, vo, x + 6, cy2, 16, bold, fade(green(), k));
            bx0 = x + vw + 8;
        }
        String band = si.band != null ? si.band : "?";
        float avail = 226 - (bx0 - x) - (si.data ? 54 : 0);
        String full = si.dist != null ? band + " · " + si.dist : band;
        String shown = tw(full, 22, semi) <= avail ? full : band;
        float fs = 22;
        float sw = tw(shown, fs, semi);
        if (sw > avail) fs = 22 * avail / sw;
        float ex = text(c, shown, bx0, cy2, fs, semi, fade(blue(), k));
        if (si.data) {
            float ax = ex + 10;
            ax = text(c, "↓", ax, cy2, 24, bold, dataIn ? green() : color);
            text(c, "↑", ax - 2, cy2, 24, bold, dataOut ? blue() : color);
        }
    }

    // ---- battery

    // ------------------------------------------------------------------ glyphs

    /** Small symbols, drawn around cy, starting at x, w wide. */
    private void glyph(Canvas c, int id, float x, float cy, float w, int col) {
        float cx = x + w / 2f;
        switch (id) {
            case G_BELL: {
                float h = w * 0.92f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float bw = h * 0.78f;
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.66f, cy + h * 0.2f, cx + bw * 0.66f, cy + h * 0.34f, gp);
                c.drawCircle(cx, cy + h * 0.44f, h * 0.1f, gp);
                break;
            }
            case G_BT: {
                float h = 30;
                stroke(3f, col);
                float x0 = x + 2, x1 = x + w - 2, mx = (x0 + x1) / 2f;
                path.reset();
                path.moveTo(x0, cy - h * 0.22f);
                path.lineTo(x1, cy + h * 0.2f);
                path.lineTo(mx, cy + h * 0.45f);
                path.lineTo(mx, cy - h * 0.45f);
                path.lineTo(x1, cy - h * 0.2f);
                path.lineTo(x0, cy + h * 0.22f);
                c.drawPath(path, gp);
                break;
            }
            case G_DROP: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f;
                c.drawCircle(cx, cy + 4, r, gp);
                path.reset();
                path.moveTo(cx, cy - 13);
                path.lineTo(cx - r * 0.95f, cy + 1);
                path.lineTo(cx + r * 0.95f, cy + 1);
                path.close();
                c.drawPath(path, gp);
                break;
            }
            case G_UMB: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(x + 1, cy - 14, x + w - 1, cy + 10);
                c.drawArc(rf, 180, 180, true, gp);
                stroke(3f, col);
                c.drawLine(cx, cy - 2, cx, cy + 12, gp);
                break;
            }
            case G_WIFI: {
                float bx = cx, by = cy + 10;
                stroke(3.2f, col);
                for (int i = 1; i <= 3; i++) {
                    float r = 6.5f * i;
                    rf.set(bx - r, by - r, bx + r, by + r);
                    c.drawArc(rf, 225, 90, false, gp);
                }
                gp.setStyle(Paint.Style.FILL);
                c.drawCircle(bx, by - 0.5f, 2.4f, gp);
                break;
            }
            case G_ALARM: {
                float h = w * 0.8f;
                stroke(2.6f, col);
                c.drawCircle(cx, cy + 2, h * 0.38f, gp);
                c.drawLine(cx, cy + 2, cx, cy - h * 0.18f, gp);
                c.drawLine(cx, cy + 2, cx + h * 0.16f, cy + h * 0.1f, gp);
                c.drawLine(cx - h * 0.44f, cy - h * 0.28f, cx - h * 0.26f, cy - h * 0.46f, gp);
                c.drawLine(cx + h * 0.44f, cy - h * 0.28f, cx + h * 0.26f, cy - h * 0.46f, gp);
                break;
            }
            case G_VIB: {
                float h = w * 0.9f;
                stroke(2.6f, col);
                rf.set(cx - h * 0.2f, cy - h * 0.48f, cx + h * 0.2f, cy + h * 0.48f);
                c.drawRoundRect(rf, h * 0.08f, h * 0.08f, gp);
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    c.drawLine(cx + sgn * h * 0.34f, cy - h * 0.22f, cx + sgn * h * 0.34f, cy + h * 0.22f, gp);
                    c.drawLine(cx + sgn * h * 0.5f, cy - h * 0.12f, cx + sgn * h * 0.5f, cy + h * 0.12f, gp);
                }
                break;
            }
            case G_SIL: {
                float h = w * 0.9f, bw = h * 0.7f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.62f, cy + h * 0.22f, cx + bw * 0.62f, cy + h * 0.34f, gp);
                stroke(3f, col);
                c.drawLine(cx - h * 0.5f, cy - h * 0.5f, cx + h * 0.5f, cy + h * 0.5f, gp);
                break;
            }
            case G_DND: {
                float h = w * 0.9f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                c.drawCircle(cx, cy, h * 0.46f, gp);
                gp.setColor(dk ? 0xFF1C1C1E : 0xFFFFFFFF);
                rf.set(cx - h * 0.26f, cy - h * 0.07f, cx + h * 0.26f, cy + h * 0.07f);
                c.drawRoundRect(rf, h * 0.05f, h * 0.05f, gp);
                break;
            }
            case G_SUN: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f, sx = x + w / 2f + 1;
                c.drawCircle(sx, cy, r, gp);
                for (int a = 0; a < 360; a += 45) {
                    double ra = Math.toRadians(a);
                    c.drawCircle((float) (sx + w * 0.62 * Math.cos(ra)), (float) (cy + w * 0.62 * Math.sin(ra)), 1.7f, gp);
                }
                break;
            }
            case G_HEAD: {
                stroke(3f, col);
                float r = w * 0.42f;
                rf.set(cx - r, cy - r, cx + r, cy + r);
                c.drawArc(rf, 180, 180, false, gp);
                gp.setStyle(Paint.Style.FILL);
                rf.set(cx - r - 2, cy - 1, cx - r + 6, cy + r * 0.85f);
                c.drawRoundRect(rf, 3, 3, gp);
                rf.set(cx + r - 6, cy - 1, cx + r + 2, cy + r * 0.85f);
                c.drawRoundRect(rf, 3, 3, gp);
                break;
            }
            case G_BOLT: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float hh = w * 1.15f;
                path.reset();
                path.moveTo(x + w * 0.62f, cy - hh / 2);
                path.lineTo(x + w * 0.08f, cy + hh * 0.08f);
                path.lineTo(x + w * 0.46f, cy + hh * 0.08f);
                path.lineTo(x + w * 0.34f, cy + hh / 2);
                path.lineTo(x + w * 0.94f, cy - hh * 0.12f);
                path.lineTo(x + w * 0.54f, cy - hh * 0.12f);
                path.close();
                c.drawPath(path, gp);
                break;
            }
            case G_EYE: {
                // eye: almond outline + pupil
                stroke(2.2f, col);
                float hw = w * 0.48f, hh = w * 0.30f;
                path.reset();
                path.moveTo(cx - hw, cy);
                path.quadTo(cx, cy - hh * 1.9f, cx + hw, cy);
                path.quadTo(cx, cy + hh * 1.9f, cx - hw, cy);
                c.drawPath(path, gp);
                gp.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, w * 0.16f, gp);
                break;
            }
            case G_CLOUD: {
                // cloud: three puffs on a flat base
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.2f, base = cy + w * 0.22f;
                c.drawCircle(cx - w * 0.22f, base - r, r, gp);
                c.drawCircle(cx + w * 0.02f, base - r * 1.55f, r * 1.3f, gp);
                c.drawCircle(cx + w * 0.26f, base - r * 0.9f, r * 0.9f, gp);
                rf.set(cx - w * 0.42f, base - r, cx + w * 0.44f, base);
                c.drawRoundRect(rf, r, r, gp);
                break;
            }
            case G_SUNSET: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.32f, sy = cy + 4;
                rf.set(cx - r, sy - r, cx + r, sy + r);
                c.drawArc(rf, 180, 180, true, gp);
                for (int a = 180; a <= 360; a += 45) {
                    double ra = Math.toRadians(a);
                    c.drawCircle((float) (cx + w * 0.55 * Math.cos(ra)), (float) (sy + w * 0.55 * Math.sin(ra)), 1.7f, gp);
                }
                c.drawRect(cx - w * 0.55f, sy + 1, cx + w * 0.55f, sy + 3.5f, gp);
                break;
            }
            default:
                break;
        }
    }

    private void stroke(float width, int col) {
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(width);
        gp.setStrokeCap(Paint.Cap.ROUND);
        gp.setStrokeJoin(Paint.Join.ROUND);
        gp.setColor(col);
    }

    // ================================================================== pro layout (4 rows, 1280 x 206)
    //
    //  strip : ISS / satellite · solar time + sun phase · moon phase name with illumination % under it
    //  left  : clock / zone | C / B temperature | amps / watts | GPU ...... ↓↑ speed by the camera   (row 1)
    //          sunrise-sunset · alarm · notifications | system-icon slot          (row 2)
    //          GPS satellites                                                     (row 3)
    //  centre: battery-health ring around the camera, "93% · 402" under it
    //  right : one column per SIM (network, operator, bars, ↓↑, Vo / dBm, SNR / band, distance, cells),
    //          battery; weather on rows 3 and 4 (temperature, feels, rain, UV, AQI / high-low, humidity, wind)

    boolean pro;
    int soh = -1, cycles = -1, cpuLoad = -1, sats = -1, ping = -1, deep = -1;
    String wake = "";
    boolean vpn;
    /** Camera hole centre and radius in this view's pixels (NaN = unknown). */
    float camX = Float.NaN, camY = Float.NaN, camR = Float.NaN;

    private static final float PRO_H = 206f;
    private static final float P_CLK = 56, P1A = 41, P1B = 77, P2 = 106, P3 = 158, P4 = 188;
    /** CPU / BAT temperatures: one line straight under the other, no gap. */
    private static final float T1A = 45, T1B = 73;
    private static final int G_HEAD = 11, G_BOLT = 12, G_SUNSET = 13, G_EYE = 14, G_CLOUD = 15;

    private void drawPro(Canvas c, int w, int h) {
        s = Math.min(w / DESIGN_W, h / PRO_H);
        W = w / s;
        vs = 1f;
        oy = Math.max(0f, (h / s - PRO_H) / 2f);
        c.save();
        try {
            c.scale(s, s);
            float cx = Float.isNaN(camX) ? W / 2f : camX / s;
            float cr = Float.isNaN(camR) ? 24f : Math.max(14f, Math.min(34f, camR / s));
            float ry = Float.isNaN(camY) ? oy + 50f : camY / s;
            float hw = Math.max(cr + 10f, tw(healthText(), 23, bold) / 2f + 6f);
            float leftEnd = cx - hw - 12f, rightStart = cx + hw + 12f, rightEnd = W - 8f;
            l4End = 0;
            w4Start = rightEnd;
            // row 1 may run up to the camera hole itself; the lower rows keep clear of the wider health text
            try { proLeft(c, leftEnd, Math.max(leftEnd, cx - cr - 14f)); } catch (Throwable ignored) { }
            try { proRight(c, rightStart, rightEnd); } catch (Throwable ignored) { }
            try { proCam(c, cx, ry, cr); } catch (Throwable ignored) { }
            try { proSky(c, cx); } catch (Throwable ignored) { }
        } finally {
            c.restore();
        }
    }

    /** Text whose baseline matches text of size ref centred on cy (for small units beside big numbers). */
    private float textB(Canvas c, String str, float x, float cy, float ref, float size, Typeface tf, int col) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(col);
        c.drawText(str, x, cy + ref * 0.36f, tp);
        return x + tp.measureText(str);
    }

    /**
     * Leftmost x (design units) where text whose top is at topU (design units) is not cut by the
     * screen's rounded top-left corner. 0 when the corner is unknown or the line is below it.
     */
    private float cornerX(float topU) {
        try {
            android.view.WindowInsets wi = getRootWindowInsets();
            if (wi == null || android.os.Build.VERSION.SDK_INT < 31) return 0;
            android.view.RoundedCorner rc = wi.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT);
            if (rc == null || rc.getRadius() <= 0) return 0;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float r = rc.getRadius();
            float ccx = rc.getCenter().x - loc[0], ccy = rc.getCenter().y - loc[1];
            float top = topU * s;
            if (top >= ccy) return 0;
            float dy = ccy - top;
            float x = ccx - (float) Math.sqrt(Math.max(0, r * r - dy * dy));
            return Math.max(0, x / s);
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Rightmost x (design units) clear of the screen's rounded top-right corner for text whose top is at topU. */
    private float cornerRightX(float topU) {
        try {
            android.view.WindowInsets wi = getRootWindowInsets();
            if (wi == null || android.os.Build.VERSION.SDK_INT < 31) return W;
            android.view.RoundedCorner rc = wi.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_RIGHT);
            if (rc == null || rc.getRadius() <= 0) return W;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float r = rc.getRadius();
            float ccx = rc.getCenter().x - loc[0], ccy = rc.getCenter().y - loc[1];
            float top = topU * s;
            if (top >= ccy) return W;
            float dy = ccy - top;
            return (ccx + (float) Math.sqrt(Math.max(0, r * r - dy * dy))) / s;
        } catch (Throwable t) {
            return W;
        }
    }

    private long zoneAt = 0;
    private String zoneTxt = "";

    /** "IST" for the phone's time zone, no GMT offset; "" when the zone has no short name. Checked once a minute. */
    private String zone(long now) {
        if (now - zoneAt < 60_000) return zoneTxt;
        zoneAt = now;
        try {
            java.util.TimeZone tz = java.util.TimeZone.getDefault();
            boolean dst = tz.inDaylightTime(new Date(now));
            String name = tz.getDisplayName(dst, java.util.TimeZone.SHORT, Locale.ENGLISH);
            if ("Asia/Kolkata".equals(tz.getID()) || "Asia/Calcutta".equals(tz.getID())) name = "IST";
            zoneTxt = name == null || name.startsWith("GMT") || name.startsWith("UTC") ? "" : name;
        } catch (Throwable t) {
            zoneTxt = "";
        }
        return zoneTxt;
    }

    private static String minus(String v) {
        return v.replace('-', '−');
    }

    // ---- left half

    private void proLeft(Canvas c, float L1, float top1) {
        long now = System.currentTimeMillis();
        if (now - h24CheckedAt > 30_000) {
            h24CheckedAt = now;
            try {
                h24 = android.text.format.DateFormat.is24HourFormat(getContext());
            } catch (Throwable ignored) { }
        }
        Date d = new Date(now);
        float cx0 = Math.max(20, cornerX(y(P1A) - 15) + 4);
        float e = text(c, (h24 ? t24 : t12).format(d), cx0, y(P1A), 38, bold, color);
        if (!h24) e = textB(c, ampm.format(d).toLowerCase(Locale.getDefault()), e + 3, y(P1A), 38, 17, semi, grey());
        // time zone name only (no GMT offset); nothing when the zone has no name
        String z = zone(now);
        if (!z.isEmpty()) {
            float zx0 = Math.max(20, cornerX(y(P1B) - 9) + 4);
            e = Math.max(e, textB(c, z, zx0, y(P1B), 22, 22, bold, color));
        }

        // network speed: fixed-width column at the right end of the left half, next to the camera
        float speedW = tw("↓", 30, bold) + 3 + tw("999", 30, bold) + 2 + tw("K/s", 20, semi);
        float sx = top1 - speedW;
        proSpeed(c, true, down, sx, y(P1A));
        proSpeed(c, false, up, sx, y(P1B));
        float lim = sx - 6;

        // C / B temperatures right after the clock, then amps / watts, then the GPU temperature
        float tx = e + 8;
        float lw = Math.max(tw("C", 20, semi), tw("B", 20, semi)) + 4;
        float colW = lw + tw("99°", 30, bold);
        if (tx + colW <= lim && (!Float.isNaN(cpu) || !Float.isNaN(bat))) {
            if (!Float.isNaN(cpu)) {
                textB(c, "C", tx, y(T1A), 30, 20, semi, grey());
                textB(c, Math.round(cpu) + "°", tx + lw, y(T1A), 30, 30, bold, heat(cpu, 45, 55, 65));
            }
            if (!Float.isNaN(bat)) {
                textB(c, "B", tx, y(T1B), 30, 20, semi, grey());
                textB(c, Math.round(bat) + "°", tx + lw, y(T1B), 30, 30, bold, heat(bat, 38, 42, 45));
            }
            tx += colW + 10;
        }
        if (!Float.isNaN(amps) && !Float.isNaN(watts)) {
            String sg = amps > 0 ? "+" : "−";
            float aw = Math.abs(watts);
            String av = sg + String.format(Locale.US, "%.2f", Math.abs(amps));
            String wv = sg + String.format(Locale.US, aw < 10 ? "%.1f" : "%.0f", aw);
            float bolt = charging ? 25 : 0;
            float pw = bolt + Math.max(tw(av, 30, bold) + tw("A", 20, semi), tw(wv, 30, bold) + tw("W", 20, semi)) + 2;
            if (tx + pw <= lim) {
                if (charging) glyph(c, G_BOLT, tx, y(T1A), 20, powerColor);
                float ae = textB(c, av, tx + bolt, y(T1A), 30, 30, bold, powerColor);
                textB(c, "A", ae + 1, y(T1A), 30, 20, semi, grey());
                float we = textB(c, wv, tx + bolt, y(T1B), 30, 30, bold, powerColor);
                textB(c, "W", we + 1, y(T1B), 30, 20, semi, grey());
                tx += pw + 10;
            }
        }
        // one column: GPU temperature on top, CPU usage under it
        if (!Float.isNaN(gpu) || cpuLoad >= 0) {
            float gl = Math.max(tw("GPU", 20, semi), tw("CPU", 20, semi)) + 4;
            float vw = Math.max(tw("99°", 30, bold), cpuLoad >= 0 ? tw(cpuLoad + "%", 27, bold) : 0);
            if (tx + gl + vw <= lim) {
                if (!Float.isNaN(gpu)) {
                    textB(c, "GPU", tx, y(T1A), 30, 20, semi, grey());
                    textB(c, Math.round(gpu) + "°", tx + gl, y(T1A), 30, 30, bold, heat(gpu, 45, 55, 65));
                }
                if (cpuLoad >= 0) {
                    int cc = cpuLoad < 50 ? green() : cpuLoad < 80 ? yellow() : red();
                    textB(c, "CPU", tx, y(T1B), 30, 20, semi, grey());
                    textB(c, cpuLoad + "%", tx + gl, y(T1B), 30, 27, bold, cc);
                }
            }
        }

        // row 2: sun, alarm, notifications, then the system icons in a frame
        List<Item> r2 = new ArrayList<>();
        String[] sun = nextSun(now);
        if (sun != null) {
            boolean rise = "r".equals(sun[1]);
            int sc = rise ? yellow() : orange();
            r2.add(new Item(8, 27).g(rise ? G_SUN : G_SUNSET, 26, sc).sp(6).t(sun[0], 27, bold, sc));
        }
        if (alarmAt > 0) {
            String f = alarmAt - now < 20 * 3600_000L ? "HH:mm" : "EEE HH:mm";
            String lbl = new SimpleDateFormat(f, Locale.US).format(new Date(alarmAt));
            r2.add(new Item(6, 27).g(G_ALARM, 26, color).sp(6).t(lbl, 27, semi, color));
        }
        String n = notifAll < 0 ? "?" : String.valueOf(notifAll);
        int ncol = notifAll == 0 ? grey() : orange();
        Item ni = new Item(9, 27).g(G_BELL, 24, ncol).sp(6).t(n, 27, bold, ncol);
        if (notifSilent > 0) ni.sp(5).t("(" + notifSilent + ")", 20, semi, grey());
        r2.add(ni);
        float e2 = drawLine(c, r2, 22, y(P2), L1 - 120, 18);
        proSlot(c, e2 + 16, L1, y(P2));

        // row 3: GPS (amps / watts moved up beside the temperatures; CPU load removed)
        List<Item> r3 = new ArrayList<>();
        int gc = sats < 0 ? grey() : sats >= 8 ? green() : sats > 0 ? yellow() : red();
        r3.add(new Item(5, 27).t("GPS", 20, semi, grey()).sp(7).t(sats < 0 ? "off" : sats + " sats", 27, bold, gc));
        drawLine(c, r3, 22, y(P3), L1, 22);

        // row 4: ping, deep sleep, RAM and GHz removed; GPU moved up to row 1
        l4End = 22;
    }

    private void proSpeed(Canvas c, boolean isDown, long bps, float x, float cy) {
        boolean idle = bps < 1024;
        int arrow = idle ? grey() : isDown ? green() : blue();
        int val = idle ? grey() : bps >= (10L << 20) ? teal() : color;
        String[] f = fmtSpeed(bps);
        float e = textB(c, isDown ? "↓" : "↑", x, cy, 30, 30, bold, arrow);
        e = textB(c, f[0], e + 3, cy, 30, 30, bold, val);
        textB(c, f[1], e + 2, cy, 30, 20, semi, grey());
    }

    /** {"06:30", "r"} for the next sunrise, {"18:09", "s"} for the next sunset. */
    private String[] nextSun(long now) {
        try {
            double[] sun = SunTimes.today(latLon[0], latLon[1]);
            if (Double.isNaN(sun[0]) || Double.isNaN(sun[1])) return null;
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(now);
            double m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
            if (m >= sun[0] && m < sun[1]) return new String[]{SunTimes.hhmm(sun[1]), "s"};
            return new String[]{SunTimes.hhmm(sun[0]), "r"};
        } catch (Throwable t) {
            return null;
        }
    }

    /** Framed slot for the system icons: Wi-Fi, Bluetooth, ringer / DND, VPN, then the stock tray icons. */
    private void proSlot(Canvas c, float x0, float x1, float cy) {
        if (x1 - x0 < 44) return;
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(2f);
        gp.setColor(fade(color, 0.32f));
        rf.set(x0, cy - 19, x1, cy + 19);
        c.drawRoundRect(rf, 11, 11, gp);
        float x = x0 + 10, lim = x1 - 10;
        int hidden = 0;
        if (wifiOn) {
            int lc = wifiLevel >= 3 ? green() : wifiLevel == 2 ? yellow() : wifiLevel == 1 ? orange() : red();
            float need = 28 + (wifiRssi != 0 ? 4 + tw(String.valueOf(wifiRssi), 20, bold) : 0);
            if (x + need <= lim) {
                glyph(c, G_WIFI, x, cy - 2, 28, lc);
                x += 30;
                if (wifiRssi != 0) x = textB(c, minus(String.valueOf(wifiRssi)), x, cy, 22, 20, bold, lc) + 8;
            } else hidden++;
        }
        if (btOn) {
            int bl = devs.isEmpty() ? -1 : devs.get(0).battery;
            String bp = bl >= 0 ? bl + "%" : null;
            float need = 20 + (bp != null ? 4 + 11 + 4 + tw(bp, 18, bold) : 0);
            if (x + need <= lim) {
                glyph(c, G_BT, x, cy, 18, devs.isEmpty() ? grey() : blue());
                x += 22;
                if (bp != null) {
                    int bc = SysViews.levelColor(bl, dk);
                    float bx = x + 2, bt = cy - 10, bb = cy + 10, bw = 9;
                    gp.setStyle(Paint.Style.FILL);
                    gp.setColor(color);
                    rf.set(bx + 2.5f, bt - 2.5f, bx + bw - 2.5f, bt);
                    c.drawRect(rf, gp);                                         // nub
                    gp.setStyle(Paint.Style.STROKE);
                    gp.setStrokeWidth(1.6f);
                    rf.set(bx, bt, bx + bw, bb);
                    c.drawRoundRect(rf, 2, 2, gp);                              // body
                    gp.setStyle(Paint.Style.FILL);
                    gp.setColor(bc);
                    float fh = (bb - bt - 3) * Math.max(0, Math.min(100, bl)) / 100f;
                    rf.set(bx + 1.5f, bb - 1.5f - fh, bx + bw - 1.5f, bb - 1.5f);
                    c.drawRect(rf, gp);                                         // fill
                    x = textB(c, bp, bx + bw + 4, cy, 18, 18, bold, bc) + 8;
                } else x += 4;
            } else hidden++;
        }
        if (ringer != 0) {
            if (x + 24 <= lim) {
                int g = ringer == 1 ? G_VIB : ringer == 2 ? G_SIL : G_DND;
                glyph(c, g, x, cy, 22, ringer == 1 ? orange() : ringer == 2 ? red() : purple());
                x += 30;
            } else hidden++;
        }
        if (vpn) {
            float vw = tw("VPN", 17, bold) + 10;
            if (x + vw <= lim) {
                gp.setStyle(Paint.Style.STROKE);
                gp.setStrokeWidth(2f);
                gp.setColor(green());
                rf.set(x, cy - 11, x + vw, cy + 11);
                c.drawRoundRect(rf, 5, 5, gp);
                textB(c, "VPN", x + 5, cy, 17, 17, bold, green());
                x += vw + 8;
            } else hidden++;
        }
        for (int i = 0; i < tray.size(); i++) {
            Bitmap b = tray.get(i);
            float ih = 24, iw = b.getHeight() == 0 ? ih : ih * b.getWidth() / b.getHeight();
            if (x + iw > lim) { hidden += tray.size() - i; break; }
            ip.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            rf.set(x, cy - ih / 2, x + iw, cy + ih / 2);
            c.drawBitmap(b, null, rf, ip);
            x += iw + 6;
        }
        if (hidden > 0) {
            String p = "+" + hidden;
            if (x + tw(p, 18, bold) <= x1 - 4) textB(c, p, x, cy, 18, 18, bold, grey());
        }
    }

    // ---- centre: battery health and cycles under the camera (numbers only)

    private String altText() {
        return fix != null && !Double.isNaN(fix[2]) ? " · " + Math.round(fix[2]) + "m" : "";
    }

    private String healthText() {
        return (soh > 0 ? soh + "%" : "--") + " · " + (cycles >= 0 ? String.valueOf(cycles) : "--") + altText();
    }

    private void proCam(Canvas c, float cx, float cy, float r) {
        try {
            float room = cy - r - 2;                         // free height above the hole
            if (room >= 9) {
                float size = Math.min(21f, room * 1.2f);
                // real phase and lit fraction for your place and time
                double ph;
                int lit;
                try {
                    Astro.Moon mo = Astro.moon(System.currentTimeMillis(), fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
                    ph = mo.phase;
                    lit = (int) Math.round(mo.illum * 100);
                } catch (Throwable t) {
                    ph = moonPhase();
                    lit = (int) Math.round(50 * (1 - Math.cos(2 * Math.PI * ph)));
                }
                String nm = MOON_NAMES[(int) Math.floor(ph * 8 + 0.5) % 8];
                float half = tw(nm, size, semi) / 2f;
                // phase name, and the illumination % straight under it (both squeezed into the room above the hole)
                float ps = Math.min(size, Math.max(9f, (room - 1) / 2.1f));
                float top = Math.max(ps * 0.38f + 1, ps * 0.5f + 1);
                float top2 = top + ps * 1.05f;
                if (top2 + ps * 0.45f > cy - r) {            // no room for two lines: name only, as before
                    ps = size;
                    top = Math.max(size * 0.38f + 1, room / 2f + 1);
                    top2 = Float.NaN;
                }
                size = ps;
                half = tw(nm, size, semi) / 2f;
                text(c, nm, cx - half, top, size, semi, grey());
                String ls = lit + "%";
                String la = ph < 0.5 ? "↑" : "↓";
                float lsW = tw(ls, size, bold) + tw(la, size * 0.8f, semi);
                if (!Float.isNaN(top2)) {
                    float le = text(c, ls, cx - lsW / 2f, top2, size, bold, color);
                    textB(c, la, le, top2, size, size * 0.8f, semi, grey());
                } else {
                    // fallback: right after the name on the same line
                    float le = text(c, ls, cx + half + 8, top, size, bold, color);
                    textB(c, la, le, top, size, size * 0.8f, semi, grey());
                }
                // ISS / satellite line at the left of the strip, above the clock
                try {
                    String sat = satText;
                    if (sat != null && !sat.isEmpty()) {
                        float sx0 = Math.max(20, cornerX(top - size * 0.4f) + 4);
                        float maxX = cx - half - 22;
                        String[] sol0 = solarNow();
                        if (sol0 != null) maxX -= tw(sol0[0], size, bold) + 8 + tw(sol0[1], size, semi) + 14;
                        int scol = satLive ? teal() : grey();
                        String st = sat;
                        while (st.length() > 4 && sx0 + tw(st, size, semi) > maxX) st = st.substring(0, st.length() - 2) + "…";
                        if (sx0 + tw(st, size, semi) <= maxX) text(c, st, sx0, top, size, semi, scol);
                    }
                } catch (Throwable ignored) { }
                try {
                    String[] sol = solarNow();
                    if (sol != null) {
                        float sx1 = cx - half - 22;
                        float w1 = tw(sol[0], size, bold), w2 = tw(sol[1], size, semi);
                        float sx0 = sx1 - w1 - 8 - w2;
                        if (sx0 >= Math.max(20, cornerX(top - size * 0.4f) + 4)) {
                            float e1 = text(c, sol[0], sx0, top, size, bold, yellow());
                            text(c, sol[1], e1 + 8, top, size, semi, color);
                        }
                    }
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
        String a = healthText();
        float ly = Math.max(y(P3), cy + r + 14);
        float w = tw(a, 23, bold);
        int hc = soh <= 0 ? color : soh >= 85 ? green() : soh >= 75 ? yellow() : soh >= 65 ? orange() : red();
        String pct = soh > 0 ? soh + "%" : "--";
        String alt = altText();
        float e = text(c, pct, cx - w / 2f, ly, 23, bold, hc);
        e = text(c, a.substring(pct.length(), a.length() - alt.length()), e, ly, 23, bold, color);
        if (!alt.isEmpty()) text(c, alt, e, ly, 23, bold, teal());
    }

    /** Row 4 centre: moon phase disc + illumination, then the latest nearby quake (24 h). */
    private void proSky(Canvas c, float cx) {
        double ph = moonPhase();
        List<Item> its = new ArrayList<>();
        // small moon disc only; its illumination % now sits under the phase name above the camera
        its.add(new Item(5, 24).sp(24));
        boolean q = !Float.isNaN(quakeMag);
        Item qi = new Item(3, 24);
        if (q) {
            int qc = quakeMag < 4 ? yellow() : quakeMag < 5.5 ? orange() : red();
            qi.t("M" + String.format(Locale.US, "%.1f", quakeMag), 24, bold, qc).sp(6);
            if (quakeKm >= 0) qi.t(quakeKm + "km", 20, semi, grey());
            if (quakeCc != null && !quakeCc.isEmpty()) qi.sp(6).t(quakeCc, 20, bold, color);
        } else {
            qi.t("no quake", 18, semi, grey());
        }
        its.add(qi);
        float lo = l4End + 18, hi = w4Start - 18;
        if (hi - lo < 60) return;
        float total = 0;
        for (Item it : its) total += it.w();
        total += 14;
        if (total > hi - lo) { its.remove(qi); total = its.get(0).w(); }
        if (total > hi - lo) return;
        float x = Math.max(lo, Math.min(hi - total, cx - total / 2f));
        moon(c, x + 12, y(P4), 11, ph);
        float e = drawItem(c, its.get(0), x, y(P4));
        if (its.size() > 1) drawItem(c, its.get(1), e + 14, y(P4));
    }

    /**
     * {"☉ 22:58", "Night"}: apparent solar time here, and the sun's phase right now from its elevation
     * (day, golden hour, civil / nautical / astronomical twilight as dawn or dusk, night). NOAA formulas.
     */
    private String[] solarNow() {
        double lat = fix != null ? fix[0] : latLon[0], lon = fix != null ? fix[1] : latLon[1];
        long now = System.currentTimeMillis();
        double jd = now / 86400000.0 + 2440587.5, t = (jd - 2451545.0) / 36525.0;
        double l0 = (280.46646 + t * (36000.76983 + t * 0.0003032)) % 360;
        double m = Math.toRadians(357.52911 + t * (35999.05029 - 0.0001537 * t));
        double e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t);
        double cc = Math.sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t)) + Math.sin(2 * m) * (0.019993 - 0.000101 * t)
                + Math.sin(3 * m) * 0.000289;
        double om = Math.toRadians(125.04 - 1934.136 * t);
        double lam = Math.toRadians(l0 + cc - 0.00569 - 0.00478 * Math.sin(om));
        double eps = Math.toRadians(23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
                + 0.00256 * Math.cos(om));
        double dec = Math.asin(Math.sin(eps) * Math.sin(lam));
        double y = Math.tan(eps / 2) * Math.tan(eps / 2), l0r = Math.toRadians(l0);
        double eot = 4 * Math.toDegrees(y * Math.sin(2 * l0r) - 2 * e * Math.sin(m) + 4 * e * y * Math.sin(m) * Math.cos(2 * l0r)
                - 0.5 * y * y * Math.sin(4 * l0r) - 1.25 * e * e * Math.sin(2 * m));          // minutes
        double utcMin = ((now % 86400000L) + 86400000L) % 86400000L / 60000.0;
        double solarMin = ((utcMin + 4 * lon + eot) % 1440 + 1440) % 1440;
        double ha = Math.toRadians(solarMin / 4 - 180);                                     // hour angle
        double la = Math.toRadians(lat);
        double el = Math.toDegrees(Math.asin(Math.sin(la) * Math.sin(dec) + Math.cos(la) * Math.cos(dec) * Math.cos(ha)));
        String ph;
        if (el >= 6) ph = Math.abs(solarMin - 720) < 15 ? "Solar noon" : "Day";
        else if (el >= -0.833) ph = "Golden hour";
        else if (el >= -6) ph = "Civil twilight";
        else if (el >= -12) ph = "Nautical twilight";
        else if (el >= -18) ph = "Astronomical twilight";
        else ph = Math.min(solarMin, 1440 - solarMin) < 15 ? "Solar midnight" : "Night";
        int sm = (int) Math.floor(solarMin);
        return new String[]{String.format(Locale.US, "☉ %02d:%02d", sm / 60, sm % 60), ph};
    }

    /** Moon phase 0..1 (0 new, 0.5 full). */
    private static double moonPhase() {
        double days = System.currentTimeMillis() / 86400000.0 + 2440587.5 - 2451550.1;
        return ((days % 29.530588853) + 29.530588853) % 29.530588853 / 29.530588853;
    }

    private static final String[] MOON_NAMES = {"New moon", "Waxing crescent", "First quarter", "Waxing gibbous",
            "Full moon", "Waning gibbous", "Last quarter", "Waning crescent"};

    /** Small moon: dark disc, lit side, terminator ellipse. */
    private void moon(Canvas c, float mx, float my, float r, double ph) {
        int litCol = 0xFFF2E9C9, darkCol = fade(color, 0.22f);
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(darkCol);
        c.drawCircle(mx, my, r, gp);
        boolean waxing = ph < 0.5;
        float k = (float) Math.cos(2 * Math.PI * ph);     // 1 new, -1 full
        android.graphics.Path p = new android.graphics.Path();
        rf.set(mx - r, my - r, mx + r, my + r);
        // lit half (right while waxing, left while waning, as seen from the north)
        p.addArc(rf, waxing ? -90 : 90, 180);
        p.close();
        gp.setColor(litCol);
        c.drawPath(p, gp);
        float ew = Math.abs(k) * r;
        rf.set(mx - ew, my - r, mx + ew, my + r);
        gp.setColor(k > 0 ? darkCol : litCol);
        c.drawOval(rf, gp);
    }

    // ---- right half

    private void proRight(Canvas c, float R0, float R1) {
        int n = Math.min(2, sims.size());
        float simR = Math.min(R1, cornerRightX(y(P1A) - 24) - 4);
        if (n > 0) {
            final float pad = 7, gap = 2;
            float[] bw = new float[n];
            float total = gap * (n - 1);
            for (int i = 0; i < n; i++) {
                bw[i] = simW(sims.get(i)) + 2 * pad;
                total += bw[i];
            }
            float f = total > simR - R0 ? (simR - R0) / total : 1f;
            float x = simR - total * f;
            for (int i = 0; i < n; i++) {
                SimInfo si = sims.get(i);
                float b = bw[i] * f;
                if (si.data) {
                    gp.setStyle(Paint.Style.STROKE);
                    gp.setStrokeWidth(2.5f);
                    gp.setColor(dk ? 0xFFFFFFFF : color);
                    rf.set(x + 1.25f, y(P1A) - 24, x + b - 1.25f, y(P2) + 17);
                    c.drawRoundRect(rf, 12, 12, gp);
                }
                try { proSim(c, si, x + pad * f, b - 2 * pad * f); } catch (Throwable ignored) { }
                x += b + gap * f;
            }
        }
        try { proQuality(c, simR + 3, W - 4); } catch (Throwable ignored) { }
        try { proWeather(c, R0, R1); } catch (Throwable ignored) { }
    }

    /** Data SIM signal quality 0-100: 60 % from RSRP (-125..-80 dBm), 40 % from SNR (-5..25 dB). */
    private int quality(SimInfo si) {
        if (!si.inService || si.dbm == Bands.NO_DBM) return -1;
        float a = Math.max(0, Math.min(1, (si.dbm + 125f) / 45f));
        if (Float.isNaN(si.snr)) return Math.round(a * 100);
        float b = Math.max(0, Math.min(1, (si.snr + 5f) / 30f));
        return Math.round((0.6f * a + 0.4f * b) * 100);
    }

    /** "Q" over "82%" in the corner space beside the SIMs (lines 1b and 2, below the corner curve). */
    private void proQuality(Canvas c, float x0, float x1) {
        SimInfo d = null;
        for (SimInfo si : sims) if (si.data) d = si;
        if (d == null) return;
        int q = quality(d);
        if (q < 0 || x1 - x0 < 14) return;
        final String v = q + "%";
        final int col = q >= 70 ? green() : q >= 45 ? yellow() : q >= 25 ? orange() : red();
        final float cw = x1 - x0;
        fit(c, x0, y(P1B), tw("Q", 16, semi), cw, () -> text(c, "Q", 0, 0, 16, semi, grey()));
        fit(c, x0, y(P2), tw(v, 20, bold), cw, () -> text(c, v, 0, 0, 20, bold, col));
    }

    private static final float DISH_W = 22;

    /** Phone picking up signals: phone outline (earpiece + home dot) with two waves arriving from the right. */
    private void dish(Canvas c, float x, float cy, int col) {
        stroke(2f, col);
        rf.set(x + 1, cy - 10, x + 11, cy + 10);
        c.drawRoundRect(rf, 2.5f, 2.5f, gp);                     // phone body
        c.drawLine(x + 4.5f, cy - 7, x + 7.5f, cy - 7, gp);      // earpiece
        gp.setStyle(Paint.Style.FILL);
        c.drawCircle(x + 6, cy + 7, 1.2f, gp);                   // home dot
        stroke(2f, col);
        rf.set(x + 9, cy - 7, x + 17, cy + 1);
        c.drawArc(rf, -60, 120, false, gp);                      // inner wave
        rf.set(x + 9, cy - 11, x + 23, cy + 5);
        c.drawArc(rf, -55, 110, false, gp);                      // outer wave
    }

    private static final float BARS_W = 4 * 9.5f;

    /** Width of the Samsung-style voice badge: "Vo" with an antenna, "NR" / "LTE" under it. */
    private float voW(String type) {
        return Math.max(tw("Vo", 17, bold) + 9, tw(type, 13, bold));
    }

    /** "Vo" on top with a little antenna at its upper right, the voice type (NR / LTE / WiFi) under it. */
    private void voBadge(Canvas c, String type, float x, int col) {
        tp.setTypeface(bold);
        tp.setTextSize(17);
        tp.setColor(col);
        c.drawText("Vo", x, -2, tp);
        float ax = x + tw("Vo", 17, bold) + 4, ay = -14;
        stroke(1.6f, col);
        c.drawLine(ax, ay - 1, ax, ay + 8, gp);
        rf.set(ax - 4, ay - 5, ax + 4, ay + 3);
        c.drawArc(rf, -150, 60, false, gp);
        c.drawArc(rf, -30, 60, false, gp);
        gp.setStyle(Paint.Style.FILL);
        c.drawCircle(ax, ay - 1, 1.6f, gp);
        tp.setTypeface(bold);
        tp.setTextSize(13);
        tp.setColor(col);
        c.drawText(type, x, 13, tp);
    }

    /** Natural width of one SIM's block (its widest line). */
    private float simW(SimInfo si) {
        boolean live = si.inService;
        String rat = live && si.rat != null && !si.rat.isEmpty() ? si.rat : "—";
        float wa = (si.data ? tw("↓↑", 26, bold) + 6 : 0) + tw(rat, 34, bold) + (si.eco ? 6 + tw("E", 22, bold) : 0)
                + (si.roaming ? 12 + tw("R", 18, bold) : 0) + 10 + BARS_W + (si.voice != null ? 8 + voW(si.voice) : 0);
        String dbm = live && si.dbm != Bands.NO_DBM ? minus(String.valueOf(si.dbm)) : null;
        String snr = live && !Float.isNaN(si.snr) ? minus(String.valueOf(Math.round(si.snr))) : null;
        float wb = (dbm != null ? tw(dbm, 28, bold) + 3 + tw("dBm", 18, semi) : 0)
                + (snr != null ? 14 + tw(snr, 28, bold) + 3 + tw("dB", 18, semi) : 0);
        String band = si.band != null ? si.band : "?";
        float w2 = tw(band, 26, semi) + (si.dist != null ? 10 + tw(si.dist, 26, semi) : 0)
                + (si.cells > 0 ? 12 + DISH_W + 4 + tw(String.valueOf(si.cells), 24, bold) : 0);
        return Math.max(wa, Math.max(wb, w2));
    }

    /** Draws [draw] scaled down to fit width cw if it is wider. */
    private void fit(Canvas c, float x, float cy, float width, float cw, Runnable draw) {
        float f = width > cw ? cw / width : 1f;
        c.save();
        c.translate(x, cy);
        if (f < 1f) c.scale(f, f);
        try { draw.run(); } finally { c.restore(); }
    }

    private void proSim(final Canvas c, final SimInfo si, float x, float cw) {
        final boolean live = si.inService;
        final float k = si.data ? 1f : 0.8f;
        final String rat = live && si.rat != null && !si.rat.isEmpty() ? si.rat : "—";
        final String vo = si.voice;
        final float barsW = BARS_W;
        float wa = (si.data ? tw("↓↑", 26, bold) + 6 : 0) + tw(rat, 34, bold) + (si.eco ? 6 + tw("E", 22, bold) : 0)
                + (si.roaming ? 12 + tw("R", 18, bold) : 0) + 10 + barsW + (vo != null ? 8 + voW(vo) : 0);
        // line 1a: network, operator, bars, live arrows, voice
        fit(c, x, y(P1A), wa, cw, () -> {
            float e = 0;
            if (si.data) {
                // live arrows only while data actually moves; the space stays so the network type doesn't jump
                float dw = tw("↓", 26, bold);
                if (dataIn) textB(c, "↓", e, 0, 34, 26, bold, green());
                if (dataOut) textB(c, "↑", e + dw - 1, 0, 34, 26, bold, blue());
                e += dw - 1 + tw("↑", 26, bold) + 6;
            }
            e = textB(c, rat, e, 0, 34, 34, bold, fade(color, k));
            if (si.roaming) {
                float rw = tw("R", 18, bold) + 8;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(orange());
                rf.set(e + 4, -12, e + 4 + rw, 12);
                c.drawRoundRect(rf, 5, 5, gp);
                textB(c, "R", e + 8, 0, 18, 18, bold, 0xFF3A1C00);
                e += 4 + rw;
            }
            if (si.eco) e = textB(c, "E", e + 6, 0, 34, 22, bold, green());
            e += 10;
            boolean has = live && si.dbm != Bands.NO_DBM;
            int lvl = !has ? 0 : si.dbm >= -90 ? 4 : si.dbm >= -100 ? 3 : si.dbm >= -110 ? 2 : si.dbm >= -120 ? 1 : 0;
            int bc = has ? dbmColor(si.dbm) : grey();
            gp.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 4; i++) {
                float bh = 26f * (i + 1) / 4f, l = e + i * 9.5f;
                gp.setColor(i < lvl ? bc : fade(color, 0.22f));
                rf.set(l, 12 - bh, l + 6.5f, 12);
                c.drawRoundRect(rf, 2, 2, gp);
            }
            e += barsW;
            if (vo != null) voBadge(c, vo, e + 8, fade(green(), k));
        });
        // line 1b: dBm, SNR
        final String dbm = live && si.dbm != Bands.NO_DBM ? minus(String.valueOf(si.dbm)) : null;
        final String snr = live && !Float.isNaN(si.snr) ? minus(String.valueOf(Math.round(si.snr))) : null;
        if (dbm != null || snr != null) {
            float wb = (dbm != null ? tw(dbm, 28, bold) + 3 + tw("dBm", 18, semi) : 0)
                    + (snr != null ? 14 + tw(snr, 28, bold) + 3 + tw("dB", 18, semi) : 0);
            fit(c, x, y(P1B), wb, cw, () -> {
                float e = 0;
                if (dbm != null) {
                    e = textB(c, dbm, 0, 0, 28, 28, bold, fade(dbmColor(si.dbm), k));
                    e = textB(c, "dBm", e + 3, 0, 28, 18, semi, grey()) + 14;
                }
                if (snr != null) {
                    int sc = si.snr >= 13 ? green() : si.snr >= 5 ? yellow() : si.snr >= 0 ? orange() : red();
                    e = textB(c, snr, e, 0, 28, 28, bold, fade(sc, k));
                    textB(c, "dB", e + 3, 0, 28, 18, semi, grey());
                }
            });
        }
        // row 2: band, distance, cells heard
        final String band = si.band != null ? si.band : "?";
        final String dist = si.dist;
        final String cells = si.cells > 0 ? String.valueOf(si.cells) : null;
        float w2 = tw(band, 26, semi) + (dist != null ? 10 + tw(dist, 26, semi) : 0)
                + (cells != null ? 12 + DISH_W + 4 + tw(cells, 24, bold) : 0);
        fit(c, x, y(P2), w2, cw, () -> {
            float e = textB(c, band, 0, 0, 26, 26, semi, fade(blue(), k));
            if (dist != null) e = textB(c, dist, e + 10, 0, 26, 26, semi, fade(color, k));
            if (cells != null) {
                dish(c, e + 12, 0, grey());
                e += 12 + DISH_W - 1;
                textB(c, cells, e + 5, 0, 26, 24, bold, grey());
            }
        });
    }

    private void proWeather(Canvas c, float R0, float R1) {
        if (wxTemp == null) return;
        // row 3: icon, temperature, feels, rain, UV ... AQI pill on the right
        float max3 = R1;
        if (wxAqi >= 0) {
            String a = "AQI " + wxAqi;
            float pw = tw(a, 22, bold) + 22;
            int ac = wxAqi <= 50 ? 0xFF2E9E4F : wxAqi <= 100 ? 0xFFC9A400 : wxAqi <= 150 ? 0xFFE07B1A
                    : wxAqi <= 200 ? 0xFFD93A2B : wxAqi <= 300 ? 0xFF8E3FB5 : 0xFF7A1F2B;
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(ac);
            rf.set(R1 - pw, y(P3) - 17, R1, y(P3) + 17);
            c.drawRoundRect(rf, 17, 17, gp);
            textB(c, a, R1 - pw + 11, y(P3), 22, 22, bold, 0xFFFFFFFF);
            max3 = R1 - pw - 6;
        }
        List<Item> l3 = new ArrayList<>();
        l3.add(new Item(10, 38).t(wxTemp + "°", 38, bold, color));
        if (wxRain >= 0) l3.add(new Item(5, 26).g(G_UMB, 22, blue()).sp(5).t(wxRain + "%", 25, bold, color));
        if (!Float.isNaN(wxUv)) {
            int uv = Math.round(wxUv);
            int uc = uv < 3 ? green() : uv < 6 ? yellow() : uv < 8 ? orange() : red();
            l3.add(new Item(4, 26).t("UV", 19, semi, grey()).sp(5).t(String.valueOf(uv), 25, bold, uc));
        }
        float x3 = tailStart(l3, max3, R0 + 44, 14);
        drawTail(c, l3, max3, y(P3), R0 + 44, 14);
        if (wxIcon != null) {
            try {
                float ix = x3 - 42;
                wxIcon.setBounds(Math.round(ix), Math.round(y(P3) - 18), Math.round(ix + 36), Math.round(y(P3) + 18));
                if (wxTint) wxIcon.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                else wxIcon.clearColorFilter();
                wxIcon.draw(c);
            } catch (Throwable ignored) { }
        }

        // row 4: high / low, humidity, wind
        List<Item> l4 = new ArrayList<>();
        // visibility · cloud cover, first on the line so it sits under the temperature
        if (!Float.isNaN(wxVis) || wxCloud >= 0) {
            Item vc = new Item(3, 25);
            if (!Float.isNaN(wxVis)) {
                String v = wxVis >= 10000 ? Math.round(wxVis / 1000f) + "" : wxVis >= 1000
                        ? String.format(Locale.US, "%.1f", wxVis / 1000f) : String.valueOf(Math.round(wxVis));
                String u = wxVis >= 1000 ? "km" : "m";
                int col = wxVis >= 5000 ? color : wxVis >= 2000 ? yellow() : orange();
                vc.g(G_EYE, 22, grey()).sp(4).t(v, 25, bold, col).t(u, 17, semi, grey());
            }
            if (!Float.isNaN(wxVis) && wxCloud >= 0) vc.sp(5).t("·", 18, bold, grey()).sp(5);
            if (wxCloud >= 0) vc.g(G_CLOUD, 24, grey()).sp(4).t(wxCloud + "%", 25, bold, color);
            l4.add(vc);
        }
        if (!Float.isNaN(wxMax) && !Float.isNaN(wxMin)) {
            l4.add(new Item(8, 25).t("↑", 24, bold, orange()).t(Math.round(wxMax) + "°", 25, bold, color).sp(10)
                    .t("↓", 24, bold, blue()).t(Math.round(wxMin) + "°", 25, bold, color));
        }
        if (wxHum >= 0) l4.add(new Item(6, 25).g(G_DROP, 20, teal()).sp(5).t(wxHum + "%", 25, bold, color));
        if (!Float.isNaN(wxWind)) {
            l4.add(new Item(5, 25).t(wxArrow == null ? "" : wxArrow, 24, bold, grey()).sp(4)
                    .t(String.valueOf(Math.round(wxWind)), 25, bold, color).t(" km/h", 19, semi, grey()));
        }
        w4Start = tailStart(l4, R1, R0 + 44, 16);
        drawTail(c, l4, R1, y(P4), R0 + 44, 16);
    }
}
