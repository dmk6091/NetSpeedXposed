package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.TrafficStats;
import android.os.SystemClock;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The "readable" status bar: one view that draws four evenly spaced lines of large text.
 *
 *   left   : clock, seconds line, date, sunrise - sunset
 *   next   : CPU / battery temperature, watts, amps
 *   next   : download / upload speed, notification count, Bluetooth device
 *   centre : left empty (camera)
 *   right  : one block per SIM (network, operator, signal, band, distance, voice dot; the SIM that
 *            carries mobile data sits in a highlighted pill with live ↓↑), weather under them,
 *            then the portrait battery
 *
 * Everything is drawn in a 1280 x 124 design space that is scaled to the bar. When a line is too
 * long the least important item drops out instead of anything being cut or squeezed.
 * DualRow.Updater fills in the model fields once a second; the old layout keeps running hidden.
 */
final class ReadableBar extends View {

    /** One SIM's block. */
    static final class SimInfo {
        int slot;
        String rat;        // "5G", "4G+" ... null = unknown
        boolean inService;
        int dbm = Bands.NO_DBM;
        String opLetter;   // operator badge
        boolean roaming;
        int opColor;
        String band;       // "n78"
        String dist;       // "1.0km" or null
        String voice;      // "NR", "LTE", "WiFi" when calls use IMS, else null
        boolean data;      // carries mobile data
        boolean inCall;
        int cells = -1;
        boolean eco;       // NetSwitch eco mode (5G off to save battery)
        float snr = Float.NaN;
        String area;       // locality of the tower ("Ravet"), null = unknown
        String netName;    // network's own broadcast name when it differs from the SIM's ("Dolphin"), else null
        String circle;     // circle code when on another circle's network ("KA"), else null
        String nrMode;     // "SA" / "NSA·B3" / null
        int cqi = -1;      // channel quality 0..15, -1 unknown
        int rsrq = Integer.MIN_VALUE;
        int pci = -1, arfcn = -1, tac = -1;   // serving cell details, -1 unknown
        long dataToday = -1;                  // bytes on this SIM since midnight
        String bearing;                       // "↗NE" from you to the tower, null unknown
        int hoToday;                          // tower switches today for this SIM
        String onCell;                        // time on this tower: "45s", "3m", "1h05"
        String trend;                         // signal change over the last minute: "+4dB" / "−5dB", null steady
    }

    // ------------------------------------------------------------------ model (main thread)
    int color = 0xFFFFFFFF;
    Typeface base;
    float cpu = Float.NaN, bat = Float.NaN, amps = Float.NaN, watts = Float.NaN;
    int powerColor = 0xFFFFD60A;
    boolean charging;
    int notifAll = -1, notifSilent;
    boolean btOn;
    List<SysState.Dev> devs = new ArrayList<>();
    int ringer;                    // 0 none, 1 vibrate, 2 silent, 3 DND
    long alarmAt = -1;
    boolean wifiOn;
    int wifiLevel, wifiRssi, wifiFreq;
    List<Bitmap> tray = new ArrayList<>();
    List<SimInfo> sims = new ArrayList<>();
    boolean dataIn, dataOut;
    String wxTemp;
    Drawable wxIcon;
    int wxCode = -1;   // OmniJaws / Yahoo condition code behind the icon
    boolean wxTint = true;
    float wxMax = Float.NaN, wxMin = Float.NaN, wxFeels = Float.NaN, wxWind = Float.NaN, wxUv = Float.NaN;
    int wxHum = -1, wxRain = -1, wxAqi = -1;
    String wxArrow = "";
    int battPct = -1;
    double[] latLon = {18.62, 73.80};
    float gpu = Float.NaN;
    float ghz = Float.NaN;
    long ramFree = -1, ramTotal = -1;
    float wxVis = Float.NaN;
    int wxCloud = -1;
    int hz = -1;
    double[] fix;
    float groundElev = Float.NaN;
    float quakeMag = Float.NaN;
    int quakeKm = -1;
    long quakeAt = 0;
    String quakeCc;
    /** Strip above the clock: "ISS over Nagpur", "No ISS pass", plus a satellite in your sky; satLive = something is up. */
    long m4g = 0, m5g = 0;                        // this month's 4G / 5G data
    long used4g = 0, limit4g = 1, used5g = 0;   // today's 4G data and the fallback limit
    int nrShare = -1;               // % of today on 5G, -1 unknown
    String satText = "";
    boolean satLive;
    String satIssS = "", satNameS = "", satCityS = "";
    /** Where the left row 4 ended and the right (weather) row 4 starts, for the centre item. */
    private float l4End = 0, w4Start = 1e9f, healthEnd = 0;
    /** How far right row 4 is free for the quake line: under SIM boxes whose area text stays on one line. */
    private float q4End = 1e9f;
    /** What the moon / quake line did last frame (for the NetSpeed app's diagnostics box). */
    static volatile String skyDbg = "";

    // ------------------------------------------------------------------ internals
    private static final float DESIGN_W = 1280f, DESIGN_H = 124f;
    private static final float CY1 = 16, CY2 = 46, CY3 = 76, CY4 = 106;   // line centres, design px

    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private Typeface bold = Typeface.DEFAULT_BOLD, semi = Typeface.DEFAULT_BOLD, reg = Typeface.DEFAULT;
    private Typeface builtFrom;
    private boolean dk = true;

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEE d MMM", Locale.getDefault());
    private final SimpleDateFormat t24 = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat t12 = new SimpleDateFormat("h:mm", Locale.getDefault());
    private final SimpleDateFormat ampm = new SimpleDateFormat("a", Locale.getDefault());
    private boolean h24 = true;
    private long h24CheckedAt;

    private long lastRx = -1, lastTx = -1, lastAt;
    private long down, up;
    private String sunTxt = "";
    private long sunAt;

    private float s = 1f, oy = 0f, vs = 1f, W = DESIGN_W;

    ReadableBar(Context c) {
        super(c);
        setWillNotDraw(false);
    }

    // ------------------------------------------------------------------ tick (seconds hand, clock)

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (isAttachedToWindow()) {
                long now = System.currentTimeMillis();
                postDelayed(this, 1000 - now % 1000 + 5);
            }
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(tick);
        post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    /** Called once a second by the updater: network speed from the traffic counters. */
    void sampleSpeed() {
        long rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        long now = SystemClock.elapsedRealtime();
        if (lastAt > 0 && rx >= 0 && tx >= 0 && lastRx >= 0) {
            long dt = Math.max(1, now - lastAt);
            down = Math.max(0, (rx - lastRx) * 1000 / dt);
            up = Math.max(0, (tx - lastTx) * 1000 / dt);
        }
        lastRx = rx;
        lastTx = tx;
        lastAt = now;
    }

    // ------------------------------------------------------------------ text items

    private static final int G_BELL = 1, G_BT = 2, G_DROP = 3, G_UMB = 4, G_WIFI = 5, G_ALARM = 6,
            G_VIB = 7, G_SIL = 8, G_DND = 9, G_SUN = 10, G_SPACE = 99;

    private static final class Part {
        String text;
        float size;
        Typeface tf;
        int col;
        int glyph;
        float w;
    }

    /** A group that stays together on a line; low priority groups drop out first when it is full. */
    private final class Item {
        final int prio;
        final float ref;
        final List<Part> parts = new ArrayList<>();
        float width = -1;

        Item(int prio, float ref) {
            this.prio = prio;
            this.ref = ref;
        }

        Item t(String text, float size, Typeface tf, int col) {
            Part p = new Part();
            p.text = text;
            p.size = size;
            p.tf = tf;
            p.col = col;
            tp.setTypeface(tf);
            tp.setTextSize(size);
            p.w = tp.measureText(text);
            parts.add(p);
            return this;
        }

        Item g(int glyph, float w, int col) {
            Part p = new Part();
            p.glyph = glyph;
            p.w = w;
            p.col = col;
            parts.add(p);
            return this;
        }

        Item sp(float w) {
            return g(G_SPACE, w, 0);
        }

        float w() {
            if (width < 0) {
                float x = 0;
                for (Part p : parts) x += p.w;
                width = x;
            }
            return width;
        }
    }

    private float drawItem(Canvas c, Item it, float x, float cy) {
        float base = cy + it.ref * 0.36f;
        for (Part p : it.parts) {
            if (p.glyph == 0) {
                tp.setTypeface(p.tf);
                tp.setTextSize(p.size);
                tp.setColor(p.col);
                c.drawText(p.text, x, base, tp);
            } else if (p.glyph != G_SPACE) {
                glyph(c, p.glyph, x, cy, p.w, p.col);
            }
            x += p.w;
        }
        return x;
    }

    /** Draws left to right from x, dropping the lowest priority item until it fits before maxX. */
    private float drawLine(Canvas c, List<Item> items, float x, float cy, float maxX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (use.size() > 1) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (x + total <= maxX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float end = x;
        for (int i = 0; i < use.size(); i++) {
            end = drawItem(c, use.get(i), end, cy);
            if (i < use.size() - 1) end += gap;
        }
        return end;
    }

    /** Right-aligned at rightX, but only as much as fits to the right of minX. */
    private void drawTail(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            x = drawItem(c, use.get(i), x, cy);
            if (i < use.size() - 1) x += gap;
        }
    }

    /** Where drawTail would start the line (same dropping rule). */
    private float tailStart(List<Item> items, float rightX, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) return rightX - total;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        return rightX;
    }

    // ------------------------------------------------------------------ colours

    private int teal() { return SysViews.teal(dk); }
    private int blue() { return SysViews.blue(dk); }
    private int green() { return SysViews.green(dk); }
    private int yellow() { return SysViews.yellow(dk); }
    private int orange() { return SysViews.orange(dk); }
    private int red() { return SysViews.red(dk); }
    private int purple() { return SysViews.purple(dk); }
    /** Secondary text (units, labels): light grey on a dark bar so it stays readable, dimmed text on a light one. */
    private int grey() { return dk ? 0xFFCDCDCD : SysViews.dim(color); }

    private static int fade(int col, float k) {
        int a = Math.round(((col >>> 24) & 0xFF) * k);
        return (col & 0x00FFFFFF) | (a << 24);
    }

    private int heat(float t, float warm, float hot, float burn) {
        return t >= burn ? red() : t >= hot ? orange() : t >= warm ? yellow() : color;
    }

    private int dbmColor(int dbm) {
        return dbm >= -95 ? green() : dbm >= -105 ? yellow() : dbm >= -115 ? orange() : red();
    }

    // ------------------------------------------------------------------ drawing

    private void fonts() {
        if (builtFrom == base && bold != null) return;
        builtFrom = base;
        Typeface b = base != null ? base : Typeface.DEFAULT;
        try {
            bold = Typeface.create(b, 700, false);
            semi = Typeface.create(b, 600, false);
            reg = Typeface.create(b, 500, false);
        } catch (Throwable t) {
            bold = Typeface.create(b, Typeface.BOLD);
            semi = bold;
            reg = b;
        }
    }

    private long brightAt = 0;
    private int brightA = 255;

    /**
     * Bar opacity (140..255) that follows the screen brightness you set: full from half brightness up,
     * easing down to ~55 % at the lowest, so the bar never glares in a dark room. Checked every 2 s.
     */
    private int brightAlpha() {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - brightAt < 2000) return brightA;
        brightAt = now;
        try {
            float frac = -1;
            String src = "";
            // the display's real brightness right now (follows auto-brightness and your slider)
            try {
                Object bi = getContext().getDisplay().getClass().getMethod("getBrightnessInfo").invoke(getContext().getDisplay());
                if (bi != null) {
                    Class<?> k = bi.getClass();
                    float br = k.getField("brightness").getFloat(bi), mn = k.getField("brightnessMinimum").getFloat(bi),
                            mx = k.getField("brightnessMaximum").getFloat(bi);
                    if (mx > mn) {
                        frac = (br - mn) / (mx - mn);
                        src = "display " + br;
                    }
                }
            } catch (Throwable ignored) { }
            if (frac < 0) {
                android.content.ContentResolver cr = getContext().getContentResolver();
                try {
                    frac = android.provider.Settings.System.getFloat(cr, "screen_brightness_float");   // 0..1 where available
                    src = "setting float " + frac;
                } catch (Throwable e) {
                    int v = android.provider.Settings.System.getInt(cr, "screen_brightness", 255);
                    int max = 255;
                    try {
                        android.os.PowerManager pm = (android.os.PowerManager) getContext().getSystemService(android.content.Context.POWER_SERVICE);
                        max = (Integer) pm.getClass().getMethod("getMaximumScreenBrightnessSetting").invoke(pm);
                    } catch (Throwable ignored) { }
                    frac = v / (float) Math.max(1, max);
                    src = "setting " + v + "/" + max;
                }
            }
            frac = Math.max(0f, Math.min(1f, frac));
            int na = Math.round(140 + 115 * Math.min(1f, frac / 0.5f));
            if (Math.abs(na - brightA) >= 8)
                de.robv.android.xposed.XposedBridge.log("NetSpeedXposed: [dim] brightness " + Math.round(frac * 100) + "% (" + src + ") -> bar opacity "
                        + Math.round(na * 100 / 255f) + "%");
            brightA = na;
        } catch (Throwable t) {
            brightA = 255;
        }
        return brightA;
    }

    @Override
    protected void onDraw(Canvas c) {
        int layer = -1;
        try {
            if (Cfg.b(Cfg.DIM_NIGHT, Cfg.D_DIM_NIGHT)) {
                int a = brightAlpha();
                if (a < 250) layer = c.saveLayerAlpha(0, 0, getWidth(), getHeight(), a);
            }
        } catch (Throwable ignored) { layer = -1; }
        try {
            draw2(c);
        } catch (Throwable t) {
            // never take System UI down over a drawing slip
        }
        if (layer >= 0) c.restoreToCount(layer);
    }

    private void draw2(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fonts();
        dk = SysViews.dark(color);
        if (pro) {
            drawPro(c, w, h);
            return;
        }
        s = Math.min(w / DESIGN_W, h / DESIGN_H);
        W = w / s;
        oy = -3f;
        vs = Math.max(1f, Math.min(1.36f, (h / s) / DESIGN_H));
        c.save();
        try {
            c.scale(s, s);
            // each part on its own, so one slip doesn't blank the others
            try { drawClock(c); } catch (Throwable ignored) { }
            try { drawDevice(c); } catch (Throwable ignored) { }
            try { drawActivity(c); } catch (Throwable ignored) { }
            try { drawSims(c); } catch (Throwable ignored) { }
        } finally {
            c.restore();
        }
    }

    private float y(float line) {
        return oy + line * vs;
    }

    /** Plain text, baseline set so that cy is the visual middle of the digits. */
    private float text(Canvas c, String str, float x, float cy, float size, Typeface tf, int col) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(col);
        c.drawText(str, x, cy + size * 0.36f, tp);
        return x + tp.measureText(str);
    }

    private float tw(String str, float size, Typeface tf) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        return tp.measureText(str);
    }

    // ---- clock, seconds line, date, sun

    private void drawClock(Canvas c) {
        long now = System.currentTimeMillis();
        if (now - h24CheckedAt > 30_000) {
            h24CheckedAt = now;
            try {
                h24 = true;   // always 24-hour
            } catch (Throwable ignored) { }
        }
        Date d = new Date(now);
        String time = (h24 ? t24 : t12).format(d);
        float x = 22;
        float end = text(c, time, x, y(38), 60, bold, color);
        if (!h24 && end + 4 + 30 < 210) text(c, ampm.format(d).toLowerCase(Locale.getDefault()), end + 4, y(52), 20, semi, grey());
        // seconds line
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(SysViews.faint(color));
        rf.set(24, y(70), 182, y(73));
        c.drawRect(rf, gp);
        gp.setColor(teal());
        rf.set(24, y(70), 24 + 158 * ((now % 60_000L) / 60_000f), y(73));
        c.drawRect(rf, gp);
        text(c, dateFmt.format(d), 24, y(90), 25, semi, color);
        // sunrise - sunset, refreshed every few minutes
        if (now - sunAt > 5 * 60_000L || sunTxt.isEmpty()) {
            sunAt = now;
            try {
                double[] sun = SunTimes.today(latLon[0], latLon[1]);
                sunTxt = SunTimes.hhmm(sun[0]) + " – " + SunTimes.hhmm(sun[1]);
            } catch (Throwable t) {
                sunTxt = "";
            }
        }
        if (!sunTxt.isEmpty()) {
            glyph(c, G_SUN, 24, y(112), 17, orange());
            text(c, sunTxt, 50, y(112), 24, bold, orange());
        }
    }

    // ---- CPU / battery temperature, watts, amps

    private void drawDevice(Canvas c) {
        float x = 214;
        if (!Float.isNaN(cpu)) {
            int col = heat(cpu, 45, 55, 65);
            text(c, "CPU", x, y(CY1), 20, semi, teal());
            text(c, Math.round(cpu) + "°", x + 52, y(CY1), 29, bold, col);
        }
        if (!Float.isNaN(bat)) {
            int col = heat(bat, 38, 42, 45);
            text(c, "BAT", x, y(CY2), 20, semi, teal());
            text(c, Math.round(bat) + "°", x + 52, y(CY2), 29, bold, col);
        }
        if (!Float.isNaN(watts) && !Float.isNaN(amps)) {
            float aw = Math.abs(watts);
            String ws = (amps > 0 ? "+" : "\u2212") + String.format(Locale.US, aw < 10 ? "%.1f" : "%.0f", aw);
            float e = text(c, ws, x, y(CY3), 29, bold, powerColor);
            text(c, "W", e + 1, y(CY3), 22, bold, powerColor);
            String as = (amps > 0 ? "+" : "\u2212") + String.format(Locale.US, "%.2f", Math.abs(amps));
            e = text(c, as, x, y(CY4), 25, semi, powerColor);
            text(c, "A", e + 1, y(CY4), 19, semi, powerColor);
        }
    }

    // ---- speed, notifications, Bluetooth

    private static String[] fmtSpeed(long bps) {
        if (bps < 1024) return new String[]{String.valueOf(bps), "B/s"};
        double kb = bps / 1024.0;
        if (kb < 100) return new String[]{String.format(Locale.US, "%.1f", kb), "K/s"};
        if (kb < 1024) return new String[]{String.format(Locale.US, "%.0f", kb), "K/s"};
        double mb = kb / 1024.0;
        if (mb < 100) return new String[]{String.format(Locale.US, "%.1f", mb), "M/s"};
        return new String[]{String.format(Locale.US, "%.0f", mb), "M/s"};
    }

    private void speedLine(Canvas c, boolean isDown, long bps, float x, float cy) {
        boolean idle = bps < 1024;
        int arrow = idle ? grey() : isDown ? green() : blue();
        int val = idle ? grey() : bps >= (10L << 20) ? teal() : color;
        String[] f = fmtSpeed(bps);
        float e = text(c, isDown ? "↓" : "↑", x, cy, 29, bold, arrow);
        e = text(c, f[0], e + 3, cy, 28, bold, val);
        text(c, f[1], e + 1, cy, 20, semi, grey());
    }

    private void drawActivity(Canvas c) {
        float x = 344;
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(SysViews.faint(color));
        rf.set(328, y(2), 330.5f, y(118));
        c.drawRect(rf, gp);
        float limit = W / 2f - 100;
        speedLine(c, true, down, x, y(CY1));
        speedLine(c, false, up, x, y(CY2));

        // bell + count
        glyph(c, G_BELL, x, y(CY3), 26, color);
        String n = notifAll < 0 ? "?" : String.valueOf(notifAll);
        int ncol = notifAll == 0 ? grey() : color;
        float e = text(c, n, x + 32, y(CY3), 29, bold, ncol);
        if (notifSilent > 0) text(c, "(" + notifSilent + ")", e + 6, y(CY3), 22, semi, grey());

        // Bluetooth
        if (btOn) {
            glyph(c, G_BT, x, y(CY4), 22, devs.isEmpty() ? grey() : blue());
            float dx = x + 32;
            List<Item> items = new ArrayList<>();
            for (int i = 0; i < devs.size() && i < 3; i++) {
                SysState.Dev d = devs.get(i);
                int kc = d.kind == 'W' ? blue() : d.kind == 'H' ? purple() : d.kind == 'P' ? green() : color;
                Item it = new Item(10 - i * 3, 27).t(String.valueOf(d.kind), 27, bold, kc).sp(7);
                if (d.battery >= 0) it.t(d.battery + "%", 27, bold, SysViews.levelColor(d.battery, dk));
                else it.t("--", 27, bold, grey());
                items.add(it);
            }
            if (devs.size() > 3) items.add(new Item(1, 22).t("+" + (devs.size() - 3), 22, semi, grey()));
            drawLine(c, items, dx, y(CY4), limit, 14);
        }
    }

    // ---- SIM blocks, weather, tails

    private void drawSims(Canvas c) {
        float x0 = W / 2f + 98;
        float colW = 240;
        float rightEdge = W - 18;
        float wxMaxX = rightEdge;
        for (int i = 0; i < sims.size() && i < 2; i++) drawSim(c, sims.get(i), x0 + i * colW);

        // weather: line 3 (icon, temp, feels, high/low, rain) and line 4 (humidity, wind, AQI, UV)
        float end3 = x0, end4 = x0;
        if (wxTemp != null) {
            if (wxIcon != null) {
                try {
                    wxIcon.setBounds(Math.round(x0), Math.round(y(CY3) - 17), Math.round(x0 + 34), Math.round(y(CY3) + 17));
                    if (wxTint) wxIcon.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                    else wxIcon.clearColorFilter();
                    wxIcon.draw(c);
                } catch (Throwable ignored) { }
            }
            List<Item> l3 = new ArrayList<>();
            float tempNum = Float.NaN;
            try {
                tempNum = Float.parseFloat(wxTemp);
            } catch (Throwable ignored) { }
            l3.add(new Item(10, 30).t(wxTemp + "°", 30, bold, color));
            end3 = drawLine(c, l3, x0 + 44, y(CY3), wxMaxX, 16);

            end4 = x0;
        }

        // tails: whatever is on, right-aligned on lines 3 and 4, only if there is room
        List<Item> t3 = new ArrayList<>();
        if (alarmAt > 0) {
            String f = alarmAt - System.currentTimeMillis() < 20 * 3600_000L ? "HH:mm" : "EEE HH:mm";
            String lbl = new SimpleDateFormat(f, Locale.US).format(new Date(alarmAt));
            t3.add(new Item(5, 24).g(G_ALARM, 24, color).sp(5).t(lbl, 24, semi, color));
        }
        if (ringer != 0) {
            int g = ringer == 1 ? G_VIB : ringer == 2 ? G_SIL : G_DND;
            t3.add(new Item(7, 24).g(g, 26, ringer == 1 ? orange() : ringer == 2 ? red() : purple()));
        }
        drawTail(c, t3, rightEdge, y(CY3), end3 + 18, 14);

        List<Item> t4 = new ArrayList<>();
        for (int i = 0; i < tray.size() && i < 4; i++) {
            final Bitmap b = tray.get(i);
            float ih = 24, iw = b.getHeight() == 0 ? ih : ih * b.getWidth() / b.getHeight();
            t4.add(new Item(2 + i, 20).g(1000 + i, iw, grey()));
        }
        if (wifiOn) {
            int lc = wifiLevel >= 3 ? green() : wifiLevel == 2 ? yellow() : wifiLevel == 1 ? orange() : red();
            String band = SysState.band(wifiFreq).replace(" GHz", "G");
            Item it = new Item(9, 22).g(G_WIFI, 28, lc).sp(5).t(band, 21, semi, grey()).sp(6);
            it.t(String.valueOf(wifiRssi), 23, bold, lc);
            t4.add(it);
        }
        drawTailWithBitmaps(c, t4, rightEdge, y(CY4), end4 + 18, 12);
    }

    /** Like drawTail, but glyph ids 1000+ are tray bitmaps. */
    private void drawTailWithBitmaps(Canvas c, List<Item> items, float rightX, float cy, float minX, float gap) {
        List<Item> use = new ArrayList<>(items);
        while (!use.isEmpty()) {
            float total = gap * (use.size() - 1);
            for (Item it : use) total += it.w();
            if (rightX - total >= minX) break;
            Item low = use.get(0);
            for (Item it : use) if (it.prio < low.prio) low = it;
            use.remove(low);
        }
        float total = gap * Math.max(0, use.size() - 1);
        for (Item it : use) total += it.w();
        float x = rightX - total;
        for (int i = 0; i < use.size(); i++) {
            Item it = use.get(i);
            Part p = it.parts.get(0);
            if (p.glyph >= 1000) {
                int bi = p.glyph - 1000;
                if (bi < tray.size()) {
                    Bitmap b = tray.get(bi);
                    ip.setColorFilter(new PorterDuffColorFilter(grey(), PorterDuff.Mode.SRC_IN));
                    rf.set(x, cy - 12, x + p.w, cy + 12);
                    c.drawBitmap(b, null, rf, ip);
                }
                x += p.w;
            } else {
                x = drawItem(c, it, x, cy);
            }
            if (i < use.size() - 1) x += gap;
        }
    }

    private void drawSim(Canvas c, SimInfo si, float x) {
        float k = si.data ? 1f : 0.55f;
        if (si.data) {
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(fade(color, 0.16f));
            rf.set(x - 12, y(2), x + 228, y(64));
            c.drawRoundRect(rf, 14, 14, gp);
        }
        float cy1 = y(CY1), cy2 = y(CY2);
        // line 1: network, signal (dBm), number of cells heard
        String rat = si.inService && si.rat != null && !si.rat.isEmpty() ? si.rat : "\u2014";
        String dbm = si.inService && si.dbm != Bands.NO_DBM ? String.valueOf(si.dbm) : null;
        String cells = si.cells > 0 ? String.valueOf(si.cells) : null;
        float total = tw(rat, 36, bold) + (si.eco ? 8 + tw("E", 26, bold) : 0)
                + (dbm != null ? 10 + tw(dbm, 28, bold) : 0)
                + (cells != null ? 12 + tw(cells, 26, bold) : 0);
        float f = total > 224 ? 224 / total : 1f;
        float e = text(c, rat, x, cy1, 36 * f, bold, fade(color, k));
        if (si.eco) e = text(c, "E", e + 8 * f, cy1, 26 * f, bold, fade(green(), k));
        if (dbm != null) e = text(c, dbm, e + 10 * f, cy1, 28 * f, bold, fade(dbmColor(si.dbm), k));
        if (cells != null) {
            text(c, cells, e + 12 * f, cy1, 26 * f, bold, fade(color, k));
        }

        // line 2: small boxed Vo badge (VoNR / VoLTE / VoWiFi), band + distance, live arrows on the data SIM
        float bx0 = x;
        if (si.voice != null) {
            String vo = "Vo" + si.voice;
            float vw = tw(vo, 16, bold) + 10;
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(2f);
            gp.setColor(fade(green(), k));
            rf.set(x + 1, cy2 - 11, x + 1 + vw, cy2 + 11);
            c.drawRoundRect(rf, 5, 5, gp);
            text(c, vo, x + 6, cy2, 16, bold, fade(green(), k));
            bx0 = x + vw + 8;
        }
        String band = si.band != null ? si.band : "?";
        float avail = 226 - (bx0 - x) - (si.data ? 54 : 0);
        String full = si.dist != null ? band + " · " + si.dist : band;
        String shown = tw(full, 22, semi) <= avail ? full : band;
        float fs = 22;
        float sw = tw(shown, fs, semi);
        if (sw > avail) fs = 22 * avail / sw;
        float ex = text(c, shown, bx0, cy2, fs, semi, fade(blue(), k));
        if (si.data) {
            float ax = ex + 10;
            ax = text(c, "↓", ax, cy2, 24, bold, dataIn ? green() : color);
            text(c, "↑", ax - 2, cy2, 24, bold, dataOut ? blue() : color);
        }
    }

    // ---- battery

    // ------------------------------------------------------------------ glyphs

    /** Small symbols, drawn around cy, starting at x, w wide. */
    private void glyph(Canvas c, int id, float x, float cy, float w, int col) {
        float cx = x + w / 2f;
        switch (id) {
            case G_BELL: {
                float h = w * 0.92f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float bw = h * 0.78f;
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.66f, cy + h * 0.2f, cx + bw * 0.66f, cy + h * 0.34f, gp);
                c.drawCircle(cx, cy + h * 0.44f, h * 0.1f, gp);
                break;
            }
            case G_BT: {
                float h = 30;
                stroke(3f, col);
                float x0 = x + 2, x1 = x + w - 2, mx = (x0 + x1) / 2f;
                path.reset();
                path.moveTo(x0, cy - h * 0.22f);
                path.lineTo(x1, cy + h * 0.2f);
                path.lineTo(mx, cy + h * 0.45f);
                path.lineTo(mx, cy - h * 0.45f);
                path.lineTo(x1, cy - h * 0.2f);
                path.lineTo(x0, cy + h * 0.22f);
                c.drawPath(path, gp);
                break;
            }
            case G_WAVE: {
                stroke(2.6f, col);
                float hw = w * 0.42f;
                for (int k = 0; k < 2; k++) {
                    float yy = cy - 4 + k * 9;
                    path.reset();
                    path.moveTo(cx - hw, yy);
                    path.cubicTo(cx - hw / 2, yy - 6, cx - hw / 2, yy + 6, cx, yy);
                    path.cubicTo(cx + hw / 2, yy - 6, cx + hw / 2, yy + 6, cx + hw, yy);
                    c.drawPath(path, gp);
                }
                gp.setStyle(Paint.Style.FILL);
                break;
            }
            case G_DROP: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f;
                c.drawCircle(cx, cy + 4, r, gp);
                path.reset();
                path.moveTo(cx, cy - 13);
                path.lineTo(cx - r * 0.95f, cy + 1);
                path.lineTo(cx + r * 0.95f, cy + 1);
                path.close();
                c.drawPath(path, gp);
                break;
            }
            case G_UMB: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(x + 1, cy - 14, x + w - 1, cy + 10);
                c.drawArc(rf, 180, 180, true, gp);
                stroke(3f, col);
                c.drawLine(cx, cy - 2, cx, cy + 12, gp);
                break;
            }
            case G_WIFI: {
                float bx = cx, by = cy + 10;
                stroke(3.2f, col);
                for (int i = 1; i <= 3; i++) {
                    float r = 6.5f * i;
                    rf.set(bx - r, by - r, bx + r, by + r);
                    c.drawArc(rf, 225, 90, false, gp);
                }
                gp.setStyle(Paint.Style.FILL);
                c.drawCircle(bx, by - 0.5f, 2.4f, gp);
                break;
            }
            case G_ALARM: {
                float h = w * 0.8f;
                stroke(2.6f, col);
                c.drawCircle(cx, cy + 2, h * 0.38f, gp);
                c.drawLine(cx, cy + 2, cx, cy - h * 0.18f, gp);
                c.drawLine(cx, cy + 2, cx + h * 0.16f, cy + h * 0.1f, gp);
                c.drawLine(cx - h * 0.44f, cy - h * 0.28f, cx - h * 0.26f, cy - h * 0.46f, gp);
                c.drawLine(cx + h * 0.44f, cy - h * 0.28f, cx + h * 0.26f, cy - h * 0.46f, gp);
                break;
            }
            case G_VIB: {
                float h = w * 0.9f;
                stroke(2.6f, col);
                rf.set(cx - h * 0.2f, cy - h * 0.48f, cx + h * 0.2f, cy + h * 0.48f);
                c.drawRoundRect(rf, h * 0.08f, h * 0.08f, gp);
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    c.drawLine(cx + sgn * h * 0.34f, cy - h * 0.22f, cx + sgn * h * 0.34f, cy + h * 0.22f, gp);
                    c.drawLine(cx + sgn * h * 0.5f, cy - h * 0.12f, cx + sgn * h * 0.5f, cy + h * 0.12f, gp);
                }
                break;
            }
            case G_SIL: {
                float h = w * 0.9f, bw = h * 0.7f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                rf.set(cx - bw / 2, cy - h * 0.5f, cx + bw / 2, cy + h * 0.3f);
                c.drawArc(rf, 180, 180, true, gp);
                c.drawRect(cx - bw / 2, cy - h * 0.1f, cx + bw / 2, cy + h * 0.28f, gp);
                c.drawRect(cx - bw * 0.62f, cy + h * 0.22f, cx + bw * 0.62f, cy + h * 0.34f, gp);
                stroke(3f, col);
                c.drawLine(cx - h * 0.5f, cy - h * 0.5f, cx + h * 0.5f, cy + h * 0.5f, gp);
                break;
            }
            case G_DND: {
                float h = w * 0.9f;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                c.drawCircle(cx, cy, h * 0.46f, gp);
                gp.setColor(dk ? 0xFF1C1C1E : 0xFFFFFFFF);
                rf.set(cx - h * 0.26f, cy - h * 0.07f, cx + h * 0.26f, cy + h * 0.07f);
                c.drawRoundRect(rf, h * 0.05f, h * 0.05f, gp);
                break;
            }
            case G_SUN: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.34f, sx = x + w / 2f + 1;
                c.drawCircle(sx, cy, r, gp);
                for (int a = 0; a < 360; a += 45) {
                    double ra = Math.toRadians(a);
                    c.drawCircle((float) (sx + w * 0.62 * Math.cos(ra)), (float) (cy + w * 0.62 * Math.sin(ra)), 1.7f, gp);
                }
                break;
            }
            case G_HEAD: {
                stroke(3f, col);
                float r = w * 0.42f;
                rf.set(cx - r, cy - r, cx + r, cy + r);
                c.drawArc(rf, 180, 180, false, gp);
                gp.setStyle(Paint.Style.FILL);
                rf.set(cx - r - 2, cy - 1, cx - r + 6, cy + r * 0.85f);
                c.drawRoundRect(rf, 3, 3, gp);
                rf.set(cx + r - 6, cy - 1, cx + r + 2, cy + r * 0.85f);
                c.drawRoundRect(rf, 3, 3, gp);
                break;
            }
            case G_BOLT: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float hh = w * 1.15f;
                path.reset();
                path.moveTo(x + w * 0.62f, cy - hh / 2);
                path.lineTo(x + w * 0.08f, cy + hh * 0.08f);
                path.lineTo(x + w * 0.46f, cy + hh * 0.08f);
                path.lineTo(x + w * 0.34f, cy + hh / 2);
                path.lineTo(x + w * 0.94f, cy - hh * 0.12f);
                path.lineTo(x + w * 0.54f, cy - hh * 0.12f);
                path.close();
                c.drawPath(path, gp);
                break;
            }
            case G_EYE: {
                // eye: almond outline + pupil
                stroke(2.2f, col);
                float hw = w * 0.48f, hh = w * 0.30f;
                path.reset();
                path.moveTo(cx - hw, cy);
                path.quadTo(cx, cy - hh * 1.9f, cx + hw, cy);
                path.quadTo(cx, cy + hh * 1.9f, cx - hw, cy);
                c.drawPath(path, gp);
                gp.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, w * 0.16f, gp);
                break;
            }
            case G_CLOUD: {
                // cloud: three puffs on a flat base
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.2f, base = cy + w * 0.22f;
                c.drawCircle(cx - w * 0.22f, base - r, r, gp);
                c.drawCircle(cx + w * 0.02f, base - r * 1.55f, r * 1.3f, gp);
                c.drawCircle(cx + w * 0.26f, base - r * 0.9f, r * 0.9f, gp);
                rf.set(cx - w * 0.42f, base - r, cx + w * 0.44f, base);
                c.drawRoundRect(rf, r, r, gp);
                break;
            }
            case G_SUNSET: {
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(col);
                float r = w * 0.32f, sy = cy + 4;
                rf.set(cx - r, sy - r, cx + r, sy + r);
                c.drawArc(rf, 180, 180, true, gp);
                for (int a = 180; a <= 360; a += 45) {
                    double ra = Math.toRadians(a);
                    c.drawCircle((float) (cx + w * 0.55 * Math.cos(ra)), (float) (sy + w * 0.55 * Math.sin(ra)), 1.7f, gp);
                }
                c.drawRect(cx - w * 0.55f, sy + 1, cx + w * 0.55f, sy + 3.5f, gp);
                break;
            }
            default:
                break;
        }
    }

    private void stroke(float width, int col) {
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(width);
        gp.setStrokeCap(Paint.Cap.ROUND);
        gp.setStrokeJoin(Paint.Join.ROUND);
        gp.setColor(col);
    }

    // ================================================================== pro layout (4 rows, 1280 x 206)
    //
    //  strip : ISS / satellite · solar time + sun phase · moon phase name
    //  left  : clock / zone | C / B temperature | amps / watts | GPU ...... ↓↑ speed by the camera   (row 1)
    //          sunrise-sunset · alarm · notifications | system-icon slot          (row 2)
    //          GPS satellites                                                     (row 3)
    //  centre: battery-health ring around the camera, "93% · 402" under it
    //  right : one column per SIM (network, operator, bars, ↓↑, Vo / dBm, SNR / band, distance, cells),
    //          battery; weather on rows 3 and 4 (temperature, feels, rain, UV, AQI / high-low, humidity, wind)

    boolean pro;
    int soh = -1, cycles = -1, cpuLoad = -1, sats = -1, ping = -1, deep = -1;
    float wxPres = Float.NaN, wxPresTrend = Float.NaN;
    String wake = "";
    boolean vpn;
    private long flagsAt = 0;
    private int sysFlags = 0;   // 1 airplane, 2 battery saver, 4 NFC, 8 hotspot
    /** Camera hole centre and radius in this view's pixels (NaN = unknown). */
    float camX = Float.NaN, camY = Float.NaN, camR = Float.NaN;

    private static final float PRO_H = 206f;
    private static final float P_CLK = 56, P1A = 41, P1B = 77, P2 = 106, P3 = 158, P4 = 188;
    /** CPU / BAT temperatures: one line straight under the other, no gap. */
    private static final float T1A = 45, T1B = 73;
    private static final int G_HEAD = 11, G_BOLT = 12, G_SUNSET = 13, G_EYE = 14, G_CLOUD = 15, G_WAVE = 16;

    private void drawPro(Canvas c, int w, int h) {
        s = Math.min(w / DESIGN_W, h / PRO_H);
        W = w / s;
        vs = 1f;
        oy = Math.max(0f, (h / s - PRO_H) / 2f);
        c.save();
        try {
            c.scale(s, s);
            float cx = Float.isNaN(camX) ? W / 2f : camX / s;
            float cr = Float.isNaN(camR) ? 24f : Math.max(14f, Math.min(34f, camR / s));
            float ry = Float.isNaN(camY) ? oy + 50f : camY / s;
            float hw = Math.max(cr + 10f, tw(healthText(), 23, bold) / 2f + 6f);
            float leftEnd = cx - hw - 12f, rightStart = cx + hw + 12f, rightEnd = W - 8f;
            // battery health · cycles · altitude sits right against the SIM boxes instead of centred under the camera:
            // the rows on the left may then run up to it
            healthX = Float.NaN;
            float sl = predictSimLeft(cx + cr + 22f, rightEnd);
            if (!Float.isNaN(sl)) {
                float hwid = tw(healthText(), 23, bold);
                healthX = sl - 6f - hwid;
                rightStart = cx + cr + 22f;
                leftEnd = Math.min(cx - cr - 14f, healthX - 14f);
            }
            l4End = 0;
            w4Start = rightEnd;
            camRight = cx + cr;
            // battery health · cycles · altitude now sits on row 2, ending under the camera's right edge (after the
            // speed meter); the system-icon frame stops before it and rows 3-4 may run on to the SIM boxes
            hP2W = tw(healthText(), HP2_SIZE, bold);
            hP2X = (!Float.isNaN(sl) ? sl - 8f : camRight) - hP2W;   // row 3, hugging the SIM boxes
            wxEnd = !Float.isNaN(sl) ? sl - 14f : leftEnd;
            // row 1 may run up to the camera hole itself; the lower rows keep clear of the wider health text
            try { proLeft(c, leftEnd, Math.max(leftEnd, cx - cr - 14f)); } catch (Throwable ignored) { }
            try { proRight(c, rightStart, rightEnd); } catch (Throwable ignored) { }
            try { proCam(c, cx, ry, cr); } catch (Throwable ignored) { }
            try { proSky(c, cx); } catch (Throwable t) { skyDbg = "moon/quake line failed: " + t; }
            try { proTail4(c); } catch (Throwable ignored) { }
        } finally {
            c.restore();
        }
    }

    /** Text whose baseline matches text of size ref centred on cy (for small units beside big numbers). */
    private float textB(Canvas c, String str, float x, float cy, float ref, float size, Typeface tf, int col) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setColor(col);
        c.drawText(str, x, cy + ref * 0.36f, tp);
        return x + tp.measureText(str);
    }

    /**
     * Leftmost x (design units) where text whose top is at topU (design units) is not cut by the
     * screen's rounded top-left corner. 0 when the corner is unknown or the line is below it.
     */
    private float cornerX(float topU) {
        try {
            android.view.WindowInsets wi = getRootWindowInsets();
            if (wi == null || android.os.Build.VERSION.SDK_INT < 31) return 0;
            android.view.RoundedCorner rc = wi.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT);
            if (rc == null || rc.getRadius() <= 0) return 0;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float r = rc.getRadius();
            float ccx = rc.getCenter().x - loc[0], ccy = rc.getCenter().y - loc[1];
            float top = topU * s;
            if (top >= ccy) return 0;
            float dy = ccy - top;
            float x = ccx - (float) Math.sqrt(Math.max(0, r * r - dy * dy));
            return Math.max(0, x / s);
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Rightmost x (design units) clear of the screen's rounded top-right corner for text whose top is at topU. */
    private float cornerRightX(float topU) {
        try {
            android.view.WindowInsets wi = getRootWindowInsets();
            if (wi == null || android.os.Build.VERSION.SDK_INT < 31) return W;
            android.view.RoundedCorner rc = wi.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_RIGHT);
            if (rc == null || rc.getRadius() <= 0) return W;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float r = rc.getRadius();
            float ccx = rc.getCenter().x - loc[0], ccy = rc.getCenter().y - loc[1];
            float top = topU * s;
            if (top >= ccy) return W;
            float dy = ccy - top;
            return (ccx + (float) Math.sqrt(Math.max(0, r * r - dy * dy))) / s;
        } catch (Throwable t) {
            return W;
        }
    }

    private long zoneAt = 0;
    private String zoneTxt = "";

    /** "IST" for the phone's time zone, no GMT offset; "" when the zone has no short name. Checked once a minute. */
    private String zone(long now) {
        if (true) return "";   // time-zone label removed on request
        if (now - zoneAt < 60_000) return zoneTxt;
        zoneAt = now;
        try {
            java.util.TimeZone tz = java.util.TimeZone.getDefault();
            boolean dst = tz.inDaylightTime(new Date(now));
            String name = tz.getDisplayName(dst, java.util.TimeZone.SHORT, Locale.ENGLISH);
            if ("Asia/Kolkata".equals(tz.getID()) || "Asia/Calcutta".equals(tz.getID())) name = "IST";
            zoneTxt = name == null || name.startsWith("GMT") || name.startsWith("UTC") ? "" : name;
        } catch (Throwable t) {
            zoneTxt = "";
        }
        return zoneTxt;
    }

    private long moonEvAt = 0;
    private long[] moonEv;

    /** Next moonrise / moonset {time, 1 rise}; recomputed every 5 min or right after it happens. */
    private long[] moonEvent(long now) {
        if (moonEv != null && now - moonEvAt < 300_000 && moonEv[0] > now) return moonEv;
        if (moonEv == null && now - moonEvAt < 60_000 && moonEvAt != 0) return null;
        moonEvAt = now;
        try {
            moonEv = Astro.nextMoonEvent(now, fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
        } catch (Throwable t) {
            moonEv = null;
        }
        return moonEv;
    }

    private static String minus(String v) {
        return v.replace('-', '−');
    }

    // ---- left half

    private void proLeft(Canvas c, float L1, float top1) {
        long now = System.currentTimeMillis();
        if (now - h24CheckedAt > 30_000) {
            h24CheckedAt = now;
            try {
                h24 = true;   // always 24-hour
            } catch (Throwable ignored) { }
        }
        Date d = new Date(now);
        float cx0 = Math.max(20, cornerX(y(P1A) - 15) + 4);
        float e = text(c, (h24 ? t24 : t12).format(d), cx0, y(P1A), 38, bold, color);
        if (!h24) e = textB(c, ampm.format(d).toLowerCase(Locale.getDefault()), e + 3, y(P1A), 38, 17, semi, grey());
        final float clkEnd = e;
        // time zone name only (no GMT offset); nothing when the zone has no name
        String z = zone(now);
        float zx0 = Math.max(20, cornerX(y(P1B) - 9) + 4);
        float ze = zx0;
        if (!z.isEmpty()) ze = textB(c, z, zx0, y(P1B), 22, 22, bold, color) + 10;
        // next moonrise / moonset beside the zone: small moon, arrow, time
        long[] mev = moonEvent(now);
        if (mev != null) {
            String mt = new SimpleDateFormat("HH:mm", Locale.US).format(new Date(mev[0]));
            boolean rise = mev[1] == 1;
            moon(c, ze + 8, y(P1B), 8, moonPhase());
            float me = textB(c, rise ? "↑" : "↓", ze + 18, y(P1B), 22, 19, bold, rise ? teal() : grey());
            ze = textB(c, mt, me + 1, y(P1B), 22, 21, bold, rise ? color : grey());
        }
        // next sunrise / sunset right after the moon time: sun glyph and clock time
        String[] sun = nextSun(now);
        if (sun != null) {
            boolean sr = "r".equals(sun[1]);
            int sc = sr ? yellow() : orange();
            Item si = new Item(8, 22).g(sr ? G_SUN : G_SUNSET, 21, sc).sp(4).t(sun[0], 22, bold, sc);
            ze = drawItem(c, si, ze + 10, y(P1B));
        }
        e = Math.max(e, ze);
        // weekday ("Mon") in small grey right after the clock, on the clock's baseline
        String wd = new SimpleDateFormat("EEE", Locale.getDefault()).format(d);
        e = Math.max(e, textB(c, wd, clkEnd + 6, y(P1A), 38, 19, semi, grey()));

        // network speed goes right after the last column (drawn at the end); it must stay clear of the camera
        float speedW = tw("↓", 30, bold) + 3 + tw("999", 30, bold) + 2 + tw("K/s", 20, semi);
        float lim = top1 - speedW - 6;

        // C / B temperatures right after the clock, then amps / watts, then the GPU temperature
        float tx = e + 8;
        // while the heat throttle is capping the CPU / GPU the labels turn red and get a down arrow
        boolean thr = HeatWarn.throttled;
        String cLab = thr ? "C\u2193" : "C", bLab = thr ? "B\u2193" : "B";
        int labCol = thr ? (dk ? 0xFFFF5440 : SysViews.red(false)) : grey();
        float lw = Math.max(tw(cLab, 20, semi), tw(bLab, 20, semi)) + 4;
        float colW = lw + tw("99°", 30, bold);
        if (tx + colW <= lim && (!Float.isNaN(cpu) || !Float.isNaN(bat))) {
            if (!Float.isNaN(cpu)) {
                textB(c, cLab, tx, y(T1A), 30, 20, semi, labCol);
                textB(c, Math.round(cpu) + "°", tx + lw, y(T1A), 30, 30, bold, heat(cpu, 45, 55, 65));
            }
            if (!Float.isNaN(bat)) {
                textB(c, bLab, tx, y(T1B), 30, 20, semi, labCol);
                textB(c, Math.round(bat) + "°", tx + lw, y(T1B), 30, 30, bold, heat(bat, 38, 42, 45));
            }
            tx += colW + 10;
        }
        if (!Float.isNaN(amps) && !Float.isNaN(watts)) {
            String sg = amps > 0 ? "+" : "−";
            float aw = Math.abs(watts);
            String av = sg + String.format(Locale.US, "%.2f", Math.abs(amps));
            String wv = sg + String.format(Locale.US, aw < 10 ? "%.1f" : "%.0f", aw);
            float bolt = charging ? 25 : 0;
            // fixed width from the widest likely values, so the columns after it don't come and go
            float pw = bolt + Math.max(tw("−9.99", 30, bold) + tw("A", 20, semi), tw("−99.9", 30, bold) + tw("W", 20, semi)) + 2;
            if (tx + pw <= lim) {
                if (charging) glyph(c, G_BOLT, tx, y(T1A), 20, powerColor);
                float ae = textB(c, av, tx + bolt, y(T1A), 30, 30, bold, powerColor);
                textB(c, "A", ae + 1, y(T1A), 30, 20, semi, grey());
                float we = textB(c, wv, tx + bolt, y(T1B), 30, 30, bold, powerColor);
                textB(c, "W", we + 1, y(T1B), 30, 20, semi, grey());
                tx += pw + 10;
            }
        }
        // one column: GPU temperature on top, CPU usage under it
        if (!Float.isNaN(gpu) || cpuLoad >= 0) {
            float gl = Math.max(tw("G", 20, semi), tw("C", 20, semi)) + 4;
            // width of the numbers actually shown, so the speed sits right against them
            float vw = Math.max(Float.isNaN(gpu) ? 0 : tw(Math.round(gpu) + "°", 30, bold),
                    cpuLoad >= 0 ? tw(cpuLoad + "%", 27, bold) : 0);
            // shrink (down to 70 %) rather than vanish when the row is a little short
            float need = gl + vw, f = Math.min(1f, (lim - tx) / need);
            if (f >= 0.7f) {
                c.save();
                c.scale(f, f, tx, (y(T1A) + y(T1B)) / 2f);
                try {
                    if (!Float.isNaN(gpu)) {
                        textB(c, "G", tx, y(T1A), 30, 20, semi, grey());
                        textB(c, Math.round(gpu) + "°", tx + gl, y(T1A), 30, 30, bold, heat(gpu, 45, 55, 65));
                    }
                    if (cpuLoad >= 0) {
                        int cc = cpuLoad < 50 ? green() : cpuLoad < 80 ? yellow() : red();
                        textB(c, "C", tx, y(T1B), 30, 20, semi, grey());
                        textB(c, cpuLoad + "%", tx + gl, y(T1B), 30, 27, bold, cc);
                    }
                } finally {
                    c.restore();
                }
                tx += need * f + 4;
            }
        }
        // speed almost touching the GPU / CPU column
        float sx = Math.min(tx, top1 - speedW);
        proSpeed(c, true, down, sx, y(P1A));
        proSpeed(c, false, up, sx, y(P1B));
        // uptime in the gap right of the speeds, before the camera; only at full size
        try {
            long up = android.os.SystemClock.elapsedRealtime() / 60_000L;
            String uv = up < 60 ? up + "m" : up < 1440 ? (up / 60) + "h" + (up % 60 < 10 ? "0" : "") + (up % 60)
                    : (up / 1440) + "d" + ((up % 1440) / 60) + "h";
            float ux = sx + speedW + 10;
            if (ux + Math.max(tw(uv, 26, bold), tw("up", 20, semi)) <= top1) {
                textB(c, "up", ux, y(T1A), 30, 20, semi, grey());
                textB(c, uv, ux, y(T1B), 30, 26, bold, color);
            }
        } catch (Throwable ignored) { }

        // row 2: alarm, notifications, then the system icons in a frame
        List<Item> r2 = new ArrayList<>();
        if (alarmAt > 0) {
            String f = alarmAt - now < 20 * 3600_000L ? "HH:mm" : "EEE HH:mm";
            String lbl = new SimpleDateFormat(f, Locale.US).format(new Date(alarmAt));
            r2.add(new Item(6, 27).g(G_ALARM, 26, color).sp(6).t(lbl, 27, semi, color));
        }
        String n = notifAll < 0 ? "?" : String.valueOf(notifAll);
        int ncol = notifAll == 0 ? grey() : orange();
        Item ni = new Item(9, 27).g(G_BELL, 24, ncol).sp(6).t(n, 27, bold, ncol);
        if (notifSilent > 0) ni.sp(5).t("(" + notifSilent + ")", 20, semi, grey());
        r2.add(ni);
        float r2End = L1;
        float e2 = drawLine(c, r2, 22, y(P2), r2End - 120, 18);
        proSlot(c, e2 + 16, r2End, y(P2));

        // row 3: GPS pin + satellite count, only while an app is actually using GPS
        float e3 = 0;
        if (sats > 0) {
            int gc = sats >= 8 ? green() : yellow();
            pin(c, 22, y(P3), gc);
            e3 = textB(c, String.valueOf(sats), 22 + 22, y(P3), 27, 27, bold, gc);
        }

        // rows 3 and 4: the weather, moved here from under the SIMs (they now show their towers' areas)
        l4End = 22;
        try { proWeatherLeft(c, e3 > 0 ? e3 + 22 : 22, 22, Math.max(L1, wxEnd), 1e9f); } catch (Throwable ignored) { }
    }

    /** Map-pin outline with a dot: round head, pointed tip, 18 wide x 24 tall, centred on cy. */
    private void pin(Canvas c, float x, float cy, int col) {
        float r = 7.5f, hx = x + 9, hy = cy - 4;
        android.graphics.Path p = new android.graphics.Path();
        rf.set(hx - r, hy - r, hx + r, hy + r);
        p.arcTo(rf, 140, 260, true);                       // head, open at the bottom
        p.lineTo(hx, cy + 12);                             // down to the tip
        p.close();
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(2.4f);
        gp.setStrokeJoin(Paint.Join.ROUND);
        gp.setColor(col);
        c.drawPath(p, gp);
        gp.setStyle(Paint.Style.FILL);
        c.drawCircle(hx, hy, 2.8f, gp);
    }

    private void proSpeed(Canvas c, boolean isDown, long bps, float x, float cy) {
        boolean idle = bps < 1024;
        int arrow = idle ? grey() : isDown ? green() : blue();
        int val = idle ? grey() : bps >= (10L << 20) ? teal() : color;
        String[] f = fmtSpeed(bps);
        float e = textB(c, isDown ? "↓" : "↑", x, cy, 30, 30, bold, arrow);
        e = textB(c, f[0], e + 3, cy, 30, 30, bold, val);
        textB(c, f[1], e + 2, cy, 30, 20, semi, grey());
    }

    /** {"06:30", "r"} for the next sunrise, {"18:09", "s"} for the next sunset. */
    private String[] nextSun(long now) {
        try {
            double[] sun = SunTimes.today(latLon[0], latLon[1]);
            if (Double.isNaN(sun[0]) || Double.isNaN(sun[1])) return null;
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(now);
            double m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
            if (m >= sun[0] && m < sun[1]) return new String[]{SunTimes.hhmm(sun[1]), "s"};
            return new String[]{SunTimes.hhmm(sun[0]), "r"};
        } catch (Throwable t) {
            return null;
        }
    }

    /** Framed slot for the system icons: Wi-Fi, Bluetooth, ringer / DND, VPN, then the stock tray icons. */
    private void proSlot(Canvas c, float x0, float x1, float cy) {
        if (x1 - x0 < 44) return;
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(2f);
        gp.setColor(fade(color, 0.32f));
        rf.set(x0, cy - 19, x1, cy + 19);
        c.drawRoundRect(rf, 11, 11, gp);
        float x = x0 + 10, lim = x1 - 10;
        int hidden = 0;
        if (wifiOn) {
            int lc = wifiLevel >= 3 ? green() : wifiLevel == 2 ? yellow() : wifiLevel == 1 ? orange() : red();
            float need = 28 + (wifiRssi != 0 ? 4 + tw(String.valueOf(wifiRssi), 20, bold) : 0);
            if (x + need <= lim) {
                glyph(c, G_WIFI, x, cy - 2, 28, lc);
                x += 30;
                if (wifiRssi != 0) x = textB(c, minus(String.valueOf(wifiRssi)), x, cy, 22, 20, bold, lc) + 8;
            } else hidden++;
        }
        if (btOn) {
            int bl = devs.isEmpty() ? -1 : devs.get(0).battery;
            String bp = bl >= 0 ? bl + "%" : null;
            float need = 20 + (bp != null ? 4 + 11 + 4 + tw(bp, 18, bold) : 0);
            if (x + need <= lim) {
                glyph(c, G_BT, x, cy, 18, devs.isEmpty() ? grey() : blue());
                x += 22;
                if (bp != null) {
                    int bc = SysViews.levelColor(bl, dk);
                    float bx = x + 2, bt = cy - 10, bb = cy + 10, bw = 9;
                    gp.setStyle(Paint.Style.FILL);
                    gp.setColor(color);
                    rf.set(bx + 2.5f, bt - 2.5f, bx + bw - 2.5f, bt);
                    c.drawRect(rf, gp);                                         // nub
                    gp.setStyle(Paint.Style.STROKE);
                    gp.setStrokeWidth(1.6f);
                    rf.set(bx, bt, bx + bw, bb);
                    c.drawRoundRect(rf, 2, 2, gp);                              // body
                    gp.setStyle(Paint.Style.FILL);
                    gp.setColor(bc);
                    float fh = (bb - bt - 3) * Math.max(0, Math.min(100, bl)) / 100f;
                    rf.set(bx + 1.5f, bb - 1.5f - fh, bx + bw - 1.5f, bb - 1.5f);
                    c.drawRect(rf, gp);                                         // fill
                    x = textB(c, bp, bx + bw + 4, cy, 18, 18, bold, bc) + 8;
                } else x += 4;
            } else hidden++;
        }
        if (ringer != 0) {
            if (x + 24 <= lim) {
                int g = ringer == 1 ? G_VIB : ringer == 2 ? G_SIL : G_DND;
                glyph(c, g, x, cy, 22, ringer == 1 ? orange() : ringer == 2 ? red() : purple());
                x += 30;
            } else hidden++;
        }
        if (vpn) {
            float vw = tw("VPN", 17, bold) + 10;
            if (x + vw <= lim) {
                gp.setStyle(Paint.Style.STROKE);
                gp.setStrokeWidth(2f);
                gp.setColor(green());
                rf.set(x, cy - 11, x + vw, cy + 11);
                c.drawRoundRect(rf, 5, 5, gp);
                textB(c, "VPN", x + 5, cy, 17, 17, bold, green());
                x += vw + 8;
            } else hidden++;
        }
        long nowF = System.currentTimeMillis();
        if (nowF - flagsAt > 4000) {
            flagsAt = nowF;
            int fl = 0;
            try {
                android.content.Context cx = getContext();
                try { if (android.provider.Settings.Global.getInt(cx.getContentResolver(), "airplane_mode_on", 0) == 1) fl |= 1; } catch (Throwable ignored) { }
                try { if (((android.os.PowerManager) cx.getSystemService(android.content.Context.POWER_SERVICE)).isPowerSaveMode()) fl |= 2; } catch (Throwable ignored) { }
                try {
                    android.nfc.NfcAdapter na = android.nfc.NfcAdapter.getDefaultAdapter(cx);
                    if (na != null && na.isEnabled()) fl |= 4;
                } catch (Throwable ignored) { }
                try {
                    android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) cx.getApplicationContext().getSystemService(android.content.Context.WIFI_SERVICE);
                    if (Boolean.TRUE.equals(wm.getClass().getMethod("isWifiApEnabled").invoke(wm))) fl |= 8;
                } catch (Throwable ignored) { }
            } catch (Throwable ignored) { }
            sysFlags = fl;
        }
        String[] chipT = {"✈", "SAVER", "NFC", "HOTSPOT"};
        for (int k = 0; k < 4; k++) {
            if ((sysFlags & (1 << k)) == 0) continue;
            int cc = k == 0 ? red() : k == 1 ? yellow() : k == 2 ? blue() : teal();
            float vw = tw(chipT[k], 17, bold) + 10;
            if (x + vw > lim) { hidden++; continue; }
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(2f);
            gp.setColor(cc);
            rf.set(x, cy - 11, x + vw, cy + 11);
            c.drawRoundRect(rf, 5, 5, gp);
            textB(c, chipT[k], x + 5, cy, 17, 17, bold, cc);
            x += vw + 8;
        }
        for (int i = 0; i < tray.size(); i++) {
            Bitmap b = tray.get(i);
            float ih = 24, iw = b.getHeight() == 0 ? ih : ih * b.getWidth() / b.getHeight();
            if (x + iw > lim) { hidden += tray.size() - i; break; }
            ip.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            rf.set(x, cy - ih / 2, x + iw, cy + ih / 2);
            c.drawBitmap(b, null, rf, ip);
            x += iw + 6;
        }
        if (hidden > 0) {
            String p = "+" + hidden;
            if (x + tw(p, 18, bold) <= x1 - 4) textB(c, p, x, cy, 18, 18, bold, grey());
        }
    }

    // ---- centre: battery health and cycles under the camera (numbers only)

    /** GPS height when there is one, else the ground height at your position from the weather service ("~"). */
    private String altText() {
        if (fix != null && !Double.isNaN(fix[2])) return " · " + Math.round(fix[2]) + "m";
        if (!Float.isNaN(groundElev)) return " · ~" + Math.round(groundElev) + "m";
        return "";
    }

    private String healthText() {
        return (soh > 0 ? soh + "%" : "--") + " · " + (cycles >= 0 ? String.valueOf(cycles) : "--");   // altitude removed
    }

    private void proCam(Canvas c, float cx, float cy, float r) {
        try {
            float room = cy - r - 2;                         // free height above the hole
            if (room >= 9) {
                float size = Math.min(21f, room * 1.2f);
                // real phase and lit fraction for your place and time
                double ph;
                int lit;
                try {
                    Astro.Moon mo = Astro.moon(System.currentTimeMillis(), fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
                    ph = mo.phase;
                    lit = (int) Math.round(mo.illum * 100);
                } catch (Throwable t) {
                    ph = moonPhase();
                    lit = (int) Math.round(50 * (1 - Math.cos(2 * Math.PI * ph)));
                }
                String nm = phaseName(lit, ph < 0.5);
                // phase name on one line, same size as the solar time / day-time name beside it
                float half = tw(nm, size, semi) / 2f;
                float top = Math.max(size * 0.38f + 1, room / 2f + 1);
                // best: the phase name in the thin band above the SIM boxes, which frees the whole strip up to
                // the SIM boxes for the solar time and the ISS line; otherwise slide it right up to the SIM boxes
                float nameX = cx - half;
                boolean upTop = false, solUp = false;
                if (!Float.isNaN(simLeft)) {
                    float bandH = y(P1A) - 24 - 1;                // above the SIM frame's top edge
                    // whole letters inside the band: cap height ~0.72 x size, descenders ~0.2 x size
                    // a bit smaller than the band, anchored to the SIM boxes' top line so tall letters can't reach the edge
                    float bs = Math.min(size, bandH * 1.15f);
                    float bx = simLeft + 6, bw = tw(nm, bs, semi);
                    float by = bandH / 2f + 0.5f;
                    float bEnd = cornerRightX(by - bs * 0.4f) - 6;
                    String[] solB = solarNow();
                    float sw = solB == null ? 0 : tw(solB[0], bs, bold) + 8 + tw(solB[1], bs, semi);
                    // long phase names ("Nautical twilight"): shorten the word first, then the text a little,
                    // so the solar time stays up beside the moon phase instead of dropping to the centre
                    // auto-fit: full words a little smaller first; only if that isn't enough, short words
                    if (solB != null && bx + sw + 16 + bw > bEnd) {
                        String[][] tries = {
                                {solB[1], nm},
                                {solB[1].replace("Astronomical twilight", "Astro twilight").replace("Nautical twilight", "Nautical tw.")
                                        .replace("Civil twilight", "Civil tw."), nm},
                                {solB[1].replace("Astronomical twilight", "Astro twilight").replace("Nautical twilight", "Nautical tw.")
                                        .replace("Civil twilight", "Civil tw."), nm.replace("Waning ", "Wan. ").replace("Waxing ", "Wax. ")}};
                        float floor = Math.max(11f, bs * 0.85f);
                        for (int ti = 0; ti < tries.length; ti++) {
                            float min = ti == tries.length - 1 ? 11f : floor;
                            float bs2 = bs;
                            float sw2 = tw(solB[0], bs2, bold) + 8 + tw(tries[ti][0], bs2, semi), bw2 = tw(tries[ti][1], bs2, semi);
                            while (bs2 > min && bx + sw2 + 16 + bw2 > bEnd) {
                                bs2 -= 0.5f;
                                sw2 = tw(solB[0], bs2, bold) + 8 + tw(tries[ti][0], bs2, semi);
                                bw2 = tw(tries[ti][1], bs2, semi);
                            }
                            if (bx + sw2 + 16 + bw2 <= bEnd) {
                                solB = new String[]{solB[0], tries[ti][0]};
                                nm = tries[ti][1]; bs = bs2; sw = sw2; bw = bw2;
                                break;
                            }
                        }
                    }
                    if (bs >= 11 && solB != null && bx + sw + 16 + bw <= bEnd) {
                        // solar time and phase name both above the SIM boxes; the name pushed to the right end
                        float e1 = text(c, solB[0], bx, by, bs, bold, yellow());
                        text(c, solB[1], e1 + 8, by, bs, semi, color);
                        text(c, nm, bEnd - bw, by, bs, semi, grey());
                        upTop = solUp = true;
                        nameX = simLeft + 14;                     // the ISS line may now run up to the SIM boxes
                        half = 0;
                    } else if (bs >= 11 && bx + bw <= bEnd) {
                        text(c, nm, bEnd - bw, by, bs, semi, grey());   // name only, as far right as it goes
                        upTop = true;
                        nameX = simLeft + 14;                     // so the solar time (nameX - 22) ends 8 short of the SIM boxes
                        half = 0;
                    } else {
                        nameX = Math.max(nameX, simLeft - 10 - 2 * half);
                    }
                }
                if (!upTop) text(c, nm, nameX, top, size, semi, grey());
                // ISS / satellite line at the left of the strip, above the clock (a bit larger than the strip text)
                try {
                    String sat = satText;
                    if (sat != null && !sat.isEmpty()) {
                        float ss = Math.min(25f, size * 1.2f);
                        float stop = Math.max(top, ss * 0.5f + 1);
                        float sx0 = Math.max(20, cornerX(stop - ss * 0.4f) + 4);
                        float maxX = nameX - 22;
                        String[] sol0 = solarNow();
                        if (sol0 != null && !solUp) maxX -= tw(sol0[0], size, bold) + 8 + tw(sol0[1], size, semi) + 14;
                        int scol = satLive ? teal() : grey();
                        String st = sat;
                        // too long: shorten the satellite's name first, keeping "ISS ..." and the city / country after it
                        String nmS = satNameS, cityS = satCityS;
                        if (sx0 + tw(st, ss, semi) > maxX && nmS != null && !nmS.isEmpty() && satIssS != null) {
                            String n2 = nmS;
                            while (n2.length() > 3) {
                                n2 = n2.substring(0, n2.length() - 1);
                                st = satIssS + " · " + n2.trim() + "…" + cityS;
                                if (sx0 + tw(st, ss, semi) <= maxX) break;
                            }
                        }
                        while (st.length() > 4 && sx0 + tw(st, ss, semi) > maxX) st = st.substring(0, st.length() - 2) + "…";
                        if (sx0 + tw(st, ss, semi) <= maxX) text(c, st, sx0, stop, ss, semi, scol);
                    }
                } catch (Throwable ignored) { }
                try {
                    String[] sol = solUp ? null : solarNow();
                    if (sol != null) {
                        float sx1 = nameX - 22;
                        float w1 = tw(sol[0], size, bold), w2 = tw(sol[1], size, semi);
                        float sx0 = sx1 - w1 - 8 - w2;
                        if (sx0 >= Math.max(20, cornerX(top - size * 0.4f) + 4)) {
                            float e1 = text(c, sol[0], sx0, top, size, bold, yellow());
                            text(c, sol[1], e1 + 8, top, size, semi, color);
                        }
                    }
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
        String a = healthText();
        // under the camera hole, between the speeds and the 4G / 5G data counters; shrunk to fit that gap
        float HS = HP2_SIZE;
        float room = 2 * r + 22;
        float fw = tw(a, HS, bold);
        if (fw > room) HS = Math.max(12f, HS * room / fw);
        float ly = y(P1A) - 6;   // the thin gap under the ISS / satellite line, centred over the camera
        hP2X = cx - tw(a, HS, bold) / 2f;
        int hc = soh <= 0 ? color : soh >= 85 ? green() : soh >= 75 ? yellow() : soh >= 65 ? orange() : red();
        String pct = soh > 0 ? soh + "%" : "--";
        String alt = "";
        // small battery outline before the health figure
        {
            float bh = Math.max(12f, HS * 0.8f), bw = bh * 0.52f, bx = hP2X - bw - 7f;
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(hc);
            rf.set(bx + bw * 0.3f, ly - bh / 2f - 2f, bx + bw * 0.7f, ly - bh / 2f);
            c.drawRect(rf, gp);                                    // nub
            gp.setStyle(Paint.Style.STROKE);
            gp.setStrokeWidth(1.8f);
            rf.set(bx, ly - bh / 2f, bx + bw, ly + bh / 2f);
            c.drawRoundRect(rf, 2.5f, 2.5f, gp);                   // body
            gp.setStyle(Paint.Style.FILL);
            float fh = (bh - 4f) * (soh > 0 ? Math.min(100, soh) / 100f : 0.5f);
            rf.set(bx + 2f, ly + bh / 2f - 2f - fh, bx + bw - 2f, ly + bh / 2f - 2f);
            c.drawRect(rf, gp);                                    // fill = health
        }
        float e = text(c, pct, hP2X, ly, HS, bold, hc);
        e = text(c, a.substring(pct.length(), a.length() - alt.length()), e, ly, HS, bold, color);
        if (!alt.isEmpty()) e = text(c, alt, e, ly, HS, bold, teal());
        healthEnd = row3End;   // row 3 is the weather's now: the quake fallback goes after it
    }

    // ---- towers switched today (both SIMs), reset at midnight
    private static volatile int hoCount;
    private static volatile int hoDay = -1;

    private static volatile long hoAt = 0;

    private static boolean hoRecent() {
        return System.currentTimeMillis() - hoAt < 10_000;
    }

    private static final int[] hoSim = new int[3];
    private static volatile int hoSimDay = -1;

    /** Tower switches today for SIM slot 1 or 2. */
    static int handoversFor(int slot) {
        int d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR);
        return d == hoSimDay && slot >= 1 && slot <= 2 ? hoSim[slot] : 0;
    }

    static void handover(long now, int slot) {
        int d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR);
        if (d != hoSimDay) { hoSimDay = d; hoSim[1] = 0; hoSim[2] = 0; }
        if (slot >= 1 && slot <= 2) hoSim[slot]++;
        handover(now);
    }

    static void handover(long now) {
        hoAt = System.currentTimeMillis();
        int d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR);
        if (d != hoDay) { hoDay = d; hoCount = 0; }
        hoCount++;
    }

    private static int handoversToday() {
        int d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR);
        return d == hoDay ? hoCount : 0;
    }

    /** "☀11h18m" by day (sunrise to sunset), "☾12h42m" by night (sunset to next sunrise). */
    private String dayNightLen() {
        double[] st = SunTimes.today(fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
        if (st == null || Double.isNaN(st[0]) || Double.isNaN(st[1])) return null;
        java.util.Calendar c = java.util.Calendar.getInstance();
        double nowMin = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE);
        double dayLen = st[1] - st[0];
        boolean day = nowMin >= st[0] && nowMin < st[1];
        int m = (int) Math.round(day ? dayLen : 1440 - dayLen);
        return (day ? "☀" : "☾") + (m / 60) + "h" + String.format(Locale.US, "%02d", m % 60) + "m";
    }

    /** Two tiny lines right of the pressure / ping strip, left of SIM 1's tower name: day or night length, towers switched today. */
    private void proGap2(Canvas c, float x0, float x1) {
        if (x1 - x0 < 30) return;
        String dl = dayNightLen();
        int ho = handoversToday();
        float cy = (y(P2) + 19 + y(P3) - 16) / 2f;
        float sz = 16;
        if (dl != null) fit(c, x0, cy - 8, tw(dl, sz, bold), x1 - x0, () -> text(c, dl, 0, 0, sz, bold, dl.startsWith("☀") ? yellow() : color));
        final boolean hot = hoRecent();
        final String hs = "↔" + ho + " twr" + (hot ? " now" : "");
        fit(c, x0, cy + 9, tw(hs, sz, bold), x1 - x0, () -> text(c, hs, 0, 0, sz, bold, hot || ho > 30 ? orange() : grey()));
    }

    /** Thin strip between row 2 and row 3, ending under the camera: pressure + trend, ping. */
    private void proGap(Canvas c, float cx, float cr) {
        List<Item> its = new ArrayList<>();
        if (!Float.isNaN(wxPres)) {
            String ar = Float.isNaN(wxPresTrend) || Math.abs(wxPresTrend) < 0.5f ? "→" : wxPresTrend > 0 ? "↑" : "↓";
            int pc = Float.isNaN(wxPresTrend) ? grey() : wxPresTrend <= -1.5f ? orange() : wxPresTrend >= 1.5f ? green() : color;
            its.add(new Item(5, 18).t(String.valueOf(Math.round(wxPres)), 18, bold, color).t(ar, 17, bold, pc));
        }
        if (ping > 0) {
            int qc = ping < 60 ? green() : ping < 150 ? yellow() : ping < 400 ? orange() : red();
            its.add(new Item(4, 18).t("⇄", 16, bold, grey()).t(String.valueOf(ping), 18, bold, qc).t("ms", 13, semi, grey()));
        }
        if (its.isEmpty()) return;
        float gy = (y(P2) + 19 + y(P3) - 16) / 2f;
        float xR = cx + Math.min(cr, 10);
        drawTail(c, its, xR, gy, Math.max(30, xR - 260), 10);
    }

    /** Row 4 centre: moon phase disc + illumination, then the latest nearby quake (24 h). */
    private float skyX, skyRow, skyF = 1f;
    private long skyAt;
    private int skyDrawn, skyHidden;
    private String skyWhy = "";

    private void hidden(String why) {
        skyHidden++;
        skyWhy = why;
        skyDbg = "moon/quake drawn " + skyDrawn + ", hidden " + skyHidden + " (last: " + why + ")";
    }

    /** A frame that would hide the line keeps the last good placement for 15 s, so it doesn't blink. */
    private boolean holdSky(Canvas c, List<Item> its, double ph) {
        if (System.currentTimeMillis() - skyAt > 15_000L || its.isEmpty()) return false;
        c.save();
        c.scale(skyF, skyF, skyX, skyRow);
        try {
            float e = drawItem(c, its.get(0), skyX, skyRow);
            if (its.size() > 1) drawItem(c, its.get(1), e, skyRow);
        } finally {
            c.restore();
        }
        return true;
    }

    private float skyEnd4 = 0;

    /** Row 4, right end (under the SIM boxes): day/night length, towers switched today, pressure + trend, ping. */
    private void proTail4(Canvas c) {
        List<Item> its = new ArrayList<>();
        String dl = dayNightLen();
        if (dl != null) its.add(new Item(3, 22).t(dl, 20, bold, dl.startsWith("☀") ? yellow() : color));
        if (!Float.isNaN(wxPres)) {
            String ar = Float.isNaN(wxPresTrend) || Math.abs(wxPresTrend) < 0.5f ? "→" : wxPresTrend > 0 ? "↑" : "↓";
            int pc = Float.isNaN(wxPresTrend) ? grey() : wxPresTrend <= -1.5f ? orange() : wxPresTrend >= 1.5f ? green() : color;
            its.add(new Item(5, 22).t(String.valueOf(Math.round(wxPres)), 20, bold, color).t(ar, 19, bold, pc));
        }
        float minX = Math.max(skyEnd4 + 16, Math.max(l4End + 16, Float.isNaN(simLeft) ? W * 0.6f : simLeft - 40));
        drawTail(c, its, W - 8, y(P4), minX, 14);
    }

    private void proSky(Canvas c, float cx) {
        skyEnd4 = 0;
        double ph = moonPhase();
        int lit = (int) Math.round(50 * (1 - Math.cos(2 * Math.PI * ph)));
        boolean waxing = ph < 0.5;
        try {
            Astro.Moon mo = Astro.moon(System.currentTimeMillis(), fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
            ph = mo.phase;
            lit = (int) Math.round(mo.illum * 100);
            waxing = mo.waxing;
        } catch (Throwable ignored) { }
        List<Item> its = new ArrayList<>();
        // no moon here any more (disc and % are in the moonrise / moonset picture): empty lead item, quake only
        its.add(new Item(5, 24));
        boolean q = !Float.isNaN(quakeMag) && (quakeKm < 0 || quakeKm <= 2500 || quakeMag >= 6.0f);
        // quake variants, most informative first: full country name, then its code, then less
        List<Item> qv = new ArrayList<>();
        if (q) {
            int qc = quakeMag < 4 ? yellow() : quakeMag < 5.5 ? orange() : red();
            String mg = "M" + String.format(Locale.US, "%.1f", quakeMag);
            String cc = quakeCc != null && !quakeCc.isEmpty() ? quakeCc : null;
            String full = cc != null ? countryName(cc) : null;
            if (full != null && quakeKm >= 0)
                qv.add(new Item(3, 24).t(mg, 24, bold, qc).sp(6).t(quakeKm + "km", 20, semi, grey()).sp(6).t(full, 20, bold, color));
            if (cc != null && quakeKm >= 0)
                qv.add(new Item(3, 24).t(mg, 24, bold, qc).sp(6).t(quakeKm + "km", 20, semi, grey()).sp(6).t(cc, 20, bold, color));
            if (full != null) qv.add(new Item(3, 24).t(mg, 24, bold, qc).sp(6).t(full, 20, bold, color));
            if (quakeKm >= 0) qv.add(new Item(3, 24).t(mg, 24, bold, qc).sp(6).t(quakeKm + "km", 20, semi, grey()));
            if (cc != null) qv.add(new Item(3, 24).t(mg, 24, bold, qc).sp(6).t(cc, 20, bold, color));
            qv.add(new Item(3, 24).t(mg, 24, bold, qc));
        } else {
            qv.add(new Item(3, 24).t("no quake", 18, semi, grey()));
        }
        long hNow = System.currentTimeMillis();
        if (Cfg.b(Cfg.HAZARDS, Cfg.D_HAZARDS)) {
            Hazards.Ev hv = Hazards.disaster(hNow) ? Hazards.pick(hNow) : null;
            if (hv != null) {
                // GDACS orange / red alerts take the quake's place, rotating every 8 s when there are several
                qv.clear();
                String dot = (hv.india ? "🇮🇳" : "") + (hv.lvl >= 2 ? "🔴" : hv.lvl == 1 ? "🟠" : hv.lvl == 0 ? "🟡" : "🟢"), ic = Hazards.icon(hv.type);
                String nm = hv.name == null ? "" : hv.name, pl = hv.place;
                String dk = hv.km >= 0 ? hv.km + "km " + hv.dir : "";
                int nc = hv.lvl >= 2 ? red() : hv.lvl == 1 ? orange() : hv.lvl == 0 ? yellow() : green();
                if (!nm.isEmpty() && pl != null && !dk.isEmpty())
                    qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc).sp(5).t(nm, 21, bold, nc).t(" · ", 18, semi, grey())
                            .t(pl, 19, semi, color).sp(6).t(dk, 19, semi, grey()));
                if (nm.isEmpty() && pl != null)       // no name (fires, floods): the place instead
                    qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc).sp(5).t(pl, 20, bold, color)
                            .sp(6).t(dk, 19, semi, grey()));
                if (!nm.isEmpty() && !dk.isEmpty())
                    qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc).sp(5).t(nm, 21, bold, nc).sp(6).t(dk, 19, semi, grey()));
                if (!dk.isEmpty()) qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc).sp(5).t(dk, 19, semi, grey()));
                if (!nm.isEmpty()) qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc).sp(5).t(nm, 21, bold, nc));
                qv.add(new Item(3, 24).t(dot + ic, 20, bold, nc));
            }
            int g = Hazards.storm(hNow);
            if (g > 0) {
                // magnetic storm: "🧲Kp6 G2" after whatever row 4 shows; the G drops first when tight
                int kc = g == 1 ? yellow() : g == 2 ? orange() : g == 3 ? red() : purple();
                String kpS = "Kp" + (int) Math.floor(Hazards.kp);
                List<Item> withG = new ArrayList<>(), noG = new ArrayList<>();
                for (Item v : qv) {
                    Item a = new Item(3, 24); a.parts.addAll(v.parts); a.sp(10).t("🧲" + kpS, 20, bold, kc).sp(4).t("G" + g, 18, semi, kc);
                    Item b = new Item(3, 24); b.parts.addAll(v.parts); b.sp(10).t("🧲" + kpS, 20, bold, kc);
                    withG.add(a); noG.add(b);
                }
                qv.clear();
                for (int i = 0; i < withG.size(); i++) { qv.add(withG.get(i)); qv.add(noG.get(i)); }
            }
        }
        Item qi = qv.get(0);
        its.add(qi);
        // row 4 runs on under the SIM boxes while their area names stay on one line
        float lo = l4End + 18, hi = Math.max(w4Start, Math.min(q4End, W - 8)) - 18;
        float rowY = y(P4);
        if (hi - lo < 120) {
            // no room beside the weather: use row 3 right of the health text instead
            lo = Math.max(l4End + 18, healthEnd + 18);
            hi = w4Start - 18;
            rowY = y(P3);
            if (hi - lo < 60) { hidden(String.format(Locale.US, "room %.0f..%.0f", lo, hi)); if (!holdSky(c, its, ph)) return; return; }
        }
        float room = hi - lo;
        float base = its.get(0).w();
        // the first variant that fits at 85 % or more wins; otherwise the shortest one, shrunk down to 65 %
        float f = 1f, total = base + qi.w();
        boolean placed = false;
        for (Item v : qv) {
            float t = base + v.w();
            if (t * 0.85f <= room) { qi = v; total = t; f = Math.min(1f, room / t); placed = true; break; }
        }
        if (!placed) {
            qi = qv.get(qv.size() - 1);
            total = base + qi.w();
            f = Math.max(0.65f, Math.min(1f, room / total));
            if (total * f > room + 0.5f) { qi = null; total = its.get(0).w(); f = Math.max(0.65f, Math.min(1f, room / total)); }
            if (total * f > room + 0.5f) { hidden(String.format(Locale.US, "needs %.0f, room %.0f", total * f, room)); holdSky(c, its, ph); return; }
        }
        if (qi != null) its.set(1, qi); else its.remove(1);
        float tw = total * f;
        float x = Math.max(lo, Math.min(hi - tw, cx - tw / 2f));
        c.save();
        c.scale(f, f, x, rowY);
        try {
            float e = drawItem(c, its.get(0), x, rowY);
            if (its.size() > 1) drawItem(c, its.get(1), e, rowY);
        } finally {
            c.restore();
        }
        if (rowY == y(P4)) skyEnd4 = x + tw;
        skyX = x; skyRow = rowY; skyF = f; skyAt = System.currentTimeMillis(); skyDrawn++;
        skyDbg = String.format(Locale.US, "moon/quake drawn %d, hidden %d%s (now x %.0f, room %.0f..%.0f, width %.0f, row %s)",
                skyDrawn, skyHidden, skyWhy.isEmpty() ? "" : " last: " + skyWhy, x, lo, hi, tw, rowY == y(P4) ? "4" : "3");
    }

    /**
     * {"☉ 22:58", "Night"}: apparent solar time here, and the sun's phase right now from its elevation
     * (day, golden hour, civil / nautical / astronomical twilight as dawn or dusk, night). NOAA formulas.
     */
    private String[] solarNow() {
        double lat = fix != null ? fix[0] : latLon[0], lon = fix != null ? fix[1] : latLon[1];
        long now = System.currentTimeMillis();
        double jd = now / 86400000.0 + 2440587.5, t = (jd - 2451545.0) / 36525.0;
        double l0 = (280.46646 + t * (36000.76983 + t * 0.0003032)) % 360;
        double m = Math.toRadians(357.52911 + t * (35999.05029 - 0.0001537 * t));
        double e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t);
        double cc = Math.sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t)) + Math.sin(2 * m) * (0.019993 - 0.000101 * t)
                + Math.sin(3 * m) * 0.000289;
        double om = Math.toRadians(125.04 - 1934.136 * t);
        double lam = Math.toRadians(l0 + cc - 0.00569 - 0.00478 * Math.sin(om));
        double eps = Math.toRadians(23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
                + 0.00256 * Math.cos(om));
        double dec = Math.asin(Math.sin(eps) * Math.sin(lam));
        double y = Math.tan(eps / 2) * Math.tan(eps / 2), l0r = Math.toRadians(l0);
        double eot = 4 * Math.toDegrees(y * Math.sin(2 * l0r) - 2 * e * Math.sin(m) + 4 * e * y * Math.sin(m) * Math.cos(2 * l0r)
                - 0.5 * y * y * Math.sin(4 * l0r) - 1.25 * e * e * Math.sin(2 * m));          // minutes
        double utcMin = ((now % 86400000L) + 86400000L) % 86400000L / 60000.0;
        double solarMin = ((utcMin + 4 * lon + eot) % 1440 + 1440) % 1440;
        double ha = Math.toRadians(solarMin / 4 - 180);                                     // hour angle
        double la = Math.toRadians(lat);
        double el = Math.toDegrees(Math.asin(Math.sin(la) * Math.sin(dec) + Math.cos(la) * Math.cos(dec) * Math.cos(ha)));
        String ph;
        if (el >= 6) ph = Math.abs(solarMin - 720) < 15 ? "Solar noon" : "Day";
        else if (el >= -0.833) ph = "Golden hour";
        else if (el >= -6) ph = "Civil twilight";
        else if (el >= -12) ph = "Nautical twilight";
        else if (el >= -18) ph = "Astronomical twilight";
        else ph = Math.min(solarMin, 1440 - solarMin) < 15 ? "Solar midnight" : "Night";
        int sm = (int) Math.floor(solarMin);
        return new String[]{String.format(Locale.US, "☉ %02d:%02d", sm / 60, sm % 60), ph};
    }

    /** Moon phase 0..1 (0 new, 0.5 full). */
    private static double moonPhase() {
        double days = System.currentTimeMillis() / 86400000.0 + 2440587.5 - 2451550.1;
        return ((days % 29.530588853) + 29.530588853) % 29.530588853 / 29.530588853;
    }

    /**
     * Name from how much is lit (the way calendars name it): quarters only near 50 %, new / full only
     * near 0 / 100 %, crescent below half, gibbous above.
     */
    static String phaseName(int litPct, boolean waxing) {
        if (litPct <= 2) return "New moon";
        if (litPct >= 98) return "Full moon";
        if (Math.abs(litPct - 50) <= 3) return waxing ? "First quarter" : "Last quarter";
        if (litPct < 50) return waxing ? "Waxing crescent" : "Waning crescent";
        return waxing ? "Waxing gibbous" : "Waning gibbous";
    }

    private static final String[] MOON_NAMES = {"New moon", "Waxing crescent", "First quarter", "Waxing gibbous",
            "Full moon", "Waning gibbous", "Last quarter", "Waning crescent"};

    /** Small moon: dark disc, lit side, terminator ellipse. */
    private void moon(Canvas c, float mx, float my, float r, double ph) {
        int litCol = 0xFFF2E9C9, darkCol = fade(color, 0.22f);
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(darkCol);
        c.drawCircle(mx, my, r, gp);
        boolean waxing = ph < 0.5;
        float k = (float) Math.cos(2 * Math.PI * ph);     // 1 new, -1 full
        android.graphics.Path p = new android.graphics.Path();
        rf.set(mx - r, my - r, mx + r, my + r);
        // lit half (right while waxing, left while waning, as seen from the north)
        p.addArc(rf, waxing ? -90 : 90, 180);
        p.close();
        gp.setColor(litCol);
        c.drawPath(p, gp);
        float ew = Math.abs(k) * r;
        rf.set(mx - ew, my - r, mx + ew, my + r);
        gp.setColor(k > 0 ? darkCol : litCol);
        c.drawOval(rf, gp);
    }

    // ---- right half

    /** Left edge of the SIM blocks (design units), for the strip above to stop short of; NaN = no SIM drawn. */
    private float simLeft = Float.NaN;

    private final float[] colX = new float[2], colW = new float[2];
    private float camRight = Float.NaN;

    /**
     * Two-bar signal meter in the gap between the camera hole and the first SIM box (data SIM):
     * top bar = strength (RSRP, -125..-80 dBm), bottom bar = cleanliness (SNR, -5..25 dB),
     * each filling and turning green / yellow / orange / red. Shows at a glance whether a bad link is
     * weak, noisy or both.
     */
    private void proMeter(Canvas c) {
        if (Float.isNaN(simLeft) || Float.isNaN(camRight)) return;
        SimInfo d = null;
        for (SimInfo si : sims) if (si.data) d = si;
        if (d == null || !d.inService || d.dbm == Bands.NO_DBM) return;
        float x0 = camRight + 10, x1 = simLeft - 8;
        if (x1 - x0 < 34) return;
        float w = Math.min(x1 - x0, 80);
        x0 = x1 - w;                                        // hug the SIM box
        float sig = Math.max(0, Math.min(1, (d.dbm + 125f) / 45f));
        int sc = dbmColor(d.dbm);
        bar(c, x0, y(P1A) + 6, w, "SIG", sig, sc);   // kept below the ISS line above
        if (!Float.isNaN(d.snr)) {
            float q = Math.max(0, Math.min(1, (d.snr + 5f) / 30f));
            int nc = d.snr >= 13 ? green() : d.snr >= 5 ? yellow() : d.snr >= 0 ? orange() : red();
            bar(c, x0, y(P2) - 2, w, "SNR", q, nc);
        }
    }

    /**
     * Data SIM radio details in the gap between the camera and the first SIM box:
     * line 1 = 5G mode ("SA" / "NSA·B3"), line 2 = CQI (modem's 0-15 channel quality) or RSRQ when CQI is missing.
     */
    private void proRadio(Canvas c) {
        if (Float.isNaN(simLeft) || Float.isNaN(camRight)) return;
        SimInfo d = null;
        int di = -1;
        for (int i = 0; i < sims.size(); i++) if (sims.get(i).data) { d = sims.get(i); di = i; }
        if (d == null || !d.inService) return;
        float x1 = simLeft - 8, room = x1 - (camRight + 10);
        if (room < 30) return;
        // the gap sits beside the first box: when the data SIM is another box, say which ("2·")
        String pre = di > 0 ? d.slot + "·" : "";
        if (!pre.isEmpty()) room -= tw(pre, 15, bold);
        if (d.nrMode != null) {
            int col = d.nrMode.equals("SA") ? green() : d.nrMode.startsWith("4G") ? orange() : teal();
            float e = fitRight(c, d.nrMode, x1, y(P1A) + 2, 20, room, bold, col);
            if (e > 0 && !pre.isEmpty()) textB(c, pre, e - tw(pre, 15, bold), y(P1A) + 2, 20, 15, bold, grey());
        }
        // ping, between the 5G mode and the 4G data line
        if (ping > 0) {
            int qc = ping < 60 ? green() : ping < 150 ? yellow() : ping < 400 ? orange() : red();
            String pv = ping + "ms";
            fitRight(c, pv, x1, (y(P1A) + 2 + y(P1B) + 6) / 2f, 17, room, bold, qc);
        }
        // line 2: 4G data used today, coloured by how close it is to the limit
        {
            float f = (float) used4g / Math.max(1, limit4g);
            int col = f < 0.5f ? green() : f < 0.8f ? yellow() : f < 1f ? orange() : red();
            String v = used4g < 100_000_000L ? String.format(Locale.US, "%.0fM", used4g / 1e6)
                    : String.format(Locale.US, "%.2fG", used4g / 1e9);
            float e = fitRight(c, v, x1, y(P1B) + 6, 22, room, bold, col);
            if (e > 0) textB(c, "4G", e - 3 - tw("4G", 15, semi), y(P1B) + 6, 22, 15, semi, grey());
        }
        // line 3: 5G data used today (no limit on it, so one calm colour)
        {
            String v = used5g < 100_000_000L ? String.format(Locale.US, "%.0fM", used5g / 1e6)
                    : String.format(Locale.US, "%.2fG", used5g / 1e9);
            float e = fitRight(c, v, x1, y(P2) + 4, 22, room, bold, teal());
            if (e > 0) textB(c, "5G", e - 3 - tw("5G", 15, semi), y(P2) + 4, 22, 15, semi, grey());
        }
        if (false && d.cqi >= 0) {
            int col = d.cqi >= 10 ? green() : d.cqi >= 7 ? yellow() : d.cqi >= 4 ? orange() : red();
            float e = fitRight(c, String.valueOf(d.cqi), x1, y(P1B) + 6, 22, room, bold, col);
            if (e > 0) textB(c, pre + "CQI", e - 3 - tw(pre + "CQI", 15, semi), y(P1B) + 6, 22, 15, semi, grey());
        }
    }

    /** Right-aligned at x1, shrunk to fit room; returns its left edge (0 if not drawn). */
    private float fitRight(Canvas c, String t, float x1, float cy, float size, float room, Typeface tf, int col) {
        float sz = size;
        while (sz > 13 && tw(t, sz, tf) > room - 26) sz -= 1;
        if (tw(t, sz, tf) > room) return 0;
        float x = x1 - tw(t, sz, tf);
        textB(c, t, x, cy, size, sz, tf, col);
        return x;
    }

    /** "IN" -> "India", "US" -> "USA"; null for codes that aren't countries (sea / ridge initials). */
    private static String countryName(String cc) {
        if (cc == null || cc.length() != 2) return null;
        switch (cc) {
            case "US": return "USA";
            case "GB": return "UK";
            case "AE": return "UAE";
            case "RU": return "Russia";
            case "IR": return "Iran";
            case "KR": return "S Korea";
            case "KP": return "N Korea";
            case "TW": return "Taiwan";
            case "BO": return "Bolivia";
            case "VE": return "Venezuela";
            case "TZ": return "Tanzania";
            case "SY": return "Syria";
            case "PG": return "PNG";
        }
        for (String iso : Locale.getISOCountries()) {
            if (iso.equals(cc)) {
                String n = new Locale("", cc).getDisplayCountry(Locale.ENGLISH);
                return n == null || n.isEmpty() || n.length() > 16 ? null : n;
            }
        }
        return null;
    }

    /** Small label above a rounded bar: track in faint text colour, fill in col. */
    private void bar(Canvas c, float x, float cy, float w, String label, float f, int col) {
        textB(c, label, x, cy - 12, 14, 14, semi, grey());
        float t = cy + 2, b = cy + 12;
        gp.setStyle(Paint.Style.FILL);
        gp.setColor(fade(color, 0.22f));
        rf.set(x, t, x + w, b);
        c.drawRoundRect(rf, 5, 5, gp);
        gp.setColor(col);
        rf.set(x, t, x + Math.max(10, w * f), b);
        c.drawRoundRect(rf, 5, 5, gp);
    }
    private int colN;

    private float healthX = Float.NaN;
    private static final float HP2_SIZE = 15;
    private float hP2X = 1e9f, hP2W = 0, wxEnd = 0, row3End = 0;

    /** Where the SIM boxes will start (same sums as proRight), before they're drawn. */
    private float predictSimLeft(float R0, float R1) {
        int n = Math.min(2, sims.size());
        if (n == 0) return Float.NaN;
        float simR = Math.min(R1, cornerRightX(y(P1A) - 24) - 4);
        final float pad = 7, gap = 2;
        float total = gap * (n - 1);
        for (int i = 0; i < n; i++) total += simW(sims.get(i)) + 2 * pad;
        float f = total > simR - R0 ? (simR - R0) / total : 1f;
        return simR - total * f;
    }

    private void proRight(Canvas c, float R0, float R1) {
        simLeft = Float.NaN;
        colN = 0;
        int n = Math.min(2, sims.size());
        float simR = Math.min(R1, cornerRightX(y(P1A) - 24) - 4);
        if (n > 0) {
            final float pad = 7, gap = 2;
            float[] bw = new float[n];
            float total = gap * (n - 1);
            for (int i = 0; i < n; i++) {
                bw[i] = simW(sims.get(i)) + 2 * pad;
                total += bw[i];
            }
            float f = total > simR - R0 ? (simR - R0) / total : 1f;
            float x = simR - total * f;
            simLeft = x;
            for (int i = 0; i < n; i++) {
                SimInfo si = sims.get(i);
                float b = bw[i] * f;
                if (si.data) {
                    gp.setStyle(Paint.Style.STROKE);
                    gp.setStrokeWidth(2.5f);
                    gp.setColor(dk ? 0xFFFFFFFF : color);
                    rf.set(x + 1.25f, y(P1A) - 24, x + b - 1.25f, y(P2) + 17);
                    c.drawRoundRect(rf, 12, 12, gp);
                }
                try { proSim(c, si, x + pad * f, b - 2 * pad * f); } catch (Throwable ignored) { }
                colX[i] = x; colW[i] = b; colN = i + 1;
                x += b + gap * f;
            }
        }
        // corner beside the SIMs: today's 5G share, or the data SIM's signal quality, or nothing
        int corner = Cfg.i(Cfg.CORNER, Cfg.D_CORNER);
        try {
            if (corner == 1) proNrShare(c, simR + 3, W - 4);
            else if (corner == 2) proQuality(c, simR + 3, W - 4);
        } catch (Throwable ignored) { }
        try { proTowerAreas(c); } catch (Throwable ignored) { }
    }

    /** Data SIM signal quality 0-100: 60 % from RSRP (-125..-80 dBm), 40 % from SNR (-5..25 dB). */
    private int quality(SimInfo si) {
        if (!si.inService || si.dbm == Bands.NO_DBM) return -1;
        float a = Math.max(0, Math.min(1, (si.dbm + 125f) / 45f));
        if (Float.isNaN(si.snr)) return Math.round(a * 100);
        float b = Math.max(0, Math.min(1, (si.snr + 5f) / 30f));
        return Math.round((0.6f * a + 0.4f * b) * 100);
    }

    /** "Q" over "82%" in the corner space beside the SIMs (lines 1b and 2, below the corner curve). */
    private void proQuality(Canvas c, float x0, float x1) {
        // phone battery level above the Q label
        if (battPct >= 0 && x1 - x0 >= 14) {
            final String bv = (charging ? "⚡" : "") + battPct + "%";
            final int bc = charging ? green() : battPct >= 50 ? green() : battPct >= 20 ? yellow() : battPct >= 10 ? orange() : red();
            final float bcw = x1 - x0;
            fit(c, x0, y(P1A) + 2, tw(bv, 19, bold), bcw, () -> text(c, bv, 0, 0, 19, bold, bc));
        }
        SimInfo d = null;
        for (SimInfo si : sims) if (si.data) d = si;
        if (d == null) return;
        int q = quality(d);
        if (q < 0 || x1 - x0 < 14) return;
        final String v = q + "%";
        final int col = q >= 70 ? green() : q >= 45 ? yellow() : q >= 25 ? orange() : red();
        final float cw = x1 - x0;
        fit(c, x0, y(P1B), tw("Q", 16, semi), cw, () -> text(c, "Q", 0, 0, 16, semi, grey()));
        fit(c, x0, y(P2), tw(v, 20, bold), cw, () -> text(c, v, 0, 0, 20, bold, col));
    }

    /** "5G" over "92%" in the corner beside the SIMs: how much of today was on 5G. */
    private void proNrShare(Canvas c, float x0, float x1) {
        if (nrShare < 0 || x1 - x0 < 14) return;
        final String v = nrShare + "%";
        final int col = nrShare >= 80 ? green() : nrShare >= 50 ? yellow() : nrShare >= 25 ? orange() : red();
        final float cw = x1 - x0;
        fit(c, x0, y(P1B), tw("5G", 16, semi), cw, () -> text(c, "5G", 0, 0, 16, semi, grey()));
        fit(c, x0, y(P2), tw(v, 20, bold), cw, () -> text(c, v, 0, 0, 20, bold, col));
    }

    private static final float DISH_W = 22;

    /** Phone picking up signals: phone outline (earpiece + home dot) with two waves arriving from the right. */
    private void dish(Canvas c, float x, float cy, int col) {
        stroke(2f, col);
        rf.set(x + 1, cy - 10, x + 11, cy + 10);
        c.drawRoundRect(rf, 2.5f, 2.5f, gp);                     // phone body
        c.drawLine(x + 4.5f, cy - 7, x + 7.5f, cy - 7, gp);      // earpiece
        gp.setStyle(Paint.Style.FILL);
        c.drawCircle(x + 6, cy + 7, 1.2f, gp);                   // home dot
        stroke(2f, col);
        rf.set(x + 9, cy - 7, x + 17, cy + 1);
        c.drawArc(rf, -60, 120, false, gp);                      // inner wave
        rf.set(x + 9, cy - 11, x + 23, cy + 5);
        c.drawArc(rf, -55, 110, false, gp);                      // outer wave
    }

    private static final float BARS_W = 4 * 9.5f;

    /** Roaming badge text: "R·KA" when the circle is known, else "R". */
    private static String roamText(SimInfo si) {
        return si.circle != null ? "R·" + si.circle : "R";
    }

    /** "VoNR" / "VoLTE" / "VoWiFi" text as shown in the pill. */
    private static String voText(String type) {
        return "Vo" + ("WiFi".equalsIgnoreCase(type) ? "WiFi" : type);
    }

    /** Width of the voice pill. */
    private float voW(String type) {
        return tw(voText(type), 17, bold) + 12;
    }

    /** Voice pill: "VoNR" in a thin rounded outline, centred on the line. */
    private float voBadge(Canvas c, String type, float x, int col) {
        String t = voText(type);
        float w = tw(t, 17, bold) + 12;
        stroke(1.8f, col);
        rf.set(x, -12, x + w, 12);
        c.drawRoundRect(rf, 6, 6, gp);
        tp.setTypeface(bold);
        tp.setTextSize(17);
        tp.setColor(col);
        c.drawText(t, x + 6, 6, tp);
        return x + w;
    }

    private static final float LOCK_W = 8 + 13;
    private static final float ARROW_W = 11;

    /** "5G+" drawn as 5G with a small raised plus. */
    private float ratW(String rat) {
        if (rat.endsWith("+") && rat.length() > 1) return tw(rat.substring(0, rat.length() - 1), 34, bold) + 1 + tw("+", 22, bold);
        return tw(rat, 34, bold);
    }

    private float drawRat(Canvas c, String rat, float x, int col) {
        if (!(rat.endsWith("+") && rat.length() > 1)) return textB(c, rat, x, 0, 34, 34, bold, col);
        float e = textB(c, rat.substring(0, rat.length() - 1), x, 0, 34, 34, bold, col);
        return textB(c, "+", e + 1, -9, 34, 22, bold, col);
    }

    /** Stacked activity triangles centred on cy: up (blue) above, down (green) below. */
    private void arrows(Canvas c, float x, float cy, boolean up, boolean down) {
        int idle = fade(color, 0.22f);
        gp.setStyle(Paint.Style.FILL);
        float w = ARROW_W, h = 9;
        path.reset();
        path.moveTo(x, cy - 2); path.lineTo(x + w, cy - 2); path.lineTo(x + w / 2, cy - 2 - h); path.close();
        gp.setColor(up ? blue() : idle);
        c.drawPath(path, gp);
        path.reset();
        path.moveTo(x, cy + 2); path.lineTo(x + w, cy + 2); path.lineTo(x + w / 2, cy + 2 + h); path.close();
        gp.setColor(down ? green() : idle);
        c.drawPath(path, gp);
    }

    /** True when this SIM has a band lock set in settings. */
    private static boolean locked(SimInfo si) {
        try { return !Cfg.s(si.slot == 2 ? Cfg.BANDS2 : Cfg.BANDS1).isEmpty(); } catch (Throwable t) { return false; }
    }

    /** Small padlock, 13 wide, centred on cy. */
    private void lockIcon(Canvas c, float x, float cy, int col) {
        gp.setColor(col);
        gp.setStyle(Paint.Style.FILL);
        rf.set(x, cy - 2, x + 13, cy + 9);
        c.drawRoundRect(rf, 2, 2, gp);
        gp.setStyle(Paint.Style.STROKE);
        gp.setStrokeWidth(2.2f);
        rf.set(x + 2.5f, cy - 10, x + 10.5f, cy + 2);
        c.drawArc(rf, 180, 180, false, gp);
        gp.setStyle(Paint.Style.FILL);
    }

    /** Natural width of one SIM's block (its widest line). */
    private static final float S1 = 0.88f, S2 = 0.82f, S3 = 0.8f, S4 = 0.9f, BOX_MIN = 235f;
    /** Largest scale a line may grow to when its box has spare width (the lines sit 25 px apart, so only a little). */
    private static final float G1 = 1.04f, G2 = 1.0f, G3 = 1.0f, G4 = 1.12f;

    private String modeText(SimInfo si) {
        return si.data && si.inService ? si.nrMode : null;
    }

    private String pingText(SimInfo si) {
        return si.data && si.inService && ping > 0 ? ping + "ms" : null;
    }

    /** Width of "SA · 28ms" after the voice pill (data SIM only), 0 when there is none. */
    private float modePingW(SimInfo si) {
        String m = modeText(si), p = pingText(si);
        if (m == null && p == null) return 0;
        return 8 + (m != null ? tw(m, 17, bold) : 0) + (m != null && p != null ? tw(" · ", 17, semi) : 0)
                + (p != null ? tw(p, 17, bold) : 0);
    }

    private String dataTodayText(SimInfo si, boolean f4) {
        boolean mo = monthly();
        long u = f4 ? (mo ? m4g : used4g) : (mo ? m5g : used5g);
        return u < 100_000_000L ? String.format(Locale.US, "%.0fM", u / 1e6) : String.format(Locale.US, "%.2fG", u / 1e9);
    }

    private boolean monthly() { return Cfg.i(Cfg.DATA_PERIOD, Cfg.D_DATA_PERIOD) == 1; }
    /** Width of the little coloured "D" / "M" box that says which period the data figures are for. */
    private float periodBoxW() { return tw(monthly() ? "M" : "D", 15, bold) + 10 + 4; }

    private float dataTodayW(SimInfo si) {
        if (!si.data || !si.inService) return 0;
        return periodBoxW() + tw("4G ", 15, semi) + tw(dataTodayText(si, true), 20, bold)
                + tw(" · ", 17, semi) + tw("5G ", 15, semi) + tw(dataTodayText(si, false), 20, bold);
    }

    private float simW(SimInfo si) {
        boolean live = si.inService;
        String rat = live && si.rat != null && !si.rat.isEmpty() ? si.rat : "—";
        float wa = (si.data ? ARROW_W + 4 : 0) + ratW(rat) + (si.eco ? 6 + tw("E", 22, bold) : 0)
                + 0 + 10 + BARS_W + (si.voice != null ? 8 + voW(si.voice) : 0) + modePingW(si);
        String dbm = live && si.dbm != Bands.NO_DBM ? minus(String.valueOf(si.dbm)) : null;
        String snr = live && !Float.isNaN(si.snr) ? minus(String.valueOf(Math.round(si.snr))) : null;
        float wb = (dbm != null ? tw(dbm, 28, bold) + 4 + tw("↑", 24, bold) : 0)
                + (snr != null ? 14 + tw("/", 22, semi) + 6 + tw(snr, 28, bold) + 4 + tw("good", 15, semi) : 0)
                + (locked(si) ? LOCK_W : 0);
        String band = si.band != null ? si.band : "?";
        float w2 = tw(band, 26, semi) + (si.dist != null ? 10 + tw(si.dist, 26, semi) : 0)
                + (si.cells > 0 ? 12 + DISH_W + 4 + tw(String.valueOf(si.cells), 24, bold) : 0);
        float w4 = dataTodayW(si);
        return Math.max(BOX_MIN, Math.max(Math.max(wa * S1, wb * S2), Math.max(w2 * S3, w4 * S4)));
    }

    /** Like fit(), but the line is drawn at scale sc (smaller text) and shrinks further if still too wide. */
    private static float grow(float sc) {
        return sc == S1 ? G1 : sc == S2 ? G2 : sc == S3 ? G3 : G4;
    }
    private void fitK(Canvas c, float x, float cy, float width, float cw, float sc, Runnable draw) {
        float f = Math.min(cw / width, grow(sc));
        c.save();
        c.translate(x, cy);
        c.scale(f, f);
        try { draw.run(); } finally { c.restore(); }
    }

    /** Draws [draw] scaled down to fit width cw if it is wider. */
    private void fit(Canvas c, float x, float cy, float width, float cw, Runnable draw) {
        float f = width > cw ? cw / width : 1f;
        c.save();
        c.translate(x, cy);
        if (f < 1f) c.scale(f, f);
        try { draw.run(); } finally { c.restore(); }
    }

    private void proSim(final Canvas c, final SimInfo si, float x, float cw) {
        final boolean live = si.inService;
        final float k = si.data ? 1f : 0.8f;
        final String rat = live && si.rat != null && !si.rat.isEmpty() ? si.rat : "—";
        final String vo = si.voice;
        final float barsW = BARS_W;
        // four lines in the box: link / signal / cell / data today (data SIM only)
        final float yL1 = y(P1A) - 4, yL2 = y(P1B) - 13, yL3 = y(P2) - 18, yL4 = y(P2) + 4;
        final String mode = modeText(si), pingT = pingText(si);
        float wa = (si.data ? ARROW_W + 4 : 0) + ratW(rat) + (si.eco ? 6 + tw("E", 22, bold) : 0)
                + 0 + 10 + barsW + (vo != null ? 8 + voW(vo) : 0) + modePingW(si);
        // line 1: network, bars, live arrows, voice, and for the data SIM "SA · 28ms"
        fitK(c, x, yL1, wa, cw, S1, () -> {
            float e = 0;
            if (si.data) {
                // one narrow column: ▲ upload on top, ▼ download below; faint while idle
                arrows(c, e, 0, dataOut, dataIn);
                e += ARROW_W + 4;
            }
            e = drawRat(c, rat, e, fade(color, k));
            if (si.eco) e = textB(c, "E", e + 6, 0, 34, 22, bold, green());
            e += 10;
            boolean has = live && si.dbm != Bands.NO_DBM;
            int lvl = !has ? 0 : si.dbm >= -90 ? 4 : si.dbm >= -100 ? 3 : si.dbm >= -110 ? 2 : si.dbm >= -120 ? 1 : 0;
            int bc = has ? dbmColor(si.dbm) : grey();
            gp.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 4; i++) {
                float bh = 26f * (i + 1) / 4f, l = e + i * 9.5f;
                gp.setColor(i < lvl ? bc : fade(color, 0.22f));
                rf.set(l, 12 - bh, l + 6.5f, 12);
                c.drawRoundRect(rf, 2, 2, gp);
            }
            e += barsW;
            if (vo != null) e = voBadge(c, vo, e + 8, fade(green(), k));
            if (mode != null || pingT != null) {
                e += 8;
                if (mode != null) {
                    int mc = mode.equals("SA") ? green() : mode.startsWith("4G") ? orange() : teal();
                    e = textB(c, mode, e, 0, 28, 17, bold, mc);
                }
                if (mode != null && pingT != null) e = textB(c, " · ", e, 0, 28, 17, semi, grey());
                if (pingT != null) {
                    int qc = ping < 60 ? green() : ping < 150 ? yellow() : ping < 400 ? orange() : red();
                    e = textB(c, pingT, e, 0, 28, 17, bold, qc);
                }
            }
        });
        // line 2: signal (dBm) with its direction arrow, then SINR with its word; units dropped, colours say it
        final String dbm = live && si.dbm != Bands.NO_DBM ? minus(String.valueOf(si.dbm)) : null;
        final String snr = live && !Float.isNaN(si.snr) ? minus(String.valueOf(Math.round(si.snr))) : null;
        if (dbm != null || snr != null) {
            float wb = (dbm != null ? tw(dbm, 28, bold) + 4 + tw("↑", 24, bold) : 0)
                    + (snr != null ? 14 + tw("/", 22, semi) + 6 + tw(snr, 28, bold) + 4 + tw("good", 15, semi) : 0)
                    + (locked(si) ? LOCK_W : 0);
            final boolean lk = locked(si);
            fitK(c, x, yL2, wb, cw, S2, () -> {
                float e = 0;
                if (dbm != null) {
                    e = textB(c, dbm, 0, 0, 28, 28, bold, fade(dbmColor(si.dbm), k));
                    // signal direction over the last minute: ↑ stronger, ↓ weaker, → steady
                    String trd = si.trend;
                    boolean up = trd != null && trd.startsWith("+");
                    e = textB(c, trd == null ? "→" : up ? "↑" : "↓", e + 3, 0, 28, 24, bold,
                            trd == null ? grey() : up ? green() : red());
                }
                if (snr != null) {
                    int sc = si.snr >= 13 ? green() : si.snr >= 5 ? yellow() : si.snr >= 0 ? orange() : red();
                    if (dbm != null) e = textB(c, "/", e + 8, 0, 28, 22, semi, grey()) + 6;
                    e = textB(c, snr, e, 0, 28, 28, bold, fade(sc, k));
                    e = textB(c, si.snr >= 13 ? "good" : si.snr >= 5 ? "ok" : si.snr >= 0 ? "poor" : "bad",
                            e + 4, 0, 28, 15, semi, fade(sc, k));
                }
                if (lk) lockIcon(c, e + 8, 0, teal());           // bands locked in settings
            });
        }
        // line 3: band, distance, cells heard
        final String band = si.band != null ? si.band : "?";
        final String dist = si.dist;
        final String cells = si.cells > 0 ? String.valueOf(si.cells) : null;
        float w2 = tw(band, 26, semi) + (dist != null ? 10 + tw(dist, 26, semi) : 0)
                + (cells != null ? 12 + DISH_W + 4 + tw(cells, 24, bold) : 0);
        fitK(c, x, yL3, w2, cw, S3, () -> {
            float e = textB(c, band, 0, 0, 26, 26, semi, fade(blue(), k));
            if (dist != null) e = textB(c, dist, e + 10, 0, 26, 26, semi, fade(color, k));
            if (cells != null) {
                dish(c, e + 12, 0, grey());
                e += 12 + DISH_W - 1;
                textB(c, cells, e + 5, 0, 26, 24, bold, grey());
            }
        });
        // line 4 (data SIM only): data used today on 4G and on 5G
        final float w4 = dataTodayW(si);
        if (w4 > 0) {
            final float f4 = (float) used4g / Math.max(1, limit4g);
            final int c4 = monthly() ? green() : f4 < 0.5f ? green() : f4 < 0.8f ? yellow() : f4 < 1f ? orange() : red();
            fitK(c, x, yL4, w4, cw, S4, () -> {
                String pl = monthly() ? "M" : "D";
                float bw0 = tw(pl, 15, bold) + 10;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(monthly() ? 0xFFB388FF : 0xFF4DD0E1);        // M purple, D cyan
                rf.set(0, -10, bw0, 10);
                c.drawRoundRect(rf, 4, 4, gp);
                textB(c, pl, 5, 0, 22, 15, bold, 0xFF1A1A1A);
                float e = bw0 + 4;
                e = textB(c, "4G ", e, 0, 22, 15, semi, grey());
                e = textB(c, dataTodayText(si, true), e, 0, 22, 20, bold, c4);
                e = textB(c, " · ", e, 0, 22, 17, semi, grey());
                e = textB(c, "5G ", e, 0, 22, 15, semi, grey());
                textB(c, dataTodayText(si, false), e, 0, 22, 20, bold, teal());
            });
        }
    }

    /**
     * Each SIM's tower area under its box (rows 3-4): one line when it fits, two lines for long names,
     * smaller text before cutting with "…".
     */
    private boolean towerBelow, towerAnyBelow;
    /** The name sits right after the roaming tag (left-aligned) instead of centred in the space. */
    private boolean nameLeft;
    private float cx(float bx, float bw, float w) { return nameLeft ? bx : bx + Math.max(0, (bw - w) / 2f); }
    private android.graphics.Bitmap scratchBmp;
    private Canvas scratchCv;

    /** Two passes: a dry run finds out whether any SIM's extras don't fit beside its name; if so, all SIMs put them below, so names match. */
    private void proTowerAreas(Canvas c) {
        if (scratchCv == null) {
            scratchBmp = android.graphics.Bitmap.createBitmap(1, 1, android.graphics.Bitmap.Config.ARGB_8888);
            scratchCv = new Canvas(scratchBmp);
        }
        towerBelow = false;
        towerAnyBelow = false;
        try { proTowerAreas0(scratchCv); } catch (Throwable ignored) { }
        towerBelow = towerAnyBelow;
        proTowerAreas0(c);
    }

    private void proTowerAreas0(Canvas c) {
        w4Start = Float.isNaN(simLeft) ? W - 8 : simLeft;
        q4End = w4Start;
        boolean q4Open = true;                              // row 4 free under the boxes so far (left to right)
        float boxBottom = y(P2) + 17;                      // the SIM box's white line
        for (int i = 0; i < colN && i < sims.size(); i++) {
            SimInfo si = sims.get(i);
            // no service: "No signal" replaces the tower-area line
            // very weak signal (RSRP -115 dBm or lower): "Weak signal" goes in front of the area name
            boolean weakSig = si.inService && si.dbm != Bands.NO_DBM && si.dbm <= -115;
            if (!si.inService) {
                float nsz = 23, nbw = colW[i] - 8;
                while (nsz > 15 && tw("No signal", nsz, semi) > nbw) nsz -= 0.5f;
                text(c, "No signal", colX[i] + 4 + (nbw - tw("No signal", nsz, semi)) / 2f, boxBottom + 3 + nsz * 0.5f, nsz, semi, grey());
                if (q4Open) q4End = colX[i] + colW[i];
                continue;
            }
            boolean hasArea = si.area != null && !si.area.isEmpty(), hasNet = si.netName != null && !si.netName.isEmpty();
            if (!hasArea && !hasNet && weakSig) {
                float wsz = 23, wbw = colW[i] - 8;
                while (wsz > 15 && tw("Weak signal", wsz, semi) > wbw) wsz -= 0.5f;
                text(c, "Weak signal", colX[i] + 4 + (wbw - tw("Weak signal", wsz, semi)) / 2f, boxBottom + 3 + wsz * 0.5f, wsz, semi, grey());
                if (q4Open) q4End = colX[i] + colW[i];
                continue;
            }
            if (!hasArea && !hasNet) { if (q4Open) q4End = colX[i] + colW[i]; continue; }
            float bx = colX[i] + 4, bw = colW[i] - 8;
            nameLeft = false;
            float top = boxBottom;
            final float fullBx = bx, fullBw = bw;
            if (si.roaming) {
                // yellow "R·KA" tag: beside the area name when both fit, else on its own line above it
                String rt = roamText(si);
                float tagW = tw(rt, 18, bold) + 10;
                String nm0 = hasNet && hasArea ? si.netName + " · " + si.area : hasNet ? si.netName : hasArea ? si.area : "";
                boolean beside = nm0.isEmpty() || tw(nm0, 18, semi) + tagW + 6 <= bw;
                float tx = beside && !nm0.isEmpty() ? bx : bx + (bw - tagW) / 2f, ty = top + 3 + 11;
                gp.setStyle(Paint.Style.FILL);
                gp.setColor(0xFFFFD21F);
                rf.set(tx, ty - 11, tx + tagW, ty + 11);
                c.drawRoundRect(rf, 5, 5, gp);
                textB(c, rt, tx + 5, ty, 18, 18, bold, 0xFF2A2000);
                if (!hasArea && !hasNet) continue;
                if (beside) { bx += tagW + 6; bw -= tagW + 6; nameLeft = !nm0.isEmpty(); }
                else top += 26;                      // name goes on the next line(s)
            }
            int col = si.data ? color : grey();
            // "Dolphin · ~Andheri": the network's own name first; when too long, the area name shortens first
            String nm = hasNet && hasArea ? si.netName + " · " + si.area : hasNet ? si.netName : si.area;
            if (weakSig) nm = "Weak signal · " + nm;
            if (hasNet && hasArea && tw(nm, 20, semi) > bw && split2(nm) == null) {
                String a = si.area;
                while (a.length() > 3 && tw(si.netName + " · " + a, 20, semi) > bw) a = a.substring(0, a.length() - 2) + "…";
                nm = si.netName + " · " + a;
            }
            float yEnd;
            boolean pciDone = false;
            // beside the name: direction to the tower and time on it; signal trend after
            java.util.List<String> bes = new java.util.ArrayList<>();
            if (si.bearing != null) bes.add(si.bearing);
            if (si.onCell != null) bes.add(si.onCell);
            if (si.hoToday > 0) bes.add("×" + si.hoToday);
            String pci = null;
            while (!bes.isEmpty()) {
                String cand = String.join(" · ", bes);
                if (tw(nm, 18, semi) + tw(" · " + cand, 18 * 0.85f, semi) <= bw) { pci = cand; break; }
                bes.remove(bes.size() - 1);
            }
            java.util.List<String> rest = new java.util.ArrayList<>();
            if (si.bearing != null && (pci == null || !pci.contains(si.bearing))) rest.add(si.bearing);
            if (si.onCell != null && (pci == null || !pci.contains(si.onCell))) rest.add(si.onCell);
            if (si.hoToday > 0 && (pci == null || !pci.contains("×" + si.hoToday))) rest.add("×" + si.hoToday);
            float szP = 23;
            if (pci != null) while (szP > 18 && tw(nm, szP, semi) + tw(" · " + pci, szP * 0.85f, semi) > bw) szP -= 0.5f;
            if (pci != null && !towerBelow && tw(nm, szP, semi) + tw(" · " + pci, szP * 0.85f, semi) <= bw) {
                // short name: "~Ravet · ↗NE · 3m" on one line
                float wN = tw(nm, szP, semi), wP = tw(" · " + pci, szP * 0.85f, semi);
                float x0 = cx(bx, bw, wN + wP), cy = top + 3 + szP * 0.5f;
                text(c, nm, x0, cy, szP, semi, col);
                text(c, " · " + pci, x0 + wN, cy, szP * 0.85f, semi, grey());
                yEnd = top + 3 + szP;
                pciDone = true;
            } else {
                if (pci == null && (si.bearing != null || si.onCell != null || si.hoToday > 0)) towerAnyBelow = true;
                yEnd = drawAreaName(c, nm, bx, bw, top, col);
            }
            // whatever room is left below: channel, tracking area, data used today
            if (!pciDone) {   // nothing went beside the name: everything goes below
                rest.clear();
                if (si.bearing != null) rest.add(si.bearing);
                if (si.onCell != null) rest.add(si.onCell);
                if (si.hoToday > 0) rest.add("×" + si.hoToday);
            }
            float used = yEnd;
            try { used = Math.max(used, cellExtras(c, si, fullBx, fullBw, yEnd, rest)); } catch (Throwable ignored) { }
            if (q4Open && used < y(P4) - 13) q4End = colX[i] + colW[i];
            else q4Open = false;
        }
    }

    /** The area name under a box: one line (smaller if long), two balanced lines, or cut with "…". Returns its bottom. */
    private float drawAreaName(Canvas c, String nm, float bx, float bw, float top, int col) {
        float sz = 23;   // same top size as the one-line form beside the name, so both SIMs match
        while (sz > 15 && tw(nm, sz, semi) > bw) sz -= 0.5f;
        if (tw(nm, sz, semi) <= bw) {
            text(c, nm, cx(bx, bw, tw(nm, sz, semi)), top + 3 + sz * 0.5f, sz, semi, col);
            return top + 3 + sz;
        }
        String[] two = split2(nm);
        if (two != null) {
            float s2 = 23;
            while (s2 > 12 && Math.max(tw(two[0], s2, semi), tw(two[1], s2, semi)) > bw) s2 -= 1;
            if (Math.max(tw(two[0], s2, semi), tw(two[1], s2, semi)) <= bw) {
                float l1 = top + 3 + s2 * 0.5f, l2 = l1 + s2 * 1.1f;
                text(c, two[0], cx(bx, bw, tw(two[0], s2, semi)), l1, s2, semi, col);
                text(c, two[1], cx(bx, bw, tw(two[1], s2, semi)), l2, s2, semi, col);
                return l2 + s2 * 0.5f;
            }
        }
        sz = 20;
        while (sz > 12 && tw(nm, sz, semi) > bw) sz -= 1;
        String t = nm;
        while (t.length() > 3 && tw(t, sz, semi) > bw) t = t.substring(0, t.length() - 2) + "…";
        text(c, t, cx(bx, bw, tw(t, sz, semi)), top + 3 + sz * 0.5f, sz, semi, col);
        return top + 3 + sz;
    }

    /**
     * Cell details in the space left under a SIM box, one line if there's room: (PCI when it didn't fit beside
     * the name) · channel · TAC · data today. Items drop from the end until the line fits; nothing if no room.
     */
    private float cellExtras(Canvas c, SimInfo si, float bx, float bw, float yTop, java.util.List<String> lead) {
        java.util.List<String> parts = new java.util.ArrayList<>(lead);
        if (si.dataToday >= 0) parts.add(si.dataToday < 1_000_000_000L
                ? String.format(java.util.Locale.US, "%.0fM", si.dataToday / 1e6)
                : String.format(java.util.Locale.US, "%.1fG", si.dataToday / 1e9));
        float bottom = y(204);
        while (!parts.isEmpty()) {
            String line = String.join(" · ", parts);
            float sz = 17;
            while (sz > 13.5f && tw(line, sz, semi) > bw) sz -= 0.5f;
            if (yTop + 2 + sz > bottom) return yTop;            // no room under this box
            if (tw(line, sz, semi) <= bw) {
                text(c, line, bx + (bw - tw(line, sz, semi)) / 2f, yTop + 2 + sz * 0.5f, sz, semi, grey());
                return yTop + 2 + sz;
            }
            parts.remove(parts.size() - 1);
        }
        return yTop;
    }

    /** "Pimpri Chinchwad" -> {"Pimpri", "Chinchwad"}; null when there is no space to split at. */
    private static String[] split2(String s) {
        String[] w = s.trim().split("\\s+");
        if (w.length < 2) {
            int h = s.indexOf('-');
            return h > 0 && h < s.length() - 1 ? new String[]{s.substring(0, h + 1), s.substring(h + 1)} : null;
        }
        String[] best = null;
        for (int k = 1; k < w.length; k++) {
            String a = String.join(" ", java.util.Arrays.copyOfRange(w, 0, k));
            String b = String.join(" ", java.util.Arrays.copyOfRange(w, k, w.length));
            if (best == null || Math.abs(a.length() - b.length()) < Math.abs(best[0].length() - best[1].length())) best = new String[]{a, b};
        }
        return best;
    }

    /**
     * Tide on row 3 after the AQI pill. Richest form that fits wins, and the place name is kept as long as
     * possible by dropping the wave icon and height first:
     * "≈ ↑ +1.4m H 22:14 Alibag" → "≈↑ H22:14 Alibag" → "↑H22:14 Alibag" → "≈↑ +1.4m H22:14" → "↑H22:14".
     */
    /** Gap between weather items: the normal one when it fits, smaller (down to 1, touching) when space is short. */
    private float tightGap(List<Item> items, float x, float maxX, float normal) {
        if (items.size() < 2) return normal;
        float sum = 0;
        for (Item it : items) sum += it.w();
        float g = (maxX - x - sum) / (items.size() - 1);
        return Math.max(1f, Math.min(normal, g));
    }

    /** Width of the smallest tide form ("↑H22:14"), 0 when there's no tide to show. */
    private float tideMinW(boolean withName) {
        Tide.Now t;
        if (!Cfg.b(Cfg.TIDE, Cfg.D_TIDE) || (t = Tide.now(System.currentTimeMillis())) == null) return 0;
        Item it = new Item(1, 25).t("↑", 24, bold, color).t("H", 18, semi, color).t("22:14", 23, bold, color);
        if (withName && t.place != null) it.sp(5).t(t.place, 18, semi, color);
        return it.w() + 1;
    }

    /** Sea temperature at the tide place, right after the tide; drawn only at full size. */
    private float proSea(Canvas c, float x0, float x1) {
        float st = Tide.seaTemp(System.currentTimeMillis());
        if (Float.isNaN(st)) return x0 - 14;
        int col = st < 24 ? blue() : st < 28 ? teal() : st < 30 ? yellow() : orange();
        Item it = new Item(1, 25).t("🌊", 21, bold, col).sp(3).t(Math.round(st) + "°", 25, bold, col);   // wave emoji + temperature
        if (x0 + it.w() > x1) return x0 - 14;
        return drawItem(c, it, x0, y(P3));
    }

    /** Width (with the 14 px gap before it) of the sea temperature + smallest coast-distance form; 0 when there is none. */
    private float seaDistW() {
        try {
            float st = Tide.seaTemp(System.currentTimeMillis());
            if (Float.isNaN(st)) return 0;
            double[] n = Tide.nearest(fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
            String dist = n[1] < 1 ? "~" + Math.round(n[1] * 10) * 100 + "m" : "~" + Math.round(n[1]) + "km";
            return 14 + new Item(1, 25).t("🌊", 21, bold, grey()).sp(3).t(Math.round(st) + "°", 25, bold, grey())
                    .sp(3).t(dist, 14, semi, grey()).w() - 10;
        } catch (Throwable e) { return 0; }
    }

    private float proTide(Canvas c, float x0, float x1) {
        if (!Cfg.b(Cfg.TIDE, Cfg.D_TIDE) || x1 - x0 < 40) return 0;
        Tide.Now t = Tide.now(System.currentTimeMillis());
        if (t == null) return 0;
        int ac = t.rising ? blue() : teal();
        long nowT = System.currentTimeMillis();
        long minsTo = (t.nextAt - nowT) / 60000L;
        boolean soon = minsTo >= 0 && minsTo <= 60;
        int hc = soon ? orange() : t.spring ? SysViews.amber(dk) : color;
        String arrow = t.rising ? "↑" : "↓";
        String hl = t.nextHigh ? "H" : "L";
        String tm = new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new java.util.Date(t.nextAt));
        String ht = String.format(Locale.US, "%+.1f", t.height);
        String pl = t.place == null ? "" : t.place;
        Item[] v0 = {
                new Item(1, 25).g(G_WAVE, 22, ac).t(arrow, 24, bold, ac).sp(5).t(hl, 19, semi, grey()).t(tm, 24, bold, hc)
                        .sp(6).t(pl, 19, semi, grey()),
                new Item(1, 25).t(arrow, 24, bold, ac).t(hl, 18, semi, grey()).t(tm, 23, bold, hc).sp(5).t(pl, 18, semi, grey()),
                new Item(1, 25).t(arrow, 22, bold, ac).t(hl, 16, semi, grey()).t(tm, 21, bold, hc).sp(3).t(pl, 15, semi, grey()),
                new Item(1, 25).t(arrow, 24, bold, ac).t(hl, 18, semi, grey()).t(tm, 23, bold, hc),
        };
        Item[] v = v0;
        if (soon) {
            String in = "in " + minsTo + "m";
            Item[] w = new Item[v0.length + 3];
            Item nm2 = new Item(1, 25).t(arrow, 24, bold, ac).t(hl, 18, semi, grey()).t(tm, 23, bold, hc).sp(5).t(minsTo + "m", 18, semi, hc)
                    .sp(5).t(pl, 18, semi, grey());
            w[0] = new Item(1, 25).t(arrow, 24, bold, ac).t(hl, 18, semi, grey()).t(tm, 23, bold, hc).sp(5).t(in, 18, semi, hc)
                    .sp(5).t(pl, 18, semi, grey());
            w[1] = nm2;
            w[2] = new Item(1, 25).t(arrow, 24, bold, ac).t(hl, 18, semi, grey()).t(tm, 23, bold, hc).sp(5).t(in, 18, semi, hc);
            System.arraycopy(v0, 0, w, 3, v0.length);
            v = w;
        }
        // keep room for the coast distance beside the sea temperature when a form of the tide allows it
        float reserve = 0;
        if (reserve > 0) for (Item it : v) {
            if (x0 + it.w() + reserve <= x1) return drawItem(c, it, x0, y(P3));
        }
        for (Item it : v) {
            if (x0 + it.w() <= x1) return drawItem(c, it, x0, y(P3));
        }
        return 0;
    }

    /** Colour emoji for an OmniJaws (Yahoo) condition code; null = keep the ROM's own icon. */
    private static String weatherEmoji(int code) {
        switch (code) {
            case 32: case 34: case 36: return "☀️";
            case 31: case 33: return "🌙";
            case 30: return "⛅";
            case 28: return "🌥️";
            case 26: case 27: case 29: return "☁️";
            case 19: case 20: case 21: case 22: return "🌫️";
            case 23: case 24: return "💨";
            case 25: return "🥶";
            case 5: case 6: case 8: case 9: case 10: case 11: case 12: case 35: case 39: case 40: case 45: return "🌧️";
            case 3: case 4: case 37: case 38: case 47: return "⛈️";
            case 0: return "🌪️";
            case 1: case 2: return "🌀";
            case 7: case 13: case 14: case 15: case 16: case 41: case 42: case 46: return "❄️";
            case 17: case 18: case 43: return "🌨️";
            default: return null;
        }
    }

    /** The weather in the bottom-left: row 3 icon, temperature, rain, UV, AQI pill; row 4 visibility, high/low, humidity, wind. */
    private void proWeatherLeft(Canvas c, float x3, float x4, float maxX4, float maxX3) {
        float maxX = Math.min(maxX4, maxX3);   // row 3 stops before the battery health under the camera
        if (wxTemp == null) return;
        float x = x3;
        String wxEmoji = wxCode >= 0 ? weatherEmoji(wxCode) : null;
        if (wxEmoji != null) {
            drawItem(c, new Item(1, 25).t(wxEmoji, 33, bold, color), x, y(P3));
            x += 42;
        } else if (wxIcon != null) {
            try {
                wxIcon.setBounds(Math.round(x), Math.round(y(P3) - 18), Math.round(x + 36), Math.round(y(P3) + 18));
                if (wxTint) wxIcon.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                else wxIcon.clearColorFilter();
                wxIcon.draw(c);
            } catch (Throwable ignored) { }
            x += 42;
        }
        String a = wxAqi >= 0 ? String.valueOf(wxAqi) : null;   // coloured pill, number only (colour = level)
        float pw = a == null ? 0 : tw(a, 22, bold) + 22;
        List<Item> l3 = new ArrayList<>();
        l3.add(new Item(10, 38).t(wxTemp + "°", 38, bold, color));
        // today's high / low right beside the temperature (it used to sit on row 4)
        if (!Float.isNaN(wxMax) && !Float.isNaN(wxMin)) {
            l3.add(new Item(3, 22).t("↑", 15, bold, orange()).t(String.valueOf(Math.round(wxMax)), 19, bold, color)
                    .sp(3).t("↓", 15, bold, blue()).t(String.valueOf(Math.round(wxMin)), 19, bold, color));
        }
        if (!Float.isNaN(wxUv)) {
            int uv = Math.round(wxUv);
            int uc = uv < 3 ? green() : uv < 6 ? yellow() : uv < 8 ? orange() : red();
            l3.add(new Item(4, 26).t("UV", 19, semi, grey()).sp(5).t(String.valueOf(uv), 25, bold, uv == 0 ? grey() : uc));
        }
        // gaps shrink (down to touching) before anything drops, leaving the smallest tide form room after AQI
        // prefer room for the tide with its place name ("↓L21:23 Murud"); only if the weather can't fit even with
        // touching items does the tide fall back to its bare form
        float sum3 = 0;
        for (Item it : l3) sum3 += it.w();
        float wxMinW = x + sum3 + Math.max(0, l3.size() - 1) + (pw > 0 ? pw + 1 : 0);
        float tideMin = tideMinW(true);
        if (tideMin > 0 && wxMinW + tideMin + 6 > maxX) tideMin = tideMinW(false);
        float g3 = tightGap(l3, x, maxX - (pw > 0 ? pw + 12 : 0) - (tideMin > 0 ? tideMin + 6 : 0), 10);
        float e = drawLine(c, l3, x, y(P3), maxX - (pw > 0 ? pw + g3 : 0), g3);
        if (a != null && e + g3 + pw <= maxX) {
            int ac = wxAqi <= 50 ? 0xFF2E9E4F : wxAqi <= 100 ? 0xFFC9A400 : wxAqi <= 150 ? 0xFFE07B1A
                    : wxAqi <= 200 ? 0xFFD93A2B : wxAqi <= 300 ? 0xFF8E3FB5 : 0xFF7A1F2B;
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(ac);
            rf.set(e + g3, y(P3) - 17, e + g3 + pw, y(P3) + 17);
            c.drawRoundRect(rf, 17, 17, gp);
            textB(c, a, e + g3 + 11, y(P3), 22, 22, bold, 0xFFFFFFFF);
            e += g3 + pw;
        }
        row3End = e;
        try { row3End = Math.max(e, proTide(c, e + (pw > 0 || g3 < 6 ? 6 : g3), maxX)); } catch (Throwable ignored) { }
        try { if (row3End > e) row3End = proSea(c, row3End + 14, Math.max(maxX, wxEnd)); } catch (Throwable ignored) { }

        List<Item> l4 = new ArrayList<>();
        if (!Float.isNaN(wxVis) || wxCloud >= 0 || wxRain >= 0) {
            Item vc = new Item(3, 25);
            if (!Float.isNaN(wxVis)) {
                String v = wxVis >= 10000 ? Math.round(wxVis / 1000f) + "" : wxVis >= 1000
                        ? String.format(Locale.US, "%.1f", wxVis / 1000f) : String.valueOf(Math.round(wxVis));
                String u = wxVis >= 1000 ? "" : "m";   // the eye icon already says visibility; km is the norm, only metres get a unit
                int col = wxVis >= 5000 ? color : wxVis >= 2000 ? yellow() : orange();
                vc.g(G_EYE, 22, grey()).sp(4).t(v, 25, bold, col).t(u, 17, semi, grey());
            }
            if (!Float.isNaN(wxVis) && wxCloud >= 0) vc.sp(5).t("·", 18, bold, grey()).sp(5);
            if (wxCloud >= 0) vc.g(G_CLOUD, 24, grey()).sp(4).t(wxCloud + "%", 25, bold, wxCloud == 0 ? grey() : color);
            // rain chance sits with the cloud cover: both say "will it be wet"
            if (wxRain >= 0) {
                if (wxCloud >= 0) vc.sp(3).t("/", 20, semi, grey()).sp(3);
                else if (!Float.isNaN(wxVis)) vc.sp(7);
                vc.g(G_UMB, 21, blue()).sp(3).t(wxRain + "%", 25, bold, wxRain == 0 ? grey() : color);
            }
            l4.add(vc);
        }
        if (wxHum >= 0) l4.add(new Item(6, 25).g(G_DROP, 20, teal()).sp(5).t(wxHum + "%", 25, bold, color));
        if (!Float.isNaN(wxWind)) {
            l4.add(new Item(5, 25).t(wxArrow == null ? "" : wxArrow, 24, bold, grey()).sp(4)
                    .t(String.valueOf(Math.round(wxWind)), 25, bold, color));   // the arrow already says wind
        }
        // rough distance to the tide place (the one picked in settings, else the nearest coast), after the wind
        try {
            if (!Float.isNaN(Tide.seaTemp(System.currentTimeMillis()))) {
                double[] n = Tide.nearest(fix != null ? fix[0] : latLon[0], fix != null ? fix[1] : latLon[1]);
                String dist = n[1] < 1 ? "~" + Math.round(n[1] * 10) * 100 + "m" : "~" + Math.round(n[1]) + "km";
                l4.add(new Item(2, 25).t("🏖️", 21, bold, color).sp(3).t(dist, 22, bold, color));
            }
        } catch (Throwable ignored) { }
        l4End = drawLine(c, l4, x4, y(P4), maxX4, tightGap(l4, x4, maxX4, 10));
    }
}
