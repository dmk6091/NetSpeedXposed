package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Settings app: adds "Volume steps" to the Sound page, under the media volume slider.
 * It saves the numbers in a system setting that the Volume Steps Magisk module copies into its
 * config; they apply after a reboot.
 */
final class SettingsVolume {
    private static final String TAG = "NetSpeedXposed: [volsteps] ";
    private static final String KEY = "netspeed_vol_steps";
    private static final String GLOBAL = "netspeed_volume_steps";
    private static boolean logged;

    private static final String[] LABELS = {"Media", "Calls", "Ringtone", "Alarm", "Notification", "System sounds"};
    private static final String[] CODES = {"m", "c", "r", "a", "n", "s"};
    private static final int[] STREAMS = {AudioManager.STREAM_MUSIC, AudioManager.STREAM_VOICE_CALL,
            AudioManager.STREAM_RING, AudioManager.STREAM_ALARM, AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_SYSTEM};

    private SettingsVolume() {}

    static void install(final ClassLoader cl) {
        try {
            Class<?> fragment = XposedHelpers.findClass("androidx.fragment.app.Fragment", cl);
            XposedHelpers.findAndHookMethod(fragment, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        String n = p.thisObject.getClass().getName();
                        if (n.contains("SoundSettings")) inject(p.thisObject, cl);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "inject failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "hooked");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "install failed: " + t);
        }
    }

    private static void inject(final Object frag, ClassLoader cl) throws Throwable {
        Object screen = XposedHelpers.callMethod(frag, "getPreferenceScreen");
        if (screen == null) return;
        if (XposedHelpers.callMethod(screen, "findPreference", KEY) != null) return;
        if (!logged) {
            logged = true;
            StringBuilder sb = new StringBuilder("Sound page: ");
            try {
                int c = (Integer) XposedHelpers.callMethod(screen, "getPreferenceCount");
                for (int i = 0; i < c; i++) {
                    Object pr = XposedHelpers.callMethod(screen, "getPreference", i);
                    sb.append(XposedHelpers.callMethod(pr, "getKey")).append('/')
                            .append(XposedHelpers.callMethod(pr, "getOrder")).append(' ');
                }
            } catch (Throwable ignored) { }
            XposedBridge.log(TAG + sb);
        }
        final Context ctx = (Context) XposedHelpers.callMethod(frag, "getContext");
        Class<?> prefC = XposedHelpers.findClass("androidx.preference.Preference", cl);
        Object pref = prefC.getConstructor(Context.class).newInstance(ctx);
        XposedHelpers.callMethod(pref, "setKey", KEY);
        XposedHelpers.callMethod(pref, "setTitle", (CharSequence) "Volume steps");
        XposedHelpers.callMethod(pref, "setSummary", (CharSequence) summary(ctx));
        Object media = XposedHelpers.callMethod(screen, "findPreference", "media_volume");
        Object parent = screen;
        if (media != null) {
            try {
                Object icon = XposedHelpers.callMethod(media, "getIcon");
                if (icon != null) XposedHelpers.callMethod(pref, "setIcon", icon);
            } catch (Throwable ignored) { }
            Object par = XposedHelpers.callMethod(media, "getParent");
            if (par != null) parent = par;
            XposedHelpers.callMethod(pref, "setOrder", (Integer) XposedHelpers.callMethod(media, "getOrder") + 1);
        }
        Class<?> li = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceClickListener", cl);
        Object listener = Proxy.newProxyInstance(cl, new Class<?>[]{li}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method m, Object[] a) {
                if (m.getName().equals("onPreferenceClick")) {
                    try {
                        show((Activity) XposedHelpers.callMethod(frag, "getActivity"));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "dialog failed: " + t);
                    }
                    return Boolean.TRUE;
                }
                return null;
            }
        });
        XposedHelpers.callMethod(pref, "setOnPreferenceClickListener", listener);
        XposedHelpers.callMethod(parent, "addPreference", pref);
        XposedBridge.log(TAG + "row added (media_volume " + (media != null ? "found" : "missing") + ")");
    }

    private static int[] current(Context ctx) {
        int[] v = new int[6];
        AudioManager am = ctx.getSystemService(AudioManager.class);
        for (int i = 0; i < 6; i++) v[i] = am.getStreamMaxVolume(STREAMS[i]);
        String g = Settings.Global.getString(ctx.getContentResolver(), GLOBAL);
        if (g != null) {
            for (String kv : g.split(";")) {
                String[] p = kv.split("=");
                if (p.length != 2) continue;
                for (int i = 0; i < 6; i++) if (CODES[i].equals(p[0])) {
                    try { v[i] = Integer.parseInt(p[1]); } catch (NumberFormatException ignored) { }
                }
            }
        }
        return v;
    }

    private static String summary(Context ctx) {
        try {
            int[] v = current(ctx);
            return "Media " + v[0] + " levels · calls " + v[1] + " · ring " + v[2];
        } catch (Throwable t) {
            return "Levels per volume slider";
        }
    }

    private static void show(final Activity act) {
        if (act == null) return;
        final int[] cur = current(act);
        float d = act.getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Math.round(24 * d), Math.round(8 * d), Math.round(24 * d), 0);
        TextView hint = new TextView(act);
        hint.setText("Levels per volume slider (3 to 150). More levels = finer control and a quieter lowest step. Applies after a reboot.");
        hint.setTextSize(14);
        hint.setPadding(0, 0, 0, Math.round(8 * d));
        box.addView(hint);
        final EditText[] edits = new EditText[6];
        for (int i = 0; i < 6; i++) {
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView l = new TextView(act);
            l.setText(LABELS[i]);
            l.setTextSize(16);
            row.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            EditText e = new EditText(act);
            e.setInputType(InputType.TYPE_CLASS_NUMBER);
            e.setText(String.valueOf(cur[i]));
            e.setGravity(Gravity.CENTER);
            e.setMinWidth(Math.round(80 * d));
            e.setSelectAllOnFocus(true);
            edits[i] = e;
            row.addView(e);
            box.addView(row);
        }
        final DialogInterface.OnClickListener save = null;
        AlertDialog.Builder b = new AlertDialog.Builder(act);
        b.setTitle("Volume steps").setView(box)
                .setNegativeButton(android.R.string.cancel, null)
                .setNeutralButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) { save(act, edits, false); }
                })
                .setPositiveButton("Save and reboot", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) { save(act, edits, true); }
                });
        b.show();
    }

    private static void save(Activity act, EditText[] edits, boolean reboot) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            int v;
            try { v = Integer.parseInt(edits[i].getText().toString().trim()); } catch (NumberFormatException e) { v = -1; }
            if (v < 3 || v > 150) {
                Toast.makeText(act, LABELS[i] + ": use 3 to 150", Toast.LENGTH_LONG).show();
                return;
            }
            if (sb.length() > 0) sb.append(';');
            sb.append(CODES[i]).append('=').append(v);
        }
        try {
            ContentResolver cr = act.getContentResolver();
            Settings.Global.putString(cr, GLOBAL, sb.toString());
            XposedBridge.log(TAG + "saved " + sb);
        } catch (Throwable t) {
            Toast.makeText(act, "Couldn't save: " + t.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        if (reboot) {
            Toast.makeText(act, "Rebooting in 4 s...", Toast.LENGTH_SHORT).show();
            final Context app = act.getApplicationContext();
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() {
                    try { app.getSystemService(PowerManager.class).reboot(null); }
                    catch (Throwable t) { Toast.makeText(app, "Reboot by hand to apply", Toast.LENGTH_LONG).show(); }
                }
            }, 4000);
        } else {
            Toast.makeText(act, "Saved. Reboot to apply.", Toast.LENGTH_LONG).show();
        }
    }
}
