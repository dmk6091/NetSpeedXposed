package com.netspeed.xposed;

/**
 * Double tap on the back of the phone, from the accelerometer (and gyroscope).
 *
 * Why this exists: a plain "z-axis jolt above a threshold" rule also fires when the phone is put
 * down on a table (the table hits the back exactly like a finger would). So a knock only counts
 * when all of this holds:
 * <ul>
 *   <li>it is a sharp, short, mostly front/back jolt (not a shake, a footstep or a sideways nudge);</li>
 *   <li>the phone was calm for the half second before the first knock (nobody is carrying or
 *       lowering it) - this is what rejects "just placing the phone";</li>
 *   <li>the phone is not lying flat on its back (you cannot knock on the back of a phone that
 *       lies on it) and the first knock is not too hard (a drop or a bang);</li>
 *   <li>optionally, the jolt comes from the back, not from the screen (typing);</li>
 *   <li>the second knock follows after 110 - 460 ms, of similar strength and the same direction
 *       (a bounce is quicker and fades);</li>
 *   <li>nothing else knocks for the next 170 ms (typing, walking, shaking).</li>
 * </ul>
 * No Android dependencies: it is fed samples, so the same code runs in System UI and in the test screen.
 * Call it from one thread only.
 */
final class BackTapDetector {

    interface Listener {
        /** A confirmed double tap. */
        void onDoubleTap();

        /** What the detector decided, in words (test screen / log). Only called while {@link #verbose}. */
        void onLog(String line);

        /** A sharp knock was found (peak m/s², sign +1 = from the back, -1 = from the screen), accepted or not. */
        void onKnock(float peak, int sign);
    }

    // ---- settings (may be changed from another thread)
    volatile float thr = 2.0f;          // m/s²: smallest knock
    volatile int dirSign = 0;           // +1 only back knocks, -1 only screen knocks, 0 either
    volatile boolean ignoreFlat = true; // ignore while lying flat, face up
    volatile boolean verbose = false;
    /** Only report knocks (for calibration), no gesture logic. */
    volatile boolean calibrating = false;
    volatile Listener listener;

    // ---- constants
    private static final double SPIKE_MS = 60;        // a knock is judged over this long
    private static final double DEAD_MS = 50;         // ring-down after a knock, ignored
    private static final double QUIET_FROM = 500, QUIET_TO = 100; // calm period before the first knock (ms before it)
    private static final double GAP_MIN = 110, GAP_MAX = 460;     // first onset -> second onset
    private static final double CONFIRM_MS = 170;     // nothing else may knock this long after the pair
    private static final double COOLDOWN_MS = 1500;
    private static final double WIDTH_MAX_MS = 130;   // a knock is short (the Poco F7 rings ~60-120 ms after a real tap)
    private static final float TAIL_MAX = 0.9f;       // and has faded below 90% of its peak 30 ms after the peak
    private static final float Z_DOM = 1.0f;          // front/back part >= sideways part
    private static final float FLAT_COS = 0.975f;     // within ~13° of lying flat
    private static final float GYRO_MAX = 0.4f;       // rad/s average before the first knock

    // ---- filters
    private boolean init;
    private double lastT;
    private double lx, ly, lz;   // fast low-pass (the high-pass is signal - this)
    private double gx, gy, gz;   // slow low-pass = gravity

    // ---- ring buffers
    private static final int N = 512;
    private final double[] rt = new double[N];
    private final float[] rz = new float[N], rxy = new float[N], rm2 = new float[N];
    private int rh, rn;
    private static final int GN = 256;
    private final double[] gt = new double[GN];
    private final float[] gm = new float[GN];
    private int gh, gc;

    // ---- state machine
    private static final int IDLE = 0, WAIT2 = 1, CONFIRM = 2;
    private int state = IDLE;
    private boolean inSpike;
    private double spStart, deadUntil, cooldownUntil, t1, confirmAt;
    private int spSign, sign1;
    private float spQuiet, spGyro, p1, p2;
    private double t2;

    /** Forget everything (sensors were off for a while). */
    void reset() {
        init = false;
        rh = rn = gh = gc = 0;
        state = IDLE;
        inSpike = false;
        deadUntil = cooldownUntil = 0;
    }

    void configure(float thr, int dirSign, boolean ignoreFlat) {
        this.thr = thr;
        this.dirSign = dirSign;
        this.ignoreFlat = ignoreFlat;
    }

    /** Sensitivity 1..12 -> smallest knock in m/s² (1 = hard knocks only, 12 = very light taps). */
    static float thrForSens(int s) {
        s = Math.max(1, Math.min(12, s));
        return (float) (6.5 * Math.exp(-0.22 * (s - 1)));
    }

    static int sensForThr(float thr) {
        int s = (int) Math.round(1 + Math.log(6.5 / Math.max(0.3, thr)) / 0.22);
        return Math.max(1, Math.min(12, s));
    }

    private volatile float maxSince;

    /** The biggest high-passed jolt since the last call (for the test screen's meter). */
    float takeMax() {
        float v = maxSince;
        maxSince = 0;
        return v;
    }

    private void log(String s) {
        Listener l = listener;
        if (verbose && l != null) l.onLog(s);
    }

    // ------------------------------------------------------------------ input

    void onGyro(long tNs, float x, float y, float z) {
        double t = tNs / 1.0e6;
        gt[gh] = t;
        gm[gh] = (float) Math.sqrt(x * x + y * y + z * z);
        gh = (gh + 1) % GN;
        if (gc < GN) gc++;
    }

    void onAccel(long tNs, float x, float y, float z) {
        double t = tNs / 1.0e6;
        if (!init) {
            lx = gx = x;
            ly = gy = y;
            lz = gz = z;
            lastT = t;
            init = true;
            return;
        }
        double dt = (t - lastT) / 1000.0;
        if (dt <= 0) return;
        if (dt > 0.25) { // sensors were paused
            reset();
            onAccel(tNs, x, y, z);
            return;
        }
        lastT = t;
        double kf = dt / (0.04 + dt), kg = dt / (0.6 + dt);
        lx += (x - lx) * kf;
        ly += (y - ly) * kf;
        lz += (z - lz) * kf;
        gx += (x - gx) * kg;
        gy += (y - gy) * kg;
        gz += (z - gz) * kg;
        float hx = (float) (x - lx), hy = (float) (y - ly), hz = (float) (z - lz);
        float hxy = (float) Math.sqrt(hx * hx + hy * hy);
        float az = Math.abs(hz);
        if (az > maxSince) maxSince = az;
        rt[rh] = t;
        rz[rh] = hz;
        rxy[rh] = hxy;
        rm2[rh] = hx * hx + hy * hy + hz * hz;
        rh = (rh + 1) % N;
        if (rn < N) rn++;
        step(t, hz);
    }

    // ------------------------------------------------------------------ logic

    private void step(double t, float hz) {
        if (t < cooldownUntil) {
            inSpike = false;
            return;
        }
        if (inSpike) {
            if (t - spStart >= SPIKE_MS) finishSpike();
            return;
        }
        if (state == CONFIRM && t >= confirmAt) {
            fire(t);
            return;
        }
        if (state == WAIT2 && t - t1 > GAP_MAX + SPIKE_MS) {
            state = IDLE;
            log("no second tap");
        }
        if (t < deadUntil) return;
        if (Math.abs(hz) >= thr) {
            inSpike = true;
            spStart = t;
            spSign = hz > 0 ? 1 : -1;
            spQuiet = quietRms(t);
            spGyro = gyroMean(t);
        }
    }

    private void fire(double t) {
        state = IDLE;
        cooldownUntil = t + COOLDOWN_MS;
        if (ignoreFlat && flat()) {
            log("rejected at the end: lying flat");
            return;
        }
        log("DOUBLE TAP");
        Listener l = listener;
        if (l != null) l.onDoubleTap();
    }

    /** True when the phone lies on its back (screen up) within ~13°. */
    private boolean flat() {
        double g = Math.sqrt(gx * gx + gy * gy + gz * gz);
        return g > 5 && gz / g > FLAT_COS;
    }

    private void finishSpike() {
        inSpike = false;
        final double t0 = spStart;
        deadUntil = t0 + SPIKE_MS + DEAD_MS;

        float peak = 0, peakXY = 0;
        double tPeak = t0;
        for (int i = 0; i < rn; i++) {
            int k = (rh - 1 - i + N) % N;
            if (rt[k] < t0) break;
            float a = Math.abs(rz[k]);
            if (a > peak) { peak = a; tPeak = rt[k]; }
            if (rxy[k] > peakXY) peakXY = rxy[k];
        }
        double first50 = -1, last50 = -1;
        float tail = 0;
        float half = 0.5f * peak;
        for (int i = rn - 1; i >= 0; i--) { // oldest -> newest
            int k = (rh - 1 - i + N) % N;
            if (rt[k] < t0) continue;
            float a = Math.abs(rz[k]);

            if (a >= half) {
                if (first50 < 0) first50 = rt[k];
                last50 = rt[k];
            }
            // measured from the peak, not from the first crossing: on this phone a tap builds up over
            // 20-40 ms, so "35 ms after the crossing" was often still the peak itself
            if (rt[k] - tPeak >= 30 && a > tail) tail = a;
        }
        double width = first50 < 0 ? 0 : last50 - first50;
        boolean sharp = width <= WIDTH_MAX_MS && tail <= TAIL_MAX * peak;
        boolean zdom = peak >= Z_DOM * peakXY;
        int sign = spSign; // direction of the first sample over the threshold = the push
        String dir = sign > 0 ? "back" : "screen";

        if (state == CONFIRM) {
            double since2 = t0 - t2;
            if (since2 < GAP_MIN || peak < 0.5f * p2 || !sharp || !zdom) {
                log(String.format("echo of tap 2 ignored (%.1f, %d ms after)", peak, Math.round(since2)));
                return;
            }
            log(String.format("rejected: a third knock %.1f follows (typing / walking / shaking)", peak));
            state = IDLE;
            cooldownUntil = t0 + 700;
            return;
        }
        if (!sharp || !zdom) {
            if (state == WAIT2) {
                // a weak or sideways bump while waiting for tap 2 (the first tap ringing): keep waiting
                log(String.format("bump ignored while waiting for tap 2 (%s, %.1f)", !sharp ? "long / soft" : "sideways", peak));
                return;
            }
            log(String.format("ignored %.1f: %s (%d ms, tail %.0f%%)", peak, !sharp ? "long / soft knock" : "sideways nudge", Math.round(width), 100 * tail / Math.max(0.01f, peak)));
            return;
        }
        Listener l = listener;
        if (l != null) l.onKnock(peak, sign);
        if (calibrating) return;

        float pMax = Math.max(thr * 8f, 40f);
        boolean rejectedByDir = dirSign != 0 && sign != dirSign;

        if (state == WAIT2) {
            double gap = t0 - t1;
            float ratio = peak / Math.max(0.01f, p1);
            if (gap < GAP_MIN || (gap <= GAP_MAX && ratio < 0.4f)) {
                // the first tap still ringing, or a small echo of it: not a new tap, keep waiting
                log(String.format("echo of tap 1 ignored (%.1f, %d ms after)", peak, Math.round(gap)));
                return;
            }
            if (gap <= GAP_MAX) {
                if (ratio < 0.4f || ratio > 2.5f || peak > pMax) {
                    log(String.format("rejected: second knock %.1f vs first %.1f - uneven", peak, p1));
                    state = IDLE;
                    return;
                }
                log(String.format("tap 2 ok %.1f (%d ms after)", peak, Math.round(gap)));
                state = CONFIRM;
                t2 = t0;
                p2 = peak;
                // a third knock in the same rhythm would come one gap later: wait for it
                confirmAt = t0 + Math.max(SPIKE_MS + CONFIRM_MS, gap + 40);
                return;
            }
            // too late: this one may start a new pair
            state = IDLE;
        }

        // first knock
        float qMax = Math.min(Math.max(0.35f * thr, 0.25f), 0.45f);
        if (peak > pMax) {
            log(String.format("rejected %.1f: too hard (knock / drop)", peak));
        } else if (spQuiet > qMax) {
            log(String.format("rejected %.1f: phone was moving before (%.2f > %.2f)", peak, spQuiet, qMax));
        } else if (spGyro > GYRO_MAX) {
            log(String.format("rejected %.1f: phone was turning before (%.2f rad/s)", peak, spGyro));
        } else if (ignoreFlat && flat()) {
            log(String.format("rejected %.1f: lying flat on its back", peak));
        } else if (rejectedByDir) {
            log(String.format("rejected %.1f: knock from the %s side", peak, dir));
        } else {
            log(String.format("tap 1 ok %.1f from the %s (calm %.2f, %d ms)", peak, dir, spQuiet, Math.round(width)));
            state = WAIT2;
            t1 = t0;
            p1 = peak;
            sign1 = sign;
        }
    }

    /** RMS of the high-passed motion between QUIET_FROM and QUIET_TO ms before t. Small = phone was calm. */
    private float quietRms(double t) {
        double sum = 0;
        int n = 0;
        for (int i = 0; i < rn; i++) {
            int k = (rh - 1 - i + N) % N;
            double age = t - rt[k];
            if (age > QUIET_FROM) break;
            if (age < QUIET_TO) continue;
            sum += rm2[k];
            n++;
        }
        if (n < 8) return 0; // not enough history yet: no objection
        return (float) Math.sqrt(sum / n);
    }

    private float gyroMean(double t) {
        double sum = 0;
        int n = 0;
        for (int i = 0; i < gc; i++) {
            int k = (gh - 1 - i + GN) % GN;
            double age = t - gt[k];
            if (age > QUIET_FROM) break;
            if (age < QUIET_TO) continue;
            sum += gm[k];
            n++;
        }
        return n < 3 ? 0 : (float) (sum / n);
    }
}
