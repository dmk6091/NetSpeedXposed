package com.netspeed.xposed;

import java.util.Locale;

/** Builds the feed for the app's Info tab (runs in System UI): lines "S|label|value", S = A astronomy, E earth, D disasters. */
final class Info {
    private Info() {}

    private static void add(StringBuilder b, char s, String label, String v) {
        if (v == null) return;
        v = v.replace('\n', ' ').replace('|', '/').trim();
        if (v.isEmpty() || v.equals("-")) return;
        b.append(s).append('|').append(label).append('|').append(v).append('\n');
    }

    static String feed(double lat, double lon, long now) {
        StringBuilder b = new StringBuilder();
        try { for (String[] p : SkyStrip.infoLines(now)) add(b, 'A', p[0], p[1]); } catch (Throwable ignored) { }
        try { add(b, 'A', "Overhead now", Sat.issText); } catch (Throwable ignored) { }
        try { add(b, 'E', "River flow", RiverFlow.text()); } catch (Throwable ignored) { }
        try { add(b, 'E', "Dam / weir", EarthLine.dam); } catch (Throwable ignored) { }
        try { add(b, 'E', "Rain", EarthLine.rain); } catch (Throwable ignored) { }
        try {
            String soil = EarthLine.soilType == null ? "" : EarthLine.soilType;
            if (!soil.isEmpty()) {
                String x = soil + (EarthLine.soilSplit == null || EarthLine.soilSplit.isEmpty() ? "" : " · " + EarthLine.soilSplit)
                        + (EarthLine.soilMoist == null || EarthLine.soilMoist.isEmpty() ? "" : " · " + EarthLine.soilMoist);
                add(b, 'E', "Soil", x);
            }
        } catch (Throwable ignored) { }
        try {
            Tide.Now t = Tide.now(now);
            if (t != null) {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", Locale.US);
                add(b, 'E', "Tide " + (t.place == null ? "" : t.place), String.format(Locale.US, "%.1f m, %s; next %s %.1f m at %s", t.height,
                        t.rising ? "rising" : "falling", t.nextHigh ? "high" : "low", t.nextHeight, f.format(new java.util.Date(t.nextAt))));
            }
        } catch (Throwable ignored) { }
        try { add(b, 'E', "Lookups for the status bar", "beach: " + Tide.beachWhy + " \u00b7 wetland: " + Wetland.why); } catch (Throwable ignored) { }
        try {
            java.util.List<String> ws = Watershed.chains(Watershed.riverName(RiverFlow.text()));
            if (!ws.isEmpty()) add(b, 'E', "Where the water goes", ws.get(0).replace("\uD83D\uDCA7 ", ""));
        } catch (Throwable ignored) { }
        try {
            double[] bp = Tide.beachPt(lat, lon);
            if (bp != null && Tide.beachName != null)
                add(b, 'E', "Nearest beach", Tide.beachName + " \u00b7 " + Math.round(Beach.km(lat, lon, bp[0], bp[1])) + " km " + Beach.dir(lat, lon, bp[0], bp[1]) + " (straight line)");
        } catch (Throwable ignored) { }
        try { if (!EarthLine.rockType.isEmpty()) add(b, 'E', "Rock", EarthLine.rockType + (EarthLine.rockUnit.isEmpty() ? "" : " \u00b7 " + EarthLine.rockUnit) + (EarthLine.rockAge.isEmpty() ? "" : " \u00b7 " + EarthLine.rockAge)); } catch (Throwable ignored) { }
        try { add(b, 'E', "Power", EarthLine.powerLine + (EarthLine.powerSub == null || EarthLine.powerSub.isEmpty() ? "" : " · " + EarthLine.powerSub)); } catch (Throwable ignored) { }
        try { add(b, 'E', "Terrain", EarthLine.slope); } catch (Throwable ignored) { }
        try { add(b, 'E', "Highest point nearby", EarthLine.peak); } catch (Throwable ignored) { }
        try { add(b, 'E', "Ground", EarthLine.ground); } catch (Throwable ignored) { }
        try { add(b, 'E', "District", EarthLine.district); } catch (Throwable ignored) { }
        try { add(b, 'D', "Earthquakes", EarthLine.quake); } catch (Throwable ignored) { }
        try {
            int n = 0;
            for (Hazards.Ev e : Hazards.events) {
                if (n++ >= 4) break;
                add(b, 'D', (e.red ? "🔴 " : "🟠 ") + Hazards.icon(e.type) + " " + (e.name == null ? "" : e.name),
                        (e.place == null ? "" : e.place) + (e.km >= 0 ? " · " + e.km + " km " + (e.dir == null ? "" : e.dir) : ""));
            }
        } catch (Throwable ignored) { }
        try { if (!Float.isNaN(Hazards.kp)) add(b, 'D', "Geomagnetic Kp", String.format(Locale.US, "%.0f%s", Hazards.kp, Hazards.kp >= 5 ? " (storm)" : " (quiet)")); } catch (Throwable ignored) { }
        try { strips(b, lat, lon, now); } catch (Throwable ignored) { }
        return b.toString();
    }

    /** One line per strip of the place line ("Ravet \u00b7 ..."): does it have data right now, and if not, why. Lines "S|label|state". */
    private static void strip(StringBuilder b, String label, boolean on, String val, String why) {
        String v = !on ? "\u23F8 off in settings" : val != null && !val.trim().isEmpty() ? "\u2705 " + val.trim() : "\u26A0\uFE0F no data" + (why == null || why.isEmpty() ? "" : " \u00b7 " + why);
        b.append("S|").append(label).append('|').append(v.replace('\n', ' ').replace('|', '/')).append('\n');
    }

    private static void strips(StringBuilder b, double lat, double lon, long now) {
        try { strip(b, "River flow", Cfg.b(Cfg.RIVER, Cfg.D_RIVER), RiverFlow.text(), RiverFlow.why); } catch (Throwable t) { strip(b, "River flow", true, "", t.toString()); }
        try {
            java.util.List<String> ws = Watershed.chains(Watershed.riverName(RiverFlow.text()));
            strip(b, "Where the river goes", Cfg.b(Cfg.RIVER, Cfg.D_RIVER), ws.isEmpty() ? "" : ws.get(0), "river has no name yet, or is not in the river table");
        } catch (Throwable ignored) { }
        try { strip(b, "Dam / weir nearby", Cfg.b(Cfg.RIVER, Cfg.D_RIVER), EarthLine.dam, "none within the search radius, or the lookup failed"); } catch (Throwable ignored) { }
        try {
            Dam.Reading dg = Dam.curRead;
            boolean fresh = dg != null && Dam.cur != null && System.currentTimeMillis() - Dam.fetchedAt < 3 * 86400_000L;
            strip(b, "Reservoir level", Cfg.b(Cfg.DAM, Cfg.D_DAM), fresh ? Dam.cur.name + " " + Math.round(dg.pct) + "% full" : "", Dam.lastError);
        } catch (Throwable ignored) { }
        try { strip(b, "Rain", Cfg.b(Cfg.EL_RAIN, Cfg.D_EL_RAIN), EarthLine.rain, EarthLine.why); } catch (Throwable ignored) { }
        try { strip(b, "Soil", Cfg.b(Cfg.EL_SOIL, Cfg.D_EL_SOIL), EarthLine.soilType, "SoilGrids has no data here or was slow"); } catch (Throwable ignored) { }
        try { strip(b, "Rock", Cfg.b(Cfg.EL_ROCK, Cfg.D_EL_ROCK), EarthLine.rockType, "Macrostrat has no unit here or was slow"); } catch (Throwable ignored) { }
        try { strip(b, "Power line / substation", Cfg.b(Cfg.EL_POWER, Cfg.D_EL_POWER), EarthLine.powerLine, "none mapped within the radius, or lookup failed"); } catch (Throwable ignored) { }
        try { strip(b, "Highest point / land", Cfg.b(Cfg.EL_LAND, Cfg.D_EL_LAND), EarthLine.peak, "no named peak found nearby"); } catch (Throwable ignored) { }
        try { strip(b, "Earthquakes", Cfg.b(Cfg.EL_QUAKE, Cfg.D_EL_QUAKE), EarthLine.quake, "not fetched yet"); } catch (Throwable ignored) { }
        try { strip(b, "District / place", Cfg.b(Cfg.EL_EARTH, Cfg.D_EL_EARTH), EarthLine.district, "no district name yet"); } catch (Throwable ignored) { }
        try {
            java.util.List<Faults.Hit> fh = Faults.nearest(lat, lon, 1);
            double lim = Cfg.i(Cfg.FAULT_KM, Cfg.D_FAULT_KM);
            strip(b, "Fault lines", Cfg.b(Cfg.FAULT, Cfg.D_FAULT), !fh.isEmpty() ? Faults.text(fh.get(0)) + (fh.get(0).km > lim ? " (beyond your " + Math.round(lim) + " km limit, shown as 'none within')" : "") : "", "fault data not loaded");
        } catch (Throwable ignored) { }
        try {
            Wetland.Hit w = Wetland.wetland;
            strip(b, "Wetland / lake", Cfg.b(Cfg.EL_WETLAND, Cfg.D_EL_WETLAND), w == null ? "" : w.text(), Wetland.why);
            Wetland.Hit rs = Wetland.ramsar;
            strip(b, "Ramsar site", Cfg.b(Cfg.EL_WETLAND, Cfg.D_EL_WETLAND), rs != null && rs.km <= 200 ? rs.text() : "", rs == null ? "no Ramsar site matched in OpenStreetMap (normal for most places)" : "nearest is over 200 km away");
        } catch (Throwable ignored) { }
        try {
            Tide.Now t = Tide.now(now);
            strip(b, "Tide", Cfg.b(Cfg.TIDE, Cfg.D_TIDE), t == null ? "" : (t.place == null ? "" : t.place + " ") + String.format(Locale.US, "%.1f m", t.height), "marine model has no data for the nearest coast yet");
            strip(b, "Sea distance (nearest beach)", Cfg.b(Cfg.TIDE, Cfg.D_TIDE), Tide.beachName == null ? "" : Tide.beachName + " " + Math.round(Tide.seaKm(lat, lon)) + " km", Tide.beachWhy);
        } catch (Throwable ignored) { }
    }
}
