package com.netspeed.xposed;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

import java.util.Map;

/** Read-only view of the module's settings, so System UI can read them. */
public class SettingsProvider extends ContentProvider {
    static final String PREFS = "settings";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        MatrixCursor c = new MatrixCursor(new String[]{"key", "value"});
        SharedPreferences sp = getContext().getSharedPreferences(PREFS, 0);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            c.addRow(new Object[]{e.getKey(), String.valueOf(e.getValue())});
        }
        return c;
    }

    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues v) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
