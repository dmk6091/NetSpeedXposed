package com.netspeed.xposed;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.TrafficStats;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Adds a small two-line network speed indicator (download / upload)
 * to the status bar, just before the system icons.
 */
public class Hook implements IXposedHookLoadPackage {

    private static final String TAG = "NetSpeedXposed: ";
    private static final String SYSTEMUI = "com.android.systemui";

    /** How often the speed is refreshed, in milliseconds. */
    private static final long INTERVAL_MS = 1000;


    /** Below this speed (bytes per second) the connection counts as idle. */
    private static final long IDLE_BPS = 1024;

    /** How long the connection must stay idle before the indicator hides. */
    private static final long IDLE_HIDE_MS = 10_000;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if ("android".equals(lp.packageName)) {
            // System framework: makes apps start below the taller status bar.
            DualRow.hookHeight("framework");
            NavImmersive.install("framework");
            return;
        }
        if (!SYSTEMUI.equals(lp.packageName)) return;
        NavImmersive.install("systemui");

        // Load settings as soon as System UI's Application exists (before the status bar is built).
        try {
            XposedHelpers.findAndHookMethod(android.app.Instrumentation.class, "callApplicationOnCreate",
                    android.app.Application.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                Cfg.init((Context) p.args[0]);
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + "settings init failed: " + t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "settings hook failed: " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.systemui.statusbar.phone.PhoneStatusBarView",
                    lp.classLoader,
                    "onFinishInflate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                attach((ViewGroup) param.thisObject);
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + "attach failed: " + t);
                            }
                        }
                    });
            XposedBridge.log(TAG + "hooked SystemUI");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook failed: " + t);
        }

        // Show more notification icons before the "•" overflow dot.
        NotifIconLimit.install(lp.classLoader);

        // Two-row status bar with temperatures and weather.
        DualRow.install(lp.classLoader);
    }

    /** Finds a place in the status bar and adds the speed view there. */
    private void attach(ViewGroup bar) {
        Context ctx = bar.getContext();
        Resources res = bar.getResources();
        Cfg.init(ctx);

        // Don't add twice if the status bar is re-inflated.
        if (bar.findViewWithTag("netspeed_xposed") != null) return;

        // Different Android versions/ROMs name the right-side container differently,
        // so try a few known ids.
        View anchor = null;
        for (String name : new String[]{"system_icons", "statusIcons", "system_icon_area"}) {
            int id = res.getIdentifier(name, "id", SYSTEMUI);
            if (id != 0) {
                anchor = bar.findViewById(id);
                if (anchor != null) break;
            }
        }
        if (anchor == null || !(anchor.getParent() instanceof ViewGroup)) {
            XposedBridge.log(TAG + "no status bar container found");
            return;
        }
        ViewGroup parent = (ViewGroup) anchor.getParent();

        // Clock view, used to copy its colour so we match light/dark status bar.
        int clockId = res.getIdentifier("clock", "id", SYSTEMUI);
        final View clock = clockId != 0 ? bar.findViewById(clockId) : null;

        final TextView tv = new TextView(ctx);
        tv.setTag("netspeed_xposed");
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setMaxLines(2);
        tv.setLineSpacing(0, 0.85f);
        tv.setIncludeFontPadding(false);
        tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        int pad = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 4, res.getDisplayMetrics());
        tv.setPadding(pad, 0, pad, 0);
        // Fixed width, so changing numbers don't push the icons around.
        tv.setMinWidth((int) Math.ceil(tv.getPaint().measureText("↓999K/s")) + pad * 2);
        tv.setText("↓0B/s\n↑0B/s");
        tv.setVisibility(Cfg.b(Cfg.HIDE_IDLE, Cfg.D_HIDE_IDLE) ? View.GONE : View.VISIBLE);

        ViewGroup.LayoutParams lp;
        if (parent instanceof LinearLayout) {
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            llp.gravity = Gravity.CENTER_VERTICAL;
            lp = llp;
        } else {
            lp = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        parent.addView(tv, parent.indexOfChild(anchor), lp);

        startUpdates(tv, clock);
        XposedBridge.log(TAG + "indicator added");
    }

    /** Sets the text size in sp, only when it actually changed (avoids extra layouts). */
    static void setSp(TextView tv, int sp) {
        if (tv == null || sp <= 0) return;
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp,
                tv.getResources().getDisplayMetrics());
        if (Math.abs(tv.getTextSize() - px) > 0.5f) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
    }

    /** Use the clock's font (the one picked in Wallpaper & style). Small text gets the bold weight of that font. */
    static void matchClockFont(View clock, TextView tv, boolean bold) {
        if (!(clock instanceof TextView) || tv == null) return;
        Typeface base = ((TextView) clock).getTypeface();
        if (base == null) return;
        Typeface tf = bold ? Typeface.create(base, Typeface.BOLD) : base;
        if (tv.getTypeface() != tf) tv.setTypeface(tf);
    }

    private void startUpdates(final TextView tv, final View clock) {
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            long lastRx = TrafficStats.getTotalRxBytes();
            long lastTx = TrafficStats.getTotalTxBytes();
            long lastTime = SystemClock.elapsedRealtime();
            long lastActive = 0;

            @Override
            public void run() {
                try {
                    long rx = TrafficStats.getTotalRxBytes();
                    long tx = TrafficStats.getTotalTxBytes();
                    long now = SystemClock.elapsedRealtime();
                    long dt = Math.max(1, now - lastTime);

                    long down = Math.max(0, (rx - lastRx) * 1000 / dt);
                    long up = Math.max(0, (tx - lastTx) * 1000 / dt);
                    lastRx = rx;
                    lastTx = tx;
                    lastTime = now;

                    boolean active = down >= IDLE_BPS || up >= IDLE_BPS;
                    if (active) lastActive = now;

                    if (Cfg.b(Cfg.HIDE_IDLE, Cfg.D_HIDE_IDLE) && !active && now - lastActive > IDLE_HIDE_MS) {
                        if (tv.getVisibility() != View.GONE) tv.setVisibility(View.GONE);
                    } else {
                        if (clock instanceof TextView) {
                            tv.setTextColor(((TextView) clock).getCurrentTextColor());
                            matchClockFont(clock, tv, Cfg.b(Cfg.BOLD, Cfg.D_BOLD));
                            setSp(tv, Cfg.i(Cfg.SPEED_SP, Cfg.D_SPEED_SP));
                        }
                        // Two rows:
                        //   ↓9.9K/s
                        //   ↑1.2K/s
                        tv.setText("↓" + format(down) + "\n↑" + format(up));
                        if (tv.getVisibility() != View.VISIBLE) tv.setVisibility(View.VISIBLE);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "update failed: " + t);
                }
                handler.postDelayed(this, INTERVAL_MS);
            }
        });
    }

    /** 850 -> "850B/s", 12500 -> "12K/s", 1530000 -> "1.5M/s" */
    private static String format(long bps) {
        if (bps < 1024) return bps + "B/s";
        double kb = bps / 1024.0;
        if (kb < 100) return String.format(Locale.US, "%.1fK/s", kb);
        if (kb < 1024) return String.format(Locale.US, "%.0fK/s", kb);
        double mb = kb / 1024.0;
        if (mb < 100) return String.format(Locale.US, "%.1fM/s", mb);
        return String.format(Locale.US, "%.0fM/s", mb);
    }
}
