package com.netspeed.xposed;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * NetSpeed's own QR scanner: opened by the double tap (also over the lock screen). A scanned UPI
 * link is handed to the payment app chosen in settings.
 */
public class ScanActivity extends Activity {
    private TextureView tv;
    private TextView hint;
    private CameraDevice cam;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler bg;
    private volatile boolean done;
    private long lastFrame;
    private final MultiFormatReader qr = new MultiFormatReader();
    private Size size;
    private String camId;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Collections.singletonList(BarcodeFormat.QR_CODE));
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        qr.setHints(hints);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        tv = new TextureView(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        hint = new TextView(this);
        hint.setTextColor(0xFFFFFFFF);
        hint.setTextSize(20);
        hint.setGravity(Gravity.CENTER);
        hint.setBackgroundColor(0x99000000);
        hint.setPadding(32, 32, 32, 48);
        String label = SettingsProvider.prefs(this).getString(Cfg.BT_LABEL, "");
        int ar = label.indexOf("→");
        hint.setText("Point at the QR code" + (ar >= 0 ? "\nPays with " + label.substring(ar + 1).trim() : ""));
        root.addView(hint, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        done = false;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            hint.setText("Camera permission is missing.\nOpen NetSpeed settings > Double tap on back and pick "
                    + "the scanner again.");
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
            return;
        }
        ht = new HandlerThread("netspeed-scan");
        ht.start();
        bg = new Handler(ht.getLooper());
        if (tv.isAvailable()) openCamera();
        else tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { openCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) recreate();
    }

    @Override
    protected void onPause() {
        closeCamera();
        super.onPause();
    }

    private void closeCamera() {
        try {
            if (session != null) session.close();
        } catch (Throwable ignored) { }
        try {
            if (cam != null) cam.close();
        } catch (Throwable ignored) { }
        try {
            if (reader != null) reader.close();
        } catch (Throwable ignored) { }
        session = null;
        cam = null;
        reader = null;
        if (ht != null) {
            ht.quitSafely();
            ht = null;
        }
    }

    private void openCamera() {
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            camId = null;
            for (String id : cm.getCameraIdList()) {
                Integer f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == CameraCharacteristics.LENS_FACING_BACK) {
                    camId = id;
                    break;
                }
            }
            if (camId == null) {
                hint.setText("No back camera found");
                return;
            }
            StreamConfigurationMap map = cm.getCameraCharacteristics(camId)
                    .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size[] yuv = map.getOutputSizes(ImageFormat.YUV_420_888);
            Size[] prev = map.getOutputSizes(SurfaceTexture.class);
            size = null;
            long bestScore = -1;
            for (Size y : yuv) {
                if (y.getWidth() > 1600 || y.getHeight() > 1200 || y.getWidth() < 640) continue;
                boolean ok = false;
                for (Size p : prev) if (p.equals(y)) ok = true;
                if (!ok) continue;
                boolean r43 = Math.abs(y.getWidth() * 3 - y.getHeight() * 4) < 8;
                long score = (r43 ? 10_000_000L : 0) + (long) y.getWidth() * y.getHeight();
                if (score > bestScore) {
                    bestScore = score;
                    size = y;
                }
            }
            if (size == null) size = yuv[yuv.length - 1];
            // Portrait phone, sensor turned 90 degrees: the picture is height x width on screen.
            int sw = getResources().getDisplayMetrics().widthPixels;
            int vh = sw * size.getWidth() / size.getHeight();
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(sw, vh, Gravity.CENTER);
            tv.setLayoutParams(lp);
            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.YUV_420_888, 2);
            reader.setOnImageAvailableListener(this::onFrame, bg);
            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    cam = d;
                    startPreview();
                }

                @Override
                public void onDisconnected(CameraDevice d) {
                    d.close();
                }

                @Override
                public void onError(CameraDevice d, int e) {
                    d.close();
                    runOnUiThread(() -> hint.setText("Camera error " + e));
                }
            }, bg);
        } catch (SecurityException | CameraAccessException e) {
            hint.setText("Camera not available: " + e.getMessage());
        }
    }

    private void startPreview() {
        try {
            SurfaceTexture st = tv.getSurfaceTexture();
            st.setDefaultBufferSize(size.getWidth(), size.getHeight());
            Surface ps = new Surface(st);
            Surface rs = reader.getSurface();
            final CaptureRequest.Builder rb = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            rb.addTarget(ps);
            rb.addTarget(rs);
            rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            List<Surface> out = new ArrayList<>();
            out.add(ps);
            out.add(rs);
            cam.createCaptureSession(out, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    try {
                        s.setRepeatingRequest(rb.build(), null, bg);
                    } catch (Throwable ignored) { }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession s) {
                    runOnUiThread(() -> hint.setText("Camera could not start"));
                }
            }, bg);
        } catch (Throwable t) {
            runOnUiThread(() -> hint.setText("Camera could not start: " + t.getMessage()));
        }
    }

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || done) return;
            long now = System.currentTimeMillis();
            if (now - lastFrame < 100) return;
            lastFrame = now;
            int w = img.getWidth(), h = img.getHeight();
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rs = pl.getRowStride();
            byte[] data = new byte[w * h];
            for (int y = 0; y < h; y++) {
                buf.position(y * rs);
                buf.get(data, y * w, w);
            }
            LuminanceSource src = new PlanarYUVLuminanceSource(data, w, h, 0, 0, w, h, false);
            String text = decode(src);
            if (text == null) text = decode(src.invert());
            if (text != null && !done) {
                done = true;
                final String t = text;
                runOnUiThread(() -> handle(t));
            }
        } catch (Throwable ignored) {
        } finally {
            if (img != null) img.close();
        }
    }

    private String decode(LuminanceSource src) {
        try {
            Result res = qr.decodeWithState(new BinaryBitmap(new HybridBinarizer(src)));
            return res.getText();
        } catch (Throwable e) {
            return null;
        } finally {
            qr.reset();
        }
    }

    private void handle(String text) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK));
        } catch (Throwable ignored) { }
        String pkg = SettingsProvider.prefs(this).getString(Cfg.BT_PKG, "");
        if (text.toLowerCase().startsWith("upi:")) {
            Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse(text));
            try {
                if (!pkg.isEmpty()) in.setPackage(pkg);
                startActivity(in);
            } catch (ActivityNotFoundException e) {
                try {
                    in.setPackage(null);
                    startActivity(Intent.createChooser(in, "Pay with"));
                } catch (Throwable t) {
                    hint.setText("No app could open this payment link");
                    done = false;
                    return;
                }
            }
            finish();
            return;
        }
        hint.setText("That QR isn't a UPI payment code:\n" + (text.length() > 120 ? text.substring(0, 120) + "…" : text)
                + "\n\nKeep scanning, or press back.");
        done = false;
    }
}
