package com.netspeed.xposed;

import android.content.Context;
import android.content.Intent;

/**
 * Starts a scanner and (when root is available) checks that the app really came to the front,
 * because "startActivity didn't throw" doesn't mean a screen appeared. Blocking: call it off the
 * main thread.
 */
final class ScanLaunch {

    static final class Result {
        boolean ok;
        boolean viaRoot;
        boolean verified;
        String report = "";
    }

    private ScanLaunch() { }

    static Result launch(Context c, String uri, String pkg, boolean tryDirect) {
        Result r = new Result();
        StringBuilder rep = new StringBuilder();
        if (tryDirect) {
            boolean started = false;
            try {
                Intent in = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                c.startActivity(in);
                started = true;
                rep.append("1. normal start: accepted\n");
            } catch (Throwable t) {
                rep.append("1. normal start: ").append(t.getClass().getSimpleName()).append(": ")
                        .append(shorten(t.getMessage())).append('\n');
            }
            if (started) {
                int v = waitFocus(pkg, 4000);
                if (v != 0) {
                    r.ok = true;
                    r.verified = v == 1;
                    rep.append(v == 1 ? "   the app is on screen\n" : "   (can't check without root)\n");
                    r.report = rep.toString();
                    return r;
                }
                rep.append("   but the app did not come to the front\n");
            }
        }
        ScanFinder.Out o = ScanFinder.rootStartOut(uri);
        rep.append(tryDirect ? "2. " : "1. ").append("start with root: ").append(o.ok ? "accepted" : "failed")
                .append('\n');
        if (!o.text.isEmpty()) rep.append("   ").append(shorten(o.text)).append('\n');
        if (o.ok) {
            int v = waitFocus(pkg, 4000);
            if (v != 0) {
                r.ok = true;
                r.viaRoot = true;
                r.verified = v == 1;
                rep.append(v == 1 ? "   the app is on screen\n" : "   (can't check)\n");
            } else {
                rep.append("   but the app did not come to the front\n");
            }
        }
        r.report = rep.toString();
        return r;
    }

    /** Root only: open the app, wait for it, then tap its Scan button (a few tries). */
    static Result launchAuto(String uri, String pkg) {
        Result r = new Result();
        r.viaRoot = true;
        StringBuilder rep = new StringBuilder();
        ScanFinder.Out o = ScanFinder.rootStartOut(uri);
        rep.append("1. open the app with root: ").append(o.ok ? "accepted" : "failed").append('\n');
        if (!o.text.isEmpty()) rep.append("   ").append(shorten(o.text)).append('\n');
        if (!o.ok) {
            r.report = rep.toString();
            return r;
        }
        int v = waitFocus(pkg, 6000);
        if (v == 0) {
            rep.append("   but the app did not come to the front\n");
            r.report = rep.toString();
            return r;
        }
        // Banking apps ask for a fingerprint / PIN first: keep looking for up to 30 s, so the tap
        // happens right after you unlock.
        long end = System.currentTimeMillis() + 30000;
        int tries = 0;
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ignored) { }
        while (System.currentTimeMillis() < end) {
            tries++;
            String tapped = ScanFinder.tapScan();
            if (tapped != null) {
                rep.append("2. tapped ").append(tapped).append('\n');
                r.ok = true;
                r.verified = true;
                r.report = rep.toString();
                return r;
            }
            try {
                Thread.sleep(1200);
            } catch (InterruptedException ignored) { }
        }
        rep.append("2. no Scan / QR button appeared in 30 s (").append(tries).append(" looks)\n   ")
                .append(shorten(ScanFinder.lastDump)).append('\n');
        r.report = rep.toString();
        return r;
    }

    /** 1 = the app has focus, 0 = it never got it, -1 = can't tell (no root). */
    private static int waitFocus(String pkg, long maxMs) {
        long end = System.currentTimeMillis() + maxMs;
        boolean any = false;
        while (true) {
            String f = ScanFinder.focus();
            if (f == null) return -1;
            any = true;
            if (f.contains(pkg)) return 1;
            if (System.currentTimeMillis() >= end) break;
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                break;
            }
        }
        return any ? 0 : -1;
    }

    static String shorten(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').trim();
        return s.length() > 260 ? s.substring(0, 260) + "…" : s;
    }
}
