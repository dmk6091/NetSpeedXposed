package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Setup screen for "double press the power button": on/off and what to open (a home-screen shortcut,
 * NetSpeed's own QR scanner or an app's own shortcut), with a test launch and System UI's status.
 */
public class BackTapActivity extends Activity {
    private static final Uri URI = Uri.parse("content://com.netspeed.xposed.settings/all");

    private SharedPreferences sp;
    private LinearLayout list;
    private int fg, sub, card, accent, good, warn;
    private boolean dark;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView targetView, statusView;
    private AppRow lastApp;
    private List<ScanFinder.Cand> lastCands;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = SettingsProvider.prefs(this);
        dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bg = dark ? 0xFF1B1B1F : 0xFFF6F5FA;
        card = dark ? 0xFF2A2A30 : 0xFFFFFFFF;
        fg = dark ? 0xFFE6E1E9 : 0xFF1C1B1F;
        sub = dark ? 0xFF9A96A3 : 0xFF6A6672;
        accent = dark ? 0xFFC9BFFF : 0xFF5B4DB0;
        good = dark ? 0xFF34C759 : 0xFF1E8E3E;
        warn = dark ? 0xFFFFB84D : 0xFFB36B00;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        list.setPadding(p, p, p, p);
        scroll.addView(list);
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(0, sys.top, 0, sys.bottom);
            return in;
        });
        setContentView(scroll);
        if (!dark) {
            try {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light, light);
                }
            } catch (Throwable ignored) { }
        }
        build();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        if (statusView != null) statusView.setText(BtStatus.read(this));
    }

    private void build() {
        list.removeAllViews();
        TextView t = text("Double press power", 26, fg);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(4), dp(8), 0, dp(4));
        list.addView(t);
        TextView n = text("Press the power button twice and the scanner you choose below opens - from the lock "
                + "screen or with the screen off too. It uses the phone's own double-press gesture, so switch "
                + "it on in Settings > System > Gestures > Quick open camera. The camera then no longer opens "
                + "on that gesture while this is on.", 14, sub);
        n.setPadding(dp(4), 0, dp(4), dp(8));
        list.addView(n);

        section("Gesture");
        LinearLayout c = card();
        toggle(c, "Double press power", "Opens the shortcut chosen below", Cfg.BT_ON, Cfg.D_BT_ON, on -> {
            if (on && sp.getString(Cfg.BT_PKG, "").isEmpty()) {
                Toast.makeText(this, "Choose the app first", Toast.LENGTH_SHORT).show();
            }
        });
        toggle(c, "Vibrate when it triggers", null, Cfg.BT_HAPTIC, Cfg.D_BT_HAPTIC, null);

        section("Opens");
        c = card();
        targetView = text("", 18, fg);
        targetView.setPadding(0, dp(12), 0, dp(4));
        c.addView(targetView);
        showTarget();
        c.addView(text("Put the payment app's scan shortcut on your home screen first (long-press the app icon, "
                + "then drag its Scan shortcut out). Then pick it here - a double tap starts exactly that "
                + "shortcut. Needs root to read the home screen.", 13, sub));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        button(row, "Pick from home screen", true, v -> chooseHome());
        button(row, "Test launch", false, v -> testLaunch());
        c.addView(row);
        row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(10));
        button(row, "Own scanner (any payment app)", false, v -> chooseOwn());
        c.addView(row);
        c.addView(text("For apps with no home-screen shortcut: a double tap opens NetSpeed's camera scanner. "
                + "Scan the shop's QR and it opens the payment app you choose, ready to pay.", 13, sub));
        row = new LinearLayout(this);
        row.setPadding(0, dp(6), 0, dp(10));
        button(row, "Or choose from an app's own shortcuts", false, v -> chooseApp());
        c.addView(row);

        section("What System UI is doing");
        c = card();
        c.addView(text("Reported by System UI - it shows what happened on a real double press, even though this "
                + "screen wasn't open.", 13, sub));
        statusView = text("", 13, fg);
        statusView.setTypeface(Typeface.MONOSPACE);
        statusView.setPadding(0, dp(10), 0, 0);
        c.addView(statusView);
        refreshStatus();
        row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        button(row, "Refresh", false, v -> refreshStatus());
        c.addView(row);
    }

    private void showTarget() {
        String label = sp.getString(Cfg.BT_LABEL, "");
        String pkg = sp.getString(Cfg.BT_PKG, "");
        if (pkg.isEmpty()) {
            targetView.setText("Nothing chosen yet");
            targetView.setTextColor(warn);
        } else {
            targetView.setText(label.isEmpty() ? pkg : label);
            targetView.setTextColor(fg);
        }
    }

    private static final String[] PAY_WORDS = {"pay", "upi", "bhim", "phonepe", "paytm", "cred", "wallet",
            "money", "bank", "paisa", "gpay", "navi", "mobikwik", "freecharge", "amazon"};

    private static final class AppRow {
        String pkg, label;
        ResolveInfo ri;
        boolean pay;
        android.graphics.drawable.Drawable icon;
    }

    private void chooseApp() {
        Toast.makeText(this, "Loading apps…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            Map<String, AppRow> map = new LinkedHashMap<>();
            for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || map.containsKey(pkg)) continue;
                AppRow r = new AppRow();
                r.pkg = pkg;
                r.ri = ri;
                r.label = String.valueOf(ri.loadLabel(pm));
                String low = (pkg + " " + r.label).toLowerCase(Locale.ROOT);
                for (String w : PAY_WORDS) {
                    if (low.contains(w)) {
                        r.pay = true;
                        break;
                    }
                }
                map.put(pkg, r);
            }
            List<AppRow> rows = new ArrayList<>(map.values());
            Collections.sort(rows, (a, b) -> a.pay != b.pay ? (a.pay ? -1 : 1) : a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> showApps(rows));
        }).start();
    }

    private void showApps(List<AppRow> all) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps");
        search.setTextColor(fg);
        search.setHintTextColor(sub);
        box.addView(search, new LinearLayout.LayoutParams(-1, -2));
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(420)));
        final List<AppRow> shown = new ArrayList<>(all);
        final PackageManager pm = getPackageManager();
        BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                AppRow r = shown.get(i);
                LinearLayout row = new LinearLayout(BackTapActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                ImageView iv = new ImageView(BackTapActivity.this);
                if (r.icon == null) r.icon = r.ri.loadIcon(pm);
                iv.setImageDrawable(r.icon);
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout tx = new LinearLayout(BackTapActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setPadding(dp(14), 0, 0, 0);
                tx.addView(text(r.label, 17, fg));
                if (r.pay) tx.addView(text("★ looks like a payment app", 12, accent));
                row.addView(tx);
                return row;
            }
        };
        lv.setAdapter(ad);
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                String q = e.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();
                for (AppRow r : all) {
                    if (q.isEmpty() || r.label.toLowerCase(Locale.ROOT).contains(q)
                            || r.pkg.toLowerCase(Locale.ROOT).contains(q)) shown.add(r);
                }
                ad.notifyDataSetChanged();
            }
        });
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Which payment app?")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            findFor(shown.get(i));
        });
        d.show();
    }

    private void findFor(AppRow app) {
        Toast.makeText(this, "Looking for the scanner in " + app.label + "…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            List<ScanFinder.Cand> cands = ScanFinder.find(this, app.pkg);
            runOnUiThread(() -> showCandidates(app, cands));
        }).start();
    }

    private void showCandidates(AppRow app, List<ScanFinder.Cand> cands) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(16), dp(4), dp(16), 0);
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(340)));
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return cands.size(); }
            @Override public Object getItem(int i) { return cands.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                ScanFinder.Cand c = cands.get(i);
                LinearLayout tx = new LinearLayout(BackTapActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setPadding(0, dp(10), 0, dp(10));
                TextView l = text(c.label, 17, fg);
                tx.addView(l);
                tx.addView(text((i == 0 && c.score >= 10 ? "★ most likely the scanner · " : "") + c.detail, 12,
                        i == 0 && c.score >= 10 ? accent : sub));
                return tx;
            }
        });
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Scanner in " + app.label)
                .setMessage("Tap one to use it. It opens right away, so you can check it is the scanner. "
                        + "If it isn't, pick another.")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lastApp = app;
        lastCands = cands;
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            pick(app, cands.get(i));
        });
        d.show();
    }

    private void pick(AppRow app, ScanFinder.Cand c) {
        Toast.makeText(this, "Opening it and checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ScanLaunch.Result r = ScanLaunch.launch(this, c.uri, app.pkg, true);
            if (r.ok) {
                save(app, c, r.viaRoot);
                runOnUiThread(() -> {
                    showTarget();
                    Toast.makeText(this, r.verified ? "Opened ✓ and saved"
                            : "Saved. Did the scanner open? If not, pick another.", Toast.LENGTH_LONG).show();
                });
            } else {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("That one didn't open")
                        .setMessage(r.report + "\nTry another entry in the list.")
                        .setPositiveButton("Pick another", (d, w) -> {
                            if (lastCands != null && lastApp != null) showCandidates(lastApp, lastCands);
                        })
                        .setNegativeButton("Use it anyway", (d, w) -> {
                            save(app, c, true);
                            showTarget();
                        })
                        .show());
            }
        }).start();
    }

    /** Payment apps that can take a UPI link: the scanner hands the scanned code to the one you pick. */
    private void chooseOwn() {
        final PackageManager pm = getPackageManager();
        Intent probe = new Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=test@upi&pn=test&am=1&cu=INR"));
        List<ResolveInfo> found = pm.queryIntentActivities(probe, 0);
        List<ResolveInfo> apps = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (ResolveInfo ri : found) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            if (seen.add(ri.activityInfo.packageName)) apps.add(ri);
        }
        if (apps.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("No payment apps found")
                    .setMessage("No installed app says it can open UPI payment links.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(16), dp(4), dp(16), 0);
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(340)));
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int i) { return apps.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                ResolveInfo ri = apps.get(i);
                LinearLayout row = new LinearLayout(BackTapActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                ImageView iv = new ImageView(BackTapActivity.this);
                iv.setImageDrawable(ri.loadIcon(pm));
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                TextView t = text(String.valueOf(ri.loadLabel(pm)), 17, fg);
                t.setPadding(dp(14), 0, 0, 0);
                row.addView(t);
                return row;
            }
        });
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Pay with which app?")
                .setMessage("After scanning, this app opens on the payment screen.")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            ResolveInfo ri = apps.get(i);
            String label = String.valueOf(ri.loadLabel(pm));
            sp.edit().putString(Cfg.BT_PKG, ri.activityInfo.packageName)
                    .putString(Cfg.BT_LABEL, "NetSpeed scanner  →  " + label)
                    .putString(Cfg.BT_SCID, "").putString(Cfg.BT_URI, "")
                    .putBoolean(Cfg.BT_ROOT, false).putBoolean(Cfg.BT_OWN, true).commit();
            changed();
            showTarget();
            if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                new Thread(() -> {
                    try {
                        ScanFinder.suOut("pm grant " + getPackageName() + " android.permission.CAMERA");
                    } catch (Throwable ignored) { }
                    runOnUiThread(() -> {
                        if (checkSelfPermission(android.Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 7);
                        }
                    });
                }).start();
            }
            Toast.makeText(this, "Saved. Press Test launch to try the scanner.", Toast.LENGTH_LONG).show();
        });
        d.show();
    }

    private void chooseHome() {
        Toast.makeText(this, "Reading your home screen…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            List<HomeShortcuts.Item> items = HomeShortcuts.read();
            String note = HomeShortcuts.note;
            runOnUiThread(() -> showHome(items, note));
        }).start();
    }

    private void showHome(List<HomeShortcuts.Item> items, String note) {
        if (items.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("No shortcuts found")
                    .setMessage("Nothing was found on your home screen.\n\nLong-press the payment app's icon, "
                            + "long-press its Scan shortcut and drop it on the home screen, then try again."
                            + (note.isEmpty() ? "" : "\n\n(" + note + ")")
                            + "\n\nWhat I saw: " + HomeShortcuts.diag)
                    .setPositiveButton("OK", null).show();
            return;
        }
        final PackageManager pm = getPackageManager();
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(16), dp(4), dp(16), 0);
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(340)));
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return items.size(); }
            @Override public Object getItem(int i) { return items.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                HomeShortcuts.Item it = items.get(i);
                LinearLayout row = new LinearLayout(BackTapActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                ImageView iv = new ImageView(BackTapActivity.this);
                try {
                    iv.setImageDrawable(pm.getApplicationIcon(it.pkg));
                } catch (Throwable ignored) { }
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout tx = new LinearLayout(BackTapActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setPadding(dp(14), 0, 0, 0);
                tx.addView(text(it.label, 17, fg));
                String app = it.pkg;
                try {
                    app = pm.getApplicationLabel(pm.getApplicationInfo(it.pkg, 0)).toString();
                } catch (Throwable ignored) { }
                tx.addView(text(app, 12, sub));
                row.addView(tx);
                return row;
            }
        });
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Your home screen shortcuts")
                .setMessage(note.isEmpty() ? null : note)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            HomeShortcuts.Item it = items.get(i);
            String app = it.pkg;
            try {
                app = pm.getApplicationLabel(pm.getApplicationInfo(it.pkg, 0)).toString();
            } catch (Throwable ignored) { }
            sp.edit().putString(Cfg.BT_PKG, it.pkg)
                    .putString(Cfg.BT_SCID, it.id == null ? "" : it.id)
                    .putString(Cfg.BT_URI, it.uri == null ? "" : it.uri)
                    .putString(Cfg.BT_LABEL, app + "  →  " + it.label)
                    .putBoolean(Cfg.BT_OWN, false)
                    .putBoolean(Cfg.BT_ROOT, it.id == null).commit();
            changed();
            showTarget();
            Toast.makeText(this, "Saved. Press Test launch to check it.", Toast.LENGTH_LONG).show();
        });
        d.show();
    }

    private void save(AppRow app, ScanFinder.Cand c, boolean viaRoot) {
        sp.edit().putString(Cfg.BT_PKG, app.pkg)
                .putString(Cfg.BT_URI, c.uri)
                .putString(Cfg.BT_LABEL, app.label + "  →  " + c.label)
                .putBoolean(Cfg.BT_ROOT, viaRoot)
                .putBoolean(Cfg.BT_OWN, false)
                .putString(Cfg.BT_SCID, "").commit();
        changed();
    }

    private void testLaunch() {
        String uri = sp.getString(Cfg.BT_URI, "");
        String pkg = sp.getString(Cfg.BT_PKG, "");
        if (pkg.isEmpty()) {
            Toast.makeText(this, "Choose the shortcut first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (sp.getBoolean(Cfg.BT_OWN, false)) {
            startActivity(new Intent(this, ScanActivity.class));
            return;
        }
        if (!sp.getString(Cfg.BT_SCID, "").isEmpty()) {
            // A home-screen shortcut is started by System UI (the same way a double tap does it).
            sp.edit().putInt(Cfg.BT_TESTREQ, (int) (System.currentTimeMillis() / 1000)).commit();
            changed();
            Toast.makeText(this, "Asked System UI to open it - give it a couple of seconds", Toast.LENGTH_LONG).show();
            ui.postDelayed(this::refreshStatus, 4000);
            return;
        }
        Toast.makeText(this, "Opening it and checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ScanLaunch.Result r = ScanLaunch.launch(this, uri, pkg, !sp.getBoolean(Cfg.BT_ROOT, false));
            runOnUiThread(() -> {
                if (r.ok) {
                    Toast.makeText(this, r.verified ? "Opened ✓" : "Started (couldn't check it is on screen)",
                            Toast.LENGTH_SHORT).show();
                } else {
                    new AlertDialog.Builder(this).setTitle("It didn't open").setMessage(r.report)
                            .setPositiveButton("OK", null).show();
                }
            });
        }).start();
    }

    // ------------------------------------------------------------------ widgets

    private interface OnToggle { void on(boolean on); }

    private void toggle(LinearLayout parent, String label, String desc, String key, boolean def, OnToggle cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            sp.edit().putBoolean(key, on).commit();
            changed();
            if (cb != null) cb.on(on);
        });
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    private void section(String t) {
        TextView v = text(t, 13, accent);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(18), 0, dp(8));
        list.addView(v);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        list.addView(c);
        return c;
    }

    private Button button(LinearLayout parent, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? (dark ? 0xFF2A1F66 : Color.WHITE) : accent);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        if (primary) g.setColor(accent);
        else {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(dp(1), accent);
        }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), primary ? 2f : 1f);
        lp.setMarginEnd(primary ? dp(10) : 0);
        parent.addView(b, lp);
        return b;
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    private void changed() {
        getContentResolver().notifyChange(URI, null);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
