package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Setup and test screen for "double tap on the back": on/off, which payment app's scanner to open,
 * sensitivity, a calibration (tap the back 6 times) and a live test that says why each knock was
 * accepted or rejected.
 */
public class BackTapActivity extends Activity implements BackTapDetector.Listener {
    private static final Uri URI = Uri.parse("content://com.netspeed.xposed.settings/all");
    private static final int CAL_TAPS = 6;

    private SharedPreferences sp;
    private LinearLayout list;
    private int fg, sub, card, accent, good, warn;
    private boolean dark;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView targetView, calibView, liveBig, liveLog, sensorView, statusView, joltView;
    private float hold;
    private long holdAt;
    private AppRow lastApp;
    private List<ScanFinder.Cand> lastCands;
    private Button testBtn, calBtn;

    private BackTapRunner runner;
    private boolean testing, calibrating;
    private long calibFrom;
    private final List<float[]> knocks = new ArrayList<>();
    private final List<String> logLines = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = SettingsProvider.prefs(this);
        dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bg = dark ? 0xFF1B1B1F : 0xFFF6F5FA;
        card = dark ? 0xFF2A2A30 : 0xFFFFFFFF;
        fg = dark ? 0xFFE6E1E9 : 0xFF1C1B1F;
        sub = dark ? 0xFF9A96A3 : 0xFF6A6672;
        accent = dark ? 0xFFC9BFFF : 0xFF5B4DB0;
        good = dark ? 0xFF34C759 : 0xFF1E8E3E;
        warn = dark ? 0xFFFFB84D : 0xFFB36B00;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        list.setPadding(p, p, p, p);
        scroll.addView(list);
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(0, sys.top, 0, sys.bottom);
            return in;
        });
        setContentView(scroll);
        if (!dark) {
            try {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light, light);
                }
            } catch (Throwable ignored) { }
        }
        build();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTest();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        if (statusView != null) statusView.setText(BtStatus.read(this));
    }

    private void build() {
        list.removeAllViews();
        TextView t = text("Double tap on back", 26, fg);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(dp(4), dp(8), 0, dp(4));
        list.addView(t);
        TextView n = text("Tap the back of the phone twice with a fingertip and a payment app's QR scanner opens. "
                + "It listens while the screen is on (lock screen included). Switch off the ROM's own back-tap "
                + "gesture first, otherwise both fire.", 14, sub);
        n.setPadding(dp(4), 0, dp(4), dp(8));
        list.addView(n);

        section("Gesture");
        LinearLayout c = card();
        toggle(c, "Double tap on back", "Opens the scanner chosen below", Cfg.BT_ON, Cfg.D_BT_ON, on -> {
            if (on && sp.getString(Cfg.BT_PKG, "").isEmpty()) {
                Toast.makeText(this, "Choose the app first", Toast.LENGTH_SHORT).show();
            }
        });
        toggle(c, "Vibrate when it triggers", null, Cfg.BT_HAPTIC, Cfg.D_BT_HAPTIC, null);

        section("Opens");
        c = card();
        targetView = text("", 18, fg);
        targetView.setPadding(0, dp(12), 0, dp(4));
        c.addView(targetView);
        showTarget();
        c.addView(text("You pick the app, then the scan shortcut found inside it (the same ones you get by "
                + "long-pressing its icon). Picking one opens it once, so you can see it is the scanner.", 13, sub));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        button(row, "Choose app & scanner", true, v -> chooseApp());
        button(row, "Test launch", false, v -> testLaunch());
        c.addView(row);
        c.addView(text("If the scan button is only an icon (like CRED's round UPI button), teach it: the app "
                + "opens, you tap the button once, and the spot is remembered.", 13, sub));
        row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        button(row, "Teach the scan button", false, v -> teach());
        c.addView(row);

        section("Sensitivity");
        c = card();
        slider(c, "Sensitivity (higher = lighter taps count)", Cfg.BT_SENS, Cfg.D_BT_SENS, 1, 12);
        toggle(c, "Log knocks in the status box", "Every knock System UI sees and why it was accepted or "
                + "rejected - helps find why a double tap isn't recognised. Turn off when it works",
                Cfg.BT_DEBUG, Cfg.D_BT_DEBUG, null);
        toggle(c, "Ignore while lying flat", "A phone lying on its back can't be tapped on the back - this is what "
                + "stops \"just placing the phone\" from triggering", Cfg.BT_FLAT, Cfg.D_BT_FLAT, null);
        calibView = text("", 15, fg);
        calibView.setPadding(0, dp(10), 0, dp(4));
        c.addView(calibView);
        showCalibration();
        row = new LinearLayout(this);
        row.setPadding(0, dp(6), 0, dp(10));
        calBtn = button(row, "Calibrate: tap the back 6 times", true, v -> {
            if (calibrating) stopTest();
            else startTest(true);
        });
        c.addView(row);

        section("What System UI is doing");
        c = card();
        c.addView(text("Reported by the part that listens while the screen is on - it shows what happened on a "
                + "real double tap, even though this screen wasn't open.", 13, sub));
        statusView = text("", 13, fg);
        statusView.setTypeface(Typeface.MONOSPACE);
        statusView.setPadding(0, dp(10), 0, 0);
        c.addView(statusView);
        refreshStatus();
        row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        button(row, "Refresh", false, v -> refreshStatus());
        c.addView(row);

        section("Live test");
        c = card();
        c.addView(text("Hold the phone like you normally do and tap twice on the back. Then put it down on a "
                + "table, wave it about, type on the screen: those must be rejected.", 14, sub));
        liveBig = text("Test is off", 26, fg);
        liveBig.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        liveBig.setPadding(0, dp(14), 0, dp(6));
        c.addView(liveBig);
        joltView = text("", 14, sub);
        joltView.setPadding(0, 0, 0, dp(8));
        c.addView(joltView);
        liveLog = text("", 13, sub);
        liveLog.setTypeface(Typeface.MONOSPACE);
        liveLog.setMinLines(6);
        c.addView(liveLog);
        sensorView = text("", 12, sub);
        sensorView.setPadding(0, dp(8), 0, 0);
        c.addView(sensorView);
        row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, dp(10));
        testBtn = button(row, "Start test", true, v -> {
            if (testing && !calibrating) stopTest();
            else startTest(false);
        });
        c.addView(row);
    }

    private void showTarget() {
        String label = sp.getString(Cfg.BT_LABEL, "");
        String pkg = sp.getString(Cfg.BT_PKG, "");
        if (pkg.isEmpty()) {
            targetView.setText("Nothing chosen yet");
            targetView.setTextColor(warn);
        } else {
            boolean taught = sp.getBoolean(Cfg.BT_AUTO, false) && sp.getInt(Cfg.BT_TAPX, -1) >= 0;
            targetView.setText((label.isEmpty() ? pkg : label) + (taught ? "\n(taps the spot you taught)" : ""));
            targetView.setTextColor(fg);
        }
    }

    private void showCalibration() {
        int sign = sp.getInt(Cfg.BT_SIGN, Cfg.D_BT_SIGN);
        if (sign == 0) {
            calibView.setText("Not calibrated. Calibrating teaches the phone how your taps feel, so screen taps "
                    + "(typing) are ignored.");
            calibView.setTextColor(warn);
        } else {
            calibView.setText("Calibrated: your taps come from the " + (sign > 0 ? "back" : "screen side")
                    + ". Sensitivity " + sp.getInt(Cfg.BT_SENS, Cfg.D_BT_SENS) + ".");
            calibView.setTextColor(good);
        }
    }

    // ------------------------------------------------------------------ test and calibration

    private void startTest(boolean calib) {
        stopTest();
        runner = new BackTapRunner(this);
        runner.det.listener = this;
        runner.det.verbose = !calib;
        applyParams();
        if (calib) runner.det.configure(0.4f, 0, false);
        runner.det.calibrating = calib;
        if (!runner.start()) {
            Toast.makeText(this, "This phone has no accelerometer?", Toast.LENGTH_LONG).show();
            runner = null;
            return;
        }
        testing = true;
        calibrating = calib;
        knocks.clear();
        logLines.clear();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        keepAlive.run(); // tells System UI to stay quiet meanwhile
        sensorView.setText(runner.sensorInfo());
        hold = 0;
        holdAt = 0;
        ui.post(meter);
        if (calib) {
            calibFrom = System.currentTimeMillis() + 2500;
            liveBig.setTextColor(accent);
            liveBig.setText("Get ready…");
            liveLog.setText("Hold the phone as you normally do.\nIn a moment: tap the back " + CAL_TAPS
                    + " times with a fingertip, about once a second.");
            calBtn.setText("Stop");
            testBtn.setEnabled(false);
            ui.postDelayed(() -> {
                if (calibrating) {
                    liveBig.setText("Tap the back now  0 / " + CAL_TAPS);
                }
            }, 2500);
        } else {
            liveBig.setTextColor(fg);
            liveBig.setText("Listening…");
            liveLog.setText("");
            testBtn.setText("Stop test");
            calBtn.setEnabled(false);
        }
    }

    private final Runnable keepAlive = new Runnable() {
        @Override
        public void run() {
            if (!testing) return;
            sp.edit().putInt(Cfg.BT_TEST_UNTIL, (int) (System.currentTimeMillis() / 1000 + 45)).commit();
            changed();
            ui.postDelayed(this, 20000);
        }
    };

    /** Live strength of the biggest jolt: shows whether taps are felt at all, and how far from the threshold. */
    private final Runnable meter = new Runnable() {
        @Override
        public void run() {
            if (!testing || runner == null) return;
            float t = runner.det.takeMax();
            long now = System.currentTimeMillis();
            if (t >= hold || now - holdAt > 1500) {
                hold = t;
                holdAt = now;
            }
            float need = runner.det.thr;
            joltView.setText(String.format(Locale.US, "Strongest jolt, last second: %.1f   (a knock needs %.1f)",
                    hold, need));
            joltView.setTextColor(hold >= need ? good : sub);
            ui.postDelayed(this, 150);
        }
    };

    private void stopTest() {
        boolean was = testing;
        testing = false;
        calibrating = false;
        ui.removeCallbacks(keepAlive);
        ui.removeCallbacks(meter);
        if (joltView != null) joltView.setText("");
        if (runner != null) {
            runner.stop();
            runner = null;
        }
        if (was) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            sp.edit().putInt(Cfg.BT_TEST_UNTIL, 0).commit();
            changed();
            if (liveBig != null) {
                liveBig.setTextColor(fg);
                liveBig.setText("Test is off");
                testBtn.setText("Start test");
                testBtn.setEnabled(true);
                calBtn.setText("Calibrate: tap the back 6 times");
                calBtn.setEnabled(true);
            }
        }
    }

    private void applyParams() {
        if (runner == null) return;
        runner.det.configure(BackTapDetector.thrForSens(sp.getInt(Cfg.BT_SENS, Cfg.D_BT_SENS)),
                sp.getInt(Cfg.BT_SIGN, Cfg.D_BT_SIGN), sp.getBoolean(Cfg.BT_FLAT, Cfg.D_BT_FLAT));
    }

    // detector callbacks: sensor thread -> UI thread

    @Override
    public void onDoubleTap() { }

    @Override
    public void onLog(String line) {
        ui.post(() -> {
            if (!testing || calibrating) return;
            logLines.add(line);
            while (logLines.size() > 9) logLines.remove(0);
            StringBuilder b = new StringBuilder();
            for (String l : logLines) b.append(l).append('\n');
            liveLog.setText(b.toString().trim());
            if (line.startsWith("DOUBLE TAP")) {
                liveBig.setTextColor(good);
                liveBig.setText("✓ Double tap!");
            } else if (line.startsWith("tap 1")) {
                liveBig.setTextColor(accent);
                liveBig.setText("Tap 1 ✓ …and the second");
            } else if (line.startsWith("rejected")) {
                liveBig.setTextColor(warn);
                liveBig.setText("✗ " + line.replaceFirst("^rejected( [0-9.]+)?:? ?", ""));
            }
        });
    }

    @Override
    public void onKnock(float peak, int sign) {
        if (!calibrating) return;
        ui.post(() -> {
            if (!calibrating || System.currentTimeMillis() < calibFrom || peak > 40f) return;
            knocks.add(new float[]{peak, sign});
            liveBig.setText("Tap the back now  " + knocks.size() + " / " + CAL_TAPS);
            if (knocks.size() >= CAL_TAPS) finishCalibration();
        });
    }

    private void finishCalibration() {
        List<float[]> k = new ArrayList<>(knocks);
        stopTest();
        int n = k.size(), pos = 0;
        float[] peaks = new float[n];
        for (int i = 0; i < n; i++) {
            peaks[i] = k.get(i)[0];
            if (k.get(i)[1] > 0) pos++;
        }
        java.util.Arrays.sort(peaks);
        float median = peaks[n / 2];
        int neg = n - pos;
        int sign = pos >= 0.7f * n ? 1 : neg >= 0.7f * n ? -1 : 0;
        float thr = Math.max(0.5f, Math.min(6.0f, 0.5f * median));
        int sens = BackTapDetector.sensForThr(thr);
        sp.edit().putInt(Cfg.BT_SENS, sens).putInt(Cfg.BT_SIGN, sign).commit();
        changed();
        build();
        if (sign == 0) {
            Toast.makeText(this, "The taps came from both sides - use one fingertip on the back only, "
                    + "then calibrate again", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, String.format(Locale.US, "Calibrated: typical tap %.1f m/s², sensitivity %d. "
                    + "Try the live test.", median, sens), Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ choosing the scanner

    private static final String[] PAY_WORDS = {"pay", "upi", "bhim", "phonepe", "paytm", "cred", "wallet",
            "money", "bank", "paisa", "gpay", "navi", "mobikwik", "freecharge", "amazon"};

    private static final class AppRow {
        String pkg, label;
        ResolveInfo ri;
        boolean pay;
        android.graphics.drawable.Drawable icon;
    }

    private void chooseApp() {
        Toast.makeText(this, "Loading apps…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            Map<String, AppRow> map = new LinkedHashMap<>();
            for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || map.containsKey(pkg)) continue;
                AppRow r = new AppRow();
                r.pkg = pkg;
                r.ri = ri;
                r.label = String.valueOf(ri.loadLabel(pm));
                String low = (pkg + " " + r.label).toLowerCase(Locale.ROOT);
                for (String w : PAY_WORDS) {
                    if (low.contains(w)) {
                        r.pay = true;
                        break;
                    }
                }
                map.put(pkg, r);
            }
            List<AppRow> rows = new ArrayList<>(map.values());
            Collections.sort(rows, (a, b) -> a.pay != b.pay ? (a.pay ? -1 : 1) : a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> showApps(rows));
        }).start();
    }

    private void showApps(List<AppRow> all) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps");
        search.setTextColor(fg);
        search.setHintTextColor(sub);
        box.addView(search, new LinearLayout.LayoutParams(-1, -2));
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(420)));
        final List<AppRow> shown = new ArrayList<>(all);
        final PackageManager pm = getPackageManager();
        BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                AppRow r = shown.get(i);
                LinearLayout row = new LinearLayout(BackTapActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(8), 0, dp(8));
                ImageView iv = new ImageView(BackTapActivity.this);
                if (r.icon == null) r.icon = r.ri.loadIcon(pm);
                iv.setImageDrawable(r.icon);
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout tx = new LinearLayout(BackTapActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setPadding(dp(14), 0, 0, 0);
                tx.addView(text(r.label, 17, fg));
                if (r.pay) tx.addView(text("★ looks like a payment app", 12, accent));
                row.addView(tx);
                return row;
            }
        };
        lv.setAdapter(ad);
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                String q = e.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();
                for (AppRow r : all) {
                    if (q.isEmpty() || r.label.toLowerCase(Locale.ROOT).contains(q)
                            || r.pkg.toLowerCase(Locale.ROOT).contains(q)) shown.add(r);
                }
                ad.notifyDataSetChanged();
            }
        });
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Which payment app?")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            findFor(shown.get(i));
        });
        d.show();
    }

    private void findFor(AppRow app) {
        Toast.makeText(this, "Looking for the scanner in " + app.label + "…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            List<ScanFinder.Cand> cands = ScanFinder.find(this, app.pkg);
            runOnUiThread(() -> showCandidates(app, cands));
        }).start();
    }

    private void showCandidates(AppRow app, List<ScanFinder.Cand> cands) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(16), dp(4), dp(16), 0);
        ListView lv = new ListView(this);
        box.addView(lv, new LinearLayout.LayoutParams(-1, dp(340)));
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return cands.size(); }
            @Override public Object getItem(int i) { return cands.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View v, ViewGroup parent) {
                ScanFinder.Cand c = cands.get(i);
                LinearLayout tx = new LinearLayout(BackTapActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.setPadding(0, dp(10), 0, dp(10));
                TextView l = text(c.label, 17, fg);
                tx.addView(l);
                tx.addView(text((i == 0 && c.score >= 10 ? "★ most likely the scanner · " : "") + c.detail, 12,
                        i == 0 && c.score >= 10 ? accent : sub));
                return tx;
            }
        });
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Scanner in " + app.label)
                .setMessage("Tap one to use it. It opens right away, so you can check it is the scanner. "
                        + "If it isn't, pick another.")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .create();
        lastApp = app;
        lastCands = cands;
        lv.setOnItemClickListener((p, v, i, id) -> {
            d.dismiss();
            pick(app, cands.get(i));
        });
        d.show();
    }

    private void pick(AppRow app, ScanFinder.Cand c) {
        Toast.makeText(this, "Opening it and checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ScanLaunch.Result r = c.auto ? ScanLaunch.launchAuto(c.uri, app.pkg, null)
                    : ScanLaunch.launch(this, c.uri, app.pkg, true);
            if (r.ok) {
                save(app, c, r.viaRoot);
                runOnUiThread(() -> {
                    showTarget();
                    Toast.makeText(this, r.verified ? "Opened ✓ and saved"
                            : "Saved. Did the scanner open? If not, pick another.", Toast.LENGTH_LONG).show();
                });
            } else {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("That one didn't open")
                        .setMessage(r.report + "\nTry another entry in the list.")
                        .setPositiveButton("Pick another", (d, w) -> {
                            if (lastCands != null && lastApp != null) showCandidates(lastApp, lastCands);
                        })
                        .setNegativeButton("Use it anyway", (d, w) -> {
                            save(app, c, true);
                            showTarget();
                        })
                        .show());
            }
        }).start();
    }

    private void teach() {
        String uri = sp.getString(Cfg.BT_URI, "");
        if (!sp.getBoolean(Cfg.BT_AUTO, false) || uri.isEmpty()) {
            Toast.makeText(this, "First choose \"Open the app and tap its Scan button for me\"",
                    Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Teach the scan button")
                .setMessage("The app opens. Unlock it if asked, then tap the scan button ONCE and wait. "
                        + "The spot is saved after 8 seconds without touching the screen (it listens for up to "
                        + "90 s). Needs root.")
                .setPositiveButton("Start", (d, w) -> new Thread(() -> {
                    ScanFinder.rootStartOut(uri);
                    float[] t = ScanFinder.recordTap(90000, 8000);
                    if (t != null) {
                        sp.edit().putInt(Cfg.BT_TAPX, Math.round(t[0] * 10000))
                                .putInt(Cfg.BT_TAPY, Math.round(t[1] * 10000)).commit();
                        changed();
                    }
                    runOnUiThread(() -> {
                        showTarget();
                        Toast.makeText(this, t != null ? "Saved the spot you tapped"
                                : "No tap seen - try again", Toast.LENGTH_LONG).show();
                    });
                }).start())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void save(AppRow app, ScanFinder.Cand c, boolean viaRoot) {
        sp.edit().putString(Cfg.BT_PKG, app.pkg)
                .putString(Cfg.BT_URI, c.uri)
                .putString(Cfg.BT_LABEL, app.label + "  →  " + c.label)
                .putBoolean(Cfg.BT_ROOT, viaRoot)
                .putBoolean(Cfg.BT_AUTO, c.auto)
                .remove(Cfg.BT_TAPX).remove(Cfg.BT_TAPY).commit();
        changed();
    }

    private void testLaunch() {
        String uri = sp.getString(Cfg.BT_URI, "");
        String pkg = sp.getString(Cfg.BT_PKG, "");
        if (uri.isEmpty()) {
            Toast.makeText(this, "Choose the app first", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Opening it and checking…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            ScanLaunch.Result r = sp.getBoolean(Cfg.BT_AUTO, false) ? ScanLaunch.launchAuto(uri, pkg, ScanLaunch.taught(sp))
                    : ScanLaunch.launch(this, uri, pkg, !sp.getBoolean(Cfg.BT_ROOT, false));
            runOnUiThread(() -> {
                if (r.ok) {
                    Toast.makeText(this, r.verified ? "Opened ✓" : "Started (couldn't check it is on screen)",
                            Toast.LENGTH_SHORT).show();
                } else {
                    new AlertDialog.Builder(this).setTitle("It didn't open").setMessage(r.report)
                            .setPositiveButton("OK", null).show();
                }
            });
        }).start();
    }

    // ------------------------------------------------------------------ widgets

    private interface OnToggle { void on(boolean on); }

    private void toggle(LinearLayout parent, String label, String desc, String key, boolean def, OnToggle cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            sp.edit().putBoolean(key, on).commit();
            changed();
            applyParams();
            if (cb != null) cb.on(on);
        });
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    private void slider(LinearLayout parent, String label, String key, int def, int min, int max) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(10), 0, dp(6));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(text(label, 16, fg), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text("", 15, accent);
        top.addView(val);
        box.addView(top);
        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        int cur = sp.getInt(key, def);
        s.setProgress(cur);
        val.setText(String.valueOf(cur));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int v, boolean user) {
                val.setText(String.valueOf(v));
            }

            @Override public void onStartTrackingTouch(SeekBar bar) { }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sp.edit().putInt(key, bar.getProgress()).commit();
                changed();
                applyParams();
                showCalibration();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        box.addView(s, lp);
        parent.addView(box);
    }

    private void section(String t) {
        TextView v = text(t, 13, accent);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(18), 0, dp(8));
        list.addView(v);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        list.addView(c);
        return c;
    }

    private Button button(LinearLayout parent, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? (dark ? 0xFF2A1F66 : Color.WHITE) : accent);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        if (primary) g.setColor(accent);
        else {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(dp(1), accent);
        }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), primary ? 2f : 1f);
        lp.setMarginEnd(primary ? dp(10) : 0);
        parent.addView(b, lp);
        return b;
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    private void changed() {
        getContentResolver().notifyChange(URI, null);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
