package com.netspeed.xposed;

import java.util.Locale;

/**
 * Disasters and space weather for row 4:
 *  - GDACS (UN / EU Joint Research Centre): current orange and red alerts for cyclones, quakes, floods, volcanoes,
 *    droughts and wildfires. The worst one (red before orange), nearest first, replaces the quake line.
 *  - NOAA SWPC planetary Kp: shown only during a geomagnetic storm (Kp 5+ = G1..G5).
 * Both free, no key. Fetched from the weather worker thread.
 */
final class Hazards {
    private Hazards() {}

    // ---- GDACS
    static volatile String evType = null;     // TC EQ FL VO DR WF
    static volatile String evName = null;     // "MONTHA", "Etna", may be empty
    static volatile String evPlace = null;    // "Bay of Bengal" / country
    static volatile boolean evRed = false;
    static volatile int evKm = -1;
    static volatile String evDir = "";        // compass from you to the event
    static volatile long gdacsAt = 0, gdacsTried = 0;

    /** One current alert. */
    static final class Ev {
        String type, name, place, dir;
        boolean red;
        int km;
    }
    /** All current orange / red alerts, red first, then nearest. */
    static volatile java.util.List<Ev> events = java.util.Collections.emptyList();

    /** The alert to show now: rotates through all of them, 8 s each. */
    static Ev pick(long now) {
        java.util.List<Ev> l = events;
        if (l.isEmpty()) return null;
        return l.get((int) ((now / 8000L) % l.size()));
    }

    // ---- Kp
    static volatile float kp = Float.NaN;
    static volatile long kpAt = 0, kpTried = 0;

    interface Http { String get(String url) throws Exception; }

    static void tick(Http http, double lat, double lon, long now) {
        if (now - gdacsTried > (gdacsAt == 0 ? 5 : 30) * 60_000L) {
            gdacsTried = now;
            try { gdacs(http.get(gdacsUrl(now)), lat, lon, now); } catch (Throwable ignored) { }
        }
        if (now - kpTried > 15 * 60_000L) {
            kpTried = now;
            try { kp(http.get("https://services.swpc.noaa.gov/json/planetary_k_index_1m.json"), now); } catch (Throwable ignored) { }
        }
    }

    private static String gdacsUrl(long now) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return "https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH?eventlist=TC;EQ;FL;VO;DR;WF"
                + "&alertlevel=Orange;Red&fromDate=" + f.format(new java.util.Date(now - 10 * 86400_000L))
                + "&toDate=" + f.format(new java.util.Date(now + 86400_000L));
    }

    static void gdacs(String json, double lat, double lon, long now) throws Exception {
        org.json.JSONArray fs = new org.json.JSONObject(json).optJSONArray("features");
        String bt = null, bn = null, bp = null, bd = "";
        boolean br = false;
        int bk = -1;
        java.util.List<Ev> all = new java.util.ArrayList<>();
        if (fs != null) {
            for (int i = 0; i < fs.length(); i++) {
                org.json.JSONObject f = fs.optJSONObject(i);
                if (f == null) continue;
                org.json.JSONObject p = f.optJSONObject("properties");
                if (p == null) continue;
                String cur = p.optString("iscurrent", "true");
                if ("false".equalsIgnoreCase(cur)) continue;
                String lvl = p.optString("alertlevel", "");
                boolean red = "red".equalsIgnoreCase(lvl);
                if (!red && !"orange".equalsIgnoreCase(lvl)) continue;
                double elat = Double.NaN, elon = Double.NaN;
                org.json.JSONObject g = f.optJSONObject("geometry");
                if (g != null && "Point".equals(g.optString("type"))) {
                    org.json.JSONArray c = g.optJSONArray("coordinates");
                    if (c != null && c.length() >= 2) { elon = c.optDouble(0); elat = c.optDouble(1); }
                }
                int km = Double.isNaN(elat) ? 99999 : (int) Math.round(dist(lat, lon, elat, elon));
                Ev ev = new Ev();
                ev.type = p.optString("eventtype", "");
                ev.name = clean(p.optString("eventname", p.optString("name", "")));
                String ctry = p.optString("country", "");
                ev.place = ctry.isEmpty() ? null : ctry.split("[,;]")[0].trim();
                ev.red = red;
                ev.km = km >= 99999 ? -1 : km;
                ev.dir = Double.isNaN(elat) ? "" : compass(lat, lon, elat, elon);
                all.add(ev);
                boolean better = bt == null || (red && !br) || (red == br && km < bk);
                if (!better) continue;
                bt = p.optString("eventtype", "");
                bn = clean(p.optString("eventname", p.optString("name", "")));
                String country = p.optString("country", "");
                bp = country.isEmpty() ? null : country.split("[,;]")[0].trim();
                br = red;
                bk = km;
                bd = Double.isNaN(elat) ? "" : compass(lat, lon, elat, elon);
            }
        }
        java.util.Collections.sort(all, (x, y) -> x.red != y.red ? (x.red ? -1 : 1)
                : Integer.compare(x.km < 0 ? 99999 : x.km, y.km < 0 ? 99999 : y.km));
        events = all;
        evType = bt; evName = bn; evPlace = bp; evRed = br; evKm = bk >= 99999 ? -1 : bk; evDir = bd;
        gdacsAt = now;
    }

    /** GDACS names are often "Tropical Cyclone MONTHA-25" or "Earthquake in X": keep the short proper name. */
    private static String clean(String n) {
        if (n == null) return "";
        n = n.replaceAll("(?i)^(tropical cyclone|tropical storm|cyclone|hurricane|typhoon|flood|drought|forest fire|"
                + "wildfire|earthquake|volcano)\\s*(in\\s+)?", "").trim();
        n = n.replaceAll("-\\d{2,4}$", "").trim();
        return n.length() > 16 ? n.substring(0, 15) + "…" : n;
    }

    static void kp(String json, long now) throws Exception {
        org.json.JSONArray a = new org.json.JSONArray(json);
        float v = Float.NaN;
        for (int i = a.length() - 1; i >= 0 && Float.isNaN(v); i--) {
            Object o = a.get(i);
            if (o instanceof org.json.JSONObject) {
                org.json.JSONObject j = (org.json.JSONObject) o;
                if (j.has("estimated_kp") && !j.isNull("estimated_kp")) v = (float) j.optDouble("estimated_kp");
                else if (j.has("kp_index") && !j.isNull("kp_index")) v = (float) j.optDouble("kp_index");
            } else if (o instanceof org.json.JSONArray && i > 0) {            // old format: header row + [time, Kp, ..]
                try { v = Float.parseFloat(((org.json.JSONArray) o).getString(1)); } catch (Throwable ignored) { }
            }
        }
        kp = v;
        kpAt = now;
    }

    /** Disaster to show, or null when there is none (or the data is over 3 h old). */
    static boolean disaster(long now) {
        return evType != null && !evType.isEmpty() && now - gdacsAt < 3 * 3600_000L;
    }

    /** Kp storm level 1..5 (G1..G5), 0 = no storm or stale. */
    static int storm(long now) {
        if (Float.isNaN(kp) || now - kpAt > 3 * 3600_000L || kp < 5f) return 0;
        return Math.min(5, (int) Math.floor(kp) - 4);
    }

    static String icon(String t) {
        switch (t == null ? "" : t) {
            case "TC": return "🌀";
            case "EQ": return "〰";
            case "FL": return "🌊";
            case "VO": return "🌋";
            case "DR": return "🏜";
            case "WF": return "🔥";
            default: return "⚠";
        }
    }

    private static double dist(double a1, double o1, double a2, double o2) {
        double p = Math.toRadians(a2 - a1), q = Math.toRadians(o2 - o1);
        double h = Math.sin(p / 2) * Math.sin(p / 2)
                + Math.cos(Math.toRadians(a1)) * Math.cos(Math.toRadians(a2)) * Math.sin(q / 2) * Math.sin(q / 2);
        return 6371 * 2 * Math.asin(Math.min(1, Math.sqrt(h)));
    }

    private static String compass(double a1, double o1, double a2, double o2) {
        double y = Math.sin(Math.toRadians(o2 - o1)) * Math.cos(Math.toRadians(a2));
        double x = Math.cos(Math.toRadians(a1)) * Math.sin(Math.toRadians(a2))
                - Math.sin(Math.toRadians(a1)) * Math.cos(Math.toRadians(a2)) * Math.cos(Math.toRadians(o2 - o1));
        double b = (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
        return new String[]{"N", "NE", "E", "SE", "S", "SW", "W", "NW"}[(int) Math.round(b / 45) % 8];
    }
}
