package com.netspeed.xposed;

import java.util.Locale;

/**
 * River flow at your location from the Open-Meteo Flood API (GloFAS model, about 5 km grid, nearest river):
 * today's discharge in m3/s, whether it is rising or falling since yesterday, and "high" / "low" against the
 * last 30 days. Worker thread. The status bar's place line reads {@link #text()}.
 */
final class RiverFlow {
    private RiverFlow() {}

    private static volatile String text = "";
    private static volatile long okAt, triedAt;
    private static String lastKey = "";
    static volatile String why = "not fetched yet";
    static volatile String nameWhy = "name not looked up yet";
    private static String nameKey = "";
    private static String nameVal = "";
    private static long nameAt;

    /**
     * "River Pavana" / "Stream X" / "Canal Y": the nearest named waterway within 4 km from OpenStreetMap (Overpass),
     * a river preferred over a stream when they are close. "" when none is named. Cached a day per km. English name first, else the local (e.g. Marathi) one.
     */
    private static String waterName(double lat, double lon) {
        String key = String.format(Locale.US, "%.2f,%.2f", lat, lon);
        long now = System.currentTimeMillis();
        if (key.equals(nameKey) && now - nameAt < 24 * 3600_000L) return nameVal;
        try {
            String q = String.format(Locale.US, "[out:json][timeout:12];way(around:4000,%.5f,%.5f)[\"waterway\"~\"^(river|stream|canal)$\"][\"name\"];out tags geom 25;", lat, lon);
            StringBuilder sb = new StringBuilder();
            String codes = "";
            for (String ep : new String[]{"https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"}) {
                try {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(ep + "?data="
                            + java.net.URLEncoder.encode(q, "UTF-8")).openConnection();
                    c.setConnectTimeout(8_000);
                    c.setReadTimeout(14_000);
                    c.setRequestProperty("User-Agent", "NetSpeedXposed/1.0 (status bar module; github.com/dmk6091/NetSpeedXposed)");
                    int rc = c.getResponseCode();
                    codes += ep.substring(8, 12) + "=" + rc + " ";
                    if (rc != 200) continue;
                    try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
                        String ln;
                        while ((ln = r.readLine()) != null) sb.append(ln);
                    }
                    break;
                } catch (Throwable t1) {
                    codes += ep.substring(8, 12) + "=" + t1.getClass().getSimpleName() + " ";
                }
            }
            if (sb.length() == 0) { nameWhy = "OpenStreetMap lookup failed: " + codes; return nameKey.equals(key) ? nameVal : ""; }
            org.json.JSONArray els = new org.json.JSONObject(sb.toString()).optJSONArray("elements");
            String best = "";
            double bestScore = 1e18;
            double kx = 111320 * Math.cos(Math.toRadians(lat)), ky = 110540;
            for (int i = 0; els != null && i < els.length(); i++) {
                org.json.JSONObject e = els.getJSONObject(i);
                org.json.JSONObject tg = e.optJSONObject("tags");
                org.json.JSONArray g = e.optJSONArray("geometry");
                if (tg == null || g == null) continue;
                String nm = tg.optString("name:en", "");
                if (nm.isEmpty()) nm = tg.optString("int_name", "");
                if (nm.isEmpty()) nm = tg.optString("name", "");   // local name (Marathi, Devanagari) when there is no English one
                if (nm.isEmpty() || nm.length() > 30) continue;
                double d = 1e18;
                for (int j = 0; j < g.length(); j++) {
                    org.json.JSONObject pt = g.getJSONObject(j);
                    double dx = (pt.getDouble("lon") - lon) * kx, dy = (pt.getDouble("lat") - lat) * ky;
                    d = Math.min(d, Math.sqrt(dx * dx + dy * dy));
                }
                String type = tg.optString("waterway", "river");
                double score = d - ("river".equals(type) ? 1500 : "canal".equals(type) ? 500 : 0);
                if (score < bestScore) {
                    bestScore = score;
                    best = ("river".equals(type) ? "River " : "canal".equals(type) ? "Canal " : "Stream ") + nm;
                }
            }
            nameKey = key; nameVal = best; nameAt = now;
            nameWhy = (els == null ? 0 : els.length()) + " named waterways within 4 km -> " + (best.isEmpty() ? "none usable" : best);
            return best;
        } catch (Throwable t) {
            return nameKey.equals(key) ? nameVal : "";
        }
    }

    /** "River 340 m³/s ▲ high", or "" when there is no river here (or the data is old). */
    static String text() {
        return System.currentTimeMillis() - okAt > 8 * 3600_000L ? "" : text;
    }

    static void tick(Hazards.Http http, double lat, double lon) {
        long now = System.currentTimeMillis();
        String key = String.format(Locale.US, "%.2f,%.2f", lat, lon);
        if (key.equals(lastKey) && now - okAt < 60 * 60_000L) return;
        if (now - triedAt < 5 * 60_000L) return;
        triedAt = now;
        try {
            String u = String.format(Locale.US, "https://flood-api.open-meteo.com/v1/flood?latitude=%.4f&longitude=%.4f"
                    + "&daily=river_discharge&past_days=30&forecast_days=1", lat, lon);
            org.json.JSONArray a = new org.json.JSONObject(http.get(u)).getJSONObject("daily").getJSONArray("river_discharge");
            int n = a.length();
            if (n < 8 || a.isNull(n - 1)) { text = ""; okAt = now; lastKey = key; why = "no river data here"; return; }
            double today = a.getDouble(n - 1);
            double yest = a.isNull(n - 2) ? today : a.getDouble(n - 2);
            java.util.List<Double> past = new java.util.ArrayList<>();
            for (int i = 0; i < n - 1; i++) if (!a.isNull(i)) past.add(a.getDouble(i));
            java.util.Collections.sort(past);
            double med = past.isEmpty() ? today : past.get(past.size() / 2);
            if (today < 1.0 && med < 1.0) { text = ""; okAt = now; lastKey = key; why = "no real river nearby (flow " + today + ")"; return; }
            String arrow = today > yest * 1.1 ? "\u25B2" : today < yest * 0.9 ? "\u25BC" : "\u2192";
            double ratio = med > 0.5 ? today / med : 1;
            String lvl = ratio >= 4 ? " very high" : ratio >= 2 ? " high" : ratio <= 0.5 ? " low" : "";
            String v = today >= 1000 ? String.format(Locale.US, "%.1fk", today / 1000) : today >= 10 ? String.valueOf(Math.round(today))
                    : String.format(Locale.US, "%.1f", today);
            String wn = waterName(lat, lon);
            text = (wn.isEmpty() ? "River" : wn) + " " + v + " m\u00b3/s " + arrow + lvl;
            okAt = now;
            lastKey = key;
            why = "ok " + text + " (30-day median " + Math.round(med) + "); " + nameWhy;
        } catch (Throwable t) {
            why = "failed: " + t;
        }
    }
}
