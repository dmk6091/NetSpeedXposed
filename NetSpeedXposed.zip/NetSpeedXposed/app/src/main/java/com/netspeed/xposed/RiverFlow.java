package com.netspeed.xposed;

import java.util.Locale;

/**
 * River flow at your location from the Open-Meteo Flood API (GloFAS model, about 5 km grid, nearest river):
 * today's discharge in m3/s, whether it is rising or falling since yesterday, and "high" / "low" against the
 * last 30 days. Worker thread. The status bar's place line reads {@link #text()}.
 */
final class RiverFlow {
    private RiverFlow() {}

    private static volatile String text = "";
    private static volatile long okAt, triedAt;
    private static String lastKey = "";
    static volatile String why = "not fetched yet";

    /** "River 340 m³/s ▲ high", or "" when there is no river here (or the data is old). */
    static String text() {
        return System.currentTimeMillis() - okAt > 8 * 3600_000L ? "" : text;
    }

    static void tick(Hazards.Http http, double lat, double lon) {
        long now = System.currentTimeMillis();
        String key = String.format(Locale.US, "%.2f,%.2f", lat, lon);
        if (key.equals(lastKey) && now - okAt < 60 * 60_000L) return;
        if (now - triedAt < 5 * 60_000L) return;
        triedAt = now;
        try {
            String u = String.format(Locale.US, "https://flood-api.open-meteo.com/v1/flood?latitude=%.4f&longitude=%.4f"
                    + "&daily=river_discharge&past_days=30&forecast_days=1", lat, lon);
            org.json.JSONArray a = new org.json.JSONObject(http.get(u)).getJSONObject("daily").getJSONArray("river_discharge");
            int n = a.length();
            if (n < 8 || a.isNull(n - 1)) { text = ""; okAt = now; lastKey = key; why = "no river data here"; return; }
            double today = a.getDouble(n - 1);
            double yest = a.isNull(n - 2) ? today : a.getDouble(n - 2);
            java.util.List<Double> past = new java.util.ArrayList<>();
            for (int i = 0; i < n - 1; i++) if (!a.isNull(i)) past.add(a.getDouble(i));
            java.util.Collections.sort(past);
            double med = past.isEmpty() ? today : past.get(past.size() / 2);
            if (today < 1.0 && med < 1.0) { text = ""; okAt = now; lastKey = key; why = "no real river nearby (flow " + today + ")"; return; }
            String arrow = today > yest * 1.1 ? "\u25B2" : today < yest * 0.9 ? "\u25BC" : "\u2192";
            double ratio = med > 0.5 ? today / med : 1;
            String lvl = ratio >= 4 ? " very high" : ratio >= 2 ? " high" : ratio <= 0.5 ? " low" : "";
            String v = today >= 1000 ? String.format(Locale.US, "%.1fk", today / 1000) : today >= 10 ? String.valueOf(Math.round(today))
                    : String.format(Locale.US, "%.1f", today);
            text = "River " + v + " m\u00b3/s " + arrow + lvl;
            okAt = now;
            lastKey = key;
            why = "ok " + text + " (30-day median " + Math.round(med) + ")";
        } catch (Throwable t) {
            why = "failed: " + t;
        }
    }
}
