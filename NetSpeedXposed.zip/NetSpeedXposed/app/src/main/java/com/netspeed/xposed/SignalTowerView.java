package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * One icon for both SIMs: a lattice tower with antenna panels, SIM 1's signal as waves on the
 * left and SIM 2's on the right (4 arcs = 4 bars; lit = signal, faint = missing). Next to
 * each side: the network that SIM is on (4G+ / LTE / 5G) with a small SIM number, its voice
 * type (VoLTE / VoNR / VoWiFi) and, on the SIM carrying mobile data, ↓↑ arrows that light up
 * with traffic plus the level as "3/4".
 */
final class SignalTowerView extends View {

    /** What one side shows. */
    static final class Side {
        boolean present;     // a SIM in this slot
        boolean inService;
        int level = -1;      // 0..4
        String net;          // "4G+", "LTE", "5G" ...
        String band;         // "n78", "B1" ...
        String voice;        // "VoLTE" ...
        boolean data;        // carries mobile data
        boolean in, out;     // data flowing
        boolean inCall;      // a call on this SIM
        String dbm;          // "-100", drawn under the wave fan (null = none)
        String dist;         // "1.0km", "≈600m" on the band line (null = none)
        String sinr;         // "13" (dB), under the fan after the dBm (null = none)
        int sinrColor;
        String opLetter;     // operator badge letter ("J"), null = show SIM number
        int opColor;

        boolean same(Side o) {
            return o != null && present == o.present && inService == o.inService && level == o.level
                    && eq(net, o.net) && eq(band, o.band) && eq(voice, o.voice) && data == o.data && in == o.in && out == o.out && inCall == o.inCall && eq(dbm, o.dbm) && eq(dist, o.dist) && eq(sinr, o.sinr) && sinrColor == o.sinrColor && eq(opLetter, o.opLetter) && opColor == o.opColor;
        }

        Side copy() {
            Side s = new Side();
            s.present = present; s.inService = inService; s.level = level; s.net = net; s.band = band;
            s.voice = voice; s.data = data; s.in = in; s.out = out; s.inCall = inCall; s.dbm = dbm; s.opLetter = opLetter; s.dist = dist; s.sinr = sinr; s.sinrColor = sinrColor; s.opColor = opColor;
            return s;
        }

        private static boolean eq(String a, String b) {
            return a == null ? b == null : a.equals(b);
        }
    }

    private final Side[] sides = {new Side(), new Side()};
    private int color = 0xFFFFFFFF, voColor = 0xFF34C759, bandColor = 0xFF78BEFF;
    private float textPx = 20f;
    private float sizeScale = 1f;
    private boolean darkBar = true;

    /** Bright colour on a dark bar, deeper shade on a light one. */
    private int pick(int bright, int deep) {
        return darkBar ? bright : deep;
    }

    /** Wave colour for what this SIM is doing now. */
    private int activityColor(Side s) {
        if (s.inCall) return pick(0xFFFF9F0A, 0xFFC46A00);                 // call: orange
        if (s.data && s.in && s.out) return pick(0xFF64D2FF, 0xFF0086A8);  // both ways: cyan
        if (s.data && s.in) return pick(0xFF34C759, 0xFF1E8E3E);           // download: green
        if (s.data && s.out) return pick(0xFF0A84FF, 0xFF0A60C0);          // upload: blue
        if (s.data) return color;                                          // data SIM, idle
        return pick(0xFF8EA4C8, 0xFF5A6E90);                               // standby: grey-blue
    }

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();

    SignalTowerView(Context ctx) {
        super(ctx);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Returns true when something changed (and a redraw / relayout was requested). */
    boolean update(Side s1, Side s2, int color, float textPx, Typeface tf, float scale) {
        boolean layout = textPx != this.textPx || scale != sizeScale || (tf != null && tf != text.getTypeface())
                || !eqStr(s1.net, sides[0].net) || !eqStr(s2.net, sides[1].net)
                || !eqStr(s1.band, sides[0].band) || !eqStr(s2.band, sides[1].band)
                || !eqStr(s1.voice, sides[0].voice) || !eqStr(s2.voice, sides[1].voice)
                || !eqStr(s1.sinr, sides[0].sinr) || !eqStr(s2.sinr, sides[1].sinr)
                || !eqStr(s1.dist, sides[0].dist) || !eqStr(s2.dist, sides[1].dist)
                || !eqStr(s1.opLetter, sides[0].opLetter) || !eqStr(s2.opLetter, sides[1].opLetter)
                || !eqStr(s1.dbm, sides[0].dbm) || !eqStr(s2.dbm, sides[1].dbm)
                || s1.data != sides[0].data || s2.data != sides[1].data
                || s1.present != sides[0].present || s2.present != sides[1].present;
        boolean changed = layout || color != this.color || !s1.same(sides[0]) || !s2.same(sides[1]);
        if (!changed) return false;
        sides[0] = s1.copy();
        sides[1] = s2.copy();
        this.color = color;
        this.textPx = textPx;
        this.sizeScale = scale;
        if (tf != null) text.setTypeface(Typeface.create(tf, Typeface.BOLD));
        // Green voice label on a dark bar, darker green on a light one.
        float lum = (0.299f * ((color >> 16) & 0xFF) + 0.587f * ((color >> 8) & 0xFF) + 0.114f * (color & 0xFF)) / 255f;
        darkBar = lum > 0.5f;
        voColor = lum > 0.5f ? 0xFF34C759 : 0xFF1E8E3E;
        bandColor = lum > 0.5f ? 0xFF78BEFF : 0xFF0A5BC4;
        if (layout) requestLayout();
        invalidate();
        return true;
    }

    private static boolean eqStr(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    // ------------------------------------------------------------ geometry

    private float h() {
        return textPx * 2.05f * sizeScale;          // as tall as two text lines
    }

    private float bigText() {
        return textPx * 0.95f * sizeScale;
    }

    private float smallText() {
        return textPx * 0.58f * sizeScale;
    }

    /** Half-width of the tower + waves block. */
    private float coreHalf() {
        float h = h();
        float half = h * 0.56f;
        // room for the dBm under each fan, centred 0.40 h from the mast
        text.setTextSize(dbmText());
        for (Side s : sides) {
            if (s.present && (s.dbm != null || s.sinr != null)) half = Math.max(half, h * 0.40f + underWidth(s) / 2f + 1);
        }
        return half;
    }

    private float dbmText() {
        return textPx * 0.52f * sizeScale;
    }

    private float labelWidth(int i) {
        Side s = sides[i];
        if (!s.present) return 0;
        text.setTextSize(bigText());
        float w = s.net != null ? text.measureText(s.net) : text.measureText("?");
        text.setTextSize(smallText());
        w += (s.opLetter != null ? badgeR() * 2 + 2 : text.measureText("1")) + 1;
        float w2 = line2Width(s);
        float w3 = (s.voice != null ? text.measureText(s.voice) : 0)
                + (s.data ? arrowsWidth() + (s.voice != null ? smallText() * 0.3f : 0) : 0);
        return Math.max(w, Math.max(w2, w3));
    }

    /** Band line: "n78", then (with a distance) a dotted line + pin and "1.0km". */
    private static final String SEP = " \u2502 ";

    private float line2Width(Side s) {
        text.setTextSize(smallText());
        float w = s.band != null ? text.measureText(s.band) : 0;
        if (s.dist != null) w += (w > 0 ? text.measureText(SEP) : 0) + text.measureText(s.dist);
        return w;
    }

    /** Width of "-99│13dB" under a fan. */
    private float underWidth(Side s) {
        text.setTextSize(dbmText());
        float w = 0;
        if (s.dbm != null) w += text.measureText(s.dbm);
        if (s.sinr != null) {
            if (s.dbm != null) w += text.measureText("\u2502");
            w += text.measureText(s.sinr);
            text.setTextSize(dbmText() * 0.7f);
            w += text.measureText("dB");
        }
        return w;
    }

    private float badgeR() {
        return smallText() * 0.62f;
    }

    /** Operator disc: brand-ish colour with its initial (a plain letter, not the operator's logo). */
    static Object[] operatorBadge(String name, String mccMnc) {
        String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
        if (n.contains("jio")) return new Object[]{"J", 0xFF0A3D91};
        if (n.contains("airtel")) return new Object[]{"A", 0xFFE40000};
        if (n.contains("vodafone") || n.contains("idea") || n.equals("vi") || n.startsWith("vi ")) return new Object[]{"V", 0xFFE60000};
        if (n.contains("bsnl")) return new Object[]{"B", 0xFFF57C00};
        if (n.contains("mtnl")) return new Object[]{"M", 0xFF1565C0};
        if (mccMnc != null && mccMnc.startsWith("405-8")) return new Object[]{"J", 0xFF0A3D91};
        if (n.isEmpty()) return null;
        return new Object[]{n.substring(0, 1).toUpperCase(java.util.Locale.US), 0xFF607D8B};
    }

    private float arrowsWidth() {
        return smallText() * 1.3f;
    }

    private String levelText(Side s) {
        return s.level >= 0 ? s.level + "/4" : "?/4";
    }

    private float gap() {
        return textPx * 0.18f;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float w = labelWidth(0) + gap() + 2 * coreHalf() + gap() + labelWidth(1);
        int hh = (int) Math.ceil(h());
        setMeasuredDimension((int) Math.ceil(w) + 2, resolveSize(hh, hSpec));
    }

    // ------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        float h = h();
        float top = (getHeight() - h) / 2f;
        float lw0 = labelWidth(0);
        float cx = lw0 + gap() + coreHalf();
        int dim = (color & 0x00FFFFFF) | 0x4D000000;

        // --- tower, painted like real ones: red / white sections, red beacon on top
        float sw = Math.max(1.2f, h * 0.045f);
        int red = pick(0xFFFF3B30, 0xFFC62828);
        int light = color;                       // white on a dark bar, dark grey on a light one
        float bottom = top + h - sw / 2;
        float apex = top + h * 0.20f;
        float foot = h * 0.17f;
        stroke.setStrokeWidth(sw);
        stroke.setColor(red);
        c.drawLine(cx, top + sw * 1.2f, cx, apex, stroke);               // antenna tip
        int n = 4;
        for (int i = 0; i < n; i++) {
            int col = i % 2 == 0 ? red : light;
            float y0 = apex + (bottom - apex) * i / n, y1 = apex + (bottom - apex) * (i + 1) / n;
            float x0 = foot * (y0 - apex) / (bottom - apex), x1 = foot * (y1 - apex) / (bottom - apex);
            stroke.setColor(col);
            stroke.setStrokeWidth(sw);
            c.drawLine(cx - x0, y0, cx - x1, y1, stroke);                 // legs
            c.drawLine(cx + x0, y0, cx + x1, y1, stroke);
            c.drawLine(cx, y0, cx, y1, stroke);                           // mast
            stroke.setStrokeWidth(Math.max(1f, sw * 0.6f));
            if (i > 0) {
                c.drawLine(cx - x0, y0, cx + x1, y1, stroke);             // lattice
                c.drawLine(cx + x0, y0, cx - x1, y1, stroke);
            }
            c.drawLine(cx - x1, y1, cx + x1, y1, stroke);
        }
        fill.setColor(red);
        c.drawCircle(cx, top + sw * 1.1f, sw * 1.1f, fill);              // beacon
        fill.setColor(color);
        // antenna panels
        float py = top + h * 0.10f, ph = h * 0.30f, pw = Math.max(2f, h * 0.075f);
        float px = h * 0.13f;
        rect.set(cx - px - pw / 2, py, cx - px + pw / 2, py + ph);
        c.drawRoundRect(rect, pw / 2, pw / 2, fill);
        rect.set(cx + px - pw / 2, py, cx + px + pw / 2, py + ph);
        c.drawRoundRect(rect, pw / 2, pw / 2, fill);

        // --- waves: 4 per side
        float oy = py + ph / 2;
        stroke.setStrokeWidth(Math.max(1.2f, h * 0.05f));
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            float ox = sd == 0 ? cx - px : cx + px;
            int wc = activityColor(s);
            // While data flows, a bright pulse runs outward through the lit arcs (~1 s per sweep).
            boolean ripple = s.inService && s.data && (s.in || s.out) && !s.inCall;
            int hot = ripple ? (int) ((android.os.SystemClock.uptimeMillis() / 220) % 5) : -1;
            for (int i = 0; i < 4; i++) {
                float r = h * 0.14f + i * h * 0.085f;
                rect.set(ox - r, oy - r, ox + r, oy + r);
                boolean lit = s.present && s.inService && s.level > i;
                int col = lit ? wc : dim;
                if (lit && ripple && i != hot) col = (wc & 0x00FFFFFF) | 0x8C000000;
                stroke.setColor(col);
                if (sd == 0) c.drawArc(rect, 145, 70, false, stroke);
                else c.drawArc(rect, -35, 70, false, stroke);
            }
            // no service: small cross by the panel
            if (s.present && !s.inService) {
                stroke.setColor(pick(0xFFFF453A, 0xFFC4281C));
                float k = h * 0.07f, xx = sd == 0 ? ox - h * 0.30f : ox + h * 0.30f, yy = oy + h * 0.30f;
                c.drawLine(xx - k, yy - k, xx + k, yy + k, stroke);
                c.drawLine(xx - k, yy + k, xx + k, yy - k, stroke);
            }
        }

        // --- dBm under each wave fan, beside the tower legs
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            if (!s.present || (s.dbm == null && s.sinr == null)) continue;
            float tw = underWidth(s);
            float mx = sd == 0 ? cx - h * 0.40f : cx + h * 0.40f;
            float x = mx - tw / 2f, y = top + h * 0.80f;
            text.setTextSize(dbmText());
            if (s.dbm != null) {
                text.setColor(color);
                c.drawText(s.dbm, x, y, text);
                x += text.measureText(s.dbm);
            }
            if (s.sinr != null) {
                if (s.dbm != null) {
                    text.setColor((color & 0x00FFFFFF) | 0x80000000);
                    c.drawText("\u2502", x, y, text);
                    x += text.measureText("\u2502");
                }
                text.setColor(s.sinrColor);
                c.drawText(s.sinr, x, y, text);
                x += text.measureText(s.sinr);
                text.setTextSize(dbmText() * 0.7f);
                text.setColor((color & 0x00FFFFFF) | 0x99000000);
                c.drawText("dB", x, y, text);
            }
        }

        // --- labels
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            if (!s.present) continue;
            boolean left = sd == 0;
            float edge = left ? lw0 : cx + coreHalf() + gap();
            float y1 = top + bigText() * 0.82f;
            // line 1: network + small SIM number
            text.setColor(color);
            text.setTextSize(bigText());
            String net = s.net != null ? s.net : "?";
            float nw = text.measureText(net);
            text.setTextSize(smallText());
            float sw1 = s.opLetter != null ? badgeR() * 2 + 2 : text.measureText(String.valueOf(sd + 1));
            float x = left ? edge - nw - sw1 - 1 : edge;
            text.setTextSize(bigText());
            c.drawText(net, x, y1, text);
            if (s.opLetter != null) {
                float br = badgeR(), bx = x + nw + 2 + br, by = y1 - bigText() * 0.36f;
                fill.setColor(s.opColor);
                c.drawCircle(bx, by, br, fill);
                text.setTextSize(br * 1.45f);
                text.setColor(0xFFFFFFFF);
                float lw = text.measureText(s.opLetter);
                c.drawText(s.opLetter, bx - lw / 2f, by + br * 0.52f, text);
                text.setColor(color);
            } else {
                text.setTextSize(smallText());
                c.drawText(String.valueOf(sd + 1), x + nw + 1, y1 + smallText() * 0.35f, text);
            }
            // line 2: band (blue)
            float y2 = y1 + smallText() * 1.08f;
            if (s.band != null || s.dist != null) {
                text.setTextSize(smallText());
                float lw2 = line2Width(s);
                float bx = left ? edge - lw2 : edge;
                text.setColor(bandColor);
                if (s.band != null) {
                    c.drawText(s.band, bx, y2, text);
                    bx += text.measureText(s.band);
                }
                if (s.dist != null) {
                    if (s.band != null) {
                        text.setColor((color & 0x00FFFFFF) | 0x80000000);
                        c.drawText(SEP, bx, y2, text);
                        bx += text.measureText(SEP);
                    }
                    text.setColor(bandColor);
                    c.drawText(s.dist, bx, y2, text);
                }
            }
            // line 3: voice type, then ↓↑ on the data SIM
            float y3 = y2 + smallText() * 1.0f;
            float vw = s.voice != null ? text.measureText(s.voice) : 0;
            float aw = s.data ? arrowsWidth() : 0;
            float g = s.voice != null && s.data ? smallText() * 0.3f : 0;
            float x0 = left ? edge - (vw + g + aw) : edge;
            if (s.voice != null) {
                text.setColor(voColor);
                c.drawText(s.voice, x0, y3, text);
            }
            if (s.data) {
                drawArrows(c, x0 + vw + g, y3 - smallText() * 0.8f, aw, smallText() * 0.85f,
                        s.in ? color : dim, s.out ? color : dim);
            }
        }
    }

    @Override
    public void draw(Canvas c) {
        super.draw(c);
        for (Side s : sides) {
            if (s.inService && s.data && (s.in || s.out) && !s.inCall && isShown()) {
                postInvalidateDelayed(110);   // ~9 fps: smooth enough, light on battery
                break;
            }
        }
    }

    /** ↓ then ↑, side by side, in a w×h box. */
    private void drawArrows(Canvas c, float x, float y, float w, float h, int downColor, int upColor) {
        float aw = w * 0.45f;
        // down arrow
        fill.setColor(downColor);
        path.reset();
        path.moveTo(x, y + h * 0.45f);
        path.lineTo(x + aw, y + h * 0.45f);
        path.lineTo(x + aw / 2, y + h);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(downColor);
        stroke.setStrokeWidth(Math.max(1f, aw * 0.28f));
        c.drawLine(x + aw / 2, y, x + aw / 2, y + h * 0.5f, stroke);
        // up arrow
        float ux = x + w - aw;
        fill.setColor(upColor);
        path.reset();
        path.moveTo(ux, y + h * 0.55f);
        path.lineTo(ux + aw, y + h * 0.55f);
        path.lineTo(ux + aw / 2, y);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(upColor);
        c.drawLine(ux + aw / 2, y + h * 0.5f, ux + aw / 2, y + h, stroke);
    }
}
