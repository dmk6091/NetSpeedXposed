package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * One icon for both SIMs: a lattice tower with antenna panels, SIM 1's signal as waves on the
 * left and SIM 2's on the right (4 arcs = 4 bars; lit = signal, faint = missing). Next to
 * each side: the network that SIM is on (4G+ / LTE / 5G) with a small SIM number, its voice
 * type (VoLTE / VoNR / VoWiFi) and, on the SIM carrying mobile data, ↓↑ arrows that light up
 * with traffic plus the level as "3/4".
 */
final class SignalTowerView extends View {

    /** What one side shows. */
    static final class Side {
        boolean present;     // a SIM in this slot
        boolean inService;
        int level = -1;      // 0..4
        String net;          // "4G+", "LTE", "5G" ...
        String voice;        // "VoLTE" ...
        boolean data;        // carries mobile data
        boolean in, out;     // data flowing

        boolean same(Side o) {
            return o != null && present == o.present && inService == o.inService && level == o.level
                    && eq(net, o.net) && eq(voice, o.voice) && data == o.data && in == o.in && out == o.out;
        }

        Side copy() {
            Side s = new Side();
            s.present = present; s.inService = inService; s.level = level; s.net = net;
            s.voice = voice; s.data = data; s.in = in; s.out = out;
            return s;
        }

        private static boolean eq(String a, String b) {
            return a == null ? b == null : a.equals(b);
        }
    }

    private final Side[] sides = {new Side(), new Side()};
    private int color = 0xFFFFFFFF, voColor = 0xFF34C759;
    private float textPx = 20f;
    private float sizeScale = 1f;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();

    SignalTowerView(Context ctx) {
        super(ctx);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Returns true when something changed (and a redraw / relayout was requested). */
    boolean update(Side s1, Side s2, int color, float textPx, Typeface tf, float scale) {
        boolean layout = textPx != this.textPx || scale != sizeScale || (tf != null && tf != text.getTypeface())
                || !eqStr(s1.net, sides[0].net) || !eqStr(s2.net, sides[1].net)
                || !eqStr(s1.voice, sides[0].voice) || !eqStr(s2.voice, sides[1].voice)
                || s1.data != sides[0].data || s2.data != sides[1].data
                || s1.present != sides[0].present || s2.present != sides[1].present;
        boolean changed = layout || color != this.color || !s1.same(sides[0]) || !s2.same(sides[1]);
        if (!changed) return false;
        sides[0] = s1.copy();
        sides[1] = s2.copy();
        this.color = color;
        this.textPx = textPx;
        this.sizeScale = scale;
        if (tf != null) text.setTypeface(Typeface.create(tf, Typeface.BOLD));
        // Green voice label on a dark bar, darker green on a light one.
        float lum = (0.299f * ((color >> 16) & 0xFF) + 0.587f * ((color >> 8) & 0xFF) + 0.114f * (color & 0xFF)) / 255f;
        voColor = lum > 0.5f ? 0xFF34C759 : 0xFF1E8E3E;
        if (layout) requestLayout();
        invalidate();
        return true;
    }

    private static boolean eqStr(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    // ------------------------------------------------------------ geometry

    private float h() {
        return textPx * 2.05f * sizeScale;          // as tall as two text lines
    }

    private float bigText() {
        return textPx * 0.95f;
    }

    private float smallText() {
        return textPx * 0.58f;
    }

    /** Half-width of the tower + waves block. */
    private float coreHalf() {
        float h = h();
        return h * 0.56f;
    }

    private float labelWidth(int i) {
        Side s = sides[i];
        if (!s.present) return 0;
        text.setTextSize(bigText());
        float w = s.net != null ? text.measureText(s.net) : text.measureText("?");
        text.setTextSize(smallText());
        w += text.measureText("1") + 1;
        float w2 = 0;
        if (s.voice != null) w2 = text.measureText(s.voice);
        float w3 = s.data ? text.measureText(levelText(s)) + arrowsWidth() + smallText() * 0.3f : 0;
        return Math.max(w, Math.max(w2, w3));
    }

    private float arrowsWidth() {
        return smallText() * 1.3f;
    }

    private String levelText(Side s) {
        return s.level >= 0 ? s.level + "/4" : "?/4";
    }

    private float gap() {
        return textPx * 0.18f;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float w = labelWidth(0) + gap() + 2 * coreHalf() + gap() + labelWidth(1);
        int hh = (int) Math.ceil(h());
        setMeasuredDimension((int) Math.ceil(w) + 2, resolveSize(hh, hSpec));
    }

    // ------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        float h = h();
        float top = (getHeight() - h) / 2f;
        float lw0 = labelWidth(0);
        float cx = lw0 + gap() + coreHalf();
        int dim = (color & 0x00FFFFFF) | 0x4D000000;

        // --- tower
        float sw = Math.max(1.2f, h * 0.045f);
        stroke.setStrokeWidth(sw);
        stroke.setColor(color);
        fill.setColor(color);
        float bottom = top + h - sw / 2;
        float apex = top + h * 0.20f;
        float foot = h * 0.17f;
        c.drawLine(cx, top + sw / 2, cx, bottom, stroke);                 // mast
        c.drawLine(cx, apex, cx - foot, bottom, stroke);                   // legs
        c.drawLine(cx, apex, cx + foot, bottom, stroke);
        stroke.setStrokeWidth(Math.max(1f, sw * 0.6f));
        int n = 3;
        for (int i = 0; i < n; i++) {                                     // lattice
            float y0 = apex + (bottom - apex) * (i + 0.15f) / n, y1 = apex + (bottom - apex) * (i + 1) / n;
            float x0 = foot * (y0 - apex) / (bottom - apex), x1 = foot * (y1 - apex) / (bottom - apex);
            c.drawLine(cx - x0, y0, cx + x1, y1, stroke);
            c.drawLine(cx + x0, y0, cx - x1, y1, stroke);
            c.drawLine(cx - x1, y1, cx + x1, y1, stroke);
        }
        // antenna panels
        float py = top + h * 0.10f, ph = h * 0.30f, pw = Math.max(2f, h * 0.075f);
        float px = h * 0.13f;
        rect.set(cx - px - pw / 2, py, cx - px + pw / 2, py + ph);
        c.drawRoundRect(rect, pw / 2, pw / 2, fill);
        rect.set(cx + px - pw / 2, py, cx + px + pw / 2, py + ph);
        c.drawRoundRect(rect, pw / 2, pw / 2, fill);

        // --- waves: 4 per side
        float oy = py + ph / 2;
        stroke.setStrokeWidth(Math.max(1.2f, h * 0.05f));
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            float ox = sd == 0 ? cx - px : cx + px;
            for (int i = 0; i < 4; i++) {
                float r = h * 0.14f + i * h * 0.085f;
                rect.set(ox - r, oy - r, ox + r, oy + r);
                boolean lit = s.present && s.inService && s.level > i;
                stroke.setColor(lit ? color : dim);
                if (sd == 0) c.drawArc(rect, 145, 70, false, stroke);
                else c.drawArc(rect, -35, 70, false, stroke);
            }
            // no service: small cross by the panel
            if (s.present && !s.inService) {
                stroke.setColor(color);
                float k = h * 0.07f, xx = sd == 0 ? ox - h * 0.30f : ox + h * 0.30f, yy = oy + h * 0.30f;
                c.drawLine(xx - k, yy - k, xx + k, yy + k, stroke);
                c.drawLine(xx - k, yy + k, xx + k, yy - k, stroke);
            }
        }

        // --- labels
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            if (!s.present) continue;
            boolean left = sd == 0;
            float edge = left ? lw0 : cx + coreHalf() + gap();
            float y1 = top + bigText() * 0.82f;
            // line 1: network + small SIM number
            text.setColor(color);
            text.setTextSize(bigText());
            String net = s.net != null ? s.net : "?";
            float nw = text.measureText(net);
            text.setTextSize(smallText());
            float sw1 = text.measureText(String.valueOf(sd + 1));
            float x = left ? edge - nw - sw1 - 1 : edge;
            text.setTextSize(bigText());
            c.drawText(net, x, y1, text);
            text.setTextSize(smallText());
            c.drawText(String.valueOf(sd + 1), x + nw + 1, y1 + smallText() * 0.35f, text);
            // line 2: voice type
            float y2 = y1 + smallText() * 1.05f;
            if (s.voice != null) {
                text.setColor(voColor);
                float vw = text.measureText(s.voice);
                c.drawText(s.voice, left ? edge - vw : edge, y2, text);
            }
            // line 3 (data SIM): ↓↑ + level
            if (s.data) {
                float y3 = y2 + smallText() * 1.0f;
                String lv = levelText(s);
                float lvw = text.measureText(lv);
                float aw = arrowsWidth();
                float total = aw + smallText() * 0.3f + lvw;
                float x0 = left ? edge - total : edge;
                drawArrows(c, x0, y3 - smallText() * 0.8f, aw, smallText() * 0.85f,
                        s.in ? color : dim, s.out ? color : dim);
                text.setColor(color);
                c.drawText(lv, x0 + aw + smallText() * 0.3f, y3, text);
            }
        }
    }

    /** ↓ then ↑, side by side, in a w×h box. */
    private void drawArrows(Canvas c, float x, float y, float w, float h, int downColor, int upColor) {
        float aw = w * 0.45f;
        // down arrow
        fill.setColor(downColor);
        path.reset();
        path.moveTo(x, y + h * 0.45f);
        path.lineTo(x + aw, y + h * 0.45f);
        path.lineTo(x + aw / 2, y + h);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(downColor);
        stroke.setStrokeWidth(Math.max(1f, aw * 0.28f));
        c.drawLine(x + aw / 2, y, x + aw / 2, y + h * 0.5f, stroke);
        // up arrow
        float ux = x + w - aw;
        fill.setColor(upColor);
        path.reset();
        path.moveTo(ux, y + h * 0.55f);
        path.lineTo(ux + aw, y + h * 0.55f);
        path.lineTo(ux + aw / 2, y);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(upColor);
        c.drawLine(ux + aw / 2, y + h * 0.5f, ux + aw / 2, y + h, stroke);
    }
}
