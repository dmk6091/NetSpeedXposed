package com.netspeed.xposed;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/**
 * One icon for both SIMs: a lattice tower with antenna panels, SIM 1's signal as waves on the
 * left and SIM 2's on the right (4 arcs = 4 bars; lit = signal, faint = missing). Next to
 * each side: the network that SIM is on (4G+ / LTE / 5G) with a small SIM number, its voice
 * type (VoLTE / VoNR / VoWiFi) and, on the SIM carrying mobile data, ↓↑ arrows that light up
 * with traffic plus the level as "3/4".
 */
final class SignalTowerView extends View {

    /** What one side shows. */
    static final class Side {
        boolean present;     // a SIM in this slot
        boolean inService;
        int level = -1;      // 0..4
        String net;          // "4G+", "LTE", "5G" ...
        String band;         // "n78", "B1" ...
        String voice;        // "VoLTE" ...
        boolean data;        // carries mobile data
        boolean in, out;     // data flowing
        boolean inCall;      // a call on this SIM
        String dbm;          // "-100", drawn under the wave fan (null = none)
        String dist;         // "1.0km", "≈600m" on the band line (null = none)
        String sinr;         // "13" (dB), under the fan after the dBm (null = none)
        int sinrColor;
        String opLetter;     // operator badge letter ("J"), null = show SIM number
        int opColor;
        String tag;          // "E" = NetSwitch holds this SIM on 4G (green eco, amber otherwise)
        int tagColor;

        boolean same(Side o) {
            return o != null && present == o.present && inService == o.inService && level == o.level
                    && eq(net, o.net) && eq(band, o.band) && eq(voice, o.voice) && data == o.data && in == o.in && out == o.out && inCall == o.inCall && eq(dbm, o.dbm) && eq(dist, o.dist) && eq(sinr, o.sinr) && sinrColor == o.sinrColor && eq(opLetter, o.opLetter) && opColor == o.opColor && eq(tag, o.tag) && tagColor == o.tagColor;
        }

        Side copy() {
            Side s = new Side();
            s.present = present; s.inService = inService; s.level = level; s.net = net; s.band = band;
            s.voice = voice; s.data = data; s.in = in; s.out = out; s.inCall = inCall; s.dbm = dbm; s.opLetter = opLetter; s.dist = dist; s.sinr = sinr; s.sinrColor = sinrColor; s.opColor = opColor; s.tag = tag; s.tagColor = tagColor;
            return s;
        }

        private static boolean eq(String a, String b) {
            return a == null ? b == null : a.equals(b);
        }
    }

    private final Side[] sides = {new Side(), new Side()};
    private int color = 0xFFFFFFFF, voColor = 0xFF34C759, bandColor = 0xFF78BEFF;
    private float textPx = 20f;
    private float sizeScale = 1f;
    private boolean darkBar = true;

    /** Bright colour on a dark bar, deeper shade on a light one. */
    private int pick(int bright, int deep) {
        return darkBar ? bright : deep;
    }

    /** Wave colour for what this SIM is doing now. */
    private int activityColor(Side s) {
        if (s.inCall) return pick(0xFFFF9F0A, 0xFFC46A00);                 // call: orange
        if (s.data && s.in && s.out) return pick(0xFF64D2FF, 0xFF0086A8);  // both ways: cyan
        if (s.data && s.in) return pick(0xFF34C759, 0xFF1E8E3E);           // download: green
        if (s.data && s.out) return pick(0xFF0A84FF, 0xFF0A60C0);          // upload: blue
        if (s.data) return color;                                          // data SIM, idle
        return pick(0xFF8EA4C8, 0xFF5A6E90);                               // standby: grey-blue
    }

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();

    SignalTowerView(Context ctx) {
        super(ctx);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Returns true when something changed (and a redraw / relayout was requested). */
    boolean update(Side s1, Side s2, int color, float textPx, Typeface tf, float scale) {
        boolean layout = textPx != this.textPx || scale != sizeScale || (tf != null && tf != text.getTypeface())
                || !eqStr(s1.net, sides[0].net) || !eqStr(s2.net, sides[1].net)
                || !eqStr(s1.band, sides[0].band) || !eqStr(s2.band, sides[1].band)
                || !eqStr(s1.voice, sides[0].voice) || !eqStr(s2.voice, sides[1].voice)
                || !eqStr(s1.sinr, sides[0].sinr) || !eqStr(s2.sinr, sides[1].sinr)
                || !eqStr(s1.dist, sides[0].dist) || !eqStr(s2.dist, sides[1].dist)
                || !eqStr(s1.tag, sides[0].tag) || !eqStr(s2.tag, sides[1].tag) || !eqStr(s1.opLetter, sides[0].opLetter) || !eqStr(s2.opLetter, sides[1].opLetter)
                || !eqStr(s1.dbm, sides[0].dbm) || !eqStr(s2.dbm, sides[1].dbm)
                || s1.data != sides[0].data || s2.data != sides[1].data
                || s1.present != sides[0].present || s2.present != sides[1].present;
        boolean changed = layout || color != this.color || !s1.same(sides[0]) || !s2.same(sides[1]);
        if (!changed) return false;
        sides[0] = s1.copy();
        sides[1] = s2.copy();
        this.color = color;
        this.textPx = textPx;
        this.sizeScale = scale;
        if (tf != null) text.setTypeface(Typeface.create(tf, Typeface.BOLD));
        // Green voice label on a dark bar, darker green on a light one.
        float lum = (0.299f * ((color >> 16) & 0xFF) + 0.587f * ((color >> 8) & 0xFF) + 0.114f * (color & 0xFF)) / 255f;
        darkBar = lum > 0.5f;
        voColor = lum > 0.5f ? 0xFF34C759 : 0xFF1E8E3E;
        bandColor = lum > 0.5f ? 0xFF78BEFF : 0xFF0A5BC4;
        if (layout) requestLayout();
        invalidate();
        return true;
    }

    private static boolean eqStr(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    // ------------------------------------------------------------ geometry

    private float h() {
        return textPx * 2.05f * sizeScale;          // as tall as two text lines
    }

    private float bigText() {
        return textPx * 0.95f * sizeScale;
    }

    private float smallText() {
        return textPx * 0.70f * sizeScale;
    }

    /** Half-width of the tower + waves block. */
    private float coreHalf() {
        float h = h();
        float half = h * 0.56f;
        // room for the dBm under each fan, centred 0.40 h from the mast
        text.setTextSize(dbmText());
        for (Side s : sides) {
            if (s.present && (s.dbm != null || s.sinr != null)) half = Math.max(half, h * LEG_CLEAR + underWidth(s) + 1);
        }
        return half;
    }

    /** Distance from the mast the under-fan numbers keep, so they never touch the legs. */
    private static final float LEG_CLEAR = 0.17f;

    private float dbmText() {
        return textPx * 0.64f * sizeScale;
    }

    private float labelWidth(int i) {
        Side s = sides[i];
        if (!s.present) return 0;
        text.setTextSize(bigText());
        float w = s.net != null ? text.measureText(s.net) : text.measureText("?");
        text.setTextSize(smallText());
        w += (s.opLetter != null ? badgeR() * 2 + 2 : text.measureText("1")) + 1 + tagWidth(s);
        float w2 = line2Width(s);
        float w3 = (s.voice != null ? text.measureText(s.voice) : 0)
                + (s.data ? arrowsWidth() + (s.voice != null ? smallText() * 0.3f : 0) : 0);
        return Math.max(w, Math.max(w2, w3));
    }

    /** Band line: "n78", then (with a distance) a dotted line + pin and "1.0km". */
    private static final String SEP = " \u2502 ";

    private float line2Width(Side s) {
        text.setTextSize(smallText());
        float w = s.band != null ? text.measureText(s.band) : 0;
        if (s.dist != null) w += (w > 0 ? text.measureText(SEP) : 0) + text.measureText(s.dist);
        return w;
    }

    /** Width of the stacked "-99" over "13dB" under a side. */
    private float underWidth(Side s) {
        text.setTextSize(dbmText());
        float w = 0;
        if (s.dbm != null) w = text.measureText(s.dbm);
        if (s.sinr != null) {
            float w2 = text.measureText(s.sinr);
            text.setTextSize(dbmText() * 0.7f);
            w2 += text.measureText("dB");
            w = Math.max(w, w2);
        }
        return w;
    }

    private float tagWidth(Side s) {
        if (s.tag == null) return 0;
        text.setTextSize(smallText());
        return text.measureText(s.tag) + 2;
    }

    private float badgeR() {
        return smallText() * 0.62f;
    }

    /** Operator disc: brand-ish colour with its initial (a plain letter, not the operator's logo). */
    static Object[] operatorBadge(String name, String mccMnc) {
        String n = name == null ? "" : name.toLowerCase(java.util.Locale.US);
        if (n.contains("jio")) return new Object[]{"J", 0xFF0A3D91};
        if (n.contains("airtel")) return new Object[]{"A", 0xFFE40000};
        if (n.contains("vodafone") || n.contains("idea") || n.equals("vi") || n.startsWith("vi ")) return new Object[]{"V", 0xFFE60000};
        if (n.contains("bsnl")) return new Object[]{"B", 0xFFF57C00};
        if (n.contains("mtnl")) return new Object[]{"M", 0xFF1565C0};
        if (mccMnc != null && mccMnc.startsWith("405-8")) return new Object[]{"J", 0xFF0A3D91};
        if (n.isEmpty()) return null;
        return new Object[]{n.substring(0, 1).toUpperCase(java.util.Locale.US), 0xFF607D8B};
    }

    private float arrowsWidth() {
        return smallText() * 1.3f;
    }

    private String levelText(Side s) {
        return s.level >= 0 ? s.level + "/4" : "?/4";
    }

    private float gap() {
        return textPx * 0.18f;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float w = labelWidth(0) + gap() + 2 * coreHalf() + gap() + labelWidth(1);
        int hh = (int) Math.ceil(h());
        setMeasuredDimension((int) Math.ceil(w) + 2, resolveSize(hh, hSpec));
    }

    // ------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        float h = h();
        float top = (getHeight() - h) / 2f;
        float lw0 = labelWidth(0);
        float cx = lw0 + gap() + coreHalf();
        int dim = (color & 0x00FFFFFF) | 0x4D000000;

        // --- a real mast: tapered red / white pole, two railed platforms, antenna panels, whip + beacon
        float sw = Math.max(1.2f, h * 0.045f);
        int red = pick(0xFFFF3B30, 0xFFC62828);
        int light = color;                       // white on a dark bar, dark grey on a light one
        float bottom = top + h - sw / 2;
        float ptop = top + h * 0.22f;
        float wt = h * 0.035f, wb = h * 0.08f;
        // whip + beacon
        stroke.setColor(light);
        stroke.setStrokeWidth(Math.max(1f, sw * 0.6f));
        c.drawLine(cx, top + sw * 1.5f, cx, ptop, stroke);
        fill.setColor(red);
        c.drawCircle(cx, top + sw * 1.2f, sw * 1.2f, fill);
        // tapered pole in 5 bands
        int nb = 5;
        for (int i = 0; i < nb; i++) {
            float y0 = ptop + (bottom - ptop) * i / nb, y1 = ptop + (bottom - ptop) * (i + 1) / nb;
            float w0 = wt + (wb - wt) * i / nb, w1 = wt + (wb - wt) * (i + 1) / nb;
            path.reset();
            path.moveTo(cx - w0, y0);
            path.lineTo(cx + w0, y0);
            path.lineTo(cx + w1, y1);
            path.lineTo(cx - w1, y1);
            path.close();
            fill.setColor(i % 2 == 0 ? red : light);
            c.drawPath(path, fill);
        }
        // platforms with railing
        stroke.setColor(red);
        stroke.setStrokeWidth(Math.max(1f, sw * 0.8f));
        rect.set(cx - h * 0.17f, top + h * 0.27f, cx + h * 0.17f, top + h * 0.37f);
        c.drawOval(rect, stroke);
        rect.set(cx - h * 0.12f, top + h * 0.62f, cx + h * 0.12f, top + h * 0.70f);
        c.drawOval(rect, stroke);
        // antenna panels: left = SIM 1, right = SIM 2 (coloured by what that SIM is doing), front = spare
        float pw = Math.max(2.5f, h * 0.065f), ph = h * 0.26f, px = h * 0.15f, py = top + h * 0.10f;
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            int pc = s.present && s.inService ? activityColor(s) : dim;
            fill.setColor(pc);
            float ox = sd == 0 ? cx - px : cx + px;
            rect.set(ox - pw / 2, py, ox + pw / 2, py + ph);
            c.drawRoundRect(rect, pw / 2, pw / 2, fill);
            // a smaller panel on the lower platform
            float lx = sd == 0 ? cx - h * 0.115f : cx + h * 0.115f;
            rect.set(lx - pw * 0.4f, top + h * 0.50f, lx + pw * 0.4f, top + h * 0.50f + ph * 0.7f);
            c.drawRoundRect(rect, pw * 0.4f, pw * 0.4f, fill);
            // no service: small cross by the panel
            if (s.present && !s.inService) {
                stroke.setColor(pick(0xFFFF453A, 0xFFC4281C));
                stroke.setStrokeWidth(Math.max(1.2f, h * 0.05f));
                float k = h * 0.06f, xx = sd == 0 ? cx - h * 0.33f : cx + h * 0.33f, yy = top + h * 0.20f;
                c.drawLine(xx - k, yy - k, xx + k, yy + k, stroke);
                c.drawLine(xx - k, yy + k, xx + k, yy - k, stroke);
            }
        }
        fill.setColor(color);
        fill.setColor(light);
        rect.set(cx - pw / 2, py + h * 0.02f, cx + pw / 2, py + ph + h * 0.02f);
        c.drawRoundRect(rect, pw / 2, pw / 2, fill);

        // --- dBm above SINR, stacked beside the mast (SIM 1 left, SIM 2 right)
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            if (!s.present || (s.dbm == null && s.sinr == null)) continue;
            float tw = underWidth(s);
            float x = sd == 0 ? cx - h * LEG_CLEAR - tw : cx + h * LEG_CLEAR;
            text.setTextSize(dbmText());
            if (s.dbm != null) {
                text.setColor(color);
                c.drawText(s.dbm, x, top + h * 0.60f, text);
            }
            if (s.sinr != null) {
                float y = top + h * 0.96f;
                text.setColor(s.sinrColor);
                c.drawText(s.sinr, x, y, text);
                float x2 = x + text.measureText(s.sinr);
                text.setTextSize(dbmText() * 0.7f);
                text.setColor((color & 0x00FFFFFF) | 0x99000000);
                c.drawText("dB", x2, y, text);
            }
        }

        // --- labels
        for (int sd = 0; sd < 2; sd++) {
            Side s = sides[sd];
            if (!s.present) continue;
            boolean left = sd == 0;
            float edge = left ? lw0 : cx + coreHalf() + gap();
            float y1 = top + bigText() * 0.82f;
            // line 1: network + small SIM number
            text.setColor(color);
            text.setTextSize(bigText());
            String net = s.net != null ? s.net : "?";
            float nw = text.measureText(net);
            text.setTextSize(smallText());
            float sw1 = s.opLetter != null ? badgeR() * 2 + 2 : text.measureText(String.valueOf(sd + 1));
            sw1 += tagWidth(s);
            float x = left ? edge - nw - sw1 - 1 : edge;
            text.setTextSize(bigText());
            c.drawText(net, x, y1, text);
            if (s.opLetter != null) {
                float br = badgeR(), bx = x + nw + 2 + br, by = y1 - bigText() * 0.36f;
                fill.setColor(s.opColor);
                c.drawCircle(bx, by, br, fill);
                text.setTextSize(br * 1.45f);
                text.setColor(0xFFFFFFFF);
                float lw = text.measureText(s.opLetter);
                c.drawText(s.opLetter, bx - lw / 2f, by + br * 0.52f, text);
                text.setColor(color);
                if (s.tag != null) {
                    text.setTextSize(smallText());
                    text.setColor(s.tagColor);
                    c.drawText(s.tag, bx + br + 2, by + br * 0.52f, text);
                    text.setColor(color);
                }
            } else {
                text.setTextSize(smallText());
                c.drawText(String.valueOf(sd + 1), x + nw + 1, y1 + smallText() * 0.35f, text);
            }
            // line 2: band (blue)
            float y2 = y1 + smallText() * 1.08f;
            if (s.band != null || s.dist != null) {
                text.setTextSize(smallText());
                float lw2 = line2Width(s);
                float bx = left ? edge - lw2 : edge;
                text.setColor(bandColor);
                if (s.band != null) {
                    c.drawText(s.band, bx, y2, text);
                    bx += text.measureText(s.band);
                }
                if (s.dist != null) {
                    if (s.band != null) {
                        text.setColor((color & 0x00FFFFFF) | 0x80000000);
                        c.drawText(SEP, bx, y2, text);
                        bx += text.measureText(SEP);
                    }
                    text.setColor(bandColor);
                    c.drawText(s.dist, bx, y2, text);
                }
            }
            // line 3: voice type, then ↓↑ on the data SIM
            float y3 = y2 + smallText() * 1.0f;
            float vw = s.voice != null ? text.measureText(s.voice) : 0;
            float aw = s.data ? arrowsWidth() : 0;
            float g = s.voice != null && s.data ? smallText() * 0.3f : 0;
            float x0 = left ? edge - (vw + g + aw) : edge;
            if (s.voice != null) {
                text.setColor(voColor);
                c.drawText(s.voice, x0, y3, text);
            }
            if (s.data) {
                drawArrows(c, x0 + vw + g, y3 - smallText() * 0.8f, aw, smallText() * 0.85f,
                        s.in ? color : dim, s.out ? color : dim);
            }
        }
    }

    @Override
    public void draw(Canvas c) {
        super.draw(c);
        for (Side s : sides) {
            if (s.inService && s.data && (s.in || s.out) && !s.inCall && isShown()) {
                postInvalidateDelayed(110);   // ~9 fps: smooth enough, light on battery
                break;
            }
        }
    }

    /** ↓ then ↑, side by side, in a w×h box. */
    private void drawArrows(Canvas c, float x, float y, float w, float h, int downColor, int upColor) {
        float aw = w * 0.45f;
        // down arrow
        fill.setColor(downColor);
        path.reset();
        path.moveTo(x, y + h * 0.45f);
        path.lineTo(x + aw, y + h * 0.45f);
        path.lineTo(x + aw / 2, y + h);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(downColor);
        stroke.setStrokeWidth(Math.max(1f, aw * 0.28f));
        c.drawLine(x + aw / 2, y, x + aw / 2, y + h * 0.5f, stroke);
        // up arrow
        float ux = x + w - aw;
        fill.setColor(upColor);
        path.reset();
        path.moveTo(ux, y + h * 0.55f);
        path.lineTo(ux + aw, y + h * 0.55f);
        path.lineTo(ux + aw / 2, y);
        path.close();
        c.drawPath(path, fill);
        stroke.setColor(upColor);
        c.drawLine(ux + aw / 2, y + h * 0.5f, ux + aw / 2, y + h, stroke);
    }
}
