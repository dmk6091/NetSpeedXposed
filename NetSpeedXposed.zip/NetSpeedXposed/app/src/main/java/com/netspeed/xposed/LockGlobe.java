package com.netspeed.xposed;

import android.animation.ValueAnimator;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * A live Earth on the lock screen: day/night terminator, your location as a red dot, drag to
 * turn it, double-tap to bring your location back to the middle.
 */
final class LockGlobe extends View {
    private static final String TAG = "NetSpeedXposed: ";
    private static final int N_LO = 300, N_HI = 640;   // render resolution while dragging / at rest
    private static final long HOME_AFTER_MS = 10_000;

    static void install(ClassLoader cl) {
        try {
            Class<?> k = XposedHelpers.findClass("com.android.systemui.shade.NotificationShadeWindowView", cl);
            try {
                XposedBridge.hookAllMethods(k, "dispatchTouchEvent", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            if (rawTouch((MotionEvent) p.args[0])) p.setResult(true);
                        } catch (Throwable ignored) { }
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log(TAG + "lock globe touch hook failed: " + t);
            }
            XposedBridge.hookAllConstructors(k, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    final ViewGroup v = (ViewGroup) p.thisObject;
                    final int[] tries = {0};
                    Runnable r = new Runnable() {
                        @Override public void run() {
                            try {
                                if (attach(v)) return;
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + "lock globe attach failed: " + t);
                                return;
                            }
                            if (++tries[0] < 10) v.postDelayed(this, 1000);
                        }
                    };
                    v.postDelayed(r, 500);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "lock globe hook failed: " + t);
        }
    }

    private static boolean attach(ViewGroup root) {
        Context c = root.getContext();
        Cfg.init(c);
        if (root.findViewWithTag("netspeed_lockglobe") != null) return true;
        int id = root.getResources().getIdentifier("custom_overlay_container", "id", "com.android.systemui");
        ViewGroup host = id != 0 ? (ViewGroup) root.findViewById(id) : null;
        if (!(host instanceof FrameLayout)) {
            return false;
        }
        LockGlobe g = new LockGlobe(c);
        g.setTag("netspeed_lockglobe");
        int w = c.getResources().getDisplayMetrics().widthPixels;
        int h = c.getResources().getDisplayMetrics().heightPixels;
        int d = (int) (w * 0.90f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(d, d, android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL);
        lp.topMargin = (int) (h * 0.235f);
        host.addView(g, lp);
        sInstance = g;
        try {
            Sky sky = new Sky(c);
            sky.setTag("netspeed_lockglobe_sky");
            root.addView(sky, 0, new FrameLayout.LayoutParams(-1, -1));
            sky.setVisibility(GONE);
            g.backdrop = sky;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "lock sky failed: " + t);
        }
        XposedBridge.log(TAG + "lock globe added " + d + "px");
        return true;
    }

    // ---- state
    private static int[] sDay, sNight;
    private static int sW, sH;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final KeyguardManager km;
    private final PowerManager pm;
    private Bitmap bmp;
    private int[] px;
    private int curN = 0;
    private static LockGlobe sInstance;
    private View backdrop;
    private boolean grab;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final GestureDetector gd;
    private double homeLat = 18.65, homeLon = 73.74;
    private double lat0 = 18.65, lon0 = 73.74;
    private float lastX, lastY;
    private boolean dragging;
    private ValueAnimator back;
    private boolean sunDirty = true;
    private long lastRender;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            boolean on = keyguardShowing();
            setVisibility(on ? VISIBLE : GONE);
            if (backdrop != null) backdrop.setVisibility(on ? VISIBLE : GONE);
            if (on) {
                long now = System.currentTimeMillis();
                if (now - lastRender > 60_000 && !dragging) { render(); invalidate(); }
            }
            if (pm.isInteractive()) h.postDelayed(this, 2000);
        }
    };

    private final BroadcastReceiver rcv = new BroadcastReceiver() {
        @Override public void onReceive(Context cx, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                h.removeCallbacks(tick);
                setVisibility(GONE);
                if (backdrop != null) backdrop.setVisibility(GONE);
            } else {
                h.removeCallbacks(tick);
                refreshHome();
                h.post(tick);
            }
        }
    };

    private LockGlobe(Context c) {
        super(c);
        km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
        pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        setVisibility(GONE);
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) { goHome(); return true; }
            @Override public boolean onDown(MotionEvent e) { return true; }
        });
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_USER_PRESENT);
        c.registerReceiver(rcv, f);
        new Thread(() -> { loadTextures(c); h.post(() -> { render(); invalidate(); }); }, "lockglobe-tex").start();
        refreshHome();
        h.post(tick);
    }

    private boolean keyguardShowing() {
        try {
            return Cfg.b(Cfg.LOCK_GLOBE, Cfg.D_LOCK_GLOBE) && pm.isInteractive() && km.isKeyguardLocked();
        } catch (Throwable t) { return false; }
    }

    private void refreshHome() {
        try {
            android.location.Location l = TowerDb.myLocation(getContext());
            if (l != null) { homeLat = l.getLatitude(); homeLon = l.getLongitude(); }
        } catch (Throwable ignored) { }
        if (!dragging) { lat0 = homeLat; lon0 = homeLon; }
        sunDirty = true;
    }

    private static synchronized void loadTextures(Context c) {
        if (sDay != null) return;
        try {
            Context m = c.createPackageContext("com.netspeed.xposed", 0);
            Bitmap d = BitmapFactory.decodeStream(m.getAssets().open("earth_day.jpg"));
            Bitmap n = BitmapFactory.decodeStream(m.getAssets().open("earth_night.jpg"));
            sW = d.getWidth(); sH = d.getHeight();
            int[] a = new int[sW * sH];
            d.getPixels(a, 0, sW, 0, 0, sW, sH);
            int[] b = new int[sW * sH];
            Bitmap n2 = Bitmap.createScaledBitmap(n, sW, sH, true);
            n2.getPixels(b, 0, sW, 0, 0, sW, sH);
            sNight = b; sDay = a;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "lock globe textures failed: " + t);
        }
    }

    // ---- sun
    private static double[] sun(long ms) {
        double d = (ms - 946728000000L) / 86400000.0;
        double L = Math.toRadians(280.46 + 0.9856474 * d);
        double g = Math.toRadians(357.528 + 0.9856003 * d);
        double lam = L + Math.toRadians(1.915) * Math.sin(g) + Math.toRadians(0.02) * Math.sin(2 * g);
        double eps = Math.toRadians(23.439 - 0.0000004 * d);
        double dec = Math.asin(Math.sin(eps) * Math.sin(lam));
        double ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
        double gmst = Math.toRadians((280.46061837 + 360.98564736629 * d) % 360.0);
        double lon = ra - gmst;
        lon = Math.atan2(Math.sin(lon), Math.cos(lon));
        return new double[]{dec, lon};
    }

    // ---- render
    private void render() { render(N_HI); }

    private void render(int N) {
        lastRender = System.currentTimeMillis();
        if (sDay == null) return;
        if (curN != N || bmp == null) {
            bmp = Bitmap.createBitmap(N, N, Bitmap.Config.ARGB_8888);
            px = new int[N * N];
            curN = N;
        }
        double[] s = sun(lastRender);
        double sd = s[0], sl = s[1];
        double sinD = Math.sin(sd), cosD = Math.cos(sd);
        double p0 = Math.toRadians(lat0), l0 = Math.toRadians(lon0);
        double sp0 = Math.sin(p0), cp0 = Math.cos(p0);
        double half = N / 2.0;
        for (int y = 0; y < N; y++) {
            double v = (half - (y + 0.5)) / half;
            for (int x = 0; x < N; x++) {
                double u = ((x + 0.5) - half) / half;
                double r2 = u * u + v * v;
                if (r2 >= 1) { px[y * N + x] = 0; continue; }
                double z = Math.sqrt(1 - r2);
                double sinP = v * cp0 + z * sp0;
                if (sinP > 1) sinP = 1; else if (sinP < -1) sinP = -1;
                double phi = Math.asin(sinP);
                double lam = l0 + Math.atan2(u, z * cp0 - v * sp0);
                double cosP = Math.cos(phi);
                double dot = sinP * sinD + cosP * cosD * Math.cos(lam - sl);
                double fx = (Math.atan2(Math.sin(lam), Math.cos(lam)) / Math.PI + 1) * 0.5 * sW;
                double fy = (0.5 - phi / Math.PI) * sH;
                int ix = (int) fx; if (ix >= sW) ix = sW - 1; if (ix < 0) ix = 0;
                int iy = (int) fy; if (iy >= sH) iy = sH - 1; if (iy < 0) iy = 0;
                int di = sDay[iy * sW + ix], ni = sNight[iy * sW + ix];
                double w = (dot + 0.10) / 0.28;
                w = w < 0 ? 0 : w > 1 ? 1 : w;
                w = w * w * (3 - 2 * w);
                double shade = (0.72 + 0.28 * Math.max(0, Math.min(1, dot))) * (0.55 + 0.45 * Math.pow(z, 0.6));
                int r = (int) (((di >> 16 & 255) * shade) * w + ((ni >> 16 & 255) * 0.9 + 4) * (1 - w) * (0.6 + 0.4 * z));
                int g = (int) (((di >> 8 & 255) * shade) * w + ((ni >> 8 & 255) * 0.9 + 6) * (1 - w) * (0.6 + 0.4 * z));
                int b = (int) (((di & 255) * shade) * w + ((ni & 255) * 0.9 + 12) * (1 - w) * (0.6 + 0.4 * z));
                if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255;
                px[y * N + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        bmp.setPixels(px, 0, N, 0, 0, N, N);
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), hgt = getHeight();
        float cx = w / 2, cy = hgt / 2, R = Math.min(w, hgt) * 0.43f;
        // soft atmosphere
        p.setShader(new RadialGradient(cx, cy, R * 1.12f, new int[]{0x00000000, 0x00000000, 0x553A7BD8, 0x00000000},
                new float[]{0f, 0.88f, 0.94f, 1f}, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, R * 1.12f, p);
        p.setShader(null);
        if (bmp != null) cv.drawBitmap(bmp, null, new android.graphics.RectF(cx - R, cy - R, cx + R, cy + R), p);

        // location
        double p0 = Math.toRadians(lat0), l0 = Math.toRadians(lon0);
        double ph = Math.toRadians(homeLat), la = Math.toRadians(homeLon) - l0;
        double cosc = Math.sin(p0) * Math.sin(ph) + Math.cos(p0) * Math.cos(ph) * Math.cos(la);
        double ux = Math.cos(ph) * Math.sin(la);
        double uy = Math.cos(p0) * Math.sin(ph) - Math.sin(p0) * Math.cos(ph) * Math.cos(la);
        float dot = Math.max(3f, R * 0.045f);
        if (cosc >= 0) {
            float x = cx + (float) ux * R, y = cy - (float) uy * R;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x44FF2A2A);
            cv.drawCircle(x, y, dot * 2.6f, p);
            p.setColor(0xFFFFFFFF);
            cv.drawCircle(x, y, dot * 1.25f, p);
            p.setColor(0xFFFF2020);
            cv.drawCircle(x, y, dot, p);
        } else {
            double len = Math.hypot(ux, uy);
            if (len < 1e-6) { ux = 0; uy = -1; len = 1; }
            float x = cx + (float) (ux / len) * (R + dot * 1.2f), y = cy - (float) (uy / len) * (R + dot * 1.2f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xAAFF2020);
            Path t = new Path();
            float a = (float) Math.atan2(-(uy / len), ux / len);
            float s = dot * 1.5f;
            t.moveTo(x + (float) Math.cos(a) * s, y + (float) Math.sin(a) * s);
            t.lineTo(x + (float) Math.cos(a + 2.4f) * s, y + (float) Math.sin(a + 2.4f) * s);
            t.lineTo(x + (float) Math.cos(a - 2.4f) * s, y + (float) Math.sin(a - 2.4f) * s);
            t.close();
            cv.drawPath(t, p);
        }
    }

    // ---- touch: the shade window would otherwise swallow drags, so hand them over from its dispatch
    static boolean rawTouch(MotionEvent e) {
        LockGlobe g = sInstance;
        if (g == null) return false;
        return g.handleRaw(e);
    }

    private boolean handleRaw(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            grab = false;
            if (getVisibility() != VISIBLE || !isShown()) return false;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float cx = loc[0] + getWidth() / 2f, cy = loc[1] + getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) * 0.5f;
            if (Math.hypot(e.getRawX() - cx, e.getRawY() - cy) > r) return false;
            grab = true;
        }
        if (!grab) return false;
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        MotionEvent c = MotionEvent.obtain(e);
        c.setLocation(e.getRawX() - loc[0], e.getRawY() - loc[1]);
        onTouchEvent(c);
        c.recycle();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) grab = false;
        return true;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        gd.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                if (back != null) back.cancel();
                h.removeCallbacks(homeRunnable);
                dragging = true;
                lastX = e.getX(); lastY = e.getY();
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - lastX, dy = e.getY() - lastY;
                lastX = e.getX(); lastY = e.getY();
                double k = 180.0 / Math.PI / (Math.min(getWidth(), getHeight()) * 0.43);
                lon0 -= dx * k / Math.max(0.35, Math.cos(Math.toRadians(lat0)));
                lat0 = Math.max(-85, Math.min(85, lat0 + dy * k));
                while (lon0 > 180) lon0 -= 360;
                while (lon0 < -180) lon0 += 360;
                render(N_LO); invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                render(N_HI); invalidate();
                h.postDelayed(homeRunnable, HOME_AFTER_MS);
                return true;
        }
        return true;
    }

    private final Runnable homeRunnable = this::goHome;

    private void goHome() {
        h.removeCallbacks(homeRunnable);
        if (back != null) back.cancel();
        final double a0 = lat0;
        double dl = homeLon - lon0;
        while (dl > 180) dl -= 360;
        while (dl < -180) dl += 360;
        final double dlon = dl, startLon = lon0, dlat = homeLat - lat0;
        back = ValueAnimator.ofFloat(0f, 1f);
        back.setDuration(700);
        back.setInterpolator(new android.view.animation.DecelerateInterpolator());
        back.addUpdateListener(an -> {
            float f = (float) an.getAnimatedValue();
            lat0 = a0 + dlat * f;
            lon0 = startLon + dlon * f;
            render(f >= 1f ? N_HI : N_LO); invalidate();
        });
        back.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h.removeCallbacksAndMessages(null);
    }

    /** Milky Way backdrop, painted once from noise (no image needed). */
    static final class Sky extends View {
        private static Bitmap sBmp;
        private final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);

        Sky(Context c) {
            super(c);
            setBackgroundColor(0xFF03050E);
            if (sBmp == null) {
                final android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
                new Thread(() -> {
                    try {
                        Bitmap b = make(Math.max(360, dm.widthPixels * 5 / 9), Math.max(780, dm.heightPixels * 5 / 9));
                        sBmp = b;
                        XposedBridge.log(TAG + "lock sky ready " + b.getWidth() + "x" + b.getHeight());
                        post(this::invalidate);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "lock sky failed: " + t);
                    }
                }, "lockglobe-sky").start();
            }
        }

        @Override protected void onDraw(Canvas cv) {
            if (sBmp != null) cv.drawBitmap(sBmp, null, new android.graphics.Rect(0, 0, getWidth(), getHeight()), p);
        }

        private static float hash(int x, int y) {
            int n = x * 374761393 + y * 668265263;
            n = (n ^ (n >>> 13)) * 1274126177;
            n ^= n >>> 16;
            return (n & 0xFFFFFF) / (float) 0x1000000;
        }

        private static float noise(float x, float y) {
            int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
            float fx = x - xi, fy = y - yi;
            fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
            float a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
            return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy;
        }

        private static float fbm(float x, float y, int oct) {
            float v = 0, amp = 0.5f, sum = 0;
            for (int i = 0; i < oct; i++) {
                v += amp * noise(x, y);
                sum += amp;
                x *= 2.03f; y *= 2.03f; amp *= 0.5f;
            }
            return v / sum;
        }

        private static float band(float u, float v) {
            float d = u * 0.82f + v * 0.57f + 0.14f * (fbm(u * 2.2f + 9, v * 2.2f + 3, 3) - 0.5f);
            return (float) Math.exp(-(d * d) / (2 * 0.17f * 0.17f));
        }

        static Bitmap make(int w, int h) {
            int[] out = new int[w * h];
            for (int y = 0; y < h; y++) {
                float v = (float) y / h - 0.5f;
                for (int x = 0; x < w; x++) {
                    float u = ((float) x / w - 0.5f) * ((float) w / h);
                    float b = band(u, v);
                    float along = u * 0.57f - v * 0.82f;
                    b *= 0.55f + 0.75f / (1f + (float) Math.exp(along * 5f));      // brighter toward the lower-left core
                    float cloud = fbm(u * 5f + 40, v * 5f + 7, 5);
                    float dust = fbm(u * 8f + 11, v * 8f + 23, 5);
                    float dk = dust < 0.52f ? 0f : Math.min(1f, (dust - 0.52f) / 0.2f);
                    float I = b * (0.30f + 1.0f * cloud) * (1f - 0.85f * dk * Math.min(1f, b * 1.6f));
                    I = Math.max(0f, I);
                    float t = Math.min(1f, I * 1.25f);
                    float warm = Math.min(1f, Math.max(0f, (I - 0.35f) * 1.8f));
                    float r = 3 + (38 + 217 * warm) * t * 0.95f;
                    float g = 5 + (52 + 168 * warm) * t * 0.95f;
                    float bl = 14 + (118 + 50 * warm) * t * 0.95f;
                    // faint sky glow everywhere
                    r += 5; g += 7; bl += 14;
                    int ri = (int) Math.min(255, r), gi = (int) Math.min(255, g), bi = (int) Math.min(255, bl);
                    out[y * w + x] = 0xFF000000 | (ri << 16) | (gi << 8) | bi;
                }
            }
            Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bm.setPixels(out, 0, w, 0, 0, w, h);
            Canvas c = new Canvas(bm);
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            java.util.Random rnd = new java.util.Random(7);
            int placed = 0;
            for (int tries = 0; tries < 20000 && placed < 2600; tries++) {
                float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h;
                float u = (x / w - 0.5f) * ((float) w / h), v = y / h - 0.5f;
                float dens = 0.25f + 0.75f * band(u, v);
                if (rnd.nextFloat() > dens) continue;
                placed++;
                float m = rnd.nextFloat();
                float br = (float) Math.pow(m, 6) ;          // few bright, many faint
                int a = (int) (70 + 185 * br);
                int tint = rnd.nextInt(5);
                int col = tint == 0 ? 0xFFBBD0FF : tint == 1 ? 0xFFFFE6C0 : 0xFFFFFFFF;
                sp.setColor((a << 24) | (col & 0xFFFFFF));
                float rad = 0.55f + 1.5f * br;
                c.drawCircle(x, y, rad, sp);
                if (br > 0.45f) {
                    sp.setColor(((a / 4) << 24) | (col & 0xFFFFFF));
                    c.drawCircle(x, y, rad * 3f, sp);
                }
            }
            return bm;
        }
    }
}
