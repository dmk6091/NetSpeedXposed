package com.netspeed.xposed;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.HardwarePropertiesManager;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.Locale;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Two-row status bar.
 *
 *   Row 1 left : clock, CPU temp / battery temp, weather icon + temperature
 *   Row 1 right: net speed, VoLTE / VoNR icons, battery
 *   Row 2 left : notification icons (full width, no camera cutout in the way)
 *   Row 2 right: other system icons (Wi-Fi, signal, Bluetooth, location ...)
 *
 * The status bar is made taller by adding Cfg.i(Cfg.ROW2_H, Cfg.D_ROW2_H) to the height System UI
 * reports for its window, so apps automatically start below both rows.
 */
final class DualRow {

    private static final String TAG = "NetSpeedXposed: [dual] ";
    private static final String SYSTEMUI = "com.android.systemui";

    // ---------------------------------------------------------------- settings

    /** Master switch. false = normal one-row status bar. */
    static final boolean ENABLED = true;

    /** Height of the second row, in dp. */
    /** Gap between row 1's icons and row 2. */
    /**
     * How much taller than stock the whole status bar gets. Row 2 is tucked into the
     * stock height first (it's tall because of the camera cutout), so 0 is usually enough;
     * raise it if row 2 looks cut off at the bottom.
     */

    /** Status icons whose slot name contains one of these stay on row 1 (right). */
    static final String[] ROW1_SLOT_KEYWORDS = {"volte", "vonr", "vowifi", "ims", "mobile"};

    /** Show CPU temperature / battery temperature / weather on row 1. */
    /** true = net speed sits on row 1 after the weather; false = stays on the right. */

    /** How often temperatures are refreshed, in milliseconds. */
    static final long TEMP_INTERVAL_MS = 5_000;
    /** How often charging current / power is read. */
    static final long POWER_INTERVAL_MS = 2_000;

    /** Weather is also refreshed whenever OmniJaws updates; this is a fallback. */
    static final long WEATHER_INTERVAL_MS = 15 * 60_000;

    // ---------------------------------------------------------------- internals

    private static final Uri OMNI_WEATHER = Uri.parse("content://org.omnirom.omnijaws.provider/weather");
    private static final Uri OMNI_SETTINGS = Uri.parse("content://org.omnirom.omnijaws.provider/settings");
    private static final String OMNI_PKG = "org.omnirom.omnijaws";

    private static final String BAR_CLASS = "com.android.systemui.statusbar.phone.PhoneStatusBarView";
    private static final String BAR_UTILS = "com.android.internal.policy.SystemBarUtils";

    /** When true, the height hook returns the original (one-row) height. */
    private static volatile boolean sBypass = false;
    private static boolean sHeightLogged = false;
    private static final Map<String, Boolean> sLogOnce = new HashMap<>();

    /** Row-2 icon container and the icons in it that are shown on row 1 instead. */
    private static volatile ViewGroup sIconContainer;
    private static final Set<View> SKIP = Collections.newSetFromMap(new WeakHashMap<>());
    private static final ThreadLocal<List<View>> HIDDEN = new ThreadLocal<>();

    private DualRow() {}

    /** Skips drawing row-1 icons inside the row-2 container (they are drawn on row 1). */
    private static void hookIconDraw() {
        try {
            XposedHelpers.findAndHookMethod(ViewGroup.class, "dispatchDraw", Canvas.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.thisObject != sIconContainer) return;
                    List<View> hidden = new ArrayList<>();
                    synchronized (SKIP) {
                        for (View v : SKIP) {
                            if (v.getParent() == p.thisObject && v.getVisibility() == View.VISIBLE) {
                                try {
                                    XposedHelpers.callMethod(v, "setTransitionVisibility", View.INVISIBLE);
                                    hidden.add(v);
                                } catch (Throwable ignored) { }
                            }
                        }
                    }
                    HIDDEN.set(hidden);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.thisObject != sIconContainer) return;
                    List<View> o = HIDDEN.get();
                    HIDDEN.set(null);
                    if (o == null) return;
                    for (View v : o) {
                        try {
                            XposedHelpers.callMethod(v, "setTransitionVisibility", View.VISIBLE);
                        } catch (Throwable ignored) { }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "icon draw hook failed: " + t);
        }
    }

    static void install(ClassLoader cl) {
        if (!ENABLED) return;
        hookHeight("systemui");
        hookIconDraw();

        try {
            XposedHelpers.findAndHookMethod(BAR_CLASS, cl, "onFinishInflate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    final ViewGroup bar = (ViewGroup) p.thisObject;
                    // Run after every other onFinishInflate hook (net speed indicator included).
                    bar.post(() -> {
                        try {
                            build(bar);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "build failed: " + t);
                            XposedBridge.log(t);
                        }
                    });
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "onFinishInflate hook failed: " + t);
        }

        // System UI recalculates the layout on rotation / cutout changes; re-apply ours after.
        try {
            Class<?> bar = XposedHelpers.findClass(BAR_CLASS, cl);
            int n = XposedBridge.hookAllMethods(bar, "updateLayoutForCutout", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        applyRowHeights((ViewGroup) p.thisObject);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "re-layout failed: " + t);
                    }
                }
            }).size();
            XposedBridge.log(TAG + "updateLayoutForCutout hooks: " + n);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "updateLayoutForCutout hook failed: " + t);
        }
    }

    // ------------------------------------------------------------ status bar height

    /**
     * Makes the status bar Cfg.i(Cfg.ROW2_H, Cfg.D_ROW2_H) taller by changing the height values Android reads
     * from its resources (status_bar_height_default / _portrait / _landscape).
     * Hooking Resources works in both System UI and the system framework, unlike hooks
     * on SystemBarUtils, which Android 16 compiles inline so they never fire.
     */
    static void hookHeight(final String where) {
        if (!ENABLED) return;
        Resources sys = Resources.getSystem();
        final java.util.Set<Integer> ids = new java.util.HashSet<>();
        for (String n : new String[]{"status_bar_height_default", "status_bar_height_portrait",
                "status_bar_height_landscape", "status_bar_height"}) {
            int id = sys.getIdentifier(n, "dimen", "android");
            if (id != 0) ids.add(id);
        }
        if (ids.isEmpty()) {
            XposedBridge.log(TAG + "[" + where + "] status bar height resources not found");
            return;
        }
        XC_MethodHook add = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (sBypass || !(p.args[0] instanceof Integer) || !ids.contains(p.args[0])) return;
                Object r = p.getResult();
                Resources res = (Resources) p.thisObject;
                int extraDp = Cfg.i(Cfg.EXTRA, Cfg.D_EXTRA);
                if (extraDp <= 0) return;
                float extra = extraDp * res.getDisplayMetrics().density;
                if (r instanceof Integer) {
                    int h = (Integer) r;
                    if (h <= 0) return;
                    p.setResult(h + Math.round(extra));
                    logHeight(where, h, h + Math.round(extra));
                } else if (r instanceof Float) {
                    float h = (Float) r;
                    if (h <= 0) return;
                    p.setResult(h + extra);
                }
            }
        };
        int n = 0;
        for (String m : new String[]{"getDimensionPixelSize", "getDimensionPixelOffset", "getDimension"}) {
            try {
                XposedHelpers.findAndHookMethod(Resources.class, m, int.class, add);
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "[" + where + "] hook " + m + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "[" + where + "] height hooks: " + n + " ids: " + ids.size());
    }

    private static void logHeight(String where, int from, int to) {
        if (sHeightLogged) return;
        sHeightLogged = true;
        XposedBridge.log(TAG + "[" + where + "] status bar height " + from + " -> " + to);
    }

    /** Status bar height without our second row. */
    private static int row1Height(Context ctx) {
        sBypass = true;
        try {
            Class<?> c = XposedHelpers.findClass(BAR_UTILS, ctx.getClassLoader());
            java.lang.reflect.Method m = c.getDeclaredMethod("getStatusBarHeight", Context.class);
            m.setAccessible(true);
            return (Integer) m.invoke(null, ctx);
        } catch (Throwable t) {
            Resources sys = Resources.getSystem();
            int id = sys.getIdentifier("status_bar_height", "dimen", "android");
            return id != 0 ? sys.getDimensionPixelSize(id) : dp(sys, 28);
        } finally {
            sBypass = false;
        }
    }

    // ------------------------------------------------------------ layout

    private static View byId(View root, String name) {
        int id = root.getResources().getIdentifier(name, "id", SYSTEMUI);
        return id != 0 ? root.findViewById(id) : null;
    }

    private static void detach(View v) {
        if (v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    private static void build(ViewGroup bar) {
        if (bar.findViewWithTag("dual_row2") != null) return;
        Context ctx = bar.getContext();
        Cfg.init(ctx);
        if (!Cfg.b(Cfg.DUAL, Cfg.D_DUAL)) {
            XposedBridge.log(TAG + "two-row layout turned off in settings");
            return;
        }

        View contents = byId(bar, "status_bar_contents");
        View notifArea = byId(bar, "notification_icon_area");
        View statusIcons = byId(bar, "statusIcons");
        View clock = byId(bar, "clock");
        View systemIcons = byId(bar, "system_icons");
        XposedBridge.log(TAG + "views: contents=" + (contents != null)
                + " notifArea=" + (notifArea != null) + " statusIcons=" + (statusIcons != null)
                + " clock=" + (clock != null) + " systemIcons=" + (systemIcons != null)
                + " bar=" + bar.getClass().getSuperclass().getSimpleName());

        if (contents == null || !(bar instanceof FrameLayout)) {
            XposedBridge.log(TAG + "unexpected status bar layout, dual row not applied");
            return;
        }

        // ---- Row 2 container
        LinearLayout row2 = new LinearLayout(ctx);
        row2.setTag("dual_row2");
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(row2, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx.getResources(), Cfg.i(Cfg.ROW2_H, Cfg.D_ROW2_H)), Gravity.TOP));

        // Row 2 left: notification icons, taking all free width.
        if (notifArea != null) {
            detach(notifArea);
            row2.addView(notifArea, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        } else {
            row2.addView(new View(ctx), new LinearLayout.LayoutParams(0, 1, 1f));
        }

        // Row 2 right: the system icons (Wi-Fi, signal, Bluetooth, location ...).
        if (statusIcons != null) {
            detach(statusIcons);
            row2.addView(statusIcons, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
            statusIcons.setPaddingRelative(statusIcons.getPaddingStart(), statusIcons.getPaddingTop(),
                    0, statusIcons.getPaddingBottom());
        }

        applyRowHeights(bar);
        // Row 1 items are measured, so re-place row 2 whenever the bar lays out again.
        bar.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) ->
                v.post(() -> {
                    try { applyRowHeights((ViewGroup) v); } catch (Throwable ignored) { }
                }));

        // ---- Row 1 right: mobile signal + VoLTE / VoNR copies, just before the battery.
        LinearLayout imsRow = null;
        if (systemIcons != null && systemIcons.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) systemIcons.getParent();
            imsRow = new LinearLayout(ctx);
            imsRow.setTag("dual_ims");
            imsRow.setOrientation(LinearLayout.HORIZONTAL);
            imsRow.setGravity(Gravity.CENTER_VERTICAL);
            p.addView(imsRow, p.indexOfChild(systemIcons), wrapParams(p));

            // Band per SIM (n78 with a small 1 over B3 with a small 2), before VoLTE / VoNR.
            TextView band = new TextView(ctx);
            band.setTag("dual_band");
            band.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            band.setIncludeFontPadding(false);
            band.setLineSpacing(0, 0.85f);
            band.setMaxLines(2);
            band.setHorizontallyScrolling(true);
            band.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            band.setPaddingRelative(0, 0, dp(ctx.getResources(), 2), 0);
            band.setVisibility(View.GONE);
            p.addView(band, p.indexOfChild(imsRow), wrapParams(p));

            // Combined voice badge: a boxed "Vo" and one line per SIM (NR / LTE / WiFi + SIM no.).
            LinearLayout vo = new LinearLayout(ctx);
            vo.setTag("dual_vo");
            vo.setOrientation(LinearLayout.HORIZONTAL);
            vo.setGravity(Gravity.CENTER_VERTICAL);
            vo.setVisibility(View.GONE);
            TextView voBox = new TextView(ctx);
            voBox.setTag("dual_vo_box");
            voBox.setText("Vo");
            voBox.setIncludeFontPadding(false);
            voBox.setGravity(Gravity.CENTER);
            int bp = dp(ctx.getResources(), 1);
            voBox.setPadding(0, 0, 0, 0);
            vo.addView(voBox, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
            TextView voLines = new TextView(ctx);
            voLines.setTag("dual_vo_lines");
            voLines.setIncludeFontPadding(false);
            voLines.setLineSpacing(0, 0.85f);
            voLines.setMaxLines(2);
            voLines.setHorizontallyScrolling(true);
            voLines.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            vlp.setMarginStart(bp);
            vo.addView(voLines, vlp);
            LinearLayout.LayoutParams volp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            volp.gravity = Gravity.CENTER_VERTICAL;
            volp.setMarginEnd(dp(ctx.getResources(), 1));
            p.addView(vo, p.indexOfChild(imsRow), volp);

            // Network type (5G SA / 4G+) with data activity arrows underneath, Samsung style.
            LinearLayout nt = new LinearLayout(ctx);
            nt.setTag("dual_nettype");
            nt.setOrientation(LinearLayout.VERTICAL);
            nt.setGravity(Gravity.CENTER_HORIZONTAL);
            nt.setVisibility(View.GONE);
            ImageView ntIcon = new ImageView(ctx);
            ntIcon.setTag("dual_nettype_icon");
            ntIcon.setAdjustViewBounds(true);
            ntIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            nt.addView(ntIcon, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView ntArrows = new TextView(ctx);
            ntArrows.setTag("dual_nettype_arrows");
            ntArrows.setTextSize(TypedValue.COMPLEX_UNIT_SP, 5.5f);
            ntArrows.setIncludeFontPadding(false);
            ntArrows.setTypeface(Typeface.DEFAULT_BOLD);
            ntArrows.setGravity(Gravity.CENTER);
            ntArrows.setLetterSpacing(-0.05f);
            nt.addView(ntArrows, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams ntlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ntlp.gravity = Gravity.CENTER_VERTICAL;
            ntlp.setMarginEnd(dp(ctx.getResources(), 1));
            p.addView(nt, p.indexOfChild(imsRow), ntlp);

        }

        // ---- Row 1 left: temperatures and weather, right after the clock.
        Extras extras = null;
        if (clock != null && clock.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) clock.getParent();
            extras = new Extras(ctx);
            p.addView(extras.root, p.indexOfChild(clock) + 1, wrapParams(p));

            // Weather goes to the right end of row 2, after the system icons.
            LinearLayout weatherBox = new LinearLayout(ctx);
            weatherBox.setTag("dual_weather");
            weatherBox.setOrientation(LinearLayout.HORIZONTAL);
            weatherBox.setGravity(Gravity.CENTER_VERTICAL);
            detach(extras.weatherIcon);
            detach(extras.weatherTemp);
            LinearLayout.LayoutParams wilp = new LinearLayout.LayoutParams(
                    dp(ctx.getResources(), 14), dp(ctx.getResources(), 14));
            weatherBox.addView(extras.weatherIcon, wilp);
            LinearLayout.LayoutParams wtlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            wtlp.setMarginStart(dp(ctx.getResources(), 2));
            weatherBox.addView(extras.weatherTemp, wtlp);
            LinearLayout.LayoutParams wblp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            wblp.setMarginStart(dp(ctx.getResources(), Cfg.i(Cfg.WEATHER_GAP, Cfg.D_WEATHER_GAP)));
            row2.addView(weatherBox, wblp);

            // Charging current / power, two lines like the temperatures, after the net speed.
            TextView power = new TextView(ctx);
            power.setTag("dual_power");
            power.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            power.setIncludeFontPadding(false);
            power.setLineSpacing(0, 0.85f);
            power.setMaxLines(2);
            power.setHorizontallyScrolling(true);
            power.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            power.setVisibility(View.GONE);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            plp.gravity = Gravity.CENTER_VERTICAL;
            plp.setMarginStart(dp(ctx.getResources(), 3));
            extras.root.addView(power, plp);

            // Cells heard per SIM, two lines (antenna + count + small SIM number), after the amps.
            TextView cellsView = new TextView(ctx);
            cellsView.setTag("dual_cells");
            cellsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            cellsView.setIncludeFontPadding(false);
            cellsView.setLineSpacing(0, 0.85f);
            cellsView.setMaxLines(2);
            cellsView.setHorizontallyScrolling(true);
            cellsView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            cellsView.setVisibility(View.GONE);
            LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp2.gravity = Gravity.CENTER_VERTICAL;
            clp2.setMarginStart(dp(ctx.getResources(), 3));
            extras.root.addView(cellsView, clp2);
        } else {
            XposedBridge.log(TAG + "clock not found, temperatures/weather not added");
        }

        if (statusIcons instanceof ViewGroup) sIconContainer = (ViewGroup) statusIcons;
        new Updater(bar, clock, statusIcons, imsRow, extras).start();
        XposedBridge.log(TAG + "dual row built");
    }

    private static ViewGroup.LayoutParams wrapParams(ViewGroup parent) {
        if (parent instanceof LinearLayout) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = Gravity.CENTER_VERTICAL;
            return lp;
        }
        return new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    /**
     * Row 1 keeps the original area at the top. Row 2 sits Cfg.i(Cfg.ROW_GAP, Cfg.D_ROW_GAP) below the lowest
     * row-1 item (clock / temperatures), not below the whole cutout-sized row 1.
     */
    private static void applyRowHeights(ViewGroup bar) {
        View row2 = bar.findViewWithTag("dual_row2");
        View contents = byId(bar, "status_bar_contents");
        if (row2 == null || contents == null) return;

        Resources res = bar.getResources();
        int row1 = row1Height(bar.getContext());
        int row2h = dp(res, Cfg.i(Cfg.ROW2_H, Cfg.D_ROW2_H));
        int barH = bar.getHeight() > 0 ? bar.getHeight() : row1 + dp(res, Cfg.i(Cfg.EXTRA, Cfg.D_EXTRA));

        ViewGroup.LayoutParams clp = contents.getLayoutParams();
        if (clp != null && clp.height != row1) {
            clp.height = row1;
            if (clp instanceof FrameLayout.LayoutParams) ((FrameLayout.LayoutParams) clp).gravity = Gravity.TOP;
            contents.setLayoutParams(clp);
        }

        // Bottom of the lowest row-1 item, in the bar's coordinates.
        int bottom = Math.max(textBottomIn(bar, byId(bar, "clock")),
                textBottomIn(bar, bar.findViewWithTag("dual_extras")));
        int top = bottom > 0 ? bottom + dp(res, Cfg.i(Cfg.ROW_GAP, Cfg.D_ROW_GAP)) : row1;
        // Keep row 2 inside the bar.
        if (top + row2h > barH) top = Math.max(0, barH - row2h);

        FrameLayout.LayoutParams rlp = (FrameLayout.LayoutParams) row2.getLayoutParams();
        if (rlp.height != row2h || rlp.topMargin != top) {
            rlp.height = row2h;
            rlp.topMargin = top;
            row2.setLayoutParams(rlp);
            logOnceStatic("rows", "row 1 items end at " + bottom + "px, row 2 at " + top
                    + "px, bar " + barH + "px");
        }
        // Line up with row 1's side padding (rounded screen corners).
        row2.setPaddingRelative(contents.getPaddingStart(), 0, contents.getPaddingEnd(), 0);
    }

    /**
     * Bottom of the visible text inside v (or its child TextViews), in the bar's
     * coordinates. The views themselves are as tall as the bar, so their own height
     * can't be used; the text inside them sits near the top.
     */
    private static int textBottomIn(ViewGroup bar, View v) {
        if (v == null || v.getVisibility() != View.VISIBLE || v.getHeight() == 0) return 0;
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            if (tv.getLayout() == null) return 0;
            int[] a = new int[2], b = new int[2];
            tv.getLocationInWindow(a);
            bar.getLocationInWindow(b);
            return a[1] - b[1] + tv.getTotalPaddingTop() + tv.getLayout().getHeight();
        }
        int max = 0;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                max = Math.max(max, textBottomIn(bar, g.getChildAt(i)));
            }
        }
        return max;
    }

    private static void logOnceStatic(String key, String msg) {
        synchronized (sLogOnce) {
            if (sLogOnce.put(key, Boolean.TRUE) != null) return;
        }
        XposedBridge.log(TAG + msg);
    }

    // ------------------------------------------------------------ row 1 extras

    /** Two-line temperature text + weather icon and temperature. */
    private static final class Extras {
        final LinearLayout root;
        final TextView temps;
        final ImageView weatherIcon;
        final TextView weatherTemp;

        Extras(Context ctx) {
            Resources res = ctx.getResources();
            int pad = dp(res, 4);

            root = new LinearLayout(ctx);
            root.setTag("dual_extras");
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setGravity(Gravity.CENTER_VERTICAL);
            root.setPaddingRelative(pad, 0, 0, 0);

            temps = new TextView(ctx);
            temps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            temps.setTypeface(Typeface.DEFAULT_BOLD);
            temps.setIncludeFontPadding(false);
            temps.setLineSpacing(0, 0.85f);
            temps.setMaxLines(2);
            temps.setHorizontallyScrolling(true);
            temps.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            temps.setVisibility(View.GONE);
            root.addView(temps, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            int icon = dp(res, 14);
            weatherIcon = new ImageView(ctx);
            weatherIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            weatherIcon.setVisibility(View.GONE);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(icon, icon);
            ilp.setMarginStart(pad);
            root.addView(weatherIcon, ilp);

            weatherTemp = new TextView(ctx);
            weatherTemp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            weatherTemp.setIncludeFontPadding(false);
            weatherTemp.setVisibility(View.GONE);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.setMarginStart(dp(res, 2));
            root.addView(weatherTemp, tlp);
        }
    }

    // ------------------------------------------------------------ updater

    private static final class Updater {
        final ViewGroup bar;
        final View clock;
        final View statusIcons;
        final LinearLayout imsRow;
        final Extras extras;
        final Context ctx;

        final Handler main = new Handler(Looper.getMainLooper());
        final Handler worker;

        /** Mirrored row-1 icons, by slot name. */

        // Values filled in by the worker thread.
        volatile float cpuTemp = Float.NaN;
        volatile float batTemp = Float.NaN;
        volatile float amps = Float.NaN;
        volatile float watts = Float.NaN;
        volatile String weatherTemp = null;
        volatile Drawable weatherIcon = null;
        volatile boolean tintWeatherIcon = true;

        boolean wasAttached = false;
        boolean stopped = false;

        Updater(ViewGroup bar, View clock, View statusIcons, LinearLayout imsRow, Extras extras) {
            this.bar = bar;
            this.clock = clock;
            this.statusIcons = statusIcons;
            this.imsRow = imsRow;
            this.extras = extras;
            this.ctx = bar.getContext();
            HandlerThread t = new HandlerThread("NetSpeedXposed-dual");
            t.start();
            worker = new Handler(t.getLooper());
        }

        void start() {
            main.post(uiTick);
            worker.post(powerTick);
            worker.post(bandTick);
            if (extras != null) {
                worker.post(tempTick);
                if (Cfg.b(Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER)) {
                    worker.post(weatherTick);
                    try {
                        ctx.getContentResolver().registerContentObserver(OMNI_WEATHER, true,
                                new ContentObserver(worker) {
                                    @Override
                                    public void onChange(boolean selfChange) {
                                        loadWeather();
                                    }
                                });
                    } catch (Throwable t) {
                        logOnce("observer", "OmniJaws observer failed: " + t);
                    }
                }
            }
        }

        /** Stop once this status bar has been replaced (re-inflated). */
        boolean dead() {
            if (stopped) return true;
            if (bar.isAttachedToWindow()) wasAttached = true;
            else if (wasAttached) {
                stopped = true;
                worker.getLooper().quitSafely();
            }
            return stopped;
        }

        int seenVersion = -1;

        // ---- UI thread: every second
        final Runnable uiTick = new Runnable() {
            @Override
            public void run() {
                if (dead()) return;
                try {
                    int color = clock instanceof TextView ? ((TextView) clock).getCurrentTextColor() : 0xFFFFFFFF;
                    updateMirrors(color);
                    updatePower(color);
                    updateBands(color);
                    updateVoice(color);
                    updateNetType(color);
                    if (extras != null) {
                        updateExtras(color);
                        moveNetSpeed();
                        placePower();
                        placePowerSide();
                        updateCells(color);
                    }
                    Cfg.retryIfNeeded();
                    int v = Cfg.version();
                    if (v != seenVersion) {
                        seenVersion = v;
                        applyRowHeights(bar);
                        View wb = bar.findViewWithTag("dual_weather");
                        if (wb != null && wb.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) wb.getLayoutParams();
                            int gap = dp(bar.getResources(), Cfg.i(Cfg.WEATHER_GAP, Cfg.D_WEATHER_GAP));
                            if (mlp.getMarginStart() != gap) {
                                mlp.setMarginStart(gap);
                                wb.setLayoutParams(mlp);
                            }
                        }
                    }
                } catch (Throwable t) {
                    logOnce("ui", "update failed: " + t);
                }
                main.postDelayed(this, 1000);
            }
        };

        /** Put the net speed indicator (added by Hook) on row 1, right after the weather. */
        void moveNetSpeed() {
            if (!Cfg.b(Cfg.SPEED_LEFT, Cfg.D_SPEED_LEFT)) return;
            View ns = bar.findViewWithTag("netspeed_xposed");
            if (ns == null || ns.getParent() == extras.root) return;
            detach(ns);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_VERTICAL;
            lp.setMarginStart(dp(bar.getResources(), 3));
            extras.root.addView(ns, lp);
            if (ns instanceof TextView) {
                TextView tv = (TextView) ns;
                tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                tv.setPadding(0, 0, 0, 0);
                // Keep a fixed width (numbers changing shouldn't shift things), minus the padding.
                tv.setMinWidth((int) Math.ceil(tv.getPaint().measureText("↓999K/s")));
            }
            XposedBridge.log(TAG + "net speed moved next to weather");
        }

        /** Keeps the amps/watts text right after the net speed on row 1. */
        void placePower() {
            View pw = bar.findViewWithTag("dual_power");
            if (pw == null || pw.getParent() != extras.root) return;
            View ns = bar.findViewWithTag("netspeed_xposed");
            int want = ns != null && ns.getParent() == extras.root
                    ? extras.root.indexOfChild(ns) + 1 : extras.root.getChildCount() - 1;
            int cur = extras.root.indexOfChild(pw);
            if (cur == want || (cur == extras.root.getChildCount() - 1 && want >= cur)) return;
            ViewGroup.LayoutParams lp = pw.getLayoutParams();
            extras.root.removeView(pw);
            extras.root.addView(pw, Math.min(want, extras.root.getChildCount()), lp);
        }

        int lastCopies = -1;
        Drawable typeDrawable, shownType;
        int typeHeight = 0;
        long typeSeenAt = 0;
        boolean netTypeShown = false;

        View findByName(View v, String name) {
            try {
                if (v.getId() != View.NO_ID && name.equals(v.getResources().getResourceEntryName(v.getId()))) return v;
            } catch (Throwable ignored) { }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View r = findByName(g.getChildAt(i), name);
                    if (r != null) return r;
                }
            }
            return null;
        }

        /** x of v inside root (sum of lefts up the tree). */
        int offsetIn(View v, View root) {
            int x = 0;
            for (View c = v; c != null && c != root; ) {
                x += c.getLeft() + (int) c.getTranslationX();
                android.view.ViewParent pp = c.getParent();
                c = pp instanceof View ? (View) pp : null;
            }
            return x;
        }

        /**
         * 5G / 4G+ icon (the system's own image, "SA" included) with ↓↑ underneath. Each arrow
         * lights up from the modem's data activity, like Samsung; dim when idle.
         */
        void updateNetType(int color) {
            View v = bar.findViewWithTag("dual_nettype");
            if (!(v instanceof LinearLayout)) return;
            ImageView icon = v.findViewWithTag("dual_nettype_icon");
            TextView arrows = v.findViewWithTag("dual_nettype_arrows");
            boolean fresh = typeDrawable != null && android.os.SystemClock.elapsedRealtime() - typeSeenAt < 3_000;
            boolean show = Cfg.b(Cfg.NET_TYPE, Cfg.D_NET_TYPE) && fresh;
            netTypeShown = show;
            if (!show) {
                if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
                return;
            }
            if (shownType != typeDrawable) {
                shownType = typeDrawable;
                Drawable d = typeDrawable.getConstantState() != null
                        ? typeDrawable.getConstantState().newDrawable(ctx.getResources()).mutate() : typeDrawable;
                int h = Math.max(dp(bar.getResources(), 8), Math.round(typeHeight * 0.72f));
                // Bold: the shift scales with the icon's drawn size (intrinsic px -> shown px).
                float scale = d.getIntrinsicHeight() > 0 ? (float) h / d.getIntrinsicHeight() : 1f;
                float boldPx = bar.getResources().getDisplayMetrics().density * 0.8f / Math.max(0.3f, scale);
                icon.setImageDrawable(new BoldDrawable(d, boldPx));
                ViewGroup.LayoutParams lp = icon.getLayoutParams();
                if (lp.height != h) {
                    lp.height = h;
                    icon.setLayoutParams(lp);
                }
            }
            icon.setColorFilter(color, PorterDuff.Mode.SRC_IN);
            int dim = (color & 0x00FFFFFF) | 0x4D000000;
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder("\u2193\u2191");
            sb.setSpan(new android.text.style.ForegroundColorSpan(DataActivity.in() ? color : dim), 0, 1, 0);
            sb.setSpan(new android.text.style.ForegroundColorSpan(DataActivity.out() ? color : dim), 1, 2, 0);
            arrows.setText(sb);
            if (v.getVisibility() != View.VISIBLE) v.setVisibility(View.VISIBLE);
        }
        final java.util.Set<View> tightened = java.util.Collections.newSetFromMap(new WeakHashMap<>());

        /**
         * Pulls the network type (5G / 4G+) right up to the signal bars inside a SIM's signal
         * view, by removing the spacing around the type icon. The row-2 original is hidden,
         * so this only changes the row-1 copy.
         */
        void tightenMobile(View root) {
            if (tightened.contains(root)) return;
            tightened.add(root);
            StringBuilder names = new StringBuilder();
            tightenWalk(root, names);
            root.requestLayout();
            logOnce("mobileids", "signal view parts: " + names);
        }

        void tightenWalk(View v, StringBuilder names) {
            String name = "";
            try {
                if (v.getId() != View.NO_ID) name = v.getResources().getResourceEntryName(v.getId());
            } catch (Throwable ignored) { }
            if (!name.isEmpty()) names.append(name).append(' ');
            if (name.equals("mobile_type") || name.equals("mobile_type_container")
                    || name.equals("mobile_roaming_space")) {
                v.setPaddingRelative(v.getPaddingStart(), v.getPaddingTop(), 0, v.getPaddingBottom());
                if (v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    lp.setMarginEnd(0);
                    v.setLayoutParams(lp);
                }
            }
            if (name.equals("mobile_signal") || name.equals("mobile_group")
                    || name.equals("mobile_signal_container")) {
                if (v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    lp.setMarginStart(0);
                    v.setLayoutParams(lp);
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) tightenWalk(g.getChildAt(i), names);
            }
        }

        /**
         * Lunaris can keep two kinds of signal view per SIM in the container (an older and a
         * newer one) and sometimes reports both as shown. When more than one kind is shown,
         * keep the newer ("Modern...") kind, else the one with the most shown views.
         */
        String mobileClassToKeep(ViewGroup g) {
            Map<String, Integer> counts = new HashMap<>();
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = g.getChildAt(i);
                String slot;
                try {
                    slot = String.valueOf(XposedHelpers.callMethod(c, "getSlot"));
                } catch (Throwable t) {
                    continue;
                }
                if (!slot.toLowerCase(Locale.US).contains("mobile")) continue;
                if (c.getVisibility() != View.VISIBLE || c.getWidth() == 0 || !iconShown(c)) continue;
                counts.merge(c.getClass().getName(), 1, Integer::sum);
            }
            if (counts.size() < 2) return null;
            String best = null;
            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                String simple = e.getKey().substring(e.getKey().lastIndexOf('.') + 1);
                if (simple.startsWith("Modern")) return e.getKey();
                if (best == null || e.getValue() > counts.get(best)) best = e.getKey();
            }
            logOnce("mobileclasses", "signal view kinds " + counts + ", keeping " + best);
            return best;
        }

        /**
         * Whether System UI itself wants this icon shown. Some icons stay in the container
         * but hidden (e.g. an older and a newer version of the signal icon), and they
         * report that here rather than through their view visibility.
         */
        boolean iconShown(View child) {
            try {
                Object v = XposedHelpers.callMethod(child, "isIconVisible");
                if (v instanceof Boolean && !((Boolean) v)) return false;
            } catch (Throwable ignored) { }
            try {
                Object st = XposedHelpers.callMethod(child, "getVisibleState");
                if (st instanceof Integer && (Integer) st != 0) return false; // 0 = STATE_ICON
            } catch (Throwable ignored) { }
            return true;
        }

        /** Row-2 icon view -> its row-1 copy, and the bitmap it is drawn into. */
        final Map<View, ImageView> snaps = new WeakHashMap<>();
        final Map<View, Bitmap> bitmaps = new WeakHashMap<>();

        /**
         * Shows VoLTE / VoNR / mobile signal on row 1 next to the battery. On this ROM those
         * icons are not plain images and the container can't be told to ignore them, so each
         * one is drawn into a bitmap shown on row 1, and its original is skipped when row 2
         * draws (see the dispatchDraw hook). Row 2's icons are shifted right to close the gap.
         */
        boolean loggedRestrict = false;

        /**
         * The icon container shows at most ~7 icons. The ones copied to row 1 still count
         * there, so on 5G (VoNR + two signals + VoLTE) icons like Bluetooth got dropped.
         * Row 2 has plenty of room, so turn the limit off.
         */
        void unrestrict(ViewGroup g) {
            try {
                java.lang.reflect.Field f = null;
                for (Class<?> c = g.getClass(); c != null && f == null; c = c.getSuperclass()) {
                    try {
                        f = c.getDeclaredField("mShouldRestrictIcons");
                    } catch (NoSuchFieldException ignored) { }
                }
                if (f == null) throw new NoSuchFieldException("mShouldRestrictIcons");
                f.setAccessible(true);
                if (f.getBoolean(g)) {
                    f.setBoolean(g, false);
                    g.requestLayout();
                    if (!loggedRestrict) {
                        loggedRestrict = true;
                        XposedBridge.log(TAG + "status icon limit turned off for row 2");
                    }
                }
            } catch (Throwable t) {
                try {
                    XposedHelpers.callMethod(g, "setShouldRestrictIcons", false);
                } catch (Throwable t2) {
                    logOnce("restrict", "couldn't lift the status icon limit: " + t2);
                }
            }
        }

        void updateMirrors(int color) {
            if (!(statusIcons instanceof ViewGroup) || imsRow == null) return;
            ViewGroup g = (ViewGroup) statusIcons;
            unrestrict(g);
            List<View> moved = new ArrayList<>();
            float rightAll = 0, rightOther = -1;
            String keepClass = mobileClassToKeep(g);
            for (int i = 0; i < g.getChildCount(); i++) {
                View child = g.getChildAt(i);
                boolean shown = child.getVisibility() == View.VISIBLE && child.getWidth() > 0
                        && child.getAlpha() > 0.01f && iconShown(child);
                float right = child.getX() + child.getWidth();
                String slot;
                try {
                    slot = String.valueOf(XposedHelpers.callMethod(child, "getSlot"));
                } catch (Throwable t) {
                    slot = "";
                }
                logOnce("slot:" + slot, "status icon slot: " + slot + " (" + child.getClass().getSimpleName() + ")");
                if (!isRow1Slot(slot)) {
                    if (shown) rightOther = Math.max(rightOther, right);
                    if (shown) rightAll = Math.max(rightAll, right);
                    continue;
                }
                moved.add(child);
                // Two kinds of signal view for the same SIM: show only one kind.
                if (keepClass != null && slot.toLowerCase(Locale.US).contains("mobile")
                        && !keepClass.equals(child.getClass().getName())) {
                    shown = false;
                }
                if (shown) rightAll = Math.max(rightAll, right);

                ImageView m = snaps.get(child);
                if (m == null) {
                    m = new ImageView(ctx);
                    m.setScaleType(ImageView.ScaleType.CENTER);
                    imsRow.addView(m, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    snaps.put(child, m);
                    XposedBridge.log(TAG + "showing " + slot + " on row 1");
                }
                // Keep row-1 order the same as row 2's.
                int want = moved.size() - 1;
                if (imsRow.indexOfChild(m) != want && want < imsRow.getChildCount()) {
                    imsRow.removeView(m);
                    imsRow.addView(m, want);
                }
                if (!shown || child.getHeight() == 0
                        || (voiceSlot(slot) && voBadgeShown)) {
                    m.setVisibility(View.GONE);
                    continue;
                }
                int cropX = 0;
                if (slot.toLowerCase(Locale.US).contains("mobile")) {
                    tightenMobile(child);
                    View type = findByName(child, "mobile_type");
                    View sig = findByName(child, "mobile_signal");
                    if (type instanceof ImageView && type.isShown() && ((ImageView) type).getDrawable() != null) {
                        typeDrawable = ((ImageView) type).getDrawable();
                        typeHeight = type.getHeight();
                        typeSeenAt = android.os.SystemClock.elapsedRealtime();
                    }
                    // Our own type + arrows replaces the stock type: start the copy at the bars.
                    if (netTypeShown && sig != null) cropX = Math.max(0, offsetIn(sig, child));
                }
                // Draw with a margin: parts like the "SA" mark can sit outside the view's bounds.
                int pad = dp(ctx.getResources(), 3);
                int bw = child.getWidth() - cropX + 2 * pad, bh = child.getHeight() + 2 * pad;
                Bitmap bmp = bitmaps.get(child);
                if (bmp == null || bmp.getWidth() != bw || bmp.getHeight() != bh) {
                    bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                    bitmaps.put(child, bmp);
                }
                if (m.getLayoutParams() instanceof LinearLayout.LayoutParams) {
                    LinearLayout.LayoutParams mlp = (LinearLayout.LayoutParams) m.getLayoutParams();
                    if (mlp.leftMargin != -pad || mlp.topMargin != -pad) {
                        mlp.setMargins(-pad, -pad, -pad, -pad);
                        mlp.gravity = Gravity.CENTER_VERTICAL;
                        m.setLayoutParams(mlp);
                    }
                }
                bmp.eraseColor(0);
                try {
                    Canvas cv = new Canvas(bmp);
                    cv.translate(pad - cropX, pad);
                    child.draw(cv);
                } catch (Throwable t) {
                    logOnce("snap:" + slot, "drawing " + slot + " failed: " + t);
                    m.setVisibility(View.GONE);
                    continue;
                }
                m.setImageBitmap(bmp);
                m.invalidate();
                m.setVisibility(View.VISIBLE);
            }
            // Log what's being copied whenever the set changes (helps spot duplicates).
            int visibleCopies = 0;
            for (ImageView m : snaps.values()) if (m.getVisibility() == View.VISIBLE) visibleCopies++;
            if (visibleCopies != lastCopies) {
                lastCopies = visibleCopies;
                StringBuilder sb = new StringBuilder("row-1 icons now " + visibleCopies + ":");
                for (View c : moved) {
                    sb.append(' ').append(c.getClass().getSimpleName())
                            .append(iconShown(c) ? "[on]" : "[off]")
                            .append(c.getWidth()).append("px");
                }
                XposedBridge.log(TAG + sb);
            }
            // Drop copies of icons that no longer exist (e.g. a SIM removed).
            for (View old : new ArrayList<>(snaps.keySet())) {
                if (old.getParent() != g) {
                    ImageView m = snaps.remove(old);
                    if (m != null) imsRow.removeView(m);
                }
            }
            synchronized (SKIP) {
                SKIP.clear();
                SKIP.addAll(moved);
            }
            // Close the gap the hidden icons leave at the right end of row 2.
            float shift = rightOther >= 0 && rightAll > rightOther ? rightAll - rightOther : 0;
            if (rightOther < 0) shift = 0;
            if (Math.abs(g.getTranslationX() - shift) > 0.5f) g.setTranslationX(shift);
            g.invalidate();
        }

        /** Two lines, one per SIM that has a band: "n78" + small "1", "B3" + small "2". */
        /** dBm left out because row 1's right side (after the camera) ran out of room. */
        boolean dbmDropped = false;
        int dbmExtraPx = 0;

        /** Screen x where row 1's right area starts: the camera cutout's right edge (plus 2dp). */
        int rightLimit() {
            int limit = Integer.MIN_VALUE;
            try {
                android.view.WindowInsets wi = bar.getRootWindowInsets();
                android.view.DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
                if (dc != null) {
                    int[] b = new int[2];
                    bar.getLocationOnScreen(b);
                    for (android.graphics.Rect r : dc.getBoundingRects()) {
                        if (r.top > b[1] + bar.getHeight() || r.right >= b[0] + bar.getWidth()) continue;
                        limit = Math.max(limit, r.right + dp(bar.getResources(), 2));
                    }
                }
            } catch (Throwable ignored) { }
            return limit;
        }

        /** Leftmost on-screen x of the row-1 right-side items we add (power if there, else band). */
        int rightGroupLeft(View band) {
            View pw = bar.findViewWithTag("dual_power");
            View first = pw != null && pw.getVisibility() == View.VISIBLE && pw.getParent() == band.getParent()
                    ? pw : band;
            if (first.getWidth() == 0) return Integer.MAX_VALUE;
            int[] p = new int[2];
            first.getLocationOnScreen(p);
            return p[0];
        }

        int lastBandColor = 0;
        boolean voBadgeShown = false;
        int lastVoColor = 0;

        /** One "Vo" badge: per SIM its voice type now (NR / LTE / WiFi), small SIM number. */
        void updateVoice(int color) {
            View v = bar.findViewWithTag("dual_vo");
            if (!(v instanceof LinearLayout)) return;
            TextView box = v.findViewWithTag("dual_vo_box");
            TextView lines = v.findViewWithTag("dual_vo_lines");
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            if (Cfg.b(Cfg.VO_BADGE, Cfg.D_VO_BADGE)) {
                for (Bands.Sim s : sims) {
                    String t = Voice.label(s.sub, s.band);
                    if (t == null) continue;
                    if (sb.length() > 0) sb.append('\n');
                    sb.append(t);
                    int st = sb.length();
                    sb.append(String.valueOf(s.slot));
                    sb.setSpan(new android.text.style.SubscriptSpan(), st, sb.length(), 0);
                    sb.setSpan(new android.text.style.RelativeSizeSpan(0.7f), st, sb.length(), 0);
                }
            }
            boolean show = sb.length() > 0;
            voBadgeShown = show;
            if (!show) {
                if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
                return;
            }
            int sp = Cfg.i(Cfg.BAND_SP, Cfg.D_BAND_SP);
            Hook.setSp(lines, sp);
            Hook.setSp(box, sp);
            boolean bold = Cfg.b(Cfg.BOLD, Cfg.D_BOLD);
            Hook.matchClockFont(clock, lines, bold);
            Hook.matchClockFont(clock, box, true);
            lines.setTextColor(color);
            box.setTextColor(color);
            if (box.getBackground() != null) box.setBackground(null); // no frame
            if (!sb.toString().equals(String.valueOf(lines.getText()))) lines.setText(sb);
            fitWidthSpanned(lines, sb);
            if (v.getVisibility() != View.VISIBLE) v.setVisibility(View.VISIBLE);
        }

        /** "350m", "1.2km", "12km". */
        String distLabel(int m) {
            if (m < 1000) return m + "m";
            if (m < 10_000) return String.format(java.util.Locale.US, "%.1fkm", m / 1000f);
            return (m / 1000) + "km";
        }

        /** Like fitWidth, but counts styled parts (small SIM number, tower symbol) correctly. */
        void fitWidthSpanned(TextView tv, CharSequence text) {
            float max = 0;
            int start = 0;
            String plain = text.toString();
            android.text.TextPaint tp = tv.getPaint();
            while (start <= plain.length()) {
                int end = plain.indexOf('\n', start);
                if (end < 0) end = plain.length();
                max = Math.max(max, android.text.Layout.getDesiredWidth(text, start, end, tp));
                start = end + 1;
            }
            int w = (int) Math.ceil(max) + tv.getPaddingLeft() + tv.getPaddingRight() + 1;
            if (tv.getMinWidth() != w) tv.setMinWidth(w);
        }

        int bandLevel = 2;

        /** Band label text at a level: 0 band, 1 + dBm, 2 + distance. One line per SIM. */
        android.text.SpannableStringBuilder bandText(TextView tv, int color, int level) {
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            if (!Cfg.b(Cfg.SHOW_BAND, Cfg.D_SHOW_BAND)) return sb;
            for (Bands.Sim s : sims) {
                if (s.band == null) continue;
                if (sb.length() > 0) sb.append('\n');
                sb.append(s.band);
                int start = sb.length();
                sb.append(String.valueOf(s.slot));
                sb.setSpan(new android.text.style.SubscriptSpan(), start, sb.length(), 0);
                sb.setSpan(new android.text.style.RelativeSizeSpan(0.7f), start, sb.length(), 0);
                if (level >= 1 && s.dbm != Bands.NO_DBM) sb.append(" ").append(String.valueOf(s.dbm));
                if (level >= 2) {
                    sb.append(' ');
                    int at = sb.length();
                    sb.append('\u2009'); // stands in for the tower symbol
                    TowerDrawable td = new TowerDrawable(color, Math.round(tv.getTextSize() * 0.95f));
                    sb.setSpan(new android.text.style.ImageSpan(td,
                            android.text.style.DynamicDrawableSpan.ALIGN_CENTER), at, at + 1, 0);
                    sb.append(s.distM < 0 ? "?" : (s.approx ? "~" : "") + distLabel(s.distM));
                }
            }
            return sb;
        }

        /** Width of the widest line, counting spans (small numbers, symbols). */
        float spannedWidth(TextView tv, CharSequence text) {
            float max = 0;
            int start = 0;
            String plain = text.toString();
            while (start <= plain.length()) {
                int end = plain.indexOf('\n', start);
                if (end < 0) end = plain.length();
                max = Math.max(max, android.text.Layout.getDesiredWidth(text, start, end, tv.getPaint()));
                start = end + 1;
            }
            return max;
        }

        void updateBands(int color) {
            View v = bar.findViewWithTag("dual_band");
            if (!(v instanceof TextView)) return;
            TextView tv = (TextView) v;

            // Three levels: 2 = band + dBm + distance, 1 = band + dBm, 0 = band only.
            // Use the fullest one that fits before the camera; drop the distance first.
            boolean wantDbm = Cfg.b(Cfg.SHOW_DBM, Cfg.D_SHOW_DBM);
            boolean wantDist = wantDbm && Cfg.b(Cfg.SHOW_DIST, Cfg.D_SHOW_DIST);
            int maxLevel = wantDist ? 2 : wantDbm ? 1 : 0;
            android.text.SpannableStringBuilder[] lv = new android.text.SpannableStringBuilder[3];
            float[] w = new float[3];
            for (int l = 0; l <= maxLevel; l++) {
                lv[l] = bandText(tv, color, l);
                w[l] = spannedWidth(tv, lv[l]);
            }
            int level = maxLevel;
            int limit = rightLimit();
            if (limit != Integer.MIN_VALUE && tv.getVisibility() == View.VISIBLE && tv.getWidth() > 0) {
                int[] pos = new int[2];
                tv.getLocationOnScreen(pos);
                int right = pos[0] + tv.getWidth();   // the group is right-aligned: this edge stays put
                int slack = dp(bar.getResources(), 4);
                level = 0;
                for (int l = maxLevel; l >= 1; l--) {
                    int leftIf = right - (int) Math.ceil(w[l]) - tv.getPaddingLeft() - tv.getPaddingRight();
                    if (leftIf - (l > bandLevel ? slack : 0) >= limit) {
                        level = l;
                        break;
                    }
                }
            }
            if (level != bandLevel) {
                XposedBridge.log(TAG + "band label: " + (level == 2 ? "band + dBm + distance"
                        : level == 1 ? "band + dBm (no room for distance)" : "band only (no room for dBm)"));
                bandLevel = level;
            }
            android.text.SpannableStringBuilder sb = lv[level] != null ? lv[level] : new android.text.SpannableStringBuilder();
            if (sb.length() == 0) {
                if (tv.getVisibility() != View.GONE) tv.setVisibility(View.GONE);
                return;
            }
            tv.setTextColor(color);
            Hook.setSp(tv, Cfg.i(Cfg.BAND_SP, Cfg.D_BAND_SP));
            Hook.matchClockFont(clock, tv, Cfg.b(Cfg.BOLD, Cfg.D_BOLD));
            if (!sb.toString().equals(String.valueOf(tv.getText())) || lastBandColor != color) {
                tv.setText(sb);
                lastBandColor = color;
            }
            fitWidthSpanned(tv, sb);
            if (tv.getVisibility() != View.VISIBLE) tv.setVisibility(View.VISIBLE);
        }

        boolean powerOnRight = false;

        /**
         * Screen x where row 1's left area ends: the camera cutout's left edge (minus 2dp),
         * or the right edge of the left container when there is no cutout.
         */
        int leftLimit() {
            int limit = Integer.MAX_VALUE;
            try {
                android.view.WindowInsets wi = bar.getRootWindowInsets();
                android.view.DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
                if (dc != null) {
                    int[] b = new int[2];
                    bar.getLocationOnScreen(b);
                    for (android.graphics.Rect r : dc.getBoundingRects()) {
                        if (r.top > b[1] + bar.getHeight() || r.left <= b[0]) continue;
                        limit = Math.min(limit, r.left - dp(bar.getResources(), 2));
                    }
                }
            } catch (Throwable ignored) { }
            // No cutout: the left side may use up to the middle of the bar.
            if (limit == Integer.MAX_VALUE && bar.getWidth() > 0) {
                int[] b = new int[2];
                bar.getLocationOnScreen(b);
                limit = b[0] + bar.getWidth() / 2 - dp(bar.getResources(), 4);
            }
            return limit;
        }

        /**
         * Amps/watts sit after the net speed when there's room; otherwise they move to the
         * right of the camera, just before the band label, so the values are never cut off.
         */
        boolean cellsNoRoom = false;
        int cellsWidth = 0;

        /** Antenna + cells heard per SIM, after the amps (or the net speed), never past the camera. */
        void updateCells(int color) {
            View v = bar.findViewWithTag("dual_cells");
            if (!(v instanceof TextView) || v.getParent() != extras.root) return;
            TextView tv = (TextView) v;
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            if (Cfg.b(Cfg.SHOW_CELLS, Cfg.D_SHOW_CELLS)) {
                float icon = tv.getTextSize() * 0.95f;
                for (Bands.Sim s : sims) {
                    if (sb.length() > 0) sb.append('\n');
                    int at = sb.length();
                    sb.append('\u2009');
                    sb.setSpan(new android.text.style.ImageSpan(new DishDrawable(color, Math.round(icon)),
                            android.text.style.DynamicDrawableSpan.ALIGN_CENTER), at, at + 1, 0);
                    sb.append(s.cells >= 0 ? String.valueOf(s.cells) : "?");
                    int st = sb.length();
                    sb.append(String.valueOf(s.slot));
                    sb.setSpan(new android.text.style.SubscriptSpan(), st, sb.length(), 0);
                    sb.setSpan(new android.text.style.RelativeSizeSpan(0.7f), st, sb.length(), 0);
                }
            }
            if (sb.length() == 0) {
                if (tv.getVisibility() != View.GONE) tv.setVisibility(View.GONE);
                return;
            }
            tv.setTextColor(color);
            Hook.setSp(tv, Cfg.i(Cfg.POWER_SP, Cfg.D_POWER_SP));
            Hook.matchClockFont(clock, tv, Cfg.b(Cfg.BOLD, Cfg.D_BOLD));
            tv.setText(sb);
            fitWidthSpanned(tv, sb);
            cellsWidth = tv.getMinWidth();

            // Keep it right after the amps (or after the net speed when the amps are elsewhere).
            View pw = bar.findViewWithTag("dual_power");
            View ns = bar.findViewWithTag("netspeed_xposed");
            View after = pw != null && pw.getParent() == extras.root && pw.getVisibility() == View.VISIBLE ? pw
                    : ns != null && ns.getParent() == extras.root ? ns : null;
            int want = after != null ? extras.root.indexOfChild(after) + 1 : extras.root.getChildCount() - 1;
            int cur = extras.root.indexOfChild(tv);
            if (cur != want && !(cur == want - 1 && cur == extras.root.getChildCount() - 1)) {
                ViewGroup.LayoutParams lp = tv.getLayoutParams();
                extras.root.removeView(tv);
                extras.root.addView(tv, Math.min(want > cur ? want - 1 : want, extras.root.getChildCount()), lp);
            }

            // Room check against the camera, with a little slack before showing again.
            int limit = leftLimit();
            int anchorRight;
            if (after != null && after.getWidth() > 0) {
                int[] p = new int[2];
                after.getLocationOnScreen(p);
                anchorRight = p[0] + after.getWidth();
            } else {
                anchorRight = Integer.MIN_VALUE;
            }
            int margin = dp(bar.getResources(), 3);
            if (anchorRight != Integer.MIN_VALUE && limit != Integer.MAX_VALUE) {
                boolean fits = anchorRight + margin + cellsWidth <= limit - (cellsNoRoom ? dp(bar.getResources(), 4) : 0);
                if (fits == cellsNoRoom) {
                    cellsNoRoom = !fits;
                    XposedBridge.log(TAG + (fits ? "cells counter shown again" : "no room for the cells counter, hiding it"));
                }
            }
            int vis = cellsNoRoom ? View.GONE : View.VISIBLE;
            if (tv.getVisibility() != vis) tv.setVisibility(vis);
        }

        void placePowerSide() {
            View pw = bar.findViewWithTag("dual_power");
            View bandView = bar.findViewWithTag("dual_band");
            if (!(pw instanceof TextView) || pw.getVisibility() != View.VISIBLE) return;
            Resources res = bar.getResources();
            int margin = dp(res, 3);
            int need = ((TextView) pw).getMinWidth() + margin;

            // Right edge of what comes before the amps on the left side.
            View ns = bar.findViewWithTag("netspeed_xposed");
            View anchor = ns != null && ns.getParent() == extras.root && ns.getVisibility() == View.VISIBLE
                    ? ns : extras.root;
            int[] p = new int[2];
            anchor.getLocationOnScreen(p);
            int anchorRight = p[0] + (anchor == extras.root && pw.getParent() == extras.root
                    ? extras.root.getWidth() - pw.getWidth() - margin : anchor.getWidth());
            int limit = leftLimit();
            if (anchor.getWidth() == 0 || limit == Integer.MAX_VALUE) return;

            // A little slack before moving back, so it doesn't flip back and forth.
            boolean fitsLeft = anchorRight + need <= limit - (powerOnRight ? dp(res, 4) : 0);
            boolean wantRight = !fitsLeft;
            if (wantRight == powerOnRight && (wantRight ? pw.getParent() != extras.root : pw.getParent() == extras.root)) return;

            detach(pw);
            if (wantRight && bandView != null && bandView.getParent() instanceof ViewGroup) {
                ViewGroup rp = (ViewGroup) bandView.getParent();
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.gravity = Gravity.CENTER_VERTICAL;
                lp.setMarginEnd(margin);
                rp.addView(pw, rp.indexOfChild(bandView), lp);
                ((TextView) pw).setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                powerOnRight = true;
                XposedBridge.log(TAG + "amps/watts moved right of the camera (no room on the left: needs "
                        + need + "px from x=" + anchorRight + ", camera at x=" + limit + ")");
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.gravity = Gravity.CENTER_VERTICAL;
                lp.setMarginStart(margin);
                extras.root.addView(pw, lp);
                ((TextView) pw).setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                powerOnRight = false;
                placePower();
                XposedBridge.log(TAG + "amps/watts back after the net speed (x=" + anchorRight
                        + ", needs " + need + "px, camera at x=" + limit + ")");
            }
        }

        void updatePower(int color) {
            View v = bar.findViewWithTag("dual_power");
            if (!(v instanceof TextView)) return;
            TextView tv = (TextView) v;
            if (!Cfg.b(Cfg.SHOW_POWER, Cfg.D_SHOW_POWER) || Float.isNaN(amps)) {
                if (tv.getVisibility() != View.GONE) tv.setVisibility(View.GONE);
                return;
            }
            tv.setTextColor(color);
            Hook.setSp(tv, Cfg.i(Cfg.POWER_SP, Cfg.D_POWER_SP));
            Hook.matchClockFont(clock, tv, Cfg.b(Cfg.BOLD, Cfg.D_BOLD));
            String a = String.format(java.util.Locale.US, "%.2fA", amps);
            String w = Float.isNaN(watts) ? "" : String.format(java.util.Locale.US,
                    Math.abs(watts) < 10 ? "%.1fW" : "%.0fW", watts);
            String text = w.isEmpty() ? a : a + "\n" + w;
            tv.setText(text);
            fitWidth(tv, text);
            if (tv.getVisibility() != View.VISIBLE) tv.setVisibility(View.VISIBLE);
        }

        /** Sets the view's width to its widest line, so two-line text never wraps or squeezes. */
        void fitWidth(TextView tv, String text) {
            float max = 0;
            for (String line : text.split("\n")) max = Math.max(max, tv.getPaint().measureText(line));
            int w = (int) Math.ceil(max) + tv.getPaddingLeft() + tv.getPaddingRight();
            if (tv.getMinWidth() != w) tv.setMinWidth(w);
        }

        void updateExtras(int color) {
            StringBuilder sb = new StringBuilder();
            if (Cfg.b(Cfg.SHOW_CPU, Cfg.D_SHOW_CPU) && !Float.isNaN(cpuTemp)) {
                sb.append("C ").append(Math.round(cpuTemp)).append('°');
            }
            if (Cfg.b(Cfg.SHOW_BAT, Cfg.D_SHOW_BAT) && !Float.isNaN(batTemp)) {
                if (sb.length() > 0) sb.append('\n');
                sb.append("B ").append(Math.round(batTemp)).append('°');
            }
            extras.temps.setTextColor(color);
            boolean bold = Cfg.b(Cfg.BOLD, Cfg.D_BOLD);
            Hook.setSp(extras.temps, Cfg.i(Cfg.TEMP_SP, Cfg.D_TEMP_SP));
            Hook.setSp(extras.weatherTemp, Cfg.i(Cfg.WEATHER_SP, Cfg.D_WEATHER_SP));
            Hook.matchClockFont(clock, extras.temps, bold);
            extras.temps.setText(sb);
            extras.temps.setVisibility(sb.length() > 0 ? View.VISIBLE : View.GONE);

            String wt = weatherTemp;
            Drawable wi = weatherIcon;
            if (Cfg.b(Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER) && wt != null) {
                extras.weatherTemp.setTextColor(color);
                Hook.matchClockFont(clock, extras.weatherTemp, false);
                extras.weatherTemp.setText(wt + "°");
                extras.weatherTemp.setVisibility(View.VISIBLE);
            } else {
                extras.weatherTemp.setVisibility(View.GONE);
            }
            if (Cfg.b(Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER) && wt != null && wi != null) {
                if (extras.weatherIcon.getDrawable() != wi) extras.weatherIcon.setImageDrawable(wi);
                if (tintWeatherIcon) extras.weatherIcon.setColorFilter(color, PorterDuff.Mode.SRC_IN);
                else extras.weatherIcon.clearColorFilter();
                extras.weatherIcon.setVisibility(View.VISIBLE);
            } else {
                extras.weatherIcon.setVisibility(View.GONE);
            }
        }

        // ---- Worker thread: temperatures
        final Runnable tempTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                if (Cfg.b(Cfg.SHOW_CPU, Cfg.D_SHOW_CPU)) cpuTemp = readCpuTemp(ctx);
                if (Cfg.b(Cfg.SHOW_BAT, Cfg.D_SHOW_BAT)) batTemp = readBatteryTemp(ctx);
                worker.postDelayed(this, TEMP_INTERVAL_MS);
            }
        };

        // ---- Worker thread: charging current / power
        volatile List<Bands.Sim> sims = new ArrayList<>();
        String lastBandLog = "";

        final Runnable bandTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                if (Cfg.b(Cfg.VO_BADGE, Cfg.D_VO_BADGE)) Voice.watch(ctx);
                if (Cfg.b(Cfg.NET_TYPE, Cfg.D_NET_TYPE)) DataActivity.watch(ctx);
                if (Cfg.b(Cfg.SHOW_BAND, Cfg.D_SHOW_BAND)) {
                    List<Bands.Sim> s = Bands.read(ctx);
                    sims = s;
                    StringBuilder sb = new StringBuilder("SIMs:");
                    for (Bands.Sim x : s) sb.append(" SIM").append(x.slot).append('=').append(x.band)
                                .append(x.distM < 0 ? " dist?" : (x.approx ? " db~" : " ta=") + x.distM + "m");
                    if (!sb.toString().equals(lastBandLog)) {
                        lastBandLog = sb.toString();
                        XposedBridge.log(TAG + sb);
                    }
                }
                worker.postDelayed(this, 5_000);
            }
        };

        final Runnable powerTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                if (Cfg.b(Cfg.SHOW_POWER, Cfg.D_SHOW_POWER)) {
                    float[] ap = readPower(ctx);
                    amps = ap[0];
                    watts = ap[1];
                }
                worker.postDelayed(this, POWER_INTERVAL_MS);
            }
        };

        // ---- Worker thread: weather fallback refresh
        final Runnable weatherTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                loadWeather();
                worker.postDelayed(this, WEATHER_INTERVAL_MS);
            }
        };

        void loadWeather() {
            try {
                boolean enabled = true;
                String iconPack = null;
                try (Cursor s = ctx.getContentResolver().query(OMNI_SETTINGS, null, null, null, null)) {
                    if (s != null && s.moveToFirst()) {
                        int e = s.getColumnIndex("enabled");
                        if (e >= 0) enabled = s.getInt(e) != 0;
                        int ip = s.getColumnIndex("icon_pack");
                        if (ip >= 0) iconPack = s.getString(ip);
                    }
                }
                if (!enabled) {
                    logOnce("omni-off", "OmniJaws weather is turned off");
                    weatherTemp = null;
                    return;
                }
                String temp = null;
                int code = -1;
                try (Cursor c = ctx.getContentResolver().query(OMNI_WEATHER, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int ti = c.getColumnIndex("temperature");
                        int ci = c.getColumnIndex("condition_code");
                        if (ti >= 0) temp = c.getString(ti);
                        if (ci >= 0) code = c.getInt(ci);
                    }
                }
                if (temp == null || temp.isEmpty()) {
                    logOnce("omni-empty", "OmniJaws has no weather data yet");
                    weatherTemp = null;
                    return;
                }
                // Drop decimals: "28.4" -> "28".
                try {
                    temp = String.valueOf(Math.round(Float.parseFloat(temp.replace(",", "."))));
                } catch (NumberFormatException ignored) {
                    // Keep OmniJaws' own text.
                }
                weatherIcon = code >= 0 ? loadWeatherIcon(iconPack, code) : null;
                weatherTemp = temp;
                logOnce("omni-ok", "OmniJaws weather: " + temp + "°, code " + code
                        + ", icon pack " + iconPack + ", icon " + (weatherIcon != null));
            } catch (Throwable t) {
                logOnce("omni-err", "OmniJaws read failed: " + t);
                weatherTemp = null;
            }
        }

        /** OmniJaws icons are named "<prefix>_<code>" inside the icon pack's package. */
        Drawable loadWeatherIcon(String iconPack, int code) {
            String[][] tries = new String[4][];
            int n = 0;
            if (iconPack != null && iconPack.lastIndexOf('.') > 0) {
                int dot = iconPack.lastIndexOf('.');
                tries[n++] = new String[]{iconPack.substring(0, dot), iconPack.substring(dot + 1)};
            }
            tries[n++] = new String[]{OMNI_PKG, "outline"};
            tries[n++] = new String[]{OMNI_PKG, "google"};
            tries[n++] = new String[]{OMNI_PKG, "weather"};
            for (int i = 0; i < n; i++) {
                try {
                    Resources r = ctx.getPackageManager().getResourcesForApplication(tries[i][0]);
                    int id = r.getIdentifier(tries[i][1] + "_" + code, "drawable", tries[i][0]);
                    if (id == 0) continue;
                    Drawable d = r.getDrawable(id, null);
                    // Outline icons are single-colour: tint them like the clock.
                    // Other packs are full colour: leave them as they are.
                    tintWeatherIcon = tries[i][1].contains("outline");
                    return d;
                } catch (Throwable ignored) {
                    // Try the next one.
                }
            }
            logOnce("omni-icon", "no OmniJaws icon found for pack " + iconPack);
            return null;
        }
    }

    /** VoLTE / VoNR / VoWiFi / IMS icons (replaced by the combined badge). */
    private static boolean voiceSlot(String slot) {
        String s = slot.toLowerCase(Locale.US);
        return s.contains("volte") || s.contains("vonr") || s.contains("vowifi") || s.contains("ims");
    }

    private static boolean isRow1Slot(String slot) {
        String s = slot.toLowerCase(Locale.US);
        for (String k : ROW1_SLOT_KEYWORDS) if (s.contains(k)) return true;
        return false;
    }

    // ------------------------------------------------------------ temperatures

    /**
     * Battery current (A, always positive) and power (W). Kernels differ in units
     * (µA vs mA) and sign (+/- for charging), so the value is normalised here.
     */
    private static float[] readPower(Context ctx) {
        float[] out = {Float.NaN, Float.NaN};
        try {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            long cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (cur == Long.MIN_VALUE || cur == 0) {
                cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            }
            if (cur == Integer.MIN_VALUE || cur == Long.MIN_VALUE) return out;
            double a = Math.abs((double) cur);
            a = a > 20_000 ? a / 1_000_000.0 : a / 1_000.0; // µA or mA
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            // Sign from the charging state, not the kernel's number (kernels disagree on it):
            // plus while charging, minus while running on battery.
            int status = i == null ? -1 : i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int plugged = i == null ? 0 : i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            boolean charging = plugged != 0 && (status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL);
            if (!charging) a = -a;
            out[0] = (float) a;
            int mv = i == null ? -1 : i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            if (mv > 0) {
                double v = mv > 100_000 ? mv / 1_000_000.0 : mv / 1000.0; // µV or mV
                out[1] = (float) (a * v);
            }
        } catch (Throwable t) {
            logOnce("power", "battery current failed: " + t);
        }
        return out;
    }

    private static float readBatteryTemp(Context ctx) {
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return Float.NaN;
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            return t == Integer.MIN_VALUE ? Float.NaN : t / 10f;
        } catch (Throwable t) {
            logOnce("bat", "battery temperature failed: " + t);
            return Float.NaN;
        }
    }

    /** Hottest CPU core. System UI has the DEVICE_POWER permission this needs. */
    private static float readCpuTemp(Context ctx) {
        try {
            HardwarePropertiesManager hpm = ctx.getSystemService(HardwarePropertiesManager.class);
            if (hpm != null) {
                float[] temps = hpm.getDeviceTemperatures(
                        HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU,
                        HardwarePropertiesManager.TEMPERATURE_CURRENT);
                float max = Float.NaN;
                for (float t : temps) {
                    if (t == HardwarePropertiesManager.UNDEFINED_TEMPERATURE || t <= 0 || t > 150) continue;
                    if (Float.isNaN(max) || t > max) max = t;
                }
                if (!Float.isNaN(max)) {
                    logOnce("cpu-hpm", "CPU temperature from HardwarePropertiesManager");
                    return max;
                }
            }
        } catch (Throwable t) {
            logOnce("cpu-hpm-err", "HardwarePropertiesManager failed: " + t);
        }
        return readThermalZones();
    }

    /** Fallback: the kernel's thermal zones (may be blocked by SELinux). */
    private static float readThermalZones() {
        float max = Float.NaN;
        try {
            File[] zones = new File("/sys/class/thermal").listFiles();
            if (zones == null) return max;
            for (File z : zones) {
                if (!z.getName().startsWith("thermal_zone")) continue;
                String type = readLine(new File(z, "type"));
                if (type == null) continue;
                String t = type.toLowerCase(Locale.US);
                if (!(t.startsWith("cpu") || t.contains("cpuss") || t.contains("soc"))) continue;
                String v = readLine(new File(z, "temp"));
                if (v == null) continue;
                float c = Float.parseFloat(v.trim());
                if (c > 1000) c /= 1000f;
                if (c <= 0 || c > 150) continue;
                if (Float.isNaN(max) || c > max) max = c;
            }
            if (!Float.isNaN(max)) logOnce("cpu-sys", "CPU temperature from /sys/class/thermal");
            else logOnce("cpu-none", "no readable CPU temperature found");
        } catch (Throwable t) {
            logOnce("cpu-sys-err", "thermal zones failed: " + t);
        }
        return max;
    }

    private static String readLine(File f) {
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            return r.readLine();
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ helpers

    private static int dp(Resources res, float dp) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, res.getDisplayMetrics()));
    }

    private static synchronized void logOnce(String key, String msg) {
        if (sLogOnce.put(key, Boolean.TRUE) == null) XposedBridge.log(TAG + msg);
    }
}
