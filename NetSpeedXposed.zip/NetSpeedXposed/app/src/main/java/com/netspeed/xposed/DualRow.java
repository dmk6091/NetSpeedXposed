package com.netspeed.xposed;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.HardwarePropertiesManager;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Two-row status bar.
 *
 *   Row 1 left : clock, CPU temp / battery temp, weather icon + temperature
 *   Row 1 right: net speed, VoLTE / VoNR icons, battery
 *   Row 2 left : notification icons (full width, no camera cutout in the way)
 *   Row 2 right: other system icons (Wi-Fi, signal, Bluetooth, location ...)
 *
 * The status bar is made taller by adding ROW2_DP to the height System UI
 * reports for its window, so apps automatically start below both rows.
 */
final class DualRow {

    private static final String TAG = "NetSpeedXposed: [dual] ";
    private static final String SYSTEMUI = "com.android.systemui";

    // ---------------------------------------------------------------- settings

    /** Master switch. false = normal one-row status bar. */
    static final boolean ENABLED = true;

    /** Height of the second row, in dp. */
    static final int ROW2_DP = 20;
    /** Gap between row 1's icons and row 2. */
    static final int ROW_GAP_DP = 2;
    /**
     * How much taller than stock the whole status bar gets. Row 2 is tucked into the
     * stock height first (it's tall because of the camera cutout), so 0 is usually enough;
     * raise it if row 2 looks cut off at the bottom.
     */
    static final int EXTRA_DP = 0;

    /** Status icons whose slot name contains one of these stay on row 1 (right). */
    static final String[] ROW1_SLOT_KEYWORDS = {"volte", "vonr", "vowifi", "ims"};

    /** Show CPU temperature / battery temperature / weather on row 1. */
    static final boolean SHOW_CPU_TEMP = true;
    static final boolean SHOW_BATTERY_TEMP = true;
    static final boolean SHOW_WEATHER = true;
    /** true = net speed sits on row 1 after the weather; false = stays on the right. */
    static final boolean NETSPEED_AFTER_WEATHER = true;

    /** How often temperatures are refreshed, in milliseconds. */
    static final long TEMP_INTERVAL_MS = 5_000;

    /** Weather is also refreshed whenever OmniJaws updates; this is a fallback. */
    static final long WEATHER_INTERVAL_MS = 15 * 60_000;

    // ---------------------------------------------------------------- internals

    private static final Uri OMNI_WEATHER = Uri.parse("content://org.omnirom.omnijaws.provider/weather");
    private static final Uri OMNI_SETTINGS = Uri.parse("content://org.omnirom.omnijaws.provider/settings");
    private static final String OMNI_PKG = "org.omnirom.omnijaws";

    private static final String BAR_CLASS = "com.android.systemui.statusbar.phone.PhoneStatusBarView";
    private static final String BAR_UTILS = "com.android.internal.policy.SystemBarUtils";

    /** When true, the height hook returns the original (one-row) height. */
    private static volatile boolean sBypass = false;
    private static boolean sHeightLogged = false;
    private static final Map<String, Boolean> sLogOnce = new HashMap<>();

    private DualRow() {}

    static void install(ClassLoader cl) {
        if (!ENABLED) return;
        hookHeight("systemui");

        try {
            XposedHelpers.findAndHookMethod(BAR_CLASS, cl, "onFinishInflate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    final ViewGroup bar = (ViewGroup) p.thisObject;
                    // Run after every other onFinishInflate hook (net speed indicator included).
                    bar.post(() -> {
                        try {
                            build(bar);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "build failed: " + t);
                            XposedBridge.log(t);
                        }
                    });
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "onFinishInflate hook failed: " + t);
        }

        // System UI recalculates the layout on rotation / cutout changes; re-apply ours after.
        try {
            Class<?> bar = XposedHelpers.findClass(BAR_CLASS, cl);
            int n = XposedBridge.hookAllMethods(bar, "updateLayoutForCutout", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        applyRowHeights((ViewGroup) p.thisObject);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "re-layout failed: " + t);
                    }
                }
            }).size();
            XposedBridge.log(TAG + "updateLayoutForCutout hooks: " + n);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "updateLayoutForCutout hook failed: " + t);
        }
    }

    // ------------------------------------------------------------ status bar height

    /**
     * Makes the status bar ROW2_DP taller by changing the height values Android reads
     * from its resources (status_bar_height_default / _portrait / _landscape).
     * Hooking Resources works in both System UI and the system framework, unlike hooks
     * on SystemBarUtils, which Android 16 compiles inline so they never fire.
     */
    static void hookHeight(final String where) {
        if (!ENABLED) return;
        Resources sys = Resources.getSystem();
        final java.util.Set<Integer> ids = new java.util.HashSet<>();
        for (String n : new String[]{"status_bar_height_default", "status_bar_height_portrait",
                "status_bar_height_landscape", "status_bar_height"}) {
            int id = sys.getIdentifier(n, "dimen", "android");
            if (id != 0) ids.add(id);
        }
        if (ids.isEmpty()) {
            XposedBridge.log(TAG + "[" + where + "] status bar height resources not found");
            return;
        }
        XC_MethodHook add = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (sBypass || !(p.args[0] instanceof Integer) || !ids.contains(p.args[0])) return;
                Object r = p.getResult();
                Resources res = (Resources) p.thisObject;
                if (EXTRA_DP <= 0) return;
                float extra = EXTRA_DP * res.getDisplayMetrics().density;
                if (r instanceof Integer) {
                    int h = (Integer) r;
                    if (h <= 0) return;
                    p.setResult(h + Math.round(extra));
                    logHeight(where, h, h + Math.round(extra));
                } else if (r instanceof Float) {
                    float h = (Float) r;
                    if (h <= 0) return;
                    p.setResult(h + extra);
                }
            }
        };
        int n = 0;
        for (String m : new String[]{"getDimensionPixelSize", "getDimensionPixelOffset", "getDimension"}) {
            try {
                XposedHelpers.findAndHookMethod(Resources.class, m, int.class, add);
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "[" + where + "] hook " + m + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "[" + where + "] height hooks: " + n + " ids: " + ids.size());
    }

    private static void logHeight(String where, int from, int to) {
        if (sHeightLogged) return;
        sHeightLogged = true;
        XposedBridge.log(TAG + "[" + where + "] status bar height " + from + " -> " + to);
    }

    /** Status bar height without our second row. */
    private static int row1Height(Context ctx) {
        sBypass = true;
        try {
            Class<?> c = XposedHelpers.findClass(BAR_UTILS, ctx.getClassLoader());
            java.lang.reflect.Method m = c.getDeclaredMethod("getStatusBarHeight", Context.class);
            m.setAccessible(true);
            return (Integer) m.invoke(null, ctx);
        } catch (Throwable t) {
            Resources sys = Resources.getSystem();
            int id = sys.getIdentifier("status_bar_height", "dimen", "android");
            return id != 0 ? sys.getDimensionPixelSize(id) : dp(sys, 28);
        } finally {
            sBypass = false;
        }
    }

    // ------------------------------------------------------------ layout

    private static View byId(View root, String name) {
        int id = root.getResources().getIdentifier(name, "id", SYSTEMUI);
        return id != 0 ? root.findViewById(id) : null;
    }

    private static void detach(View v) {
        if (v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    private static void build(ViewGroup bar) {
        if (bar.findViewWithTag("dual_row2") != null) return;
        Context ctx = bar.getContext();

        View contents = byId(bar, "status_bar_contents");
        View notifArea = byId(bar, "notification_icon_area");
        View statusIcons = byId(bar, "statusIcons");
        View clock = byId(bar, "clock");
        View systemIcons = byId(bar, "system_icons");
        XposedBridge.log(TAG + "views: contents=" + (contents != null)
                + " notifArea=" + (notifArea != null) + " statusIcons=" + (statusIcons != null)
                + " clock=" + (clock != null) + " systemIcons=" + (systemIcons != null)
                + " bar=" + bar.getClass().getSuperclass().getSimpleName());

        if (contents == null || !(bar instanceof FrameLayout)) {
            XposedBridge.log(TAG + "unexpected status bar layout, dual row not applied");
            return;
        }

        // ---- Row 2 container
        LinearLayout row2 = new LinearLayout(ctx);
        row2.setTag("dual_row2");
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(row2, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx.getResources(), ROW2_DP), Gravity.TOP));

        // Row 2 left: notification icons, taking all free width.
        if (notifArea != null) {
            detach(notifArea);
            row2.addView(notifArea, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        } else {
            row2.addView(new View(ctx), new LinearLayout.LayoutParams(0, 1, 1f));
        }

        // Row 2 right: the system icons (Wi-Fi, signal, Bluetooth, location ...).
        if (statusIcons != null) {
            detach(statusIcons);
            row2.addView(statusIcons, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        applyRowHeights(bar);
        // Row 1 items are measured, so re-place row 2 whenever the bar lays out again.
        bar.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) ->
                v.post(() -> {
                    try { applyRowHeights((ViewGroup) v); } catch (Throwable ignored) { }
                }));

        // ---- Row 1 right: VoLTE / VoNR mirrors, just before the battery.
        LinearLayout imsRow = null;
        if (systemIcons != null && systemIcons.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) systemIcons.getParent();
            imsRow = new LinearLayout(ctx);
            imsRow.setTag("dual_ims");
            imsRow.setOrientation(LinearLayout.HORIZONTAL);
            imsRow.setGravity(Gravity.CENTER_VERTICAL);
            p.addView(imsRow, p.indexOfChild(systemIcons), wrapParams(p));
        }

        // ---- Row 1 left: temperatures and weather, right after the clock.
        Extras extras = null;
        if (clock != null && clock.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) clock.getParent();
            extras = new Extras(ctx);
            p.addView(extras.root, p.indexOfChild(clock) + 1, wrapParams(p));
        } else {
            XposedBridge.log(TAG + "clock not found, temperatures/weather not added");
        }

        new Updater(bar, clock, statusIcons, imsRow, extras).start();
        XposedBridge.log(TAG + "dual row built");
    }

    private static ViewGroup.LayoutParams wrapParams(ViewGroup parent) {
        if (parent instanceof LinearLayout) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = Gravity.CENTER_VERTICAL;
            return lp;
        }
        return new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    /**
     * Row 1 keeps the original area at the top. Row 2 sits ROW_GAP_DP below the lowest
     * row-1 item (clock / temperatures), not below the whole cutout-sized row 1.
     */
    private static void applyRowHeights(ViewGroup bar) {
        View row2 = bar.findViewWithTag("dual_row2");
        View contents = byId(bar, "status_bar_contents");
        if (row2 == null || contents == null) return;

        Resources res = bar.getResources();
        int row1 = row1Height(bar.getContext());
        int row2h = dp(res, ROW2_DP);
        int barH = bar.getHeight() > 0 ? bar.getHeight() : row1 + dp(res, EXTRA_DP);

        ViewGroup.LayoutParams clp = contents.getLayoutParams();
        if (clp != null && clp.height != row1) {
            clp.height = row1;
            if (clp instanceof FrameLayout.LayoutParams) ((FrameLayout.LayoutParams) clp).gravity = Gravity.TOP;
            contents.setLayoutParams(clp);
        }

        // Bottom of the lowest row-1 item, in the bar's coordinates.
        int bottom = 0;
        for (View v : new View[]{byId(bar, "clock"), bar.findViewWithTag("dual_extras")}) {
            int b = bottomIn(bar, v);
            if (b > bottom) bottom = b;
        }
        int top = bottom > 0 ? bottom + dp(res, ROW_GAP_DP) : row1;
        // Keep row 2 inside the bar.
        if (top + row2h > barH) top = Math.max(0, barH - row2h);

        FrameLayout.LayoutParams rlp = (FrameLayout.LayoutParams) row2.getLayoutParams();
        if (rlp.height != row2h || rlp.topMargin != top) {
            rlp.height = row2h;
            rlp.topMargin = top;
            row2.setLayoutParams(rlp);
            logOnceStatic("rows", "row 1 items end at " + bottom + "px, row 2 at " + top
                    + "px, bar " + barH + "px");
        }
        // Line up with row 1's side padding (rounded screen corners).
        row2.setPaddingRelative(contents.getPaddingStart(), 0, contents.getPaddingEnd(), 0);
    }

    private static int bottomIn(ViewGroup bar, View v) {
        if (v == null || v.getHeight() == 0 || v.getVisibility() != View.VISIBLE) return 0;
        int[] a = new int[2], b = new int[2];
        v.getLocationInWindow(a);
        bar.getLocationInWindow(b);
        return a[1] - b[1] + v.getHeight();
    }

    private static void logOnceStatic(String key, String msg) {
        synchronized (sLogOnce) {
            if (sLogOnce.put(key, Boolean.TRUE) != null) return;
        }
        XposedBridge.log(TAG + msg);
    }

    // ------------------------------------------------------------ row 1 extras

    /** Two-line temperature text + weather icon and temperature. */
    private static final class Extras {
        final LinearLayout root;
        final TextView temps;
        final ImageView weatherIcon;
        final TextView weatherTemp;

        Extras(Context ctx) {
            Resources res = ctx.getResources();
            int pad = dp(res, 4);

            root = new LinearLayout(ctx);
            root.setTag("dual_extras");
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setGravity(Gravity.CENTER_VERTICAL);
            root.setPaddingRelative(pad, 0, 0, 0);

            temps = new TextView(ctx);
            temps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8);
            temps.setTypeface(Typeface.DEFAULT_BOLD);
            temps.setIncludeFontPadding(false);
            temps.setLineSpacing(0, 0.85f);
            temps.setMaxLines(2);
            temps.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            temps.setVisibility(View.GONE);
            root.addView(temps, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            int icon = dp(res, 14);
            weatherIcon = new ImageView(ctx);
            weatherIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            weatherIcon.setVisibility(View.GONE);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(icon, icon);
            ilp.setMarginStart(pad);
            root.addView(weatherIcon, ilp);

            weatherTemp = new TextView(ctx);
            weatherTemp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            weatherTemp.setIncludeFontPadding(false);
            weatherTemp.setVisibility(View.GONE);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.setMarginStart(dp(res, 2));
            root.addView(weatherTemp, tlp);
        }
    }

    // ------------------------------------------------------------ updater

    private static final class Updater {
        final ViewGroup bar;
        final View clock;
        final View statusIcons;
        final LinearLayout imsRow;
        final Extras extras;
        final Context ctx;

        final Handler main = new Handler(Looper.getMainLooper());
        final Handler worker;

        /** Mirrored row-1 icons, by slot name. */
        final Map<String, ImageView> mirrors = new HashMap<>();

        // Values filled in by the worker thread.
        volatile float cpuTemp = Float.NaN;
        volatile float batTemp = Float.NaN;
        volatile String weatherTemp = null;
        volatile Drawable weatherIcon = null;
        volatile boolean tintWeatherIcon = true;

        boolean wasAttached = false;
        boolean stopped = false;

        Updater(ViewGroup bar, View clock, View statusIcons, LinearLayout imsRow, Extras extras) {
            this.bar = bar;
            this.clock = clock;
            this.statusIcons = statusIcons;
            this.imsRow = imsRow;
            this.extras = extras;
            this.ctx = bar.getContext();
            HandlerThread t = new HandlerThread("NetSpeedXposed-dual");
            t.start();
            worker = new Handler(t.getLooper());
        }

        void start() {
            main.post(uiTick);
            if (extras != null) {
                worker.post(tempTick);
                if (SHOW_WEATHER) {
                    worker.post(weatherTick);
                    try {
                        ctx.getContentResolver().registerContentObserver(OMNI_WEATHER, true,
                                new ContentObserver(worker) {
                                    @Override
                                    public void onChange(boolean selfChange) {
                                        loadWeather();
                                    }
                                });
                    } catch (Throwable t) {
                        logOnce("observer", "OmniJaws observer failed: " + t);
                    }
                }
            }
        }

        /** Stop once this status bar has been replaced (re-inflated). */
        boolean dead() {
            if (stopped) return true;
            if (bar.isAttachedToWindow()) wasAttached = true;
            else if (wasAttached) {
                stopped = true;
                worker.getLooper().quitSafely();
            }
            return stopped;
        }

        // ---- UI thread: every second
        final Runnable uiTick = new Runnable() {
            @Override
            public void run() {
                if (dead()) return;
                try {
                    int color = clock instanceof TextView ? ((TextView) clock).getCurrentTextColor() : 0xFFFFFFFF;
                    updateMirrors(color);
                    if (extras != null) {
                        updateExtras(color);
                        moveNetSpeed();
                    }
                } catch (Throwable t) {
                    logOnce("ui", "update failed: " + t);
                }
                main.postDelayed(this, 1000);
            }
        };

        /** Put the net speed indicator (added by Hook) on row 1, right after the weather. */
        void moveNetSpeed() {
            if (!NETSPEED_AFTER_WEATHER) return;
            View ns = bar.findViewWithTag("netspeed_xposed");
            if (ns == null || ns.getParent() == extras.root) return;
            detach(ns);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.CENTER_VERTICAL;
            lp.setMarginStart(dp(bar.getResources(), 4));
            extras.root.addView(ns, lp);
            if (ns instanceof TextView) {
                TextView tv = (TextView) ns;
                tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                tv.setPadding(0, 0, 0, 0);
            }
            XposedBridge.log(TAG + "net speed moved next to weather");
        }

        void updateMirrors(int color) {
            if (!(statusIcons instanceof ViewGroup) || imsRow == null) return;
            ViewGroup g = (ViewGroup) statusIcons;
            for (int i = 0; i < g.getChildCount(); i++) {
                View child = g.getChildAt(i);
                String slot;
                try {
                    slot = String.valueOf(XposedHelpers.callMethod(child, "getSlot"));
                } catch (Throwable t) {
                    continue;
                }
                logOnce("slot:" + slot, "status icon slot: " + slot);
                if (!isRow1Slot(slot)) continue;

                ImageView m = mirrors.get(slot);
                if (m == null) {
                    // Hide it on row 2 and show a copy on row 1.
                    try {
                        XposedHelpers.callMethod(g, "addIgnoredSlot", slot);
                    } catch (Throwable t) {
                        logOnce("ignore", "addIgnoredSlot failed: " + t);
                    }
                    m = new ImageView(ctx);
                    m.setAdjustViewBounds(true);
                    m.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, dp(ctx.getResources(), 15));
                    lp.setMarginStart(dp(ctx.getResources(), 2));
                    imsRow.addView(m, lp);
                    mirrors.put(slot, m);
                    XposedBridge.log(TAG + "moved " + slot + " to row 1");
                }

                boolean visible;
                try {
                    visible = (Boolean) XposedHelpers.callMethod(child, "isIconVisible");
                } catch (Throwable t) {
                    visible = child.getVisibility() == View.VISIBLE;
                }
                Drawable d = child instanceof ImageView ? ((ImageView) child).getDrawable() : null;
                if (!visible || d == null) {
                    m.setVisibility(View.GONE);
                    continue;
                }
                if (m.getTag() != d) {
                    // A copy, so the two views don't fight over one drawable.
                    Drawable copy = d.getConstantState() != null
                            ? d.getConstantState().newDrawable(ctx.getResources()).mutate() : d;
                    m.setImageDrawable(copy);
                    m.setTag(d);
                }
                m.setColorFilter(color, PorterDuff.Mode.SRC_IN);
                m.setVisibility(View.VISIBLE);
            }
        }

        void updateExtras(int color) {
            StringBuilder sb = new StringBuilder();
            if (SHOW_CPU_TEMP && !Float.isNaN(cpuTemp)) {
                sb.append("CPU ").append(Math.round(cpuTemp)).append('°');
            }
            if (SHOW_BATTERY_TEMP && !Float.isNaN(batTemp)) {
                if (sb.length() > 0) sb.append('\n');
                sb.append("BAT ").append(Math.round(batTemp)).append('°');
            }
            extras.temps.setTextColor(color);
            Hook.matchClockFont(clock, extras.temps, true);
            extras.temps.setText(sb);
            extras.temps.setVisibility(sb.length() > 0 ? View.VISIBLE : View.GONE);

            String wt = weatherTemp;
            Drawable wi = weatherIcon;
            if (SHOW_WEATHER && wt != null) {
                extras.weatherTemp.setTextColor(color);
                Hook.matchClockFont(clock, extras.weatherTemp, false);
                extras.weatherTemp.setText(wt + "°");
                extras.weatherTemp.setVisibility(View.VISIBLE);
            } else {
                extras.weatherTemp.setVisibility(View.GONE);
            }
            if (SHOW_WEATHER && wt != null && wi != null) {
                if (extras.weatherIcon.getDrawable() != wi) extras.weatherIcon.setImageDrawable(wi);
                if (tintWeatherIcon) extras.weatherIcon.setColorFilter(color, PorterDuff.Mode.SRC_IN);
                else extras.weatherIcon.clearColorFilter();
                extras.weatherIcon.setVisibility(View.VISIBLE);
            } else {
                extras.weatherIcon.setVisibility(View.GONE);
            }
        }

        // ---- Worker thread: temperatures
        final Runnable tempTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                if (SHOW_CPU_TEMP) cpuTemp = readCpuTemp(ctx);
                if (SHOW_BATTERY_TEMP) batTemp = readBatteryTemp(ctx);
                worker.postDelayed(this, TEMP_INTERVAL_MS);
            }
        };

        // ---- Worker thread: weather fallback refresh
        final Runnable weatherTick = new Runnable() {
            @Override
            public void run() {
                if (stopped) return;
                loadWeather();
                worker.postDelayed(this, WEATHER_INTERVAL_MS);
            }
        };

        void loadWeather() {
            try {
                boolean enabled = true;
                String iconPack = null;
                try (Cursor s = ctx.getContentResolver().query(OMNI_SETTINGS, null, null, null, null)) {
                    if (s != null && s.moveToFirst()) {
                        int e = s.getColumnIndex("enabled");
                        if (e >= 0) enabled = s.getInt(e) != 0;
                        int ip = s.getColumnIndex("icon_pack");
                        if (ip >= 0) iconPack = s.getString(ip);
                    }
                }
                if (!enabled) {
                    logOnce("omni-off", "OmniJaws weather is turned off");
                    weatherTemp = null;
                    return;
                }
                String temp = null;
                int code = -1;
                try (Cursor c = ctx.getContentResolver().query(OMNI_WEATHER, null, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        int ti = c.getColumnIndex("temperature");
                        int ci = c.getColumnIndex("condition_code");
                        if (ti >= 0) temp = c.getString(ti);
                        if (ci >= 0) code = c.getInt(ci);
                    }
                }
                if (temp == null || temp.isEmpty()) {
                    logOnce("omni-empty", "OmniJaws has no weather data yet");
                    weatherTemp = null;
                    return;
                }
                // Drop decimals: "28.4" -> "28".
                try {
                    temp = String.valueOf(Math.round(Float.parseFloat(temp.replace(",", "."))));
                } catch (NumberFormatException ignored) {
                    // Keep OmniJaws' own text.
                }
                weatherIcon = code >= 0 ? loadWeatherIcon(iconPack, code) : null;
                weatherTemp = temp;
                logOnce("omni-ok", "OmniJaws weather: " + temp + "°, code " + code
                        + ", icon pack " + iconPack + ", icon " + (weatherIcon != null));
            } catch (Throwable t) {
                logOnce("omni-err", "OmniJaws read failed: " + t);
                weatherTemp = null;
            }
        }

        /** OmniJaws icons are named "<prefix>_<code>" inside the icon pack's package. */
        Drawable loadWeatherIcon(String iconPack, int code) {
            String[][] tries = new String[4][];
            int n = 0;
            if (iconPack != null && iconPack.lastIndexOf('.') > 0) {
                int dot = iconPack.lastIndexOf('.');
                tries[n++] = new String[]{iconPack.substring(0, dot), iconPack.substring(dot + 1)};
            }
            tries[n++] = new String[]{OMNI_PKG, "outline"};
            tries[n++] = new String[]{OMNI_PKG, "google"};
            tries[n++] = new String[]{OMNI_PKG, "weather"};
            for (int i = 0; i < n; i++) {
                try {
                    Resources r = ctx.getPackageManager().getResourcesForApplication(tries[i][0]);
                    int id = r.getIdentifier(tries[i][1] + "_" + code, "drawable", tries[i][0]);
                    if (id == 0) continue;
                    Drawable d = r.getDrawable(id, null);
                    // Outline icons are single-colour: tint them like the clock.
                    // Other packs are full colour: leave them as they are.
                    tintWeatherIcon = tries[i][1].contains("outline");
                    return d;
                } catch (Throwable ignored) {
                    // Try the next one.
                }
            }
            logOnce("omni-icon", "no OmniJaws icon found for pack " + iconPack);
            return null;
        }
    }

    private static boolean isRow1Slot(String slot) {
        String s = slot.toLowerCase(Locale.US);
        for (String k : ROW1_SLOT_KEYWORDS) if (s.contains(k)) return true;
        return false;
    }

    // ------------------------------------------------------------ temperatures

    private static float readBatteryTemp(Context ctx) {
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return Float.NaN;
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            return t == Integer.MIN_VALUE ? Float.NaN : t / 10f;
        } catch (Throwable t) {
            logOnce("bat", "battery temperature failed: " + t);
            return Float.NaN;
        }
    }

    /** Hottest CPU core. System UI has the DEVICE_POWER permission this needs. */
    private static float readCpuTemp(Context ctx) {
        try {
            HardwarePropertiesManager hpm = ctx.getSystemService(HardwarePropertiesManager.class);
            if (hpm != null) {
                float[] temps = hpm.getDeviceTemperatures(
                        HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU,
                        HardwarePropertiesManager.TEMPERATURE_CURRENT);
                float max = Float.NaN;
                for (float t : temps) {
                    if (t == HardwarePropertiesManager.UNDEFINED_TEMPERATURE || t <= 0 || t > 150) continue;
                    if (Float.isNaN(max) || t > max) max = t;
                }
                if (!Float.isNaN(max)) {
                    logOnce("cpu-hpm", "CPU temperature from HardwarePropertiesManager");
                    return max;
                }
            }
        } catch (Throwable t) {
            logOnce("cpu-hpm-err", "HardwarePropertiesManager failed: " + t);
        }
        return readThermalZones();
    }

    /** Fallback: the kernel's thermal zones (may be blocked by SELinux). */
    private static float readThermalZones() {
        float max = Float.NaN;
        try {
            File[] zones = new File("/sys/class/thermal").listFiles();
            if (zones == null) return max;
            for (File z : zones) {
                if (!z.getName().startsWith("thermal_zone")) continue;
                String type = readLine(new File(z, "type"));
                if (type == null) continue;
                String t = type.toLowerCase(Locale.US);
                if (!(t.startsWith("cpu") || t.contains("cpuss") || t.contains("soc"))) continue;
                String v = readLine(new File(z, "temp"));
                if (v == null) continue;
                float c = Float.parseFloat(v.trim());
                if (c > 1000) c /= 1000f;
                if (c <= 0 || c > 150) continue;
                if (Float.isNaN(max) || c > max) max = c;
            }
            if (!Float.isNaN(max)) logOnce("cpu-sys", "CPU temperature from /sys/class/thermal");
            else logOnce("cpu-none", "no readable CPU temperature found");
        } catch (Throwable t) {
            logOnce("cpu-sys-err", "thermal zones failed: " + t);
        }
        return max;
    }

    private static String readLine(File f) {
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            return r.readLine();
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ helpers

    private static int dp(Resources res, float dp) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, res.getDisplayMetrics()));
    }

    private static synchronized void logOnce(String key, String msg) {
        if (sLogOnce.put(key, Boolean.TRUE) == null) XposedBridge.log(TAG + msg);
    }
}
