package com.netspeed.xposed;

import android.content.res.Resources;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * App suggestions: Android only starts its app prediction service (which the launcher asks for
 * dock / app drawer suggestions) when the ROM names a prediction app in
 * config_defaultAppPredictionService. Lunaris names none, so we name ours (system server, at boot).
 * Switched by the property persist.sys.netspeed.predict, set by the settings app. Needs a reboot.
 */
final class Predict {
    static final String PROP = "persist.sys.netspeed.predict";
    /** Flag file (written with root by the settings app); the system server can read it at boot. */
    static final String FLAG = "/data/system/netspeed_predict";
    static final String SERVICE = "com.netspeed.xposed/.PredictionService";
    private static final String TAG = "NetSpeedXposed: [predict] ";

    private Predict() {}

    static boolean enabled() {
        try {
            if (new java.io.File(FLAG).exists()) return true;
        } catch (Throwable ignored) { }
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            return (Boolean) sp.getMethod("getBoolean", String.class, boolean.class).invoke(null, PROP, false);
        } catch (Throwable t) {
            return false;
        }
    }

    static void installSystem() {
        boolean on = enabled();
        final int id = Resources.getSystem().getIdentifier("config_defaultAppPredictionService", "string", "android");
        String current = "";
        try {
            if (id != 0) current = Resources.getSystem().getString(id);
        } catch (Throwable ignored) { }
        XposedBridge.log(TAG + "switch (" + FLAG + " or " + PROP + ") = " + on + ", ROM prediction service = \""
                + current + "\"" + (id == 0 ? " (setting not found)" : ""));
        if (!on || id == 0) return;
        if (current != null && !current.isEmpty()) {
            XposedBridge.log(TAG + "ROM already has a prediction service, leaving it alone");
            return;
        }
        XC_MethodHook h = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Integer && (Integer) p.args[0] == id) {
                    p.setResult(SERVICE);
                }
            }
        };
        int n = 0;
        for (String m : new String[]{"getText", "getString"}) {
            try {
                XposedHelpers.findAndHookMethod(Resources.class, m, int.class, h);
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "hook " + m + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "prediction service set to " + SERVICE + " (hooks " + n + ")");
    }
}
