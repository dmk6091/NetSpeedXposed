package com.netspeed.xposed;

import android.graphics.Insets;
import android.view.WindowInsets;
import android.view.WindowManager;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Immersive navigation when the launcher draws the gesture pill (Android 16 "Taskbar" on
 * phones, as on Lunaris). The Taskbar window tells the system how much space to keep free
 * for navigation; we set its navigation-bar inset to zero, so apps draw to the bottom edge.
 * The gesture inset types (system / mandatory gestures) are left as they are, so swipes keep
 * working, and the pill itself is still drawn by the launcher.
 */
final class LauncherNav {
    private static final String TAG = "NetSpeedXposed: [nav] ";
    private static boolean sLogged = false;

    private LauncherNav() {}

    static void install(String pkg, ClassLoader cl) {
        XposedBridge.log(TAG + "[" + pkg + "] loaded, property " + NavImmersive.PROP + " = "
                + NavImmersive.enabled());
        XC_MethodHook h = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                android.view.View v = null;
                WindowManager.LayoutParams lp = null;
                for (Object a : p.args) {
                    if (a instanceof android.view.View) v = (android.view.View) a;
                    if (a instanceof WindowManager.LayoutParams) lp = (WindowManager.LayoutParams) a;
                }
                if (lp == null || !isTaskbar(lp)) return;
                if (!on(v)) return;
                strip(lp);
            }
        };
        int n = 0;
        try {
            Class<?> g = XposedHelpers.findClass("android.view.WindowManagerGlobal", cl);
            n += XposedBridge.hookAllMethods(g, "addView", h).size();
            n += XposedBridge.hookAllMethods(g, "updateViewLayout", h).size();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "[" + pkg + "] window hooks failed: " + t);
        }
        XposedBridge.log(TAG + "[" + pkg + "] taskbar hooks: " + n);
    }

    static boolean isTaskbar(WindowManager.LayoutParams lp) {
        CharSequence title = lp.getTitle();
        return title != null && title.toString().toLowerCase(java.util.Locale.US).contains("taskbar");
    }

    private static boolean sLoggedSrc = false;

    /** On if the system property is set, or the NetSpeed app's setting is on (read directly). */
    static boolean on(android.view.View v) {
        if (NavImmersive.enabled()) return true;
        boolean on = false;
        String how = "app setting";
        try {
            android.content.Context ctx = v != null ? v.getContext() : null;
            if (ctx == null) {
                how = "no context";
            } else {
                try (android.database.Cursor c = ctx.getContentResolver().query(Cfg.URI, null, null, null, null)) {
                    if (c == null) how = "settings app not reachable";
                    else while (c.moveToNext()) {
                        if (Cfg.NAV_IMMERSIVE.equals(c.getString(0))) on = Boolean.parseBoolean(c.getString(1));
                    }
                }
            }
        } catch (Throwable t) {
            how = "settings read failed: " + t;
        }
        if (!sLoggedSrc) {
            sLoggedSrc = true;
            XposedBridge.log(TAG + "taskbar window seen, immersive = " + on + " (" + how + ")");
        }
        return on;
    }

    /** Zero the navigation-bar inset a Taskbar window provides (gestures untouched). */
    static void strip(WindowManager.LayoutParams lp) {
        try {
            Object arr = XposedHelpers.getObjectField(lp, "providedInsets");
            if (!(arr instanceof Object[])) return;
            int nav = WindowInsets.Type.navigationBars(), changed = 0;
            for (Object prov : (Object[]) arr) {
                if (prov == null) continue;
                int type = (Integer) XposedHelpers.callMethod(prov, "getType");
                if (type != nav) continue;
                XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                changed++;
            }
            if (changed > 0 && !sLogged) {
                sLogged = true;
                XposedBridge.log(TAG + "taskbar navigation inset removed (" + changed + ")");
            }
        } catch (Throwable t) {
            if (!sLogged) {
                sLogged = true;
                XposedBridge.log(TAG + "couldn't change the taskbar inset: " + t);
            }
        }
    }
}
