package com.netspeed.xposed;

import android.graphics.Insets;
import android.view.WindowInsets;
import android.view.WindowManager;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Immersive navigation when the launcher draws the gesture pill (Android 16 "Taskbar" on
 * phones, as on Lunaris). The Taskbar window tells the system how much space to keep free
 * for navigation; we set its navigation-bar inset to zero, so apps draw to the bottom edge.
 * The gesture inset types (system / mandatory gestures) are left as they are, so swipes keep
 * working, and the pill itself is still drawn by the launcher.
 */
final class LauncherNav {
    private static final String TAG = "NetSpeedXposed: [nav] ";
    private static boolean sLogged = false;

    private LauncherNav() {}

    static void install(String pkg, ClassLoader cl) {
        XposedBridge.log(TAG + "[" + pkg + "] loaded, property " + NavImmersive.PROP + " = "
                + NavImmersive.enabled());
        XC_MethodHook h = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (!NavImmersive.enabled()) return;
                for (Object a : p.args) {
                    if (a instanceof WindowManager.LayoutParams) strip((WindowManager.LayoutParams) a);
                }
            }
        };
        int n = 0;
        try {
            Class<?> g = XposedHelpers.findClass("android.view.WindowManagerGlobal", cl);
            n += XposedBridge.hookAllMethods(g, "addView", h).size();
            n += XposedBridge.hookAllMethods(g, "updateViewLayout", h).size();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "[" + pkg + "] window hooks failed: " + t);
        }
        XposedBridge.log(TAG + "[" + pkg + "] taskbar hooks: " + n);
    }

    /** Zero the navigation-bar inset a Taskbar window provides (gestures untouched). */
    static void strip(WindowManager.LayoutParams lp) {
        CharSequence title = lp.getTitle();
        if (title == null || !title.toString().toLowerCase(java.util.Locale.US).contains("taskbar")) return;
        try {
            Object arr = XposedHelpers.getObjectField(lp, "providedInsets");
            if (!(arr instanceof Object[])) return;
            int nav = WindowInsets.Type.navigationBars(), changed = 0;
            for (Object prov : (Object[]) arr) {
                if (prov == null) continue;
                int type = (Integer) XposedHelpers.callMethod(prov, "getType");
                if (type != nav) continue;
                XposedHelpers.callMethod(prov, "setInsetsSize", Insets.NONE);
                changed++;
            }
            if (changed > 0 && !sLogged) {
                sLogged = true;
                XposedBridge.log(TAG + "taskbar navigation inset removed (" + changed + ")");
            }
        } catch (Throwable t) {
            if (!sLogged) {
                sLogged = true;
                XposedBridge.log(TAG + "couldn't change the taskbar inset: " + t);
            }
        }
    }
}
