package com.netspeed.xposed;

import android.view.View;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Hides the big "R" that the status bar shows beside the signal bars while roaming
 * (view "mobile_roaming_updated"). The small raised R on top of the bars stays.
 * Switch: Cfg.HIDE_SIDE_R.
 */
final class HideSideRoam {

    private static final String TAG = "NetSpeedXposed: [roam] ";
    private static final String VIEW_NAME = "mobile_roaming_updated";

    private HideSideRoam() {}

    static void install(ClassLoader cl) {
        try {
            XC_MethodHook hook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (!Cfg.b(Cfg.HIDE_SIDE_R, Cfg.D_HIDE_SIDE_R)) return;
                        View v = (View) p.thisObject;
                        if (v.getId() == View.NO_ID || !isTarget(v)) return;
                        if (p.method.getName().equals("setVisibility")) p.args[0] = View.GONE;
                    } catch (Throwable ignored) {
                    }
                }

                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (!Cfg.b(Cfg.HIDE_SIDE_R, Cfg.D_HIDE_SIDE_R)) return;
                        View v = (View) p.thisObject;
                        if (v.getId() == View.NO_ID || !isTarget(v)) return;
                        if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
                    } catch (Throwable ignored) {
                    }
                }
            };
            XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, hook);
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", hook);
            XposedBridge.log(TAG + "installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "install failed: " + t);
        }
    }

    private static boolean isTarget(View v) {
        try {
            return VIEW_NAME.equals(v.getResources().getResourceEntryName(v.getId()));
        } catch (Throwable t) {
            return false;
        }
    }
}
