package com.netspeed.xposed;

import android.content.Context;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Custom operator name per SIM, system-wide on this phone. Runs inside the phone service
 * (com.android.phone), where Android builds the names it hands to everyone else:
 *
 *  - network name ("gsm.operator.alpha", what apps get from getNetworkOperatorName),
 *  - SIM operator name ("gsm.sim.operator.alpha", getSimOperatorName),
 *  - the SIM's display / carrier name (SubscriptionInfo: settings, SIM picker, dialer),
 *  - the operator name inside ServiceState (status bar carrier text, lock screen).
 *
 * Only the text changes. Operator codes (MCC-MNC), the network, calls, SMS and data stay real.
 */
final class OperatorName {
    private static final String TAG = "NetSpeedXposed: [opname] ";

    private static final ThreadLocal<Object[]> SAVED = new ThreadLocal<>();

    private OperatorName() {}

    /** Custom name for SIM slot index 0/1, or null to keep the real one. */
    static String custom(int slotIndex) {
        Cfg.retryIfNeeded(); // the phone service starts very early; settings may not be readable yet
        String v = Cfg.s(slotIndex == 0 ? Cfg.OP_NAME1 : slotIndex == 1 ? Cfg.OP_NAME2 : "");
        return v == null || v.isEmpty() ? null : v;
    }

    static void install(final ClassLoader cl) {
        int n = 0;
        // Settings are read from the NetSpeed app once the phone service is up.
        try {
            XposedHelpers.findAndHookMethod(android.app.Instrumentation.class, "callApplicationOnCreate",
                    android.app.Application.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                Cfg.init((Context) p.args[0]);
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + "settings init failed: " + t);
                            }
                            try { NrFallback.registerPhone((Context) p.args[0]); } catch (Throwable ignored) { }
                            try { BandLock.registerPhone((Context) p.args[0]); } catch (Throwable ignored) { }
                        }
                    });
            n++;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "settings hook failed: " + t);
        }

        // 1) Network / SIM operator name properties, written per phone (= slot).
        XC_MethodHook byPhoneId = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (!(p.args[0] instanceof Integer)) return;
                String c = custom((Integer) p.args[0]);
                if (c != null) p.args[1] = c;
            }
        };
        for (String m : new String[]{"setNetworkOperatorNameForPhone", "setSimOperatorNameForPhone"}) {
            try {
                XposedHelpers.findAndHookMethod("android.telephony.TelephonyManager", cl, m,
                        int.class, String.class, byPhoneId);
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + m + " not hooked: " + t);
            }
        }

        // 2) SIM display / carrier name, as handed out in SubscriptionInfo.
        try {
            Class<?> b = XposedHelpers.findClass("android.telephony.SubscriptionInfo$Builder", cl);
            XposedBridge.hookAllMethods(b, "build", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        int slot = XposedHelpers.getIntField(p.thisObject, "mSimSlotIndex");
                        String c = custom(slot);
                        if (c == null) return;
                        XposedHelpers.setObjectField(p.thisObject, "mDisplayName", c);
                        XposedHelpers.setObjectField(p.thisObject, "mCarrierName", c);
                    } catch (Throwable ignored) { }
                }
            });
            n++;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "SubscriptionInfo not hooked: " + t);
        }

        // 3) Operator name inside ServiceState, set just before it's sent to anyone.
        try {
            XposedHelpers.findAndHookMethod("android.telephony.ServiceState", cl, "writeToParcel",
                    android.os.Parcel.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            int slot = slotOf(p.thisObject, cl);
                            String c = slot < 0 ? null : custom(slot);
                            if (c == null) return;
                            try {
                                String numeric = (String) XposedHelpers.callMethod(p.thisObject, "getOperatorNumeric");
                                Object longName = XposedHelpers.callMethod(p.thisObject, "getOperatorAlphaLong");
                                if (longName == null && numeric == null) return; // not registered
                                Object shortName = XposedHelpers.callMethod(p.thisObject, "getOperatorAlphaShort");
                                SAVED.set(new Object[]{longName, shortName, numeric});
                                XposedHelpers.callMethod(p.thisObject, "setOperatorName", c, c, numeric);
                            } catch (Throwable ignored) { }
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            // Put the real names back: only what leaves the phone service changes,
                            // so its own "did anything change?" checks keep working.
                            Object[] o = SAVED.get();
                            if (o == null) return;
                            SAVED.remove();
                            try {
                                XposedHelpers.callMethod(p.thisObject, "setOperatorName", o[0], o[1], o[2]);
                            } catch (Throwable ignored) { }
                        }
                    });
            n++;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "ServiceState not hooked: " + t);
        }
        // 4) Smart carrier name (when no custom name is set): the network's own fuller name at home
        //    ("Jio True5G"), and "SIM name · network name" on another state's network ("Jio · IND airtel").
        try {
            Class<?> sst = XposedHelpers.findClass("com.android.internal.telephony.ServiceStateTracker", cl);
            int k = XposedBridge.hookAllMethods(sst, "notifySpnDisplayUpdate", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length == 0 || p.args[0] == null) return;
                        Cfg.retryIfNeeded();
                        if (!Cfg.b(Cfg.SMART_CARRIER, Cfg.D_SMART_CARRIER)) return;
                        smart(p.thisObject, p.args[0]);
                    } catch (Throwable t) {
                        logOnce("smart name skipped: " + t);
                    }
                }
            }).size();
            if (k > 0) n++;
            else XposedBridge.log(TAG + "notifySpnDisplayUpdate not found on this ROM: smart carrier name off");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "smart carrier name not hooked: " + t);
        }
        XposedBridge.log(TAG + "phone service hooks ready (" + n + ")");
    }

    private static boolean logged;

    private static void logOnce(String m) {
        if (logged) return;
        logged = true;
        XposedBridge.log(TAG + m);
    }

    private static String field(Object o, String f) {
        try {
            Object v = XposedHelpers.getObjectField(o, f);
            return v == null ? "" : v.toString().trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static void setBool(Object o, String name, boolean v) {
        try {
            XposedHelpers.findField(o.getClass(), name).setBoolean(o, v);
        } catch (Throwable ignored) { }
    }

    private static String norm(String v) {
        return v == null ? "" : v.toLowerCase(java.util.Locale.US).replaceAll("[^a-z0-9]", "");
    }

    /** Rewrites the carrier name Android is about to publish (CarrierDisplayNameData). */
    private static void smart(Object tracker, Object data) {
        Object phone = XposedHelpers.getObjectField(tracker, "mPhone");
        int slot = (Integer) XposedHelpers.callMethod(phone, "getPhoneId");
        if (custom(slot) != null) return;                          // a name typed in settings wins
        android.telephony.ServiceState ss = (android.telephony.ServiceState) XposedHelpers.getObjectField(tracker, "mSS");
        Context ctx = (Context) XposedHelpers.callMethod(phone, "getContext");
        int sub = (Integer) XposedHelpers.callMethod(phone, "getSubId");
        android.telephony.TelephonyManager tm = ctx.getSystemService(android.telephony.TelephonyManager.class)
                .createForSubscriptionId(sub);

        String spn = field(data, "mSpn"), plmn = field(data, "mPlmn");
        String home = !spn.isEmpty() ? spn : tm.getSimOperatorName();
        String net = ss == null ? null : ss.getOperatorAlphaLong();
        if (net == null || net.trim().isEmpty()) net = plmn;
        if (net == null || net.trim().isEmpty()) net = ss == null ? null : ss.getOperatorAlphaShort();
        if (home == null || home.trim().isEmpty() || net == null || net.trim().isEmpty()) return;
        home = home.trim();
        net = net.trim();
        if (home.contains("(") || home.contains(" | ")) return;      // already rewritten

        boolean roaming = ss != null && ss.getRoaming();
        boolean otherCircle = Circles.roamCircle(tm.getSimOperator(), ss == null ? null : ss.getOperatorNumeric()) != null;
        String a = norm(home), b = norm(net).replaceFirst("^ind", "");
        boolean related = !a.isEmpty() && !b.isEmpty() && (b.contains(a) || a.contains(b));

        String name;
        String[] nCirc = Circles.of(ss == null ? null : ss.getOperatorNumeric());
        if (otherCircle && related && nCirc != null) {
            String lg0 = Circles.legacy(ss.getOperatorNumeric());      // Vi only: "Vi India(Vi Mumbai · Vodafone)"
            name = home + "(" + nCirc[0] + " " + nCirc[2] + (lg0 != null ? " · " + lg0 : "") + ")";       // same operator, other circle: "Jio(Jio Mumbai)"
        } else if ((roaming || otherCircle) || !related) {
            name = home + "(" + net + ")";                          // another state's network: "Airtel(IND airtel)"
        } else if (net.length() > home.length() && !norm(net).equals(a)) {
            name = net + " | " + home;                              // home: "Jio True5G | Jio"
        } else {
            return;                                                 // same name: leave it
        }
        XposedHelpers.setObjectField(data, "mSpn", name);
        try { XposedHelpers.setObjectField(data, "mDataSpn", name); } catch (Throwable ignored) { }
        setBool(data, "mShowSpn", true);
        setBool(data, "mShowPlmn", false);
    }

    /**
     * Which SIM slot a ServiceState belongs to: the phone holding this very object, else the
     * only phone registered on the same network code. -1 when it can't be told.
     */
    static int slotOf(Object ss, ClassLoader cl) {
        try {
            Class<?> pf = XposedHelpers.findClass("com.android.internal.telephony.PhoneFactory", cl);
            Object[] phones = (Object[]) pf.getMethod("getPhones").invoke(null);
            if (phones == null) return -1;
            String numeric = null;
            try {
                numeric = (String) XposedHelpers.callMethod(ss, "getOperatorNumeric");
            } catch (Throwable ignored) { }
            int match = -1, matches = 0;
            for (Object ph : phones) {
                if (ph == null) continue;
                Object own = XposedHelpers.callMethod(ph, "getServiceState");
                int id = (Integer) XposedHelpers.callMethod(ph, "getPhoneId");
                if (own == ss) return id;
                if (numeric != null && own != null) {
                    Object n = XposedHelpers.callMethod(own, "getOperatorNumeric");
                    if (numeric.equals(n)) {
                        match = id;
                        matches++;
                    }
                }
            }
            return matches == 1 ? match : -1;
        } catch (Throwable t) {
            return -1;
        }
    }
}
