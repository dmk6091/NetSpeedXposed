package com.netspeed.xposed;

import android.content.Context;
import android.location.GnssStatus;
import android.location.LocationManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Extra frames for the satellite strip above the clock, rotating with the usual "No ISS pass" text:
 * navigation satellites in use (phone's own GNSS), people in space, stargazing score, Moon / planet pairings
 * and close asteroid passes. While the ISS (or another bright satellite) is up, the strip stays on it.
 */
final class SkyStrip {
    private SkyStrip() {}

    static volatile int cloud = -1;                       // % cloud cover from the weather fetch
    private static volatile String navText = "";
    private static volatile long navAt = 0;
    private static boolean gnssOn = false;
    private static String gnssErr = "";

    private static volatile String peopleText = "";
    private static volatile long peopleAt = 0, peopleTried = 0;
    private static volatile String astText = "";
    private static volatile long astAt = 0, astTried = 0;
    private static volatile String astRaw = "";
    private static volatile String peopleWhy = "not fetched yet", astWhy = "not fetched yet";
    private static volatile String starText = "", pairText = "";
    private static volatile String starWhy = "", pairWhy = "";
    private static boolean fetching = false;

    // ---------------------------------------------------------------- navigation satellites

    private static final String[] SYS = {"?", "GPS", "SBAS", "GLONASS", "QZSS", "BeiDou", "Galileo", "NavIC"};

    private static void gnss(Context ctx) {
        if (gnssOn) return;
        gnssOn = true;
        try {
            LocationManager lm = ctx.getSystemService(LocationManager.class);
            lm.registerGnssStatusCallback(ctx.getMainExecutor(), new GnssStatus.Callback() {
                @Override
                public void onSatelliteStatusChanged(GnssStatus s) {
                    try {
                        int[] n = new int[8];
                        int used = 0;
                        for (int i = 0; i < s.getSatelliteCount(); i++) {
                            if (!s.usedInFix(i)) continue;
                            int t = s.getConstellationType(i);
                            if (t < 0 || t > 7) t = 0;
                            n[t]++;
                            used++;
                        }
                        navAt = System.currentTimeMillis();
                        if (used == 0) { navText = ""; return; }
                        // biggest groups first, NavIC always named when present (it's the Indian one)
                        List<int[]> l = new ArrayList<>();
                        for (int t = 1; t < 8; t++) if (n[t] > 0) l.add(new int[]{t, n[t]});
                        l.sort((a, b) -> b[1] != a[1] ? b[1] - a[1] : a[0] - b[0]);
                        StringBuilder b = new StringBuilder();
                        for (int[] e : l) {
                            if (b.length() > 0) b.append(" · ");
                            b.append(SYS[e[0]]).append(' ').append(e[1]);
                        }
                        navText = b + " · " + used + " in use";
                    } catch (Throwable t) { gnssErr = String.valueOf(t); }
                }
            });
        } catch (Throwable t) { gnssErr = t.getClass().getSimpleName() + ": " + t.getMessage(); }
    }

    // ---------------------------------------------------------------- network pieces (daily)

    private static String get(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(10_000);
        c.setReadTimeout(15_000);
        c.setRequestProperty("User-Agent", "NetSpeedXposed/1.0");
        int code = c.getResponseCode();
        if (code != 200) throw new java.io.IOException("HTTP " + code);
        StringBuilder sb = new StringBuilder();
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"))) {
            String ln;
            while ((ln = r.readLine()) != null) sb.append(ln);
        }
        return sb.toString();
    }

    private static void fetchAll(final long now) {
        synchronized (SkyStrip.class) { if (fetching) return; fetching = true; }
        Thread t = new Thread(() -> {
            try {
                if (Cfg.b(Cfg.SKY_PEOPLE, Cfg.D_SKY_PEOPLE) && now - peopleTried > 3600_000L && now - peopleAt > 12 * 3600_000L) {
                    peopleTried = now;
                    try {
                        int n = new org.json.JSONObject(get("https://corquaid.github.io/international-space-station-APIs/JSON/people-in-space.json")).getInt("number");
                        peopleText = n + (n == 1 ? " person in space" : " people in space");
                        peopleAt = now;
                        peopleWhy = "ok " + n;
                    } catch (Throwable e) { peopleWhy = "failed: " + e; }
                }
                if (Cfg.b(Cfg.SKY_AST, Cfg.D_SKY_AST) && now - astTried > 3600_000L && now - astAt > 12 * 3600_000L) {
                    astTried = now;
                    try {
                        astRaw = get("https://ssd-api.jpl.nasa.gov/cad.api?dist-max=0.01&date-min=now&date-max=%2B14&sort=date&limit=10");
                        astAt = now;
                        astWhy = "ok";
                    } catch (Throwable e) { astWhy = "failed: " + e; }
                }
            } finally {
                synchronized (SkyStrip.class) { fetching = false; }
            }
        }, "skystrip-fetch");
        t.setDaemon(true);
        t.start();
    }

    /** Next close approach within 3.9 Moon-distances in the coming 2 weeks, or "". */
    private static String asteroid(long now) {
        try {
            if (astRaw.isEmpty()) return "";
            org.json.JSONObject o = new org.json.JSONObject(astRaw);
            org.json.JSONArray f = o.getJSONArray("fields"), d = o.optJSONArray("data");
            if (d == null) return "";
            int iDes = -1, iCd = -1, iDist = -1, iH = -1;
            for (int i = 0; i < f.length(); i++) {
                String k = f.getString(i);
                if (k.equals("des")) iDes = i; else if (k.equals("cd")) iCd = i; else if (k.equals("dist")) iDist = i; else if (k.equals("h")) iH = i;
            }
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MMM-dd HH:mm", Locale.US);
            in.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.text.SimpleDateFormat out = new java.text.SimpleDateFormat("d MMM", Locale.US);
            for (int r = 0; r < d.length(); r++) {
                org.json.JSONArray row = d.getJSONArray(r);
                long t = in.parse(row.getString(iCd)).getTime();
                if (t < now - 6 * 3600_000L) continue;      // already passed
                double ld = row.getDouble(iDist) / 0.00256955;   // AU -> Moon distances
                String size = "";
                if (iH >= 0 && !row.isNull(iH)) {
                    double km = 3552.0 * Math.pow(10, -row.getDouble(iH) / 5.0);   // size guess from brightness, ~14% reflective
                    double m = km * 1000;
                    size = m < 1000 ? " · ~" + (m < 10 ? Math.round(m) : Math.round(m / 5) * 5) + " m" : " · ~" + String.format(Locale.US, "%.1f", km) + " km";
                }
                return "Asteroid " + row.getString(iDes) + " passes " + String.format(Locale.US, "%.1f", ld) + " Moons away, "
                        + out.format(new java.util.Date(t)) + size;
            }
        } catch (Throwable ignored) { }
        return "";
    }

    // ---------------------------------------------------------------- sky maths

    private static String compass(double az) {
        String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return n[(int) Math.round(az / 45.0) % 8];
    }

    private static void sky(long now, double lat, double lon) {
        starText = ""; pairText = "";
        try {
            Astro.Pos sun = Astro.sun(now, lat, lon);
            Astro.Moon moon = Astro.moon(now, lat, lon);
            // stargazing score: only when it is dark enough to look at stars
            if (sun.alt > -6) starWhy = "sun at " + Math.round(sun.alt) + "°: not dark yet";
            else if (cloud < 0) starWhy = "no cloud-cover figure yet";
            else {
                double sc = 10 - 0.9 * cloud / 10.0;
                if (moon.alt > 0) sc -= moon.illum * 4 * Math.min(1, moon.alt / 30.0);
                if (sun.alt > -18) sc -= (sun.alt + 18) / 12.0 * 3;
                int s = (int) Math.max(1, Math.min(10, Math.round(sc)));
                String sky = cloud < 20 ? "clear" : cloud < 60 ? "partly cloudy" : "cloudy";
                String mn = moon.alt > 0 ? "Moon " + Math.round(moon.illum * 100) + "% up" : "no Moon";
                starText = "Stargazing " + s + "/10 · " + sky + " · " + mn;
                starWhy = "score " + sc + " (cloud " + cloud + "%, sun " + Math.round(sun.alt) + "°, moon alt " + Math.round(moon.alt) + "°)";
            }
            // pairings: Moon with a planet within 4 degrees, or two planets within 3, one of them above the horizon in a darkish sky
            double lst = SkyObjects.lst(now, lon);
            String[] nm = new String[5];
            double[][] rd = new double[5][];
            nm[0] = "Moon"; rd[0] = new double[]{moon.ra, moon.dec};
            for (int i = 0; i < SkyObjects.PLANETS.length; i++) { nm[i + 1] = SkyObjects.PLANETS[i]; rd[i + 1] = SkyObjects.planetRaDec(i, now); }
            double best = 99;
            String bt = "";
            for (int a = 0; a < 5; a++) for (int b = a + 1; b < 5; b++) {
                double lim = a == 0 ? 4 : 3;
                double sep = angle(rd[a][0], rd[a][1], rd[b][0], rd[b][1]);
                if (sep > lim || sep >= best) continue;
                double[] aa = SkyObjects.altAz(rd[a][0], rd[a][1], lst, lat), ab = SkyObjects.altAz(rd[b][0], rd[b][1], lst, lat);
                if (aa[0] < 5 || ab[0] < 5 || sun.alt > -3) continue;
                best = sep;
                bt = nm[a] + " " + Math.round(sep) + "° from " + nm[b] + " · " + (sun.az > 180 ? "evening" : "dawn") + ", " + compass(ab[1]);
            }
            pairText = bt;
            pairWhy = bt.isEmpty() ? "no close visible pair" : bt;
        } catch (Throwable t) { starWhy = "failed: " + t; pairWhy = "failed: " + t; }
    }

    private static double angle(double ra1, double d1, double ra2, double d2) {
        double a = Math.toRadians(d1), b = Math.toRadians(d2), dr = Math.toRadians(ra1 - ra2);
        double c = Math.sin(a) * Math.sin(b) + Math.cos(a) * Math.cos(b) * Math.cos(dr);
        return Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, c))));
    }

    // ---------------------------------------------------------------- public

    private static volatile long skyAt = 0;

    /** Called from the bar's background tick. */
    static void tick(Context ctx, double lat, double lon) {
        long now = System.currentTimeMillis();
        try {
            if (Cfg.b(Cfg.SKY_NAV, Cfg.D_SKY_NAV)) gnss(ctx);
            fetchAll(now);
            if (now - skyAt > 60_000L) {
                skyAt = now;
                if (Cfg.b(Cfg.SKY_STAR, Cfg.D_SKY_STAR) || Cfg.b(Cfg.SKY_PAIR, Cfg.D_SKY_PAIR)) sky(now, lat, lon);
                astText = asteroid(now);
            }
        } catch (Throwable ignored) { }
    }

    /** What the strip should show now: the ISS text when something is up, else a rotation through the base text and the enabled frames. */
    static String frame(String base, boolean live, long now) {
        if (live) return base;
        List<String> fs = new ArrayList<>();
        if (base != null && !base.isEmpty()) fs.add(base);
        try {
            if (Cfg.b(Cfg.SKY_NAV, Cfg.D_SKY_NAV) && !navText.isEmpty() && now - navAt < 90_000L) fs.add(navText);
            if (Cfg.b(Cfg.SKY_PEOPLE, Cfg.D_SKY_PEOPLE) && !peopleText.isEmpty() && now - peopleAt < 3 * 86400_000L) fs.add(peopleText);
            if (Cfg.b(Cfg.SKY_STAR, Cfg.D_SKY_STAR) && !starText.isEmpty()) fs.add(starText);
            if (Cfg.b(Cfg.SKY_PAIR, Cfg.D_SKY_PAIR) && !pairText.isEmpty()) fs.add(pairText);
            if (Cfg.b(Cfg.SKY_AST, Cfg.D_SKY_AST) && !astText.isEmpty()) fs.add(astText);
        } catch (Throwable ignored) { }
        if (fs.isEmpty()) return base == null ? "" : base;
        if (fs.size() == 1) return fs.get(0);
        long sec = Math.max(3, Math.min(8, Cfg.i(Cfg.EL_SPEED, Cfg.D_EL_SPEED)));
        return fs.get((int) ((now / (sec * 1000L)) % fs.size()));
    }

    static String report() {
        long now = System.currentTimeMillis();
        StringBuilder b = new StringBuilder("SATELLITE STRIP FRAMES\n");
        b.append("  navigation satellites: ").append(navText.isEmpty() ? (gnssOn ? "no fix data yet" + (gnssErr.isEmpty() ? "" : " (" + gnssErr + ")") : "off") : navText + " (" + (now - navAt) / 1000 + " s ago)").append('\n');
        b.append("  people in space: ").append(peopleText.isEmpty() ? "-" : peopleText).append(" · ").append(peopleWhy).append('\n');
        b.append("  stargazing: ").append(starText.isEmpty() ? "-" : starText).append(" · ").append(starWhy).append('\n');
        b.append("  pairings: ").append(pairWhy.isEmpty() ? "-" : pairWhy).append('\n');
        b.append("  asteroids: ").append(astText.isEmpty() ? "none close in the next 2 weeks" : astText).append(" · ").append(astWhy).append('\n');
        return b.toString();
    }
}
