package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Settings screen. Opens from the module's "Settings" in Vector/LSPosed and from the app icon.
 * Most changes apply to the status bar right away; a few need System UI restarted.
 */
public class SettingsActivity extends Activity {
    private static final Uri URI = Uri.parse("content://com.netspeed.xposed.settings/all");

    private SharedPreferences sp;
    private LinearLayout list;
    private int fg, sub, card, accent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = SettingsProvider.prefs(this);

        boolean dark = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        int bg = dark ? 0xFF1B1B1F : 0xFFF6F5FA;
        card = dark ? 0xFF2A2A30 : 0xFFFFFFFF;
        fg = dark ? 0xFFE6E1E9 : 0xFF1C1B1F;
        sub = dark ? 0xFF9A96A3 : 0xFF6A6672;
        accent = dark ? 0xFFC9BFFF : 0xFF5B4DB0;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        list.setPadding(p, p, p, p);
        scroll.addView(list);
        // Edge-to-edge: keep content clear of the status and navigation bars.
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(0, sys.top, 0, sys.bottom);
            return in;
        });
        setContentView(scroll);
        // Light background: ask for dark status/navigation bar icons, so they stay readable.
        if (!dark) {
            try {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light, light);
                }
            } catch (Throwable ignored) { }
        }
        build();
    }

    private void build() {
        list.removeAllViews();
        title("NetSpeed status bar");
        note("Changes apply to the status bar right away. Items marked ⟳ need System UI restarted.");

        section("Layout");
        LinearLayout c = card();
        slider(c, "Gap between rows", "dp", Cfg.ROW_GAP, Cfg.D_ROW_GAP, 0, 12);
        slider(c, "Row 2 height", "dp", Cfg.ROW2_H, Cfg.D_ROW2_H, 14, 32);
        slider(c, "Gap before weather", "dp", Cfg.WEATHER_GAP, Cfg.D_WEATHER_GAP, 0, 16);
        slider(c, "Extra status bar height ⟳", "dp", Cfg.EXTRA, Cfg.D_EXTRA, 0, 24);

        section("Text");
        c = card();
        slider(c, "Temperatures size", "sp", Cfg.TEMP_SP, Cfg.D_TEMP_SP, 6, 12);
        slider(c, "Weather size", "sp", Cfg.WEATHER_SP, Cfg.D_WEATHER_SP, 8, 16);
        slider(c, "Net speed size", "sp", Cfg.SPEED_SP, Cfg.D_SPEED_SP, 6, 12);
        slider(c, "Amps / watts size", "sp", Cfg.POWER_SP, Cfg.D_POWER_SP, 6, 12);
        slider(c, "Network band size", "sp", Cfg.BAND_SP, Cfg.D_BAND_SP, 6, 12);
        toggle(c, "Bold small text", "Temperatures and net speed", Cfg.BOLD, Cfg.D_BOLD);

        section("Show");
        c = card();
        toggle(c, "CPU temperature", null, Cfg.SHOW_CPU, Cfg.D_SHOW_CPU);
        toggle(c, "Battery temperature", null, Cfg.SHOW_BAT, Cfg.D_SHOW_BAT);
        toggle(c, "Amps and watts", "Battery current and power, after the net speed",
                Cfg.SHOW_POWER, Cfg.D_SHOW_POWER);
        toggle(c, "Network band per SIM", "e.g. n78₁ over B3₂, before VoLTE / VoNR",
                Cfg.SHOW_BAND, Cfg.D_SHOW_BAND);
        toggle(c, "Signal strength (dBm)", "e.g. n78₁ -92. Hidden by itself if there's no room",
                Cfg.SHOW_DBM, Cfg.D_SHOW_DBM);
        toggle(c, "Distance to tower", "Tower symbol + rough distance; ? when the network doesn't report it",
                Cfg.SHOW_DIST, Cfg.D_SHOW_DIST);
        toggle(c, "Combined VoLTE / VoNR badge", "One \"Vo\" badge with each SIM's voice type "
                + "(NR / LTE / WiFi) instead of the two stock icons", Cfg.VO_BADGE, Cfg.D_VO_BADGE);
        toggle(c, "Network type with activity arrows", "5G / 4G+ with ↓↑ underneath that light up "
                + "while data flows (like Samsung)", Cfg.NET_TYPE, Cfg.D_NET_TYPE);
        toggle(c, "Cells heard per SIM", "Antenna + count after the amps/watts. Hidden by itself if "
                + "there's no room before the camera", Cfg.SHOW_CELLS, Cfg.D_SHOW_CELLS);
        toggle(c, "Look up towers online", "For idle SIMs and 5G: tower position from BeaconDB + your "
                + "location, shown with ~. Sends only tower IDs", Cfg.TOWER_DB, Cfg.D_TOWER_DB);
        toggle(c, "Learn tower positions", "For towers no database knows (mostly 5G): records your "
                + "position + signal while you move and estimates the tower. Stays on this phone",
                Cfg.LEARN, Cfg.D_LEARN);
        textField(c, "OpenCelliD token (optional)", "Backup database with better coverage. Paste the "
                + "token from my.opencellid.org (starts with pk.). Stays on this phone.", Cfg.OCID_KEY);
        toggle(c, "Weather", "From OmniJaws", Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER);
        toggle(c, "Hide net speed when idle", "After 10 s below 1 KB/s", Cfg.HIDE_IDLE, Cfg.D_HIDE_IDLE);

        section("Layout mode ⟳");
        c = card();
        toggle(c, "Two-row status bar", "Off = original one-row layout", Cfg.DUAL, Cfg.D_DUAL);
        toggle(c, "Net speed after weather", "Off = on the right, before the icons",
                Cfg.SPEED_LEFT, Cfg.D_SPEED_LEFT);

        updatesSection();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(20);
        list.addView(row, rlp);
        button(row, "Restart System UI", true, v -> restartSystemUi());
        button(row, "Reset", false, v -> new AlertDialog.Builder(this)
                .setMessage("Reset all settings to defaults?")
                .setPositiveButton("Reset", (d, w) -> {
                    sp.edit().clear().commit();
                    changed();
                    build();
                })
                .setNegativeButton("Cancel", null)
                .show());
    }

    // ------------------------------------------------------------ updates

    private TextView updStatus;
    private Button updButton;
    private AppUpdater.Info latest;

    private long installedBuild() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).getLongVersionCode();
        } catch (Exception e) {
            return 0;
        }
    }

    private void updatesSection() {
        section("Updates");
        LinearLayout c = card();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text("Installed build " + installedBuild(), 16, fg));
        updStatus = text("Checking…", 13, sub);
        box.addView(updStatus);
        updButton = new Button(this);
        updButton.setAllCaps(false);
        updButton.setTextColor(isDark() ? 0xFF2A1F66 : Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        g.setColor(accent);
        updButton.setBackground(g);
        updButton.setVisibility(View.GONE);
        updButton.setOnClickListener(v -> doUpdate());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        box.addView(updButton, lp);
        c.addView(box);
        c.setOnClickListener(v -> checkUpdate());
        checkUpdate();
    }

    private void checkUpdate() {
        updStatus.setText("Checking…");
        new Thread(() -> {
            try {
                AppUpdater.Info info = AppUpdater.check();
                runOnUiThread(() -> showUpdate(info));
            } catch (Exception e) {
                runOnUiThread(() -> updStatus.setText("Couldn't check: " + e.getMessage() + ". Tap to retry."));
            }
        }).start();
    }

    private void showUpdate(AppUpdater.Info info) {
        latest = info;
        long have = installedBuild();
        if (info.build > have) {
            String notes = info.notes.isEmpty() ? "" : "\n" + info.notes.split("\n")[0];
            updStatus.setText("Build " + info.build + " is available." + notes);
            updButton.setText("Update to build " + info.build);
            updButton.setVisibility(View.VISIBLE);
        } else {
            updStatus.setText("Up to date. Tap to check again.");
            updButton.setVisibility(View.GONE);
        }
    }

    private void doUpdate() {
        updButton.setEnabled(false);
        updStatus.setText("Downloading…");
        new Thread(() -> {
            String msg;
            try {
                java.io.File apk = AppUpdater.download(getCacheDir());
                runOnUiThread(() -> updStatus.setText("Installing… the status bar restarts in a few seconds."));
                boolean ok = AppUpdater.installAndRestart(apk);
                msg = ok ? null : "Root wasn't granted. Allow root for this app in ReSukiSU and try again.";
            } catch (Exception e) {
                msg = "Update failed: " + e.getMessage();
            }
            final String m = msg;
            if (m != null) runOnUiThread(() -> {
                updStatus.setText(m);
                updButton.setEnabled(true);
            });
        }).start();
    }

    // ------------------------------------------------------------ widgets

    private void title(String t) {
        TextView v = text(t, 26, fg);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(8), 0, dp(4));
        list.addView(v);
    }

    private void note(String t) {
        TextView v = text(t, 13, sub);
        v.setPadding(dp(4), 0, dp(4), dp(8));
        list.addView(v);
    }

    private void section(String t) {
        TextView v = text(t, 13, accent);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(18), 0, dp(8));
        list.addView(v);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        list.addView(c);
        return c;
    }

    private void slider(LinearLayout parent, String label, String unit, String key, int def, int min, int max) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(10), 0, dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text(label, 16, fg);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text("", 15, accent);
        top.addView(val);
        box.addView(top);

        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        int cur = sp.getInt(key, def);
        s.setProgress(cur);
        val.setText(cur + " " + unit + (cur == def ? "  (default)" : ""));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int v, boolean user) {
                val.setText(v + " " + unit + (v == def ? "  (default)" : ""));
            }

            @Override public void onStartTrackingTouch(SeekBar bar) { }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sp.edit().putInt(key, bar.getProgress()).commit();
                changed();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        box.addView(s, lp);
        parent.addView(box);
    }

    private void textField(LinearLayout parent, String label, String desc, String key) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text(label, 16, fg));
        if (desc != null) box.addView(text(desc, 13, sub));
        android.widget.EditText et = new android.widget.EditText(this);
        et.setSingleLine(true);
        et.setTextColor(fg);
        et.setHintTextColor(sub);
        et.setHint("pk.…");
        et.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setText(sp.getString(key, ""));
        et.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(android.text.Editable e) {
                sp.edit().putString(key, e.toString().trim()).commit();
                changed();
            }
        });
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(box);
    }

    private void toggle(LinearLayout parent, String label, String desc, String key, boolean def) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            sp.edit().putBoolean(key, on).commit();
            changed();
        });
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    private void button(LinearLayout parent, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? (isDark() ? 0xFF2A1F66 : Color.WHITE) : accent);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        if (primary) g.setColor(accent);
        else {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(dp(1), accent);
        }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), primary ? 2f : 1f);
        lp.setMarginEnd(primary ? dp(10) : 0);
        parent.addView(b, lp);
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    // ------------------------------------------------------------ actions

    /** Tells System UI to reload settings. */
    private void changed() {
        getContentResolver().notifyChange(URI, null);
    }

    private void restartSystemUi() {
        new Thread(() -> {
            String err = null;
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "killall com.android.systemui"});
                if (p.waitFor() != 0) err = "Root command failed (exit " + p.exitValue() + ")";
            } catch (Exception e) {
                err = "Root not available: " + e.getMessage();
            }
            final String msg = err;
            runOnUiThread(() -> {
                if (msg != null) Toast.makeText(this, msg + ". Grant root to this app in ReSukiSU, or reboot.",
                        Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
