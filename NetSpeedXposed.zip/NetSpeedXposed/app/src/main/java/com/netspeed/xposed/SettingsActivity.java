package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Settings screen. Opens from the module's "Settings" in Vector/LSPosed and from the app icon.
 * Most changes apply to the status bar right away; a few need System UI restarted.
 */
public class SettingsActivity extends Activity {
    private static final Uri URI = Uri.parse("content://com.netspeed.xposed.settings/all");

    private SharedPreferences sp;
    private LinearLayout list;
    private int fg, sub, card, accent;

    // ---- pages: a home screen of tiles, then one page per topic
    private static final String[] CAT_NAME = {"Layout", "Network", "Weather & sky", "Earth frames", "Disasters", "Device", "System"};
    private static final String[] CAT_ICON = {"📐", "📡", "⛅", "🌍", "🌋", "🔋", "⚙️"};
    private static final String[] CAT_SUB = {"size, rows, looks, animations", "SIMs, bands, towers, 5G", "forecast, sky, tides, globe",
            "river, soil, land, power, quakes", "quakes, cyclones, alerts", "battery, CPU, speed, heat", "updates, launcher, restart"};
    private static final int[][] CAT_COL = {{0xFF173A5C, 0xFF102A44}, {0xFF1A4A40, 0xFF112E2E}, {0xFF4A3A1A, 0xFF2E2412},
            {0xFF1F4A2A, 0xFF132E1B}, {0xFF4A2222, 0xFF2E1616}, {0xFF3A2A55, 0xFF241A38}, {0xFF233648, 0xFF162330}};
    /** The older Readable / two-row layouts are no longer offered: with the 4-row bar off the status bar stays stock. */
    private static final boolean OLD_LAYOUTS = false;
    private LinearLayout home;
    private final LinearLayout[] pages = new LinearLayout[7];
    private final LinearLayout[] pcard = new LinearLayout[7];
    private int curPage = -1, lastCat = 0, secCat = 0;
    private ScrollView scrollRef;

    /** Which page a setting belongs on, from its title; -1 = the same page as the one before it. */
    private static int classify(String raw) {
        String t = raw.toLowerCase(java.util.Locale.ROOT);
        if (t.contains("fault line")) return 3;
        if (t.contains("reservoir")) return 2;
        if (t.contains("frame") || t.contains("soil") || t.contains("river")) return 3;
        if (t.contains("disaster") || t.contains("earthquake") || t.contains("solar storm")) return 4;
        if (t.contains("restart") || t.contains("reset") || t.contains("volume") || t.contains("launcher") || t.contains("update")
                || t.contains("integrity") || t.contains("diagnostic") || t.contains("immersive") || t.contains("gesture")
                || t.contains("apps' top") || t.contains("installed build") || t.contains("predict")) return 6;
        if (t.contains(" size") || t.contains("animation") || t.contains("layout") || t.contains("row") || t.contains("gap")
                || t.contains("height") || t.contains("look") || t.contains("chip") || t.contains("dashboard") || t.contains("tint")
                || t.contains("bold") || t.contains("contrast") || t.contains("dimming") || t.contains("clock") || t.contains("margin")
                || t.contains("test the")) return 0;
        if (t.contains("battery") || t.contains("cpu") || t.contains("gpu") || t.contains("temperature") || t.contains("amps")
                || t.contains("throttl") || t.contains("heat") || t.contains("speed") || t.contains("bluetooth") || t.contains("charging")
                || t.contains("brightness") || t.contains("stats column") || t.contains("warn when") || t.contains("camera")
                || t.contains("sparkline") || t.contains("hide net")) return 5;
        if (t.contains("weather") || t.contains("tide") || t.contains("coast") || t.contains("sky") || t.contains("world map")
                || t.contains("globe") || t.contains("unlock") || t.contains("haze")) return 2;
        if (t.contains("tower") || t.contains("5g") || t.contains("4g") || t.contains("sim") || t.contains("band") || t.contains("dbm")
                || t.contains("snr") || t.contains("sinr") || t.contains("volte") || t.contains("vonr") || t.contains("network")
                || t.contains("ping") || t.contains("qualcomm") || t.contains("roaming") || t.contains("carrier") || t.contains("operator")
                || t.contains("mobile data") || t.contains("internet") || t.contains("signal") || t.contains("beacon") || t.contains("learn")
                || t.contains("corner")) return 1;
        return -1;
    }

    private static String firstText(View v) {
        if (v instanceof TextView) { CharSequence c = ((TextView) v).getText(); return c == null ? "" : c.toString(); }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) { String r = firstText(g.getChildAt(i)); if (!r.isEmpty()) return r; }
        }
        return "";
    }

    /** What the old sections add their rows to: each row is sent on to the card of the page it belongs to. */
    private final class RoutedCard extends LinearLayout {
        RoutedCard() { super(SettingsActivity.this); setOrientation(VERTICAL); }

        @Override
        public void addView(View child, int index, ViewGroup.LayoutParams params) {
            int cat = classify(firstText(child));
            if (cat < 0) cat = lastCat;
            lastCat = cat;
            pcard[cat].addView(child, params);
        }
    }

    /** Faint map contour lines behind everything. */
    private static final class ContourDrawable extends android.graphics.drawable.Drawable {
        private final int bg;
        private final android.graphics.Paint line = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        ContourDrawable(int bg, int accent) {
            this.bg = bg;
            line.setStyle(android.graphics.Paint.Style.STROKE);
            line.setStrokeWidth(2f);
            line.setColor((accent & 0x00FFFFFF) | 0x16000000);
        }

        @Override
        public void draw(Canvas c) {
            c.drawColor(bg);
            int w = getBounds().width(), h = getBounds().height();
            android.graphics.Path p = new android.graphics.Path();
            for (int k = 0; k < 7; k++) {
                float y0 = h * 0.08f + k * h * 0.035f, y1 = h * 0.86f + k * h * 0.02f;
                for (float yy : new float[]{y0, y1}) {
                    p.reset();
                    p.moveTo(-20, yy);
                    p.quadTo(w * 0.3f, yy - h * 0.045f, w * 0.55f, yy + h * 0.01f);
                    p.quadTo(w * 0.8f, yy + h * 0.05f, w + 20, yy - h * 0.015f);
                    c.drawPath(p, line);
                }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(android.graphics.ColorFilter f) { }
        @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = SettingsProvider.prefs(this);
        // integrity watcher notifications (Android 13+ asks once)
        try {
            UpdateJob.schedule(this);
            DamJob.schedule(this);
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 41);
        } catch (Throwable ignored) { }
        if (getIntent() != null && getIntent().getBooleanExtra("show_dam", false))
            getWindow().getDecorView().post(this::showDam);
        if (getIntent() != null && getIntent().getBooleanExtra("show_integrity", false))
            getWindow().getDecorView().post(this::showIntegrity);

        boolean dark = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        int bg = dark ? 0xFF0B1220 : 0xFFEAF2F7;
        card = dark ? 0xFF111C2E : 0xFFFFFFFF;
        fg = dark ? 0xFFDFE8F2 : 0xFF10202F;
        sub = dark ? 0xFF7F93AB : 0xFF5A6B7D;
        accent = dark ? 0xFF7AE7C7 : 0xFF0B7A66;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(new ContourDrawable(bg, accent));
        scrollRef = scroll;
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        list.setPadding(p, p, p, p + dp(72));   // room for the footer menu
        scroll.addView(list);
        // Edge-to-edge: keep content clear of the status and navigation bars.
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(0, sys.top, 0, sys.bottom);
            return in;
        });
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(-1, -1));
        LinearLayout jump = new LinearLayout(this);
        jump.setOrientation(LinearLayout.VERTICAL);
        jump.addView(jumpButton("↑", () -> scroll.smoothScrollTo(0, 0)));
        jump.addView(jumpButton("↓", () -> scroll.smoothScrollTo(0, list.getHeight())));
        android.widget.FrameLayout.LayoutParams jlp = new android.widget.FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.END);
        jlp.setMargins(0, 0, dp(16), dp(24) + dp(64));
        root.addView(jump, jlp);
        // footer menu: Home, Search, Updates, Diagnostics
        final LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setBackgroundColor(card);
        foot.setElevation(dp(8));
        String[][] fi = {{"\uD83C\uDFE0", "Home"}, {"\uD83D\uDD0D", "Search"}, {"\u2B06\uFE0F", "Updates"}, {"\uD83E\uDE7A", "Diagnostics"}};
        Runnable[] fa = {
                () -> { showPage(-1); scroll.smoothScrollTo(0, 0); },
                () -> searchDialog(scroll),
                () -> { showPage(6); if (updStatus != null && updStatus.getParent() instanceof View) scroll.post(() -> jumpTo(scroll, (View) updStatus.getParent())); },
                this::showSatellites};
        for (int i = 0; i < 4; i++) {
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(8), 0, dp(8));
            TextView ic = text(fi[i][0], 20, accent);
            ic.setGravity(Gravity.CENTER);
            TextView lb = text(fi[i][1], 11, i == 0 ? accent : sub);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            if (i == 2) { footDot = lb; }
            final int k = i;
            it.setOnClickListener(v -> fa[k].run());
            foot.addView(it, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        final android.widget.FrameLayout.LayoutParams flp = new android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(foot, flp);
        // permission gate: covers everything until the needed permissions are allowed
        gate = new LinearLayout(this);
        gate.setOrientation(LinearLayout.VERTICAL);
        gate.setBackgroundColor(bg);
        gate.setPadding(dp(20), dp(80), dp(20), dp(20));
        gate.setVisibility(View.GONE);
        gate.setClickable(true);
        root.addView(gate, new android.widget.FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            jlp.bottomMargin = dp(24) + dp(64) + sys.bottom;
            jump.setLayoutParams(jlp);
            foot.setPadding(0, 0, 0, sys.bottom);
            scroll.dispatchApplyWindowInsets(in);
            return in;
        });
        setContentView(root);
        // Light background: ask for dark status/navigation bar icons, so they stay readable.
        if (!dark) {
            try {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light, light);
                }
            } catch (Throwable ignored) { }
        }
        build();
    }

    private void build() {
        list.removeAllViews();
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        list.addView(home);
        for (int i = 0; i < 7; i++) {
            pages[i] = new LinearLayout(this);
            pages[i].setOrientation(LinearLayout.VERTICAL);
            pages[i].setVisibility(View.GONE);
            TextView back = text("\u2039  Field Atlas", 14, accent);
            back.setPadding(dp(4), dp(4), dp(12), dp(10));
            final int idx = i;
            back.setOnClickListener(v -> showPage(-1));
            pages[i].addView(back);
            TextView ttl = text(CAT_ICON[i] + "  " + CAT_NAME[i], 26, fg);
            ttl.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            ttl.setPadding(dp(4), 0, 0, dp(2));
            pages[i].addView(ttl);
            TextView st = text(CAT_SUB[i], 13, sub);
            st.setPadding(dp(4), 0, 0, dp(10));
            pages[i].addView(st);
            pcard[i] = styledCard();
            pages[i].addView(pcard[i]);
            list.addView(pages[i]);
        }
        lastCat = 0;
        secCat = 0;
        // with the 4-row bar on, options that only shaped the old layouts are left out
        final boolean pro = sp.getBoolean(Cfg.PRO, Cfg.D_PRO);
        title("Field Atlas");
        note("Signal \u00b7 towers \u00b7 weather \u00b7 sky \u00b7 earth. Changes apply to the status bar right away; items marked \u27f3 need System UI restarted.");

        section("Layout");
        LinearLayout c = card();
        if (OLD_LAYOUTS) {
            toggle(c, "Readable layout", "Four lines of large text: clock, CPU / battery temperature, watts, speed, "
                    + "notifications, Bluetooth; per-SIM network, signal, band and distance (the SIM carrying mobile data "
                    + "sits in a highlighted pill with live \u2193\u2191); weather and air quality; portrait battery. "
                    + "Turn off for the old two-row layout", Cfg.READABLE, Cfg.D_READABLE);
        }
        toggle(c, "New 4-row status bar", "Everything in four rows: clock with time zone, speed and temperatures; sunrise/sunset, alarm, notifications and a frame for the system icons; power, CPU load and GPS; ping, deep sleep, wakelock and Bluetooth. Battery health and cycles under the camera; both SIMs (data SIM outlined) against the right edge, full weather under them. Off = the original stock status bar. Restart SystemUI to apply", Cfg.PRO, Cfg.D_PRO);
        slider(c, "4-row bar extra height \u27f3", "dp", Cfg.PRO_EXTRA, Cfg.D_PRO_EXTRA, 0, 24);
        e2eToggle(c);
        if (OLD_LAYOUTS) {
            slider(c, "Gap between rows", "dp", Cfg.ROW_GAP, Cfg.D_ROW_GAP, 0, 12);
            slider(c, "Row 2 height", "dp", Cfg.ROW2_H, Cfg.D_ROW2_H, 14, 32);
            slider(c, "Gap before weather", "dp", Cfg.WEATHER_GAP, Cfg.D_WEATHER_GAP, 0, 16);
            slider(c, "Status bar height trim / extra ⟳", "dp", Cfg.EXTRA, Cfg.D_EXTRA, -20, 24);
        }
        slider(c, "Apps' top space: move app content up", "dp", Cfg.APP_TOP_TRIM, Cfg.D_APP_TOP_TRIM, 0, 60);
        c.addView(text("0 = apps start below the whole bar. Higher moves every app's header up behind the "
                + "lower rows. Taps there go to the status bar, so keep buttons clear. Applies live", 13, sub));
        propToggle(c, "Immersive navigation", "Apps draw to the bottom edge; the gesture pill "
                + "floats over them. Tick your launcher (and System Framework) in the LSPosed/Vector scope",
                NavImmersive.PROP);
        slider(c, "Gesture pill drop: 0 = default height, higher = lower", "dp", Cfg.PILL_DY, Cfg.D_PILL_DY, 0, 12);
        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setPadding(0, dp(4), 0, dp(8));
        button(pillRow, "Save gesture-pill dump (8 s)", false, v -> savePillDump());
        button(pillRow, "Restart launcher", false, v -> new Thread(() -> {
            boolean ok = runSu("am force-stop $(cmd package resolve-activity --brief "
                    + "-a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1 | cut -d/ -f1)");
            runOnUiThread(() -> Toast.makeText(this, ok ? "Launcher restarted" : "Couldn't restart (root?)",
                    Toast.LENGTH_SHORT).show());
        }).start());
        c.addView(pillRow);

        if (OLD_LAYOUTS) {
            section("Text");
            c = card();
            slider(c, "Temperatures size", "sp", Cfg.TEMP_SP, Cfg.D_TEMP_SP, 6, 12);
            slider(c, "Weather size", "sp", Cfg.WEATHER_SP, Cfg.D_WEATHER_SP, 8, 16);
            slider(c, "Net speed size", "sp", Cfg.SPEED_SP, Cfg.D_SPEED_SP, 6, 12);
            slider(c, "Amps / watts size", "sp", Cfg.POWER_SP, Cfg.D_POWER_SP, 6, 12);
            slider(c, "Network band size", "sp", Cfg.BAND_SP, Cfg.D_BAND_SP, 6, 12);
            slider(c, "Tower mast size", "%", Cfg.MAST_PCT, Cfg.D_MAST_PCT, 80, 200);
            slider(c, "Clock size", "sp", Cfg.CLOCK_SP, Cfg.D_CLOCK_SP, 9, 18);
            slider(c, "Row 2 right margin", "dp", Cfg.ROW2_END, Cfg.D_ROW2_END, 0, 24);
            slider(c, "Signal tower icon size", "%", Cfg.TOWER_PCT, Cfg.D_TOWER_PCT, 70, 150);
            toggle(c, "Bold small text", "Temperatures and net speed", Cfg.BOLD, Cfg.D_BOLD);
        }

        section("Show");
        c = card();
        toggle(c, "CPU temperature", null, Cfg.SHOW_CPU, Cfg.D_SHOW_CPU);
        toggle(c, "Battery temperature", null, Cfg.SHOW_BAT, Cfg.D_SHOW_BAT);
        toggle(c, "Amps and watts", "Battery current and power, after the net speed",
                Cfg.SHOW_POWER, Cfg.D_SHOW_POWER);
        toggle(c, "Network band per SIM", "e.g. n78₁ over B3₂, before VoLTE / VoNR",
                Cfg.SHOW_BAND, Cfg.D_SHOW_BAND);
        if (OLD_LAYOUTS) {
            toggle(c, "Signal strength (dBm)", "e.g. n78₁ -92. Hidden by itself if there's no room",
                    Cfg.SHOW_DBM, Cfg.D_SHOW_DBM);
        }
        toggle(c, "Distance to tower", "Next to the tower counts: how far your serving tower is (~ estimate, ? unknown)",
                Cfg.SHOW_DIST, Cfg.D_SHOW_DIST);
        if (OLD_LAYOUTS) {
            toggle(c, "Signal tower icon", "One tower for both SIMs: SIM 1 waves left, SIM 2 right (4 = full), "
                    + "network + VoLTE/VoNR per SIM, ↓↑ on the data SIM. Replaces the stock bars, type and Vo badge",
                    Cfg.TOWER_ICON, Cfg.D_TOWER_ICON);
        }
        toggle(c, "Internet speed meter", "The download / upload speed in the 4-row bar. With the 4-row bar off, the status bar is fully stock and shows no speed. Restart System UI to apply", Cfg.SPEED_STOCK, Cfg.D_SPEED_STOCK);
        toggle(c, "Battery health and cycles", "Battery health % and charge cycles next to the SIM boxes", Cfg.SH_HEALTH, Cfg.D_SH_HEALTH);
        toggle(c, "CPU load", "CPU load % after the temperatures", Cfg.SH_LOAD, Cfg.D_SH_LOAD);
        toggle(c, "Free RAM", "Free memory after the system icons", Cfg.SH_RAM, Cfg.D_SH_RAM);
        toggle(c, "Screen refresh rate", "Current refresh rate in Hz (e.g. 120)", Cfg.SH_HZ, Cfg.D_SH_HZ);
        toggle(c, "CPU clock", "Current CPU frequency in GHz", Cfg.SH_GHZ, Cfg.D_SH_GHZ);
        toggle(c, "Deep sleep share", "Time the phone spent in deep sleep, as %", Cfg.SH_SLEEP, Cfg.D_SH_SLEEP);
        toggle(c, "Tower changes today", "Number of tower hand-overs today (twr)", Cfg.SH_TWR, Cfg.D_SH_TWR);
        toggle(c, "Next alarm", "Time of the next alarm", Cfg.SH_ALARM, Cfg.D_SH_ALARM);
        toggle(c, "Notification count", "Bell with the number of notifications", Cfg.SH_NOTIF, Cfg.D_SH_NOTIF);
        toggle(c, "Bluetooth device battery", "Battery % of the connected Bluetooth device", Cfg.SH_BTBAT, Cfg.D_SH_BTBAT);
        toggle(c, "Data used today", "Data used today (or this month) under each SIM box", Cfg.SH_DATA, Cfg.D_SH_DATA);
        toggle(c, "Own row 2 icons", "Bell with the notification count (silent ones in brackets), Bluetooth "
                + "devices (W watch / H headphones / P phone + battery + codec), vibrate / silent / DND, next alarm, "
                + "Wi-Fi router (generation, band, dBm, link speed, activity) and a small tray for the rest. "
                + "Replaces the stock notification and system icons", Cfg.SYS_ICONS, Cfg.D_SYS_ICONS);
        toggle(c, "Lock screen globe", "Live Earth under the lock screen clock: day/night, your location as a red dot. "
                + "Drag or flick to turn it, double-tap to come back to your location",
                Cfg.LOCK_GLOBE, Cfg.D_LOCK_GLOBE);
        toggle(c, "Pixel unlock animation", "When you unlock, the lock screen drifts up slightly and fades out while the "
                + "home screen comes in behind it, like on a Pixel. Needs System UI in NetSpeed's LSPosed scope; "
                + "restart System UI to apply", Cfg.UNLOCK_ANIM, Cfg.D_UNLOCK_ANIM);
        toggle(c, "Globe turns by itself", "When you aren't touching it the Earth turns slowly (one turn in "
                + "90 s) with the live day / night line", Cfg.GLOBE_SPIN, Cfg.D_GLOBE_SPIN);
        if (OLD_LAYOUTS) {
            toggle(c, "Portrait battery", "Upright battery with the % inside, coloured by level (green while charging)",
                    Cfg.BATT_PORTRAIT, Cfg.D_BATT_PORTRAIT);
            toggle(c, "Battery % inside the icon", "Stock battery icon with the percentage written inside it",
                    Cfg.BATT_PCT_IN, Cfg.D_BATT_PCT_IN);
            toggle(c, "Li-ion battery cell", "Battery drawn as a cell with a liquid fill and % inside, coloured "
                    + "by level (green while charging). Replaces the stock icon", Cfg.BATT_CELL, Cfg.D_BATT_CELL);
            toggle(c, "Battery details beside the cell", "Voltage, charge left / total (Ah), time to empty "
                    + "(↓) or to full (ϟ)", Cfg.BATT_TEXT, Cfg.D_BATT_TEXT);
            toggle(c, "Clock seconds + timezone", "Seconds and IST beside the time, and a thin line under it "
                    + "that fills over each minute", Cfg.CLOCK_SECONDS, Cfg.D_CLOCK_SECONDS);
            toggle(c, "Next sunrise / sunset under the clock", "Small clock moved up; under it the next sun event "
                    + "(↑ sunrise or ↓ sunset) with its time", Cfg.CLOCK_SUN, Cfg.D_CLOCK_SUN);
        }
        toggle(c, "Auto contrast", "Measures the brightness under the status bar and switches to dark "
                + "text on light screens (and white on dark), even when an app asks for the wrong one",
                Cfg.AUTO_CONTRAST, Cfg.D_AUTO_CONTRAST);
        if (OLD_LAYOUTS) {
            toggle(c, "Text around the camera", "Battery health % curved over the camera hole (amber under 90 %, red under 80 %), "
                    + "charge cycles under it (the lower line steps aside when notification icons reach under the camera)",
                    Cfg.CAM_TEXT, Cfg.D_CAM_TEXT);
        }
        toggle(c, "Weather details", "Beside the weather icon: rain chance (next 3 h), UV, "
                + "humidity, wind, AQI (Open-Meteo, every 15 min). Least important drop out when space is short. The AQI pill shows the number and a letter: "
                + "G good (0-50), M moderate (51-100), S unhealthy for sensitive groups (101-150), U unhealthy (151-200), "
                + "V very unhealthy (201-300), H hazardous (301+). Colour goes green, yellow, orange, red, purple, maroon",
                Cfg.WX_DETAILS, Cfg.D_WX_DETAILS);
        slider(c, "Earthquakes shown from", "mag", Cfg.QUAKE_MIN, Cfg.D_QUAKE_MIN, 10, 70);
        slider(c, "Earthquakes within", "km100", Cfg.QUAKE_KM, Cfg.D_QUAKE_KM, 1, 200);
        button(c, "Live diagnostics", false, v -> showSatellites());
        button(c, "Play Integrity checks (history)", false, v -> showIntegrity());
        if (OLD_LAYOUTS) {
            toggle(c, "Speedometer with the net speed", "Small gauge for download speed (1 K/s to 100 M/s); "
                    + "arrows green ↓ / blue ↑, speeds coloured idle grey → fast green/blue → very fast cyan",
                    Cfg.SPEED_GAUGE, Cfg.D_SPEED_GAUGE);
            toggle(c, "SINR with the tower counts", "Nodes symbol coloured by signal quality (green good, yellow fair, "
                    + "red poor) and the SINR in dB after the distance; the number hides first when space is short",
                    Cfg.SINR_MAST, Cfg.D_SINR_MAST);
            toggle(c, "Temperatures + current together", "Thermometer per line, temperature coloured by heat, then "
                    + "amps / watts in the same block", Cfg.COMBINE_TEMPS, Cfg.D_COMBINE_TEMPS);
            toggle(c, "SNR next to dBm", "Signal-to-noise per SIM (dB), left of the camera. Hidden by itself if there's no room",
                    Cfg.SHOW_SNR, Cfg.D_SHOW_SNR);
        }
        toggle(c, "Combined VoLTE / VoNR badge", "One \"Vo\" badge with each SIM's voice type "
                + "(NR / LTE / WiFi) instead of the two stock icons", Cfg.VO_BADGE, Cfg.D_VO_BADGE);
        toggle(c, "Network type with activity arrows", "5G / 4G+ with ↓↑ underneath that light up "
                + "while data flows (like Samsung)", Cfg.NET_TYPE, Cfg.D_NET_TYPE);
        section("Animations");
        c = card();
        toggle(c, "Low heat mode", "Turns off the always-moving animations (heat pulse, shine, moving "
                + "arrows, charging flow) and the ping dot, so the status bar isn't redrawn many times a "
                + "second. Recommended", Cfg.LOW_HEAT, Cfg.D_LOW_HEAT);
        toggle(c, "Animation: heat warning", "Warm or hot temperatures pulse orange / red (cool ones stay calm)",
                Cfg.ANIM_HEAT, Cfg.D_ANIM_HEAT);
        if (OLD_LAYOUTS) {
            toggle(c, "Speed sparkline", "A tiny live graph of the last 30 seconds after the speed numbers "
                    + "(↓ green, ↑ blue)", Cfg.ANIM_SPARK, Cfg.D_ANIM_SPARK);
        }
        toggle(c, "Idle dimming", "After a few quiet seconds the status bar softens; an item lights up "
                + "again when its value changes", Cfg.ANIM_DIM, Cfg.D_ANIM_DIM);
        if (OLD_LAYOUTS) {
            toggle(c, "Colourful network type", "5G purple-cyan, 4G+ orange-pink, 4G green, 3G yellow, 2G red "
                    + "(on the tower view)", Cfg.NET_COLOR, Cfg.D_NET_COLOR);
            toggle(c, "Animation: network type shine", "A light sweeps across 5G / 4G+ every few seconds",
                    Cfg.ANIM_SHIMMER, Cfg.D_ANIM_SHIMMER);
            toggle(c, "Animation: moving arrows", "The ↓↑ arrows move while data flows (faster look, still only "
                    + "while there is traffic)", Cfg.ANIM_ARROWS, Cfg.D_ANIM_ARROWS);
            toggle(c, "Animation: 5G / 4G switch flash", "The network type pops once when it changes, so you see "
                    + "when NetSwitch acted", Cfg.ANIM_SWITCH, Cfg.D_ANIM_SWITCH);
        }
        toggle(c, "Animation: charging flow", "A light runs along the battery fill while charging",
                Cfg.ANIM_CHARGE, Cfg.D_ANIM_CHARGE);
        if (OLD_LAYOUTS) {
            toggle(c, "Animation: bell wiggle + count roll", "The bell shakes and the number rolls up when a "
                    + "new notification arrives", Cfg.ANIM_BELL, Cfg.D_ANIM_BELL);
        }
        toggle(c, "Ping dot", "A small dot beside the network type, ticks every few seconds: green fast, "
                + "amber slow, red no connection (a tiny TCP connect to 1.1.1.1)", Cfg.ANIM_PING, Cfg.D_ANIM_PING);
        button(c, "▶  Test the animations now", true, v -> {
            try {
                sendBroadcast(new android.content.Intent("com.netspeed.xposed.ANIM_TEST"));
                android.widget.Toast.makeText(this, "Playing for 8 seconds - look at the status bar",
                        android.widget.Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) { }
        });
        section("Towers");
        c = card();
        toggle(c, "Towers around per SIM", "Dish + estimated number of towers each SIM can hear (from "
                + "the cells' ids). Hidden by itself if there's no room before the camera", Cfg.SHOW_CELLS, Cfg.D_SHOW_CELLS);
        toggle(c, "Look up towers online", "For idle SIMs and 5G: tower position from BeaconDB + your "
                + "location, shown with ~. Sends only tower IDs", Cfg.TOWER_DB, Cfg.D_TOWER_DB);
        toggle(c, "Learn tower positions", "For towers no database knows (mostly 5G): records your "
                + "position + signal while you move and estimates the tower. Stays on this phone",
                Cfg.LEARN, Cfg.D_LEARN);
        toggle(c, "Learn while riding", "When you're on the move (not standing still), one GPS fix a minute so towers get "
                + "learned even without a navigation app. Also learns the nearby towers your phone hears. A little battery "
                + "while moving, none while still", Cfg.RIDE_GPS, Cfg.D_RIDE_GPS);
        toggle(c, "Weak 5G → 4G (quota-guarded)", "When the data SIM's 5G is weak for 20 s, switch it to 4G, retry 5G after "
                + "3 min (longer if it keeps failing). Stops once 4G data today reaches the limit below, so a 5G-unlimited / "
                + "4G-capped plan isn't eaten. The bar shows 4G·used while it's on. Needs \"Phone Services\" in LSPosed; reboot once",
                Cfg.NR_FALLBACK, Cfg.D_NR_FALLBACK);
        choice(c, "5G / 4G mode", Cfg.NR_MODE, Cfg.D_NR_MODE, new String[]{"Automatic",
                "Always allow 5G (fallback off)", "Force 4G (5G off)"});
        toggle(c, "Check the internet, not just the signal", "Weak 5G also counts when the connection carries no data: "
                + "when nothing is coming in, a tiny request is sent over mobile data about once a minute (3 failures in a row = "
                + "bad). The automatic switching also pauses on Wi-Fi, in airplane mode and with mobile data off",
                Cfg.NR_NETCHECK, Cfg.D_NR_NETCHECK);
        toggle(c, "Move data to the other SIM when this one is weak", "Turns on Android's own \"switch mobile data automatically\" "
                + "for both SIMs: when the data SIM is weak the phone uses the other SIM's data, and goes back when it recovers "
                + "(the phone checks the other SIM really has internet). Turning this off puts the setting back as it was. "
                + "Needs \"Phone Services\" in LSPosed; reboot once", Cfg.AUTO_SIM, Cfg.D_AUTO_SIM);
        toggle(c, "Notify on Play Integrity checks", "A notification each time an app asks Google Play whether this "
                + "phone passes Play Integrity (watch only: nothing is blocked or changed). Needs Google Play Store "
                + "ticked in LSPosed; force-stop Play Store or reboot once", Cfg.INTEGRITY_NOTIFY, Cfg.D_INTEGRITY_NOTIFY);
        toggle(c, "Toast on Play Integrity checks", "A short pop-up message with the app's name each time it checks",
                Cfg.INTEGRITY_TOAST, Cfg.D_INTEGRITY_TOAST);
        toggle(c, "Qualcomm 5G+ reader (experimental)", "Asks Qualcomm's own phone helper (the one stock HyperOS uses) "
                + "whether each SIM's 5G counts as 5G+, and shows 5G+ when it does. What it finds is listed in "
                + "\"Live diagnostics\". Needs com.qti.phone ticked in LSPosed; reboot after switching. "
                + "Turn off if calls or data act up", Cfg.QTI_NR, Cfg.D_QTI_NR);
        toggle(c, "Tide at the nearest coast", "Row 3 after AQI: rising ↑ / falling ↓, height now, next high (H) or "
                + "low (L) water and the place. Model data (Open-Meteo Marine), about ±20 min. Amber = spring tide",
                Cfg.TIDE, Cfg.D_TIDE);
        toggle(c, "Reservoir watch chip", "Rotates in the place line with the river, rain and soil frames: the nearest dam (from your GPS, "
                + "among the 178 CWC reservoirs), how full it is, distance and hydro MW, with a dot for the state: red danger low (under 20%), orange low (20-40), green normal (40-90), "
                + "blue high (90-95), purple danger high (over 95). CWC updates once a day. \"Danger\" is % full, not a flood warning",
                Cfg.DAM, Cfg.D_DAM);
        toggle(c, "Reservoir watch notifications", "A notification once a day when the nearest dam changes state, or when "
                + "its level has gone steady (0.5 points a day or less over 3 days)", Cfg.DAM_NOTIF, Cfg.D_DAM_NOTIF);
        button(c, "Reservoir details", false, v -> showDam());
        toggle(c, "Disasters & solar storms", "Row 4: a current GDACS orange / red alert (cyclone, flood, volcano, "
                + "wildfire, drought, quake) replaces the quake line, with distance and direction from you. A magnetic "
                + "storm (NOAA Kp 5 or more) adds 🧲Kp·G at the end. Quiet most days", Cfg.HAZARDS, Cfg.D_HAZARDS);
        toggle(c, "River & dam frame", "On the place line: the nearest river with width and distance, the nearest dam within 10 km, and the flow of the nearest river to wherever you are, in m\u00b3/s, with \u25B2 rising / "
                + "\u25BC falling since yesterday and \"high\" or \"low\" against the last 30 days. A computer model (Open-Meteo "
                + "flood service), about 5 km grid, not a gauge. Hidden where there is no river", Cfg.RIVER, Cfg.D_RIVER);
        toggle(c, "Rain & soil frame", "Place line frame: rain in the last 24 h and the next 24 h, soil moisture. Model data (Open-Meteo)",
                Cfg.EL_RAIN, Cfg.D_EL_RAIN);
        toggle(c, "Soil frame", "Place line frame: soil type (clay, loam, sandy...) from the clay, silt and sand share of the top soil (ISRIC SoilGrids), plus moisture",
                Cfg.EL_SOIL, Cfg.D_EL_SOIL);
        toggle(c, "Power frame", "Place line frame: nearest power line (voltage, operator if mapped) and substation within 5 km, from OpenStreetMap. Only what mappers have drawn",
                Cfg.EL_POWER, Cfg.D_EL_POWER);
        toggle(c, "Land frame", "Place line frame: height, climb, nearest named hill or peak with distance and direction",
                Cfg.EL_LAND, Cfg.D_EL_LAND);
        toggle(c, "Quake frame", "Place line frame: the latest M2.5+ quake within 300 km in the last 30 days (USGS), or that there was none",
                Cfg.EL_QUAKE, Cfg.D_EL_QUAKE);
        toggle(c, "Earth frame", "Place line frame: full place: taluka, district and state",
                Cfg.EL_EARTH, Cfg.D_EL_EARTH);
        slider(c, "Seconds per frame", "s", Cfg.EL_SPEED, Cfg.D_EL_SPEED, 3, 8);
        choice(c, "Frame order", Cfg.EL_ORDER, Cfg.D_EL_ORDER, new String[]{"River, rain, soil, power, land, quake, place",
                "Place and land first, then water and power", "Water first, then land, power, quake", "Quake and rain first (alerts first)"});
        slider(c, "Dam search radius", "km", Cfg.EL_DAM_KM, Cfg.D_EL_DAM_KM, 3, 20);
        toggle(c, "Fault lines frame", "Rotates in the place line: the nearest mapped fault and the nearest named one, "
                + "with distance, direction and type. India: GSI atlas (via AFDI); South / Central Asia: GEM. Mapped faults only, "
                + "not a hazard warning", Cfg.FAULT, Cfg.D_FAULT);
        slider(c, "Fault line search radius", "km", Cfg.FAULT_KM, Cfg.D_FAULT_KM, 50, 1000);
        button(c, "Fault line details", false, v -> showFaults());
        slider(c, "Power line search radius", "km", Cfg.EL_POWER_KM, Cfg.D_EL_POWER_KM, 2, 10);
        slider(c, "Peak search radius", "km", Cfg.EL_PEAK_KM, Cfg.D_EL_PEAK_KM, 10, 60);
        toggle(c, "Weather extras on the sky", "Haze over the sky when the air quality is poor (AQI), a cool-blue or warm-red tint when it is cold or "
                + "hot. Gauge-line look only", Cfg.WX_FX, Cfg.D_WX_FX);
        toggle(c, "World map (day and night)", "A faint world map over the weather sky: the night side is shaded, big cities light up "
                + "there, a yellow dot marks where the sun is overhead and a white ring marks you", Cfg.BG_MAP, Cfg.D_BG_MAP);
        
        textField(c, "ReliefWeb app name (optional)", "Adds UN OCHA ReliefWeb disasters (floods, epidemics, landslides…) to the "
                + "row-4 rotation. Request an app name at apidoc.reliefweb.int, paste it here once approved", Cfg.RELIEFWEB_APP, "e.g. dmk-netspeed", false, "https://apidoc.reliefweb.int/");
        toggle(c, "Dim status bar with screen brightness", "The whole bar follows the brightness you set: full from half "
                + "brightness up, easing down to about 55 % at the lowest so it isn't glaring in a dark room", Cfg.DIM_NIGHT, Cfg.D_DIM_NIGHT);
        choice(c, "Data used in the SIM box", Cfg.DATA_PERIOD, Cfg.D_DATA_PERIOD, new String[]{"Daily (D)", "Monthly (M)"});
        choice(c, "Coast distance", Cfg.COAST_MODE, Cfg.D_COAST_MODE, new String[]{"Nearest water (creeks too)", "Open sea"});
        choice(c, "Tide place", Cfg.TIDE_PLACE, Cfg.D_TIDE_PLACE, Tide.choices());
        textField(c, "SIM 1 bands (lock)", "Only these bands, e.g. \"n78 B3 B40\" (B = 4G, n = 5G). Only B given: 5G stays free; "
                + "only n given: 4G stays free. Empty = all bands. Not saved in the modem: a reboot or emptying the field undoes it. "
                + "Needs \"Phone Services\" in LSPosed. Result shows in \"Live diagnostics\"", Cfg.BANDS1, "e.g. n78 B3 B40", false);
        textField(c, "SIM 2 bands (lock)", "Same for SIM 2", Cfg.BANDS2, "e.g. B3 B40", false);
        toggle(c, "Group tints", "Faint coloured backgrounds that group the bar: time, device, speed, mobile network, "
                + "sky, weather, Earth & hazards. No extra space used", Cfg.ZONES, Cfg.D_ZONES);
        choice(c, "Corner beside the SIMs", Cfg.CORNER, Cfg.D_CORNER, new String[]{"Off",
                "5G share today (5G over %)", "Signal quality now (Q over %)"});
        slider(c, "4G data limit for the fallback", "MB", Cfg.NR_QUOTA_MB, Cfg.D_NR_QUOTA_MB, 200, 2000);
        textField(c, "OpenCelliD token (optional)", "Backup database with better coverage. Paste the "
                + "token from my.opencellid.org (starts with pk.). Stays on this phone.", Cfg.OCID_KEY, "pk.…", true, "https://my.opencellid.org/");
        textField(c, "WeatherAPI.com key (optional)", "Free key from weatherapi.com. When set, temperature, condition, "
                + "rain chance, wind, UV, cloud and high/low come from WeatherAPI (corrected with real stations) instead "
                + "of the forecasts. Stays on this phone.", Cfg.WAPI_KEY, "key…", true, "https://www.weatherapi.com/signup.aspx");
        toggle(c, "Weather", "From OmniJaws", Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER);
        if (OLD_LAYOUTS) {
            toggle(c, "Hide net speed when idle", "After 10 s below 1 KB/s", Cfg.HIDE_IDLE, Cfg.D_HIDE_IDLE);
        }
        toggle(c, "Heat throttle (root)", "When hot: caps every CPU cluster and the GPU to the speeds below, drops the screen to 60 Hz and clears background apps. Releases when cooled and restores your refresh rate. Needs root for NetSpeed. Restart SystemUI to apply", Cfg.THR, Cfg.D_THR);
        slider(c, "Throttle when battery reaches", "\u00B0C", Cfg.THR_BAT, Cfg.D_THR_BAT, 36, 50);
        slider(c, "Throttle when CPU reaches", "\u00B0C", Cfg.THR_CPU, Cfg.D_THR_CPU, 55, 95);
        slider(c, "GPU speed while throttled", "% of max", Cfg.THR_GPU, Cfg.D_THR_GPU, 30, 90);
        slider(c, "CPU speed while throttled", "% of max", Cfg.THR_PCT, Cfg.D_THR_PCT, 30, 90);
        toggle(c, "Dim the screen while throttled", "Also caps the brightness (switches to manual brightness while hot, never raises it) and puts your brightness and auto mode back when cooled. Off by default: it can make the screen hard to read in sun", Cfg.THR_DIM, Cfg.D_THR_DIM);
        slider(c, "Brightness while throttled", "% of max", Cfg.THR_DIM_PCT, Cfg.D_THR_DIM_PCT, 20, 90);
        toggle(c, "Heat warning popup", "A Device Too Hot popup (like the Critical Battery one) when the battery or CPU passes the limits below. Comes back after 10 minutes if still hot, closes itself when cooled. Restart SystemUI to apply", Cfg.HEAT, Cfg.D_HEAT);
        slider(c, "Warn when battery reaches", "\u00B0C", Cfg.HEAT_BAT, Cfg.D_HEAT_BAT, 38, 50);
        slider(c, "Warn when CPU reaches", "\u00B0C", Cfg.HEAT_CPU, Cfg.D_HEAT_CPU, 60, 100);
        slider(c, "Freeze sky at or below battery % (0 = never)", "%", Cfg.SKY_LOW, Cfg.D_SKY_LOW, 0, 50);
        skyChoice(c);
        slider(c, "Sky opacity", "%", Cfg.SKY_OPACITY, Cfg.D_SKY_OPACITY, 30, 100);
        toggle(c, "Fade the sky into the wallpaper", "The lower part of the sky thins out so the status bar blends into "
                + "the wallpaper or app below instead of ending in a hard edge", Cfg.SKY_FADE, Cfg.D_SKY_FADE);
        toggle(c, "Stats column beside the speed", "Three small rows instead of the graph: CPU load and GPS satellites, ping and deep-sleep share, and the kernel wakelock held longest (root, refreshed every 5 min)", Cfg.STATS_COL, Cfg.D_STATS_COL);
        toggle(c, "Hide battery % in quick settings", "The percentage in the pulled-down shade header; the status bar is unchanged. Restart SystemUI to apply", Cfg.QS_BATT_HIDE, Cfg.D_QS_BATT_HIDE);

        section("Operator name");
        c = card();
        c.addView(text("Shown everywhere on this phone (status bar, lock screen, settings, dialer, apps). "
                + "Network, calls and operator codes stay real. Needs \"Phone Services\" "
                + "(com.android.phone) ticked in the Vector scope. Applies after airplane mode on/off.", 13, sub));
        toggle(c, "Smart carrier name", "Lock screen, quick settings, shade and Settings: the network's own fuller name "
                + "at home (e.g. \"Jio True5G\" instead of \"Jio\"), and your SIM's name plus the network's in another state "
                + "(\"Airtel(IND airtel)\", \"BSNL(Dolphin)\"). A name typed below wins. Needs \"Phone Services\" in "
                + "NetSpeed's LSPosed scope; reboot or toggle airplane mode to refresh", Cfg.SMART_CARRIER, Cfg.D_SMART_CARRIER);
        toggle(c, "Roaming between circles", "When your SIM's circle and the tower's circle differ (e.g. a Maharashtra SIM on a Mumbai "
                + "tower), apps, System UI and Settings are told the phone is roaming. Only what leaves the phone service changes: "
                + "the modem, calls, SMS and the phone's own data handling stay real. Off by default; turn it off if calls or 5G act "
                + "strangely. Needs \"Phone Services\" in NetSpeed's LSPosed scope; applies after airplane mode on/off", Cfg.CIRCLE_ROAM, Cfg.D_CIRCLE_ROAM);
        toggle(c, "Hide side R icon", "Hides the big R beside the signal bars while roaming; the small raised R stays. "
                + "Needs System UI in NetSpeed's LSPosed scope; restart System UI to apply", Cfg.HIDE_SIDE_R, Cfg.D_HIDE_SIDE_R);
        textField(c, "SIM 1 name", "Empty = real name", Cfg.OP_NAME1, "e.g. Jio", false);
        textField(c, "SIM 2 name", "Empty = real name", Cfg.OP_NAME2, "e.g. Vi", false);

        if (OLD_LAYOUTS) {
            section("Layout mode ⟳");
            c = card();
            toggle(c, "Two-row status bar", "Off = original one-row layout", Cfg.DUAL, Cfg.D_DUAL);
            toggle(c, "Net speed after weather", "Off = on the right, before the icons",
                    Cfg.SPEED_LEFT, Cfg.D_SPEED_LEFT);
        }

        section("Launcher");
        c = card();
        predictToggle(c);

        section("Volume steps");
        c = card();
        c.addView(text(SettingsVolume.summary(this) + ". Needs the Volume Steps Magisk module; "
                + "applies after a reboot.", 13, sub));
        button(c, "Change volume steps", false, v -> SettingsVolume.show(this));

        updatesSection();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(20);
        pages[6].addView(row, rlp);
        button(row, "Restart System UI", true, v -> restartSystemUi());
        button(row, "Reset", false, v -> new AlertDialog.Builder(this)
                .setMessage("Reset all settings to defaults?")
                .setPositiveButton("Reset", (d, w) -> {
                    sp.edit().clear().commit();
                    changed();
                    build();
                })
                .setNegativeButton("Cancel", null)
                .show());
        buildHome();
        showPage(curPage);
    }

    private void buildHome() {
        LinearLayout row = null;
        for (int i = 0; i < 7; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                home.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setPadding(dp(14), dp(14), dp(14), dp(14));
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, CAT_COL[i]);
            g.setCornerRadius(dp(20));
            t.setBackground(g);
            TextView ic = text(CAT_ICON[i], 26, 0xFFFFFFFF);
            t.addView(ic);
            TextView nm = text(CAT_NAME[i], 16, 0xFFFFFFFF);
            nm.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            nm.setPadding(0, dp(6), 0, 0);
            t.addView(nm);
            t.addView(text(CAT_SUB[i], 12, 0xFFB8C7D8));
            final int idx = i;
            t.setOnClickListener(v -> showPage(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(128), 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            if (i == 6) { lp.weight = 1f; }
            row.addView(t, lp);
        }
        if (row != null && row.getChildCount() == 1) {   // odd tile: pad the row so it keeps half width
            View pad = new View(this);
            row.addView(pad, new LinearLayout.LayoutParams(0, 1, 1f));
        }
    }

    private void showPage(int p) {
        curPage = p;
        home.setVisibility(p < 0 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 7; i++) pages[i].setVisibility(i == p ? View.VISIBLE : View.GONE);
        if (scrollRef != null) scrollRef.scrollTo(0, 0);
    }

    @Override
    public void onBackPressed() {
        if (curPage >= 0) showPage(-1);
        else super.onBackPressed();
    }

    // ------------------------------------------------------------ updates

    private TextView updStatus, footDot;
    private LinearLayout gate;
    private volatile int rootOk = -1;   // -1 not asked yet, 0 no, 1 yes

    private static final String[] ROOT_APPS = {"com.resukisu.resukisu", "me.weishu.kernelsu", "com.rifsxd.ksunext", "com.sukisu.ultra",
            "me.bmax.apatch", "com.topjohnwu.magisk", "io.github.vvb2060.magisk", "io.github.huskydg.magisk", "com.dergoogler.mmrl"};

    /** The installed root manager app (ReSukiSU, KernelSU, APatch, Magisk...), or null. */
    private String rootManager() {
        for (String p : ROOT_APPS) {
            try { getPackageManager().getPackageInfo(p, 0); return p; } catch (Exception ignored) { }
        }
        return null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGate();
        new Thread(() -> {
            int ok = 0;
            try {
                Process pr = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                if (pr.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)) ok = pr.exitValue() == 0 ? 1 : 0;
                else pr.destroy();
            } catch (Exception ignored) { }
            rootOk = ok;
            runOnUiThread(this::refreshGate);
        }).start();
    }

    private boolean usageOk() {
        try {
            android.app.AppOpsManager a = getSystemService(android.app.AppOpsManager.class);
            return a.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName())
                    == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) { return true; }
    }

    private void gateRow(String title, String why, boolean ok, String button, Runnable open) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16));
        g.setColor(card);
        r.setBackground(g);
        r.addView(text((ok ? "\u2705  " : "\u274C  ") + title, 17, fg));
        r.addView(text(ok ? "allowed" : why, 13, sub));
        if (!ok && open != null) {
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setText(button);
            b.setTextColor(isDark() ? 0xFF06251C : Color.WHITE);
            GradientDrawable bg2 = new GradientDrawable();
            bg2.setCornerRadius(dp(24));
            bg2.setColor(accent);
            b.setBackground(bg2);
            b.setOnClickListener(v -> open.run());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
            lp.topMargin = dp(8);
            r.addView(b, lp);
        }
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.bottomMargin = dp(10);
        gate.addView(r, rl);
    }

    private void refreshGate() {
        if (gate == null) return;
        final String pkg = getPackageName();
        boolean notif = getSystemService(android.app.NotificationManager.class).areNotificationsEnabled();
        boolean usage = usageOk();
        boolean write = android.provider.Settings.System.canWrite(this);
        boolean root = rootOk != 0;   // unknown counts as fine until su answers
        if (notif && usage && write && root) { gate.setVisibility(View.GONE); return; }
        gate.removeAllViews();
        TextView t = text("\uD83D\uDD12  Permissions needed", 26, fg);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        gate.addView(t);
        TextView st = text("Field Atlas can't run until these are allowed.", 14, sub);
        st.setPadding(0, dp(6), 0, dp(20));
        gate.addView(st);
        final String mgr = rootManager();
        gateRow("Root access", mgr == null ? "No root manager app found (ReSukiSU, KernelSU, APatch or Magisk). Install one and grant Field Atlas root"
                : "Needed for updates, System UI restart and battery health. Allow Field Atlas in " + mgr, root,
                mgr == null ? "Rescan" : "Open root manager", () -> {
                    Intent i = mgr == null ? null : getPackageManager().getLaunchIntentForPackage(mgr);
                    if (i != null) startActivity(i); else onResume();
                });
        gateRow("Notifications", "For update alerts and Play Integrity notifications", notif, "Open setting", () -> startActivity(
                new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, pkg)));
        gateRow("Usage access", "For launcher app suggestions", usage, "Open setting", () -> startActivity(
                new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + pkg))));
        gateRow("Modify system settings", "Lets Field Atlas write the settings the status bar reads", write, "Open setting", () -> startActivity(
                new Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + pkg))));
        if (!usage || !write) {
            TextView hint = text("Switch greyed out? Open App info \u2192 \u22EE (top right) \u2192 Allow restricted settings, then try again.", 13, sub);
            hint.setPadding(dp(4), dp(6), dp(4), 0);
            gate.addView(hint);
        }
        gate.setVisibility(View.VISIBLE);
    }
    private Button updButton;
    private AppUpdater.Info latest;

    private long installedBuild() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).getLongVersionCode();
        } catch (Exception e) {
            return 0;
        }
    }

    private void updatesSection() {
        section("Updates");
        LinearLayout c = card();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text("Installed build " + installedBuild(), 16, fg));
        updStatus = text("Checking…", 13, sub);
        box.addView(updStatus);
        updButton = new Button(this);
        updButton.setAllCaps(false);
        updButton.setTextColor(isDark() ? 0xFF06251C : Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        g.setColor(accent);
        updButton.setBackground(g);
        updButton.setVisibility(View.GONE);
        updButton.setOnClickListener(v -> doUpdate());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        box.addView(updButton, lp);
        c.addView(box);
        box.setOnClickListener(v -> checkUpdate());   // the card itself is never on screen (RoutedCard sends the box to its page)
        checkUpdate();
    }

    private void checkUpdate() {
        updStatus.setText("Checking…");
        updButton.setVisibility(View.GONE);
        new Thread(() -> {
            try {
                AppUpdater.Info info = AppUpdater.check();
                runOnUiThread(() -> showUpdate(info));
            } catch (Exception e) {
                runOnUiThread(() -> updStatus.setText("Couldn't check: " + e.getMessage() + ". Tap to retry."));
            }
        }).start();
    }

    private void showUpdate(AppUpdater.Info info) {
        latest = info;
        long have = installedBuild();
        if (info.build > have) {
            String notes = info.notes.isEmpty() ? "" : "\n\n" + info.notes;   // the whole change list, not just its first line
            if (footDot != null) { footDot.setText("Updates \u25CF"); footDot.setTextColor(0xFFFF6B6B); }
            updStatus.setText("Build " + info.build + " is available." + notes);
            updButton.setText("Update to build " + info.build);
            updButton.setVisibility(View.VISIBLE);
        } else {
            updStatus.setText("Up to date (checked " + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date()) + "). Tap to check again.");
            updButton.setVisibility(View.GONE);
        }
    }

    private void doUpdate() {
        updButton.setEnabled(false);
        updStatus.setText("Downloading…");
        new Thread(() -> {
            String msg;
            try {
                java.io.File apk = AppUpdater.download(getCacheDir());
                runOnUiThread(() -> updStatus.setText("Installing… the status bar restarts in a few seconds."));
                boolean ok = AppUpdater.installAndRestart(apk);
                msg = ok ? null : "Root wasn't granted. Allow root for this app in ReSukiSU and try again.";
            } catch (Exception e) {
                msg = "Update failed: " + e.getMessage();
            }
            final String m = msg;
            if (m != null) runOnUiThread(() -> {
                updStatus.setText(m);
                updButton.setEnabled(true);
            });
        }).start();
    }

    // ------------------------------------------------------------ widgets

    private void title(String t) {
        TextView v = text(t, 26, fg);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(8), 0, dp(4));
        home.addView(v);
    }

    private void note(String t) {
        TextView v = text(t, 13, sub);
        v.setPadding(dp(4), 0, dp(4), dp(12));
        home.addView(v);
    }

    /** One setting found by the search: its title, the words under it, and the row to jump to. */
    private static final class Hit {
        String title, desc;
        View row;
    }

    /** Every setting title (16 sp text) in the page, with the description beside it. */
    private java.util.List<Hit> collect() {
        java.util.List<Hit> out = new java.util.ArrayList<>();
        walk(list, out);
        return out;
    }

    private void walk(View v, java.util.List<Hit> out) {
        if (v instanceof TextView && !(v instanceof android.widget.Button) && !(v instanceof android.widget.EditText)) {
            TextView t = (TextView) v;
            float sz = t.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
            if (Math.abs(sz - 16) < 0.6f && t.getText().length() > 0 && t.getVisibility() == View.VISIBLE) {
                Hit h = new Hit();
                h.title = t.getText().toString();
                StringBuilder d = new StringBuilder();
                if (t.getParent() instanceof ViewGroup) {
                    ViewGroup g = (ViewGroup) t.getParent();
                    for (int i = 0; i < g.getChildCount(); i++) {
                        View o = g.getChildAt(i);
                        if (o != t && o instanceof TextView) d.append(((TextView) o).getText()).append(' ');
                    }
                    View row = g;
                    // the clickable row is the title's parent, or its grandparent (title + description in a column)
                    if (!g.isClickable() && g.getParent() instanceof View && ((View) g.getParent()).isClickable()) row = (View) g.getParent();
                    h.row = row;
                } else h.row = t;
                h.desc = d.toString().trim();
                out.add(h);
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), out);
        }
    }

    private void searchDialog(ScrollView scroll) {
        java.util.List<Hit> all = collect();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        android.widget.EditText q = new android.widget.EditText(this);
        q.setHint("Search settings (e.g. tide, ping, sky)");
        q.setSingleLine(true);
        box.addView(q);
        LinearLayout res = new LinearLayout(this);
        res.setOrientation(LinearLayout.VERTICAL);
        ScrollView rs = new ScrollView(this);
        rs.addView(res);
        box.addView(rs, new LinearLayout.LayoutParams(-1, dp(360)));
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Search").setView(box)
                .setNegativeButton("Close", null).create();
        Runnable fill = () -> {
            res.removeAllViews();
            String[] words = q.getText().toString().toLowerCase(java.util.Locale.ROOT).trim().split("\\s+");
            int n = 0;
            for (Hit h : all) {
                String hay = (h.title + " " + h.desc).toLowerCase(java.util.Locale.ROOT);
                boolean ok = true;
                for (String w : words) if (!w.isEmpty() && !hay.contains(w)) { ok = false; break; }
                if (!ok) continue;
                LinearLayout it = new LinearLayout(this);
                it.setOrientation(LinearLayout.VERTICAL);
                it.setPadding(0, dp(10), 0, dp(10));
                it.addView(text(h.title, 16, fg));
                if (!h.desc.isEmpty()) {
                    TextView dv = text(h.desc, 13, sub);
                    dv.setMaxLines(2);
                    dv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    it.addView(dv);
                }
                it.setOnClickListener(x -> {
                    dlg.dismiss();
                    jumpTo(scroll, h.row);
                });
                res.addView(it);
                if (++n >= 60) break;
            }
            if (n == 0) res.addView(text("Nothing found", 14, sub));
        };
        q.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) { }
            public void onTextChanged(CharSequence a, int b, int c, int d) { }
            public void afterTextChanged(android.text.Editable e) { fill.run(); }
        });
        fill.run();
        dlg.show();
        q.requestFocus();
        dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    /** Scroll the page to a row and flash it. */
    private void jumpTo(ScrollView scroll, View row) {
        for (int i = 0; i < 7; i++) {
            for (View v = row; v != null; v = v.getParent() instanceof View ? (View) v.getParent() : null)
                if (v == pages[i]) { showPage(i); break; }
        }
        int y = 0;
        for (View v = row; v != null && v != list; v = v.getParent() instanceof View ? (View) v.getParent() : null) y += v.getTop();
        final int fy = y;
        scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, fy - dp(80))));
        android.graphics.drawable.Drawable old = row.getBackground();
        row.setBackgroundColor((accent & 0x00FFFFFF) | 0x40000000);
        row.postDelayed(() -> row.setBackground(old), 1600);
    }

    private void section(String t) {
        int c = "Towers".equals(t) || "Operator name".equals(t) ? 1
                : "Launcher".equals(t) || "Volume steps".equals(t) || "Updates".equals(t) ? 6 : 0;
        secCat = c;
        lastCat = c;
    }

    private LinearLayout card() {
        return new RoutedCard();
    }

    private LinearLayout styledCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card);
        g.setCornerRadius(dp(20));
        g.setStroke(dp(1), (accent & 0x00FFFFFF) | 0x22000000);
        c.setBackground(g);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        return c;
    }

    /** "mag" sliders store tenths: 25 shows as "M2.5+". */
    private static String sliderText(int v, String unit) {
        if ("mag".equals(unit)) return String.format(java.util.Locale.US, "M%.1f+", v / 10f);
        if ("km100".equals(unit)) return v >= 200 ? "anywhere" : String.format(java.util.Locale.US, "%,d km of you", v * 100);
        return v + " " + unit;
    }

    private void slider(LinearLayout parent, String label, String unit, String key, int def, int min, int max) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(10), 0, dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text(label, 16, fg);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text("", 15, accent);
        top.addView(val);
        box.addView(top);

        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        int cur = sp.getInt(key, def);
        s.setProgress(cur);
        val.setText(sliderText(cur, unit) + (cur == def ? "  (default)" : ""));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int v, boolean user) {
                val.setText(sliderText(v, unit) + (v == def ? "  (default)" : ""));
            }

            @Override public void onStartTrackingTouch(SeekBar bar) { }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sp.edit().putInt(key, bar.getProgress()).commit();
                changed();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        box.addView(s, lp);
        parent.addView(box);
    }

    private void textField(LinearLayout parent, String label, String desc, String key) {
        textField(parent, label, desc, key, "pk.…", true, null);
    }

    private void textField(LinearLayout parent, String label, String desc, String key, String hint, boolean token) {
        textField(parent, label, desc, key, hint, token, null);
    }

    private void textField(LinearLayout parent, String label, String desc, String key, String hint, boolean token, String url) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text(label, 16, fg));
        if (desc != null) box.addView(text(desc, 13, sub));
        if (url != null) {
            TextView lk = text("Open " + Uri.parse(url).getHost() + " \u2197", 14, accent);
            lk.setPadding(0, dp(8), 0, dp(4));
            lk.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show(); } });
            box.addView(lk);
        }
        android.widget.EditText et = new android.widget.EditText(this);
        et.setSingleLine(true);
        et.setTextColor(fg);
        et.setHintTextColor(sub);
        et.setHint(hint);
        et.setInputType(token ? android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                : android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        et.setText(sp.getString(key, ""));
        et.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(android.text.Editable e) {
                sp.edit().putString(key, e.toString().trim()).commit();
                changed();
            }
        });
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(box);
    }

    /** Round floating button for jumping to the top / bottom of the list. */
    private View jumpButton(String t, Runnable r) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextSize(20);
        b.setTextColor(0xFFFFFFFF);
        b.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        bg.setColor((accent & 0x00FFFFFF) | 0xE0000000);
        b.setBackground(bg);
        b.setElevation(dp(4));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(0, dp(6), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void choice(LinearLayout parent, String label, String key, int def, String[] opts) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        r.addView(text(label, 16, fg));
        int cur = Math.max(0, Math.min(opts.length - 1, sp.getInt(key, def)));
        TextView v = text(opts[cur], 13, sub);
        r.addView(v);
        r.setOnClickListener(x -> new AlertDialog.Builder(this).setTitle(label)
                .setSingleChoiceItems(opts, Math.max(0, Math.min(opts.length - 1, sp.getInt(key, def))), (d, w) -> {
                    sp.edit().putInt(key, w).commit();
                    v.setText(opts[w]);
                    changed();
                    d.dismiss();
                }).show());
        parent.addView(r);
    }

    /** One choice for the animated background instead of two switches. */
    private void skyChoice(LinearLayout parent) {
        final String[] opts = {"Off — plain status bar",
                "Weather — sky follows the weather (sun, moon, clouds, rain…)",
                "Weather + stars — same, but clear nights show stars, planets and satellites"};
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        r.addView(text("Status bar background", 16, fg));
        TextView v = text("", 13, sub);
        Runnable show = () -> {
            boolean on = sp.getBoolean(Cfg.SKY, Cfg.D_SKY), st = sp.getBoolean(Cfg.NIGHT, Cfg.D_NIGHT);
            v.setText(!on ? opts[0] : st ? opts[2] : opts[1]);
        };
        show.run();
        r.addView(v);
        r.setOnClickListener(x -> {
            boolean on = sp.getBoolean(Cfg.SKY, Cfg.D_SKY), st = sp.getBoolean(Cfg.NIGHT, Cfg.D_NIGHT);
            int cur = !on ? 0 : st ? 2 : 1;
            new AlertDialog.Builder(this).setTitle("Status bar background")
                    .setSingleChoiceItems(opts, cur, (d, w) -> {
                        sp.edit().putBoolean(Cfg.SKY, w > 0).putBoolean(Cfg.NIGHT, w == 2).commit();
                        show.run();
                        changed();
                        d.dismiss();
                    }).show();
        });
        parent.addView(r);
    }

    private void toggle(LinearLayout parent, String label, String desc, String key, boolean def) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            sp.edit().putBoolean(key, on).commit();
            changed();
            if (Cfg.PRO.equals(key)) list.post(this::build);
        });
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /** Apps that asked for Play Integrity, newest first (recorded by IntegrityReceiver). */
    /** Nearest dam: what we know about it, plus the checks behind it. Refresh runs the daily check now. */
    private void showDam() {
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION,
                        android.Manifest.permission.ACCESS_FINE_LOCATION}, 42);
        } catch (Throwable ignored) { }
        TextView tv = new TextView(this);
        tv.setText(damReport());
        tv.setTextSize(13);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(18), dp(12), dp(18), dp(4));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Reservoir watch")
                .setView(sv)
                .setPositiveButton("Check now", (dd, w) -> {
                    android.widget.Toast.makeText(this, "Checking…", android.widget.Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        String r = DamJob.check(getApplicationContext(), true);
                        runOnUiThread(() -> { android.widget.Toast.makeText(this, r, android.widget.Toast.LENGTH_LONG).show(); showDam(); });
                    }).start();
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /** Fault lines: what the frame is using, as text for Live diagnostics. */
    private String faultReport() {
        android.content.SharedPreferences d = getSharedPreferences(DamJob.PREFS, MODE_PRIVATE);
        StringBuilder b = new StringBuilder();
        b.append("Frame in the place line: ").append(sp.getBoolean(Cfg.FAULT, Cfg.D_FAULT) ? "on" : "off")
                .append(", radius ").append(sp.getInt(Cfg.FAULT_KM, Cfg.D_FAULT_KM)).append(" km\n");
        if (!d.contains("lat")) { b.append("Position: none saved yet (open Reservoir details once, or let the daily check run)\n"); return b.toString(); }
        double lat = d.getFloat("lat", 0), lon = d.getFloat("lon", 0);
        b.append(String.format(java.util.Locale.US, "Position used here: %.3f, %.3f (the bar uses its own live fix)\n", lat, lon));
        long t0 = System.nanoTime();
        java.util.List<Faults.Hit> hs = Faults.nearest(lat, lon, 4);
        b.append(String.format(java.util.Locale.US, "Lookup took %d ms\n", (System.nanoTime() - t0) / 1_000_000L));
        if (hs.isEmpty()) b.append("Nearest: none in the data within 1500 km\n");
        for (Faults.Hit h : hs)
            b.append(String.format(java.util.Locale.US, "Nearest: %s %d km %s, %s [%s]\n", h.label(), Math.round(h.km), h.dir, Faults.detail(h), h.src.equals("A") ? "AFDI" : "GEM"));
        b.append("Data: AFDI (India) + GEM (South/Central Asia), built into the app\n");
        return b.toString();
    }

    /** Reservoir info and its checks, as text (the details dialog and Live diagnostics). */
    private String damReport() {
        android.content.SharedPreferences d = getSharedPreferences(DamJob.PREFS, MODE_PRIVATE);
        java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("EEE d MMM HH:mm", java.util.Locale.US);
        StringBuilder b = new StringBuilder();
        if (d.contains("name")) {
            int st = d.getInt("state", 2);
            float pct = d.getFloat("pct", 0);
            b.append(d.getString("name", "")).append("\n");
            b.append(String.format(java.util.Locale.US, "%.0f%% full: %s\n", pct, Dam.STATE_NAMES[st]));
            b.append(String.format(java.util.Locale.US, "Live storage %.3f of %.3f BCM\n", d.getFloat("storage", 0), d.getFloat("liveCap", 0)));
            if (!d.getString("river", "").isEmpty()) b.append("River: ").append(d.getString("river", "")).append("\n");
            else b.append("River: not given by CWC for this dam\n");
            if (d.getFloat("frl", 0) > 0) b.append(String.format(java.util.Locale.US, "Full reservoir level %.2f m\n", d.getFloat("frl", 0)));
            b.append(d.getFloat("mw", 0) > 0 ? String.format(java.util.Locale.US, "Hydro power installed %.0f MW\n", d.getFloat("mw", 0)) : "No hydro power station listed\n");
            b.append("Distance ").append(Dam.kmText(d.getFloat("km", 0))).append("\n");
            b.append("CWC reading dated ").append(d.getString("date", "?")).append("\n");
            try {
                org.json.JSONObject h = new org.json.JSONObject(d.getString("hist", "{}"));
                double pd = DamJob.trend(h);
                b.append(Double.isNaN(pd) ? "Trend: needs 3 days of readings\n"
                        : String.format(java.util.Locale.US, "Trend %+.1f points a day%s\n", pd, Math.abs(pd) <= 0.5 ? " (steady)" : pd > 0 ? " (rising)" : " (falling)"));
            } catch (Throwable ignored) { }
        } else {
            b.append("No reading yet. Tap Check now.\n");
        }
        b.append("\n\"Danger\" means how full the reservoir is, not a flood warning. CWC gives no river or water level, "
                + "and no live power output.\n\n--- Checks ---\n");
        long ok = d.getLong("okAt", 0), tr = d.getLong("tryAt", 0);
        boolean loc = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        b.append("Location permission: ").append(loc ? "yes" : "NO (allow it, then Check now)").append("\n");
        b.append("Position used: ").append(d.getString("where", "not checked yet"));
        if (d.getLong("whereAge", -1) > 0) b.append(" (").append(d.getLong("whereAge", 0)).append(" min old)");
        b.append("\n");
        b.append("CWC columns: ").append(Dam.riverKeys.isEmpty() ? "(list not loaded this run)" : Dam.riverKeys).append("\n");
        b.append("Reservoir list: ").append(Dam.list != null ? Dam.list.length + " dams in memory" : new java.io.File(getCacheDir(), "dam_list2.json").exists() ? "cached on phone" : "not downloaded yet").append("\n");
        b.append("CWC storage call: ").append(d.getString("err", "").isEmpty() ? (ok > 0 ? "OK " + d.getString("http", "") : "not run yet") : d.getString("err", "")).append("\n");
        b.append("Last good check: ").append(ok > 0 ? tf.format(new java.util.Date(ok)) : "never").append("\n");
        b.append("Last attempt: ").append(tr > 0 ? tf.format(new java.util.Date(tr)) : "never").append("\n");
        try {
            org.json.JSONObject h = new org.json.JSONObject(d.getString("hist", "{}"));
            b.append("Readings kept for the trend: ").append(h.length()).append("\n");
        } catch (Throwable ignored) { }
        b.append("Daily job: ").append(DamJob.scheduled(this) ? "scheduled" : "NOT scheduled").append("\n");
        b.append("Notifications: ").append(getSystemService(android.app.NotificationManager.class).areNotificationsEnabled() ? "allowed" : "blocked in Android settings").append("\n");
        try {
            boolean free = getSystemService(android.os.PowerManager.class).isIgnoringBatteryOptimizations(getPackageName());
            b.append("Battery: ").append(free ? "unrestricted" : "optimised (Android may delay the daily check)").append("\n");
        } catch (Throwable ignored) { }
        b.append("Chip in the status bar: ").append(sp.getBoolean(Cfg.DAM, Cfg.D_DAM) ? "on" : "off").append("\n");
        return b.toString();
    }

    /** Nearest mapped faults to where the phone last was. */
    private void showFaults() {
        Toast.makeText(this, "Locating…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            android.content.SharedPreferences d = getSharedPreferences(DamJob.PREFS, MODE_PRIVATE);
            double lat, lon;
            String where;
            if (d.contains("lat")) { lat = d.getFloat("lat", 0); lon = d.getFloat("lon", 0); where = "last known position"; }
            else { Object[] w = DamJob.where(getApplicationContext()); lat = (Double) w[0]; lon = (Double) w[1]; where = (String) w[3]; }
            java.util.List<Faults.Hit> hs = Faults.nearest(lat, lon, 6);
            StringBuilder b = new StringBuilder();
            b.append(String.format(java.util.Locale.US, "Position used: %.3f, %.3f (%s)\n\n", lat, lon, where));
            b.append("Nearest mapped faults\n");
            if (hs.isEmpty()) b.append("  none in the data within 1500 km (the data covers India, South and Central Asia)\n");
            for (Faults.Hit h : hs)
                b.append(String.format(java.util.Locale.US, "  %s  %d km %s\n      %s\n", h.label(), Math.round(h.km), h.dir, Faults.detail(h)));
            b.append("\n").append(Faults.credit());
            final String txt = b.toString();
            runOnUiThread(() -> {
                TextView tv = new TextView(this);
                tv.setText(txt);
                tv.setTextSize(13);
                tv.setTextIsSelectable(true);
                tv.setPadding(dp(18), dp(12), dp(18), dp(4));
                android.widget.ScrollView sv = new android.widget.ScrollView(this);
                sv.addView(tv);
                new AlertDialog.Builder(this).setTitle("Fault lines").setView(sv).setNegativeButton("Close", null).show();
            });
        }).start();
    }

    private void showIntegrity() {
        String r = IntegrityReceiver.history(this);
        if (r.isEmpty()) r = "No checks seen yet.\n\nTick Google Play Store in LSPosed for this module, then force-stop "
                + "Play Store (or reboot). Each check an app makes shows up here.";
        TextView tv = new TextView(this);
        tv.setText(r);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(18), dp(12), dp(18), dp(4));
        tv.setHorizontallyScrolling(true);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(tv);
        sv.addView(hs);
        new AlertDialog.Builder(this)
                .setTitle("Play Integrity checks")
                .setView(sv)
                .setPositiveButton("Refresh", (d, w) -> showIntegrity())
                .setNeutralButton("Clear", (d, w) -> IntegrityReceiver.clear(this))
                .setNegativeButton("Close", null)
                .show();
    }

    /** The status bar's live satellite list (published by System UI every 30 s). */
    private void showSatellites() {
        String r = null;
        try { r = android.provider.Settings.Global.getString(getContentResolver(), "netspeed_sat_report"); } catch (Throwable ignored) { }
        if (r == null || r.isEmpty()) r = "No list from the status bar yet.\n\nIt is published every 30 s once the module is "
                + "running in System UI (restart System UI after an update) and the screen is on.";
        try { r = r + "\n\nRESERVOIR WATCH\n" + damReport().replace("\n", "\n  "); } catch (Throwable ignored) { }
        try { r = r + "\n\nFAULT LINES\n  " + faultReport().replace("\n", "\n  "); } catch (Throwable ignored) { }
        TextView tv = new TextView(this);
        tv.setText(r);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(14), dp(12), dp(14), dp(4));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Live diagnostics")
                .setView(sv)
                .setPositiveButton("Refresh", (d, w) -> {
                    if (!sp.getBoolean(Cfg.DAM, Cfg.D_DAM)) { showSatellites(); return; }
                    Toast.makeText(this, "Refreshing, checking the dam…", Toast.LENGTH_SHORT).show();
                    new Thread(() -> {
                        String res = DamJob.check(getApplicationContext(), false);
                        runOnUiThread(() -> { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); showSatellites(); });
                    }).start();
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void button(LinearLayout parent, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? (isDark() ? 0xFF06251C : Color.WHITE) : accent);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        if (primary) g.setColor(accent);
        else {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(dp(1), accent);
        }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp;
        if (parent.getOrientation() == LinearLayout.VERTICAL) {
            lp = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
            lp.setMargins(0, dp(8), 0, dp(8));
        } else {
            lp = new LinearLayout.LayoutParams(0, dp(48), primary ? 2f : 1f);
            lp.setMarginEnd(primary ? dp(10) : 0);
        }
        parent.addView(b, lp);
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    // ------------------------------------------------------------ actions

    /** Tells System UI to reload settings. */
    private void changed() {
        getContentResolver().notifyChange(URI, null);
    }

    /** A switch backed by a system property (set with root), for settings the system server reads. */
    private void propToggle(LinearLayout parent, String label, String desc, String prop) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(Cfg.NAV_IMMERSIVE, Cfg.D_NAV_IMMERSIVE)
                || "1".equals(getProp(prop)) || "true".equals(getProp(prop)));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            // Saved for System UI (applies on Restart System UI), and as a property for the
            // system server (applies after a reboot).
            sp.edit().putBoolean(Cfg.NAV_IMMERSIVE, on).commit();
            changed();
            String val = on ? "1" : "0";
            boolean ok = runSu("setprop " + prop + " " + val)
                    || runSu("resetprop -p " + prop + " " + val)
                    || runSu("/data/adb/ksu/bin/resetprop -p " + prop + " " + val);
            boolean took = val.equals(getProp(prop));
            runOnUiThread(() -> {
                new AlertDialog.Builder(this)
                        .setMessage((on ? "Immersive navigation on." : "Immersive navigation off.")
                                + " Restart System UI + launcher to apply.")
                        .setPositiveButton("Restart System UI + launcher", (d, w) -> {
                            new Thread(() -> runSu("am force-stop $(cmd package resolve-activity --brief "
                                    + "-a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1 "
                                    + "| cut -d/ -f1)")).start();
                            restartSystemUi();
                        })
                        .setNegativeButton("Later", null)
                        .show();
            });
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /**
     * Edge-to-edge for every app. Android forces it on apps whose target SDK is at least
     * persist.wm.debug.default_e2e_since_sdk (read once at boot); 0 = every app. Apps draw behind the
     * status bar and around the camera and pad their content by the bar's height.
     */
    private static final String E2E_PROP = "persist.wm.debug.default_e2e_since_sdk";

    private void e2eToggle(LinearLayout parent) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text("Apps draw to the screen edges", 16, fg));
        texts.addView(text("Every app draws behind the status bar and around the camera, like apps made for "
                + "Android 15+. If one app's top bar ends up under the status bar, turn this off. Needs a reboot", 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked("0".equals(getProp(E2E_PROP)));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            String val = on ? "0" : "2147483647";
            boolean ok = runSu("setprop " + E2E_PROP + " " + val)
                    || runSu("resetprop -p " + E2E_PROP + " " + val)
                    || runSu("/data/adb/ksu/bin/resetprop -p " + E2E_PROP + " " + val);
            boolean took = val.equals(getProp(E2E_PROP));
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setMessage(took ? (on ? "Edge-to-edge for all apps is on." : "Edge-to-edge for all apps is off.")
                            + " Reboot to apply." : "Couldn't set it (root denied?).")
                    .setPositiveButton(took ? "Reboot now" : "OK", (d, w) -> {
                        if (took) new Thread(() -> runSu("svc power reboot || reboot")).start();
                    })
                    .setNegativeButton("Later", null)
                    .show());
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /** App suggestions (launcher dock + app drawer). Needs a reboot: the system reads it at boot. */
    private void predictToggle(LinearLayout parent) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text("App suggestions ⟳ reboot", 16, fg));
        texts.addView(text("Pixel-style suggested apps in empty dock slots and at the top of the app "
                + "drawer, from your own usage history (stays on this phone). Tick System Framework "
                + "in the scope", 13, sub));
        TextView st = text(predictStatus(), 12, sub);
        texts.addView(st);
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        String prop = Predict.PROP;
        sw.setChecked(sp.getBoolean(Cfg.PREDICT, Cfg.D_PREDICT));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            sp.edit().putBoolean(Cfg.PREDICT, on).commit();
            String val = on ? "1" : "0";
            runSu("setprop " + prop + " " + val);
            String f = Predict.FLAG;
            boolean ok = on
                    ? runSu("echo 1 > " + f + " && chmod 644 " + f + " && chown system:system " + f
                            + " && (chcon u:object_r:system_data_file:s0 " + f + " || true)")
                    : runSu("rm -f " + f + " && setprop " + prop + " 0; true");
            // Usage history access, so suggestions follow what you actually use.
            if (on) runSu("appops set " + getPackageName() + " GET_USAGE_STATS allow");
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setMessage((on ? "App suggestions on." : "App suggestions off.")
                            + (ok ? " Reboot to apply." : "\n\nCouldn't save the setting with root. "
                            + "Allow root for this app in ReSukiSU and try again."))
                    .setPositiveButton("Reboot now", (d, w) -> new Thread(() -> runSu("svc power reboot || reboot")).start())
                    .setNegativeButton("Later", null)
                    .show());
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    private String predictStatus() {
        try {
            java.util.Map<String, ?> m = createDeviceProtectedStorageContext()
                    .getSharedPreferences(PredictionService.STATUS_PREFS, 0).getAll();
            if (m.isEmpty()) return "Status: the system hasn't started the suggestions service yet";
            StringBuilder b = new StringBuilder("Status (now "
                    + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date()) + "):");
            for (String k : new String[]{"service", "destroyed", "alive", "tick_error", "request", "event",
                    "session_hotseat", "session_home", "usage",
                    "last_hotseat", "last_home", "rootlist", "debug", "error"}) {
                Object v = m.get(k);
                if (v != null) b.append("\n• ").append(k.replace('_', ' ')).append(": ").append(v);
            }
            return b.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    private static String getProp(String key) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            return (String) sp.getMethod("get", String.class).invoke(null, key);
        } catch (Throwable t) {
            return "";
        }
    }

    /** Wait 8 s (go to the app where the pill is too high), then save the window / inset state. */
    private void savePillDump() {
        Toast.makeText(this, "Open the app where the pill is too high - saving in 8 s", Toast.LENGTH_LONG).show();
        new Thread(() -> {
            try { Thread.sleep(8000); } catch (InterruptedException ignored) { }
            boolean ok = runSu("f=/sdcard/Download/netspeed_pill_dump_$(date +%H%M%S).txt; { date; "
                    + "echo '== focus'; dumpsys window | grep -E 'mCurrentFocus|mFocusedApp|imeControlTarget'; "
                    + "echo '== taskbar window'; dumpsys window windows | grep -i -A22 'Window{.* Taskbar}'; "
                    + "echo '== navigation insets'; dumpsys window displays | grep -i -E 'type=(navigationBars|mandatorySystemGestures|tappableElement|ime) '; "
                    + "echo '== launcher taskbar state'; dumpsys activity service com.android.launcher3/com.android.quickstep.TouchInteractionService 2>&1 "
                    + "| grep -i -E 'taskbar|stash|handle|margin|translation|inset|isInApp|transient|ime' | head -n 250; "
                    + "echo '== module log'; for x in $(ls -t /data/adb/lspd/log/modules_* /data/adb/lspd/log/verbose_* 2>/dev/null | head -n 2); do echo $x; grep -F '[nav]' $x | tail -n 60; done; "
                    + "logcat -d 2>/dev/null | grep -F '[nav]' | tail -n 40; "
                    + "} > $f 2>&1; chmod 666 $f");
            runOnUiThread(() -> Toast.makeText(this, ok ? "Saved: Download/netspeed_pill_dump_*.txt - send it to me"
                    : "Couldn't save (is root granted?)", Toast.LENGTH_LONG).show());
        }).start();
    }

    private static boolean runSu(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void restartSystemUi() {
        new Thread(() -> {
            String err = null;
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "killall com.android.systemui"});
                if (p.waitFor() != 0) err = "Root command failed (exit " + p.exitValue() + ")";
            } catch (Exception e) {
                err = "Root not available: " + e.getMessage();
            }
            final String msg = err;
            runOnUiThread(() -> {
                if (msg != null) Toast.makeText(this, msg + ". Grant root to this app in ReSukiSU, or reboot.",
                        Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
