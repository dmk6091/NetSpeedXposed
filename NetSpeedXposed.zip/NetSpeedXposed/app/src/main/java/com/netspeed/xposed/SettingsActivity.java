package com.netspeed.xposed;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Settings screen. Opens from the module's "Settings" in Vector/LSPosed and from the app icon.
 * Most changes apply to the status bar right away; a few need System UI restarted.
 */
public class SettingsActivity extends Activity {
    private static final Uri URI = Uri.parse("content://com.netspeed.xposed.settings/all");

    private SharedPreferences sp;
    private LinearLayout list;
    private int fg, sub, card, accent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = SettingsProvider.prefs(this);
        // integrity watcher notifications (Android 13+ asks once)
        try {
            if (sp.getBoolean(Cfg.INTEGRITY_NOTIFY, Cfg.D_INTEGRITY_NOTIFY)
                    && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 41);
        } catch (Throwable ignored) { }
        if (getIntent() != null && getIntent().getBooleanExtra("show_integrity", false))
            getWindow().getDecorView().post(this::showIntegrity);

        boolean dark = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        int bg = dark ? 0xFF1B1B1F : 0xFFF6F5FA;
        card = dark ? 0xFF2A2A30 : 0xFFFFFFFF;
        fg = dark ? 0xFFE6E1E9 : 0xFF1C1B1F;
        sub = dark ? 0xFF9A96A3 : 0xFF6A6672;
        accent = dark ? 0xFFC9BFFF : 0xFF5B4DB0;

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        list.setPadding(p, p, p, p);
        scroll.addView(list);
        // Edge-to-edge: keep content clear of the status and navigation bars.
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(0, sys.top, 0, sys.bottom);
            return in;
        });
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(-1, -1));
        LinearLayout jump = new LinearLayout(this);
        jump.setOrientation(LinearLayout.VERTICAL);
        jump.addView(jumpButton("🔍", () -> searchDialog(scroll)));
        jump.addView(jumpButton("↑", () -> scroll.smoothScrollTo(0, 0)));
        jump.addView(jumpButton("↓", () -> scroll.smoothScrollTo(0, list.getHeight())));
        android.widget.FrameLayout.LayoutParams jlp = new android.widget.FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.END);
        jlp.setMargins(0, 0, dp(16), dp(24));
        root.addView(jump, jlp);
        root.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets sys = in.getInsets(WindowInsets.Type.systemBars());
            jlp.bottomMargin = dp(24) + sys.bottom;
            jump.setLayoutParams(jlp);
            scroll.dispatchApplyWindowInsets(in);
            return in;
        });
        setContentView(root);
        // Light background: ask for dark status/navigation bar icons, so they stay readable.
        if (!dark) {
            try {
                android.view.WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    c.setSystemBarsAppearance(light, light);
                }
            } catch (Throwable ignored) { }
        }
        build();
    }

    private void build() {
        list.removeAllViews();
        // with the 4-row bar on, options that only shaped the old layouts are left out
        final boolean pro = sp.getBoolean(Cfg.PRO, Cfg.D_PRO);
        title("NetSpeed status bar");
        note("Changes apply to the status bar right away. Items marked ⟳ need System UI restarted.");

        section("Layout");
        LinearLayout c = card();
        if (!pro) {
            toggle(c, "Readable layout", "Four lines of large text: clock, CPU / battery temperature, watts, speed, "
                    + "notifications, Bluetooth; per-SIM network, signal, band and distance (the SIM carrying mobile data "
                    + "sits in a highlighted pill with live \u2193\u2191); weather and air quality; portrait battery. "
                    + "Turn off for the old two-row layout", Cfg.READABLE, Cfg.D_READABLE);
        }
        toggle(c, "New 4-row status bar", "Everything in four rows: clock with time zone, speed and temperatures; sunrise/sunset, alarm, notifications and a frame for the system icons; power, CPU load and GPS; ping, deep sleep, wakelock and Bluetooth. Battery health and cycles under the camera; both SIMs (data SIM outlined) against the right edge, full weather under them. Overrides the layouts below. Restart SystemUI to apply", Cfg.PRO, Cfg.D_PRO);
        slider(c, "4-row bar extra height \u27f3", "dp", Cfg.PRO_EXTRA, Cfg.D_PRO_EXTRA, 0, 24);
        e2eToggle(c);
        if (!pro) {
            slider(c, "Gap between rows", "dp", Cfg.ROW_GAP, Cfg.D_ROW_GAP, 0, 12);
            slider(c, "Row 2 height", "dp", Cfg.ROW2_H, Cfg.D_ROW2_H, 14, 32);
            slider(c, "Gap before weather", "dp", Cfg.WEATHER_GAP, Cfg.D_WEATHER_GAP, 0, 16);
            slider(c, "Status bar height trim / extra ⟳", "dp", Cfg.EXTRA, Cfg.D_EXTRA, -20, 24);
        }
        slider(c, "Apps' top space: move app content up", "dp", Cfg.APP_TOP_TRIM, Cfg.D_APP_TOP_TRIM, 0, 60);
        c.addView(text("0 = apps start below the whole bar. Higher moves every app's header up behind the "
                + "lower rows. Taps there go to the status bar, so keep buttons clear. Applies live", 13, sub));
        propToggle(c, "Immersive navigation", "Apps draw to the bottom edge; the gesture pill "
                + "floats over them. Tick your launcher (and System Framework) in the LSPosed/Vector scope",
                NavImmersive.PROP);
        slider(c, "Gesture pill drop: 0 = default height, higher = lower", "dp", Cfg.PILL_DY, Cfg.D_PILL_DY, 0, 12);
        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setPadding(0, dp(4), 0, dp(8));
        button(pillRow, "Save gesture-pill dump (8 s)", false, v -> savePillDump());
        button(pillRow, "Restart launcher", false, v -> new Thread(() -> {
            boolean ok = runSu("am force-stop $(cmd package resolve-activity --brief "
                    + "-a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1 | cut -d/ -f1)");
            runOnUiThread(() -> Toast.makeText(this, ok ? "Launcher restarted" : "Couldn't restart (root?)",
                    Toast.LENGTH_SHORT).show());
        }).start());
        c.addView(pillRow);

        if (!pro) {
            section("Text");
            c = card();
            slider(c, "Temperatures size", "sp", Cfg.TEMP_SP, Cfg.D_TEMP_SP, 6, 12);
            slider(c, "Weather size", "sp", Cfg.WEATHER_SP, Cfg.D_WEATHER_SP, 8, 16);
            slider(c, "Net speed size", "sp", Cfg.SPEED_SP, Cfg.D_SPEED_SP, 6, 12);
            slider(c, "Amps / watts size", "sp", Cfg.POWER_SP, Cfg.D_POWER_SP, 6, 12);
            slider(c, "Network band size", "sp", Cfg.BAND_SP, Cfg.D_BAND_SP, 6, 12);
            slider(c, "Tower mast size", "%", Cfg.MAST_PCT, Cfg.D_MAST_PCT, 80, 200);
            slider(c, "Clock size", "sp", Cfg.CLOCK_SP, Cfg.D_CLOCK_SP, 9, 18);
            slider(c, "Row 2 right margin", "dp", Cfg.ROW2_END, Cfg.D_ROW2_END, 0, 24);
            slider(c, "Signal tower icon size", "%", Cfg.TOWER_PCT, Cfg.D_TOWER_PCT, 70, 150);
            toggle(c, "Bold small text", "Temperatures and net speed", Cfg.BOLD, Cfg.D_BOLD);
        }

        section("Show");
        c = card();
        toggle(c, "CPU temperature", null, Cfg.SHOW_CPU, Cfg.D_SHOW_CPU);
        toggle(c, "Battery temperature", null, Cfg.SHOW_BAT, Cfg.D_SHOW_BAT);
        toggle(c, "Amps and watts", "Battery current and power, after the net speed",
                Cfg.SHOW_POWER, Cfg.D_SHOW_POWER);
        toggle(c, "Network band per SIM", "e.g. n78₁ over B3₂, before VoLTE / VoNR",
                Cfg.SHOW_BAND, Cfg.D_SHOW_BAND);
        if (!pro) {
            toggle(c, "Signal strength (dBm)", "e.g. n78₁ -92. Hidden by itself if there's no room",
                    Cfg.SHOW_DBM, Cfg.D_SHOW_DBM);
        }
        toggle(c, "Distance to tower", "Next to the tower counts: how far your serving tower is (~ estimate, ? unknown)",
                Cfg.SHOW_DIST, Cfg.D_SHOW_DIST);
        if (!pro) {
            toggle(c, "Signal tower icon", "One tower for both SIMs: SIM 1 waves left, SIM 2 right (4 = full), "
                    + "network + VoLTE/VoNR per SIM, ↓↑ on the data SIM. Replaces the stock bars, type and Vo badge",
                    Cfg.TOWER_ICON, Cfg.D_TOWER_ICON);
        }
        toggle(c, "Own row 2 icons", "Bell with the notification count (silent ones in brackets), Bluetooth "
                + "devices (W watch / H headphones / P phone + battery + codec), vibrate / silent / DND, next alarm, "
                + "Wi-Fi router (generation, band, dBm, link speed, activity) and a small tray for the rest. "
                + "Replaces the stock notification and system icons", Cfg.SYS_ICONS, Cfg.D_SYS_ICONS);
        toggle(c, "Lock screen globe", "Live Earth under the lock screen clock: day/night, your location as a red dot. "
                + "Drag or flick to turn it, double-tap to come back to your location",
                Cfg.LOCK_GLOBE, Cfg.D_LOCK_GLOBE);
        toggle(c, "Globe turns by itself", "When you aren't touching it the Earth turns slowly (one turn in "
                + "90 s) with the live day / night line", Cfg.GLOBE_SPIN, Cfg.D_GLOBE_SPIN);
        if (!pro) {
            toggle(c, "Portrait battery", "Upright battery with the % inside, coloured by level (green while charging)",
                    Cfg.BATT_PORTRAIT, Cfg.D_BATT_PORTRAIT);
            toggle(c, "Battery % inside the icon", "Stock battery icon with the percentage written inside it",
                    Cfg.BATT_PCT_IN, Cfg.D_BATT_PCT_IN);
            toggle(c, "Li-ion battery cell", "Battery drawn as a cell with a liquid fill and % inside, coloured "
                    + "by level (green while charging). Replaces the stock icon", Cfg.BATT_CELL, Cfg.D_BATT_CELL);
            toggle(c, "Battery details beside the cell", "Voltage, charge left / total (Ah), time to empty "
                    + "(↓) or to full (ϟ)", Cfg.BATT_TEXT, Cfg.D_BATT_TEXT);
            toggle(c, "Clock seconds + timezone", "Seconds and IST beside the time, and a thin line under it "
                    + "that fills over each minute", Cfg.CLOCK_SECONDS, Cfg.D_CLOCK_SECONDS);
            toggle(c, "Next sunrise / sunset under the clock", "Small clock moved up; under it the next sun event "
                    + "(↑ sunrise or ↓ sunset) with its time", Cfg.CLOCK_SUN, Cfg.D_CLOCK_SUN);
        }
        toggle(c, "Auto contrast", "Measures the brightness under the status bar and switches to dark "
                + "text on light screens (and white on dark), even when an app asks for the wrong one",
                Cfg.AUTO_CONTRAST, Cfg.D_AUTO_CONTRAST);
        if (!pro) {
            toggle(c, "Text around the camera", "Battery health % curved over the camera hole (amber under 90 %, red under 80 %), "
                    + "charge cycles under it (the lower line steps aside when notification icons reach under the camera)",
                    Cfg.CAM_TEXT, Cfg.D_CAM_TEXT);
        }
        toggle(c, "Weather details", "Beside the weather icon: rain chance (next 3 h), UV, "
                + "humidity, wind, AQI (Open-Meteo, every 15 min). Least important drop out when space is short. The AQI pill shows the number and a letter: "
                + "G good (0-50), M moderate (51-100), S unhealthy for sensitive groups (101-150), U unhealthy (151-200), "
                + "V very unhealthy (201-300), H hazardous (301+). Colour goes green, yellow, orange, red, purple, maroon",
                Cfg.WX_DETAILS, Cfg.D_WX_DETAILS);
        slider(c, "Earthquakes shown from", "mag", Cfg.QUAKE_MIN, Cfg.D_QUAKE_MIN, 10, 70);
        slider(c, "Earthquakes within", "km100", Cfg.QUAKE_KM, Cfg.D_QUAKE_KM, 1, 200);
        button(c, "Sky, towers & satellites now (live from the status bar)", false, v -> showSatellites());
        button(c, "Play Integrity checks (history)", false, v -> showIntegrity());
        if (!pro) {
            toggle(c, "Speedometer with the net speed", "Small gauge for download speed (1 K/s to 100 M/s); "
                    + "arrows green ↓ / blue ↑, speeds coloured idle grey → fast green/blue → very fast cyan",
                    Cfg.SPEED_GAUGE, Cfg.D_SPEED_GAUGE);
            toggle(c, "SINR with the tower counts", "Nodes symbol coloured by signal quality (green good, yellow fair, "
                    + "red poor) and the SINR in dB after the distance; the number hides first when space is short",
                    Cfg.SINR_MAST, Cfg.D_SINR_MAST);
            toggle(c, "Temperatures + current together", "Thermometer per line, temperature coloured by heat, then "
                    + "amps / watts in the same block", Cfg.COMBINE_TEMPS, Cfg.D_COMBINE_TEMPS);
            toggle(c, "SNR next to dBm", "Signal-to-noise per SIM (dB), left of the camera. Hidden by itself if there's no room",
                    Cfg.SHOW_SNR, Cfg.D_SHOW_SNR);
        }
        toggle(c, "Combined VoLTE / VoNR badge", "One \"Vo\" badge with each SIM's voice type "
                + "(NR / LTE / WiFi) instead of the two stock icons", Cfg.VO_BADGE, Cfg.D_VO_BADGE);
        toggle(c, "Network type with activity arrows", "5G / 4G+ with ↓↑ underneath that light up "
                + "while data flows (like Samsung)", Cfg.NET_TYPE, Cfg.D_NET_TYPE);
        section("Animations");
        c = card();
        toggle(c, "Low heat mode", "Turns off the always-moving animations (heat pulse, shine, moving "
                + "arrows, charging flow) and the ping dot, so the status bar isn't redrawn many times a "
                + "second. Recommended", Cfg.LOW_HEAT, Cfg.D_LOW_HEAT);
        toggle(c, "Animation: heat warning", "Warm or hot temperatures pulse orange / red (cool ones stay calm)",
                Cfg.ANIM_HEAT, Cfg.D_ANIM_HEAT);
        if (!pro) {
            toggle(c, "Speed sparkline", "A tiny live graph of the last 30 seconds after the speed numbers "
                    + "(↓ green, ↑ blue)", Cfg.ANIM_SPARK, Cfg.D_ANIM_SPARK);
        }
        toggle(c, "Idle dimming", "After a few quiet seconds the status bar softens; an item lights up "
                + "again when its value changes", Cfg.ANIM_DIM, Cfg.D_ANIM_DIM);
        if (!pro) {
            toggle(c, "Colourful network type", "5G purple-cyan, 4G+ orange-pink, 4G green, 3G yellow, 2G red "
                    + "(on the tower view)", Cfg.NET_COLOR, Cfg.D_NET_COLOR);
            toggle(c, "Animation: network type shine", "A light sweeps across 5G / 4G+ every few seconds",
                    Cfg.ANIM_SHIMMER, Cfg.D_ANIM_SHIMMER);
            toggle(c, "Animation: moving arrows", "The ↓↑ arrows move while data flows (faster look, still only "
                    + "while there is traffic)", Cfg.ANIM_ARROWS, Cfg.D_ANIM_ARROWS);
            toggle(c, "Animation: 5G / 4G switch flash", "The network type pops once when it changes, so you see "
                    + "when NetSwitch acted", Cfg.ANIM_SWITCH, Cfg.D_ANIM_SWITCH);
        }
        toggle(c, "Animation: charging flow", "A light runs along the battery fill while charging",
                Cfg.ANIM_CHARGE, Cfg.D_ANIM_CHARGE);
        if (!pro) {
            toggle(c, "Animation: bell wiggle + count roll", "The bell shakes and the number rolls up when a "
                    + "new notification arrives", Cfg.ANIM_BELL, Cfg.D_ANIM_BELL);
        }
        toggle(c, "Ping dot", "A small dot beside the network type, ticks every few seconds: green fast, "
                + "amber slow, red no connection (a tiny TCP connect to 1.1.1.1)", Cfg.ANIM_PING, Cfg.D_ANIM_PING);
        button(c, "▶  Test the animations now", true, v -> {
            try {
                sendBroadcast(new android.content.Intent("com.netspeed.xposed.ANIM_TEST"));
                android.widget.Toast.makeText(this, "Playing for 8 seconds - look at the status bar",
                        android.widget.Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) { }
        });
        section("Towers");
        c = card();
        toggle(c, "Towers around per SIM", "Dish + estimated number of towers each SIM can hear (from "
                + "the cells' ids). Hidden by itself if there's no room before the camera", Cfg.SHOW_CELLS, Cfg.D_SHOW_CELLS);
        toggle(c, "Look up towers online", "For idle SIMs and 5G: tower position from BeaconDB + your "
                + "location, shown with ~. Sends only tower IDs", Cfg.TOWER_DB, Cfg.D_TOWER_DB);
        toggle(c, "Learn tower positions", "For towers no database knows (mostly 5G): records your "
                + "position + signal while you move and estimates the tower. Stays on this phone",
                Cfg.LEARN, Cfg.D_LEARN);
        toggle(c, "Learn while riding", "When you're on the move (not standing still), one GPS fix a minute so towers get "
                + "learned even without a navigation app. Also learns the nearby towers your phone hears. A little battery "
                + "while moving, none while still", Cfg.RIDE_GPS, Cfg.D_RIDE_GPS);
        toggle(c, "Weak 5G → 4G (quota-guarded)", "When the data SIM's 5G is weak for 20 s, switch it to 4G, retry 5G after "
                + "3 min (longer if it keeps failing). Stops once 4G data today reaches the limit below, so a 5G-unlimited / "
                + "4G-capped plan isn't eaten. The bar shows 4G·used while it's on. Needs \"Phone Services\" in LSPosed; reboot once",
                Cfg.NR_FALLBACK, Cfg.D_NR_FALLBACK);
        choice(c, "5G / 4G mode", Cfg.NR_MODE, Cfg.D_NR_MODE, new String[]{"Automatic",
                "Always allow 5G (fallback off)", "Force 4G (5G off)"});
        toggle(c, "Check the internet, not just the signal", "Weak 5G also counts when the connection carries no data: "
                + "when nothing is coming in, a tiny request is sent over mobile data about once a minute (3 failures in a row = "
                + "bad). The automatic switching also pauses on Wi-Fi, in airplane mode and with mobile data off",
                Cfg.NR_NETCHECK, Cfg.D_NR_NETCHECK);
        toggle(c, "Move data to the other SIM when this one is weak", "Turns on Android's own \"switch mobile data automatically\" "
                + "for both SIMs: when the data SIM is weak the phone uses the other SIM's data, and goes back when it recovers "
                + "(the phone checks the other SIM really has internet). Turning this off puts the setting back as it was. "
                + "Needs \"Phone Services\" in LSPosed; reboot once", Cfg.AUTO_SIM, Cfg.D_AUTO_SIM);
        toggle(c, "Notify on Play Integrity checks", "A notification each time an app asks Google Play whether this "
                + "phone passes Play Integrity (watch only: nothing is blocked or changed). Needs Google Play Store "
                + "ticked in LSPosed; force-stop Play Store or reboot once", Cfg.INTEGRITY_NOTIFY, Cfg.D_INTEGRITY_NOTIFY);
        toggle(c, "Toast on Play Integrity checks", "A short pop-up message with the app's name each time it checks",
                Cfg.INTEGRITY_TOAST, Cfg.D_INTEGRITY_TOAST);
        toggle(c, "Qualcomm 5G+ reader (experimental)", "Asks Qualcomm's own phone helper (the one stock HyperOS uses) "
                + "whether each SIM's 5G counts as 5G+, and shows 5G+ when it does. What it finds is listed in "
                + "\"Sky, towers & satellites now\". Needs com.qti.phone ticked in LSPosed; reboot after switching. "
                + "Turn off if calls or data act up", Cfg.QTI_NR, Cfg.D_QTI_NR);
        toggle(c, "Tide at the nearest coast", "Row 3 after AQI: rising ↑ / falling ↓, height now, next high (H) or "
                + "low (L) water and the place. Model data (Open-Meteo Marine), about ±20 min. Amber = spring tide",
                Cfg.TIDE, Cfg.D_TIDE);
        toggle(c, "Disasters & solar storms", "Row 4: a current GDACS orange / red alert (cyclone, flood, volcano, "
                + "wildfire, drought, quake) replaces the quake line, with distance and direction from you. A magnetic "
                + "storm (NOAA Kp 5 or more) adds 🧲Kp·G at the end. Quiet most days", Cfg.HAZARDS, Cfg.D_HAZARDS);
        textField(c, "ReliefWeb app name (optional)", "Adds UN OCHA ReliefWeb disasters (floods, epidemics, landslides…) to the "
                + "row-4 rotation. Request an app name at apidoc.reliefweb.int, paste it here once approved", Cfg.RELIEFWEB_APP, "e.g. dmk-netspeed", false);
        choice(c, "Tide place", Cfg.TIDE_PLACE, Cfg.D_TIDE_PLACE, Tide.choices());
        textField(c, "SIM 1 bands (lock)", "Only these bands, e.g. \"n78 B3 B40\" (B = 4G, n = 5G). Only B given: 5G stays free; "
                + "only n given: 4G stays free. Empty = all bands. Not saved in the modem: a reboot or emptying the field undoes it. "
                + "Needs \"Phone Services\" in LSPosed. Result shows in \"Sky, towers & satellites now\"", Cfg.BANDS1, "e.g. n78 B3 B40", false);
        textField(c, "SIM 2 bands (lock)", "Same for SIM 2", Cfg.BANDS2, "e.g. B3 B40", false);
        toggle(c, "Dashboard layout (new)", "5 labelled rows: clock + system icons | network · SKY | towers · DEVICE | data · "
                + "WEATHER | TIDE · SPACE | ALERT. Off = the previous layout", Cfg.NEWBAR, Cfg.D_NEWBAR);
        toggle(c, "Group tints", "Faint coloured backgrounds that group the bar: time, device, speed, mobile network, "
                + "sky, weather, Earth & hazards. No extra space used", Cfg.ZONES, Cfg.D_ZONES);
        choice(c, "Corner beside the SIMs", Cfg.CORNER, Cfg.D_CORNER, new String[]{"Off",
                "5G share today (5G over %)", "Signal quality now (Q over %)"});
        slider(c, "4G data limit for the fallback", "MB", Cfg.NR_QUOTA_MB, Cfg.D_NR_QUOTA_MB, 200, 2000);
        textField(c, "OpenCelliD token (optional)", "Backup database with better coverage. Paste the "
                + "token from my.opencellid.org (starts with pk.). Stays on this phone.", Cfg.OCID_KEY);
        textField(c, "WeatherAPI.com key (optional)", "Free key from weatherapi.com. When set, temperature, condition, "
                + "rain chance, wind, UV, cloud and high/low come from WeatherAPI (corrected with real stations) instead "
                + "of the forecasts. Stays on this phone.", Cfg.WAPI_KEY);
        toggle(c, "Weather", "From OmniJaws", Cfg.SHOW_WEATHER, Cfg.D_SHOW_WEATHER);
        if (!pro) {
            toggle(c, "Hide net speed when idle", "After 10 s below 1 KB/s", Cfg.HIDE_IDLE, Cfg.D_HIDE_IDLE);
        }
        toggle(c, "Heat throttle (root)", "When hot: caps every CPU cluster and the GPU to the speeds below, drops the screen to 60 Hz and clears background apps. Releases when cooled and restores your refresh rate. Needs root for NetSpeed. Restart SystemUI to apply", Cfg.THR, Cfg.D_THR);
        slider(c, "Throttle when battery reaches", "\u00B0C", Cfg.THR_BAT, Cfg.D_THR_BAT, 36, 50);
        slider(c, "Throttle when CPU reaches", "\u00B0C", Cfg.THR_CPU, Cfg.D_THR_CPU, 55, 95);
        slider(c, "GPU speed while throttled", "% of max", Cfg.THR_GPU, Cfg.D_THR_GPU, 30, 90);
        slider(c, "CPU speed while throttled", "% of max", Cfg.THR_PCT, Cfg.D_THR_PCT, 30, 90);
        toggle(c, "Dim the screen while throttled", "Also caps the brightness (switches to manual brightness while hot, never raises it) and puts your brightness and auto mode back when cooled. Off by default: it can make the screen hard to read in sun", Cfg.THR_DIM, Cfg.D_THR_DIM);
        slider(c, "Brightness while throttled", "% of max", Cfg.THR_DIM_PCT, Cfg.D_THR_DIM_PCT, 20, 90);
        toggle(c, "Heat warning popup", "A Device Too Hot popup (like the Critical Battery one) when the battery or CPU passes the limits below. Comes back after 10 minutes if still hot, closes itself when cooled. Restart SystemUI to apply", Cfg.HEAT, Cfg.D_HEAT);
        slider(c, "Warn when battery reaches", "\u00B0C", Cfg.HEAT_BAT, Cfg.D_HEAT_BAT, 38, 50);
        slider(c, "Warn when CPU reaches", "\u00B0C", Cfg.HEAT_CPU, Cfg.D_HEAT_CPU, 60, 100);
        slider(c, "Freeze sky at or below battery % (0 = never)", "%", Cfg.SKY_LOW, Cfg.D_SKY_LOW, 0, 50);
        skyChoice(c);
        slider(c, "Sky opacity", "%", Cfg.SKY_OPACITY, Cfg.D_SKY_OPACITY, 30, 100);
        toggle(c, "Fade the sky into the wallpaper", "The lower part of the sky thins out so the status bar blends into "
                + "the wallpaper or app below instead of ending in a hard edge", Cfg.SKY_FADE, Cfg.D_SKY_FADE);
        toggle(c, "Stats column beside the speed", "Three small rows instead of the graph: CPU load and GPS satellites, ping and deep-sleep share, and the kernel wakelock held longest (root, refreshed every 5 min)", Cfg.STATS_COL, Cfg.D_STATS_COL);
        toggle(c, "Hide battery % in quick settings", "The percentage in the pulled-down shade header; the status bar is unchanged. Restart SystemUI to apply", Cfg.QS_BATT_HIDE, Cfg.D_QS_BATT_HIDE);

        section("Operator name");
        c = card();
        c.addView(text("Shown everywhere on this phone (status bar, lock screen, settings, dialer, apps). "
                + "Network, calls and operator codes stay real. Needs \"Phone Services\" "
                + "(com.android.phone) ticked in the Vector scope. Applies after airplane mode on/off.", 13, sub));
        toggle(c, "Smart carrier name", "Lock screen, quick settings, shade and Settings: the network's own fuller name "
                + "at home (e.g. \"Jio True5G\" instead of \"Jio\"), and your SIM's name plus the network's in another state "
                + "(\"Airtel(IND airtel)\", \"BSNL(Dolphin)\"). A name typed below wins. Needs \"Phone Services\" in "
                + "NetSpeed's LSPosed scope; reboot or toggle airplane mode to refresh", Cfg.SMART_CARRIER, Cfg.D_SMART_CARRIER);
        textField(c, "SIM 1 name", "Empty = real name", Cfg.OP_NAME1, "e.g. Jio", false);
        textField(c, "SIM 2 name", "Empty = real name", Cfg.OP_NAME2, "e.g. Vi", false);

        if (!pro) {
            section("Layout mode ⟳");
            c = card();
            toggle(c, "Two-row status bar", "Off = original one-row layout", Cfg.DUAL, Cfg.D_DUAL);
            toggle(c, "Net speed after weather", "Off = on the right, before the icons",
                    Cfg.SPEED_LEFT, Cfg.D_SPEED_LEFT);
        }

        section("Launcher");
        c = card();
        predictToggle(c);

        section("Volume steps");
        c = card();
        c.addView(text(SettingsVolume.summary(this) + ". Needs the Volume Steps Magisk module; "
                + "applies after a reboot.", 13, sub));
        button(c, "Change volume steps", false, v -> SettingsVolume.show(this));

        updatesSection();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(20);
        list.addView(row, rlp);
        button(row, "Restart System UI", true, v -> restartSystemUi());
        button(row, "Reset", false, v -> new AlertDialog.Builder(this)
                .setMessage("Reset all settings to defaults?")
                .setPositiveButton("Reset", (d, w) -> {
                    sp.edit().clear().commit();
                    changed();
                    build();
                })
                .setNegativeButton("Cancel", null)
                .show());
    }

    // ------------------------------------------------------------ updates

    private TextView updStatus;
    private Button updButton;
    private AppUpdater.Info latest;

    private long installedBuild() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).getLongVersionCode();
        } catch (Exception e) {
            return 0;
        }
    }

    private void updatesSection() {
        section("Updates");
        LinearLayout c = card();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text("Installed build " + installedBuild(), 16, fg));
        updStatus = text("Checking…", 13, sub);
        box.addView(updStatus);
        updButton = new Button(this);
        updButton.setAllCaps(false);
        updButton.setTextColor(isDark() ? 0xFF2A1F66 : Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        g.setColor(accent);
        updButton.setBackground(g);
        updButton.setVisibility(View.GONE);
        updButton.setOnClickListener(v -> doUpdate());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        box.addView(updButton, lp);
        c.addView(box);
        c.setOnClickListener(v -> checkUpdate());
        checkUpdate();
    }

    private void checkUpdate() {
        updStatus.setText("Checking…");
        new Thread(() -> {
            try {
                AppUpdater.Info info = AppUpdater.check();
                runOnUiThread(() -> showUpdate(info));
            } catch (Exception e) {
                runOnUiThread(() -> updStatus.setText("Couldn't check: " + e.getMessage() + ". Tap to retry."));
            }
        }).start();
    }

    private void showUpdate(AppUpdater.Info info) {
        latest = info;
        long have = installedBuild();
        if (info.build > have) {
            String notes = info.notes.isEmpty() ? "" : "\n\n" + info.notes;   // the whole change list, not just its first line
            updStatus.setText("Build " + info.build + " is available." + notes);
            updButton.setText("Update to build " + info.build);
            updButton.setVisibility(View.VISIBLE);
        } else {
            updStatus.setText("Up to date. Tap to check again.");
            updButton.setVisibility(View.GONE);
        }
    }

    private void doUpdate() {
        updButton.setEnabled(false);
        updStatus.setText("Downloading…");
        new Thread(() -> {
            String msg;
            try {
                java.io.File apk = AppUpdater.download(getCacheDir());
                runOnUiThread(() -> updStatus.setText("Installing… the status bar restarts in a few seconds."));
                boolean ok = AppUpdater.installAndRestart(apk);
                msg = ok ? null : "Root wasn't granted. Allow root for this app in ReSukiSU and try again.";
            } catch (Exception e) {
                msg = "Update failed: " + e.getMessage();
            }
            final String m = msg;
            if (m != null) runOnUiThread(() -> {
                updStatus.setText(m);
                updButton.setEnabled(true);
            });
        }).start();
    }

    // ------------------------------------------------------------ widgets

    private void title(String t) {
        TextView v = text(t, 26, fg);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(8), 0, dp(4));
        list.addView(v);
    }

    private void note(String t) {
        TextView v = text(t, 13, sub);
        v.setPadding(dp(4), 0, dp(4), dp(8));
        list.addView(v);
    }

    /** One setting found by the search: its title, the words under it, and the row to jump to. */
    private static final class Hit {
        String title, desc;
        View row;
    }

    /** Every setting title (16 sp text) in the page, with the description beside it. */
    private java.util.List<Hit> collect() {
        java.util.List<Hit> out = new java.util.ArrayList<>();
        walk(list, out);
        return out;
    }

    private void walk(View v, java.util.List<Hit> out) {
        if (v instanceof TextView && !(v instanceof android.widget.Button) && !(v instanceof android.widget.EditText)) {
            TextView t = (TextView) v;
            float sz = t.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
            if (Math.abs(sz - 16) < 0.6f && t.getText().length() > 0 && t.getVisibility() == View.VISIBLE) {
                Hit h = new Hit();
                h.title = t.getText().toString();
                StringBuilder d = new StringBuilder();
                if (t.getParent() instanceof ViewGroup) {
                    ViewGroup g = (ViewGroup) t.getParent();
                    for (int i = 0; i < g.getChildCount(); i++) {
                        View o = g.getChildAt(i);
                        if (o != t && o instanceof TextView) d.append(((TextView) o).getText()).append(' ');
                    }
                    View row = g;
                    // the clickable row is the title's parent, or its grandparent (title + description in a column)
                    if (!g.isClickable() && g.getParent() instanceof View && ((View) g.getParent()).isClickable()) row = (View) g.getParent();
                    h.row = row;
                } else h.row = t;
                h.desc = d.toString().trim();
                out.add(h);
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), out);
        }
    }

    private void searchDialog(ScrollView scroll) {
        java.util.List<Hit> all = collect();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        android.widget.EditText q = new android.widget.EditText(this);
        q.setHint("Search settings (e.g. tide, ping, sky)");
        q.setSingleLine(true);
        box.addView(q);
        LinearLayout res = new LinearLayout(this);
        res.setOrientation(LinearLayout.VERTICAL);
        ScrollView rs = new ScrollView(this);
        rs.addView(res);
        box.addView(rs, new LinearLayout.LayoutParams(-1, dp(360)));
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Search").setView(box)
                .setNegativeButton("Close", null).create();
        Runnable fill = () -> {
            res.removeAllViews();
            String[] words = q.getText().toString().toLowerCase(java.util.Locale.ROOT).trim().split("\\s+");
            int n = 0;
            for (Hit h : all) {
                String hay = (h.title + " " + h.desc).toLowerCase(java.util.Locale.ROOT);
                boolean ok = true;
                for (String w : words) if (!w.isEmpty() && !hay.contains(w)) { ok = false; break; }
                if (!ok) continue;
                LinearLayout it = new LinearLayout(this);
                it.setOrientation(LinearLayout.VERTICAL);
                it.setPadding(0, dp(10), 0, dp(10));
                it.addView(text(h.title, 16, fg));
                if (!h.desc.isEmpty()) {
                    TextView dv = text(h.desc, 13, sub);
                    dv.setMaxLines(2);
                    dv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    it.addView(dv);
                }
                it.setOnClickListener(x -> {
                    dlg.dismiss();
                    jumpTo(scroll, h.row);
                });
                res.addView(it);
                if (++n >= 60) break;
            }
            if (n == 0) res.addView(text("Nothing found", 14, sub));
        };
        q.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence a, int b, int c, int d) { }
            public void onTextChanged(CharSequence a, int b, int c, int d) { }
            public void afterTextChanged(android.text.Editable e) { fill.run(); }
        });
        fill.run();
        dlg.show();
        q.requestFocus();
        dlg.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    /** Scroll the page to a row and flash it. */
    private void jumpTo(ScrollView scroll, View row) {
        int y = 0;
        for (View v = row; v != null && v != list; v = v.getParent() instanceof View ? (View) v.getParent() : null) y += v.getTop();
        scroll.smoothScrollTo(0, Math.max(0, y - dp(80)));
        android.graphics.drawable.Drawable old = row.getBackground();
        row.setBackgroundColor((accent & 0x00FFFFFF) | 0x40000000);
        row.postDelayed(() -> row.setBackground(old), 1600);
    }

    private void section(String t) {
        TextView v = text(t, 13, accent);
        v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setPadding(dp(4), dp(18), 0, dp(8));
        list.addView(v);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(card);
        g.setCornerRadius(dp(20));
        c.setBackground(g);
        c.setPadding(dp(16), dp(6), dp(16), dp(6));
        list.addView(c);
        return c;
    }

    /** "mag" sliders store tenths: 25 shows as "M2.5+". */
    private static String sliderText(int v, String unit) {
        if ("mag".equals(unit)) return String.format(java.util.Locale.US, "M%.1f+", v / 10f);
        if ("km100".equals(unit)) return v >= 200 ? "anywhere" : String.format(java.util.Locale.US, "%,d km of you", v * 100);
        return v + " " + unit;
    }

    private void slider(LinearLayout parent, String label, String unit, String key, int def, int min, int max) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(10), 0, dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text(label, 16, fg);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text("", 15, accent);
        top.addView(val);
        box.addView(top);

        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        int cur = sp.getInt(key, def);
        s.setProgress(cur);
        val.setText(sliderText(cur, unit) + (cur == def ? "  (default)" : ""));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int v, boolean user) {
                val.setText(sliderText(v, unit) + (v == def ? "  (default)" : ""));
            }

            @Override public void onStartTrackingTouch(SeekBar bar) { }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                sp.edit().putInt(key, bar.getProgress()).commit();
                changed();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        box.addView(s, lp);
        parent.addView(box);
    }

    private void textField(LinearLayout parent, String label, String desc, String key) {
        textField(parent, label, desc, key, "pk.…", true);
    }

    private void textField(LinearLayout parent, String label, String desc, String key, String hint, boolean token) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        box.addView(text(label, 16, fg));
        if (desc != null) box.addView(text(desc, 13, sub));
        android.widget.EditText et = new android.widget.EditText(this);
        et.setSingleLine(true);
        et.setTextColor(fg);
        et.setHintTextColor(sub);
        et.setHint(hint);
        et.setInputType(token ? android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                : android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        et.setText(sp.getString(key, ""));
        et.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(android.text.Editable e) {
                sp.edit().putString(key, e.toString().trim()).commit();
                changed();
            }
        });
        box.addView(et, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(box);
    }

    /** Round floating button for jumping to the top / bottom of the list. */
    private View jumpButton(String t, Runnable r) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextSize(20);
        b.setTextColor(0xFFFFFFFF);
        b.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        bg.setColor((accent & 0x00FFFFFF) | 0xE0000000);
        b.setBackground(bg);
        b.setElevation(dp(4));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(0, dp(6), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void choice(LinearLayout parent, String label, String key, int def, String[] opts) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        r.addView(text(label, 16, fg));
        int cur = Math.max(0, Math.min(opts.length - 1, sp.getInt(key, def)));
        TextView v = text(opts[cur], 13, sub);
        r.addView(v);
        r.setOnClickListener(x -> new AlertDialog.Builder(this).setTitle(label)
                .setSingleChoiceItems(opts, Math.max(0, Math.min(opts.length - 1, sp.getInt(key, def))), (d, w) -> {
                    sp.edit().putInt(key, w).commit();
                    v.setText(opts[w]);
                    changed();
                    d.dismiss();
                }).show());
        parent.addView(r);
    }

    /** One choice for the animated background instead of two switches. */
    private void skyChoice(LinearLayout parent) {
        final String[] opts = {"Off — plain status bar",
                "Weather — sky follows the weather (sun, moon, clouds, rain…)",
                "Weather + stars — same, but clear nights show stars, planets and satellites"};
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        r.addView(text("Status bar background", 16, fg));
        TextView v = text("", 13, sub);
        Runnable show = () -> {
            boolean on = sp.getBoolean(Cfg.SKY, Cfg.D_SKY), st = sp.getBoolean(Cfg.NIGHT, Cfg.D_NIGHT);
            v.setText(!on ? opts[0] : st ? opts[2] : opts[1]);
        };
        show.run();
        r.addView(v);
        r.setOnClickListener(x -> {
            boolean on = sp.getBoolean(Cfg.SKY, Cfg.D_SKY), st = sp.getBoolean(Cfg.NIGHT, Cfg.D_NIGHT);
            int cur = !on ? 0 : st ? 2 : 1;
            new AlertDialog.Builder(this).setTitle("Status bar background")
                    .setSingleChoiceItems(opts, cur, (d, w) -> {
                        sp.edit().putBoolean(Cfg.SKY, w > 0).putBoolean(Cfg.NIGHT, w == 2).commit();
                        show.run();
                        changed();
                        d.dismiss();
                    }).show();
        });
        parent.addView(r);
    }

    private void toggle(LinearLayout parent, String label, String desc, String key, boolean def) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            sp.edit().putBoolean(key, on).commit();
            changed();
            if (Cfg.PRO.equals(key)) list.post(this::build);
        });
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /** Apps that asked for Play Integrity, newest first (recorded by IntegrityReceiver). */
    private void showIntegrity() {
        String r = IntegrityReceiver.history(this);
        if (r.isEmpty()) r = "No checks seen yet.\n\nTick Google Play Store in LSPosed for this module, then force-stop "
                + "Play Store (or reboot). Each check an app makes shows up here.";
        TextView tv = new TextView(this);
        tv.setText(r);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(18), dp(12), dp(18), dp(4));
        tv.setHorizontallyScrolling(true);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(tv);
        sv.addView(hs);
        new AlertDialog.Builder(this)
                .setTitle("Play Integrity checks")
                .setView(sv)
                .setPositiveButton("Refresh", (d, w) -> showIntegrity())
                .setNeutralButton("Clear", (d, w) -> IntegrityReceiver.clear(this))
                .setNegativeButton("Close", null)
                .show();
    }

    /** The status bar's live satellite list (published by System UI every 30 s). */
    private void showSatellites() {
        String r = null;
        try { r = android.provider.Settings.Global.getString(getContentResolver(), "netspeed_sat_report"); } catch (Throwable ignored) { }
        if (r == null || r.isEmpty()) r = "No list from the status bar yet.\n\nIt is published every 30 s once the module is "
                + "running in System UI (restart System UI after an update) and the screen is on.";
        TextView tv = new TextView(this);
        tv.setText(r);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(18), dp(12), dp(18), dp(4));
        tv.setHorizontallyScrolling(true);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(tv);
        sv.addView(hs);
        new AlertDialog.Builder(this)
                .setTitle("Sky, towers & satellites now")
                .setView(sv)
                .setPositiveButton("Refresh", (d, w) -> showSatellites())
                .setNegativeButton("Close", null)
                .show();
    }

    private void button(LinearLayout parent, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? (isDark() ? 0xFF2A1F66 : Color.WHITE) : accent);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(24));
        if (primary) g.setColor(accent);
        else {
            g.setColor(Color.TRANSPARENT);
            g.setStroke(dp(1), accent);
        }
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp;
        if (parent.getOrientation() == LinearLayout.VERTICAL) {
            lp = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
            lp.setMargins(0, dp(8), 0, dp(8));
        } else {
            lp = new LinearLayout.LayoutParams(0, dp(48), primary ? 2f : 1f);
            lp.setMarginEnd(primary ? dp(10) : 0);
        }
        parent.addView(b, lp);
    }

    private TextView text(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        return v;
    }

    // ------------------------------------------------------------ actions

    /** Tells System UI to reload settings. */
    private void changed() {
        getContentResolver().notifyChange(URI, null);
    }

    /** A switch backed by a system property (set with root), for settings the system server reads. */
    private void propToggle(LinearLayout parent, String label, String desc, String prop) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(label, 16, fg));
        if (desc != null) texts.addView(text(desc, 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(Cfg.NAV_IMMERSIVE, Cfg.D_NAV_IMMERSIVE)
                || "1".equals(getProp(prop)) || "true".equals(getProp(prop)));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            // Saved for System UI (applies on Restart System UI), and as a property for the
            // system server (applies after a reboot).
            sp.edit().putBoolean(Cfg.NAV_IMMERSIVE, on).commit();
            changed();
            String val = on ? "1" : "0";
            boolean ok = runSu("setprop " + prop + " " + val)
                    || runSu("resetprop -p " + prop + " " + val)
                    || runSu("/data/adb/ksu/bin/resetprop -p " + prop + " " + val);
            boolean took = val.equals(getProp(prop));
            runOnUiThread(() -> {
                new AlertDialog.Builder(this)
                        .setMessage((on ? "Immersive navigation on." : "Immersive navigation off.")
                                + " Restart System UI + launcher to apply.")
                        .setPositiveButton("Restart System UI + launcher", (d, w) -> {
                            new Thread(() -> runSu("am force-stop $(cmd package resolve-activity --brief "
                                    + "-a android.intent.action.MAIN -c android.intent.category.HOME | tail -n 1 "
                                    + "| cut -d/ -f1)")).start();
                            restartSystemUi();
                        })
                        .setNegativeButton("Later", null)
                        .show();
            });
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /**
     * Edge-to-edge for every app. Android forces it on apps whose target SDK is at least
     * persist.wm.debug.default_e2e_since_sdk (read once at boot); 0 = every app. Apps draw behind the
     * status bar and around the camera and pad their content by the bar's height.
     */
    private static final String E2E_PROP = "persist.wm.debug.default_e2e_since_sdk";

    private void e2eToggle(LinearLayout parent) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text("Apps draw to the screen edges", 16, fg));
        texts.addView(text("Every app draws behind the status bar and around the camera, like apps made for "
                + "Android 15+. If one app's top bar ends up under the status bar, turn this off. Needs a reboot", 13, sub));
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked("0".equals(getProp(E2E_PROP)));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            String val = on ? "0" : "2147483647";
            boolean ok = runSu("setprop " + E2E_PROP + " " + val)
                    || runSu("resetprop -p " + E2E_PROP + " " + val)
                    || runSu("/data/adb/ksu/bin/resetprop -p " + E2E_PROP + " " + val);
            boolean took = val.equals(getProp(E2E_PROP));
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setMessage(took ? (on ? "Edge-to-edge for all apps is on." : "Edge-to-edge for all apps is off.")
                            + " Reboot to apply." : "Couldn't set it (root denied?).")
                    .setPositiveButton(took ? "Reboot now" : "OK", (d, w) -> {
                        if (took) new Thread(() -> runSu("svc power reboot || reboot")).start();
                    })
                    .setNegativeButton("Later", null)
                    .show());
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    /** App suggestions (launcher dock + app drawer). Needs a reboot: the system reads it at boot. */
    private void predictToggle(LinearLayout parent) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(12), 0, dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text("App suggestions ⟳ reboot", 16, fg));
        texts.addView(text("Pixel-style suggested apps in empty dock slots and at the top of the app "
                + "drawer, from your own usage history (stays on this phone). Tick System Framework "
                + "in the scope", 13, sub));
        TextView st = text(predictStatus(), 12, sub);
        texts.addView(st);
        r.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        String prop = Predict.PROP;
        sw.setChecked(sp.getBoolean(Cfg.PREDICT, Cfg.D_PREDICT));
        sw.setOnCheckedChangeListener((v, on) -> new Thread(() -> {
            sp.edit().putBoolean(Cfg.PREDICT, on).commit();
            String val = on ? "1" : "0";
            runSu("setprop " + prop + " " + val);
            String f = Predict.FLAG;
            boolean ok = on
                    ? runSu("echo 1 > " + f + " && chmod 644 " + f + " && chown system:system " + f
                            + " && (chcon u:object_r:system_data_file:s0 " + f + " || true)")
                    : runSu("rm -f " + f + " && setprop " + prop + " 0; true");
            // Usage history access, so suggestions follow what you actually use.
            if (on) runSu("appops set " + getPackageName() + " GET_USAGE_STATS allow");
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setMessage((on ? "App suggestions on." : "App suggestions off.")
                            + (ok ? " Reboot to apply." : "\n\nCouldn't save the setting with root. "
                            + "Allow root for this app in ReSukiSU and try again."))
                    .setPositiveButton("Reboot now", (d, w) -> new Thread(() -> runSu("svc power reboot || reboot")).start())
                    .setNegativeButton("Later", null)
                    .show());
        }).start());
        r.addView(sw);
        r.setOnClickListener(v -> sw.toggle());
        parent.addView(r);
    }

    private String predictStatus() {
        try {
            java.util.Map<String, ?> m = createDeviceProtectedStorageContext()
                    .getSharedPreferences(PredictionService.STATUS_PREFS, 0).getAll();
            if (m.isEmpty()) return "Status: the system hasn't started the suggestions service yet";
            StringBuilder b = new StringBuilder("Status (now "
                    + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date()) + "):");
            for (String k : new String[]{"service", "destroyed", "alive", "tick_error", "request", "event",
                    "session_hotseat", "session_home", "usage",
                    "last_hotseat", "last_home", "rootlist", "debug", "error"}) {
                Object v = m.get(k);
                if (v != null) b.append("\n• ").append(k.replace('_', ' ')).append(": ").append(v);
            }
            return b.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    private static String getProp(String key) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            return (String) sp.getMethod("get", String.class).invoke(null, key);
        } catch (Throwable t) {
            return "";
        }
    }

    /** Wait 8 s (go to the app where the pill is too high), then save the window / inset state. */
    private void savePillDump() {
        Toast.makeText(this, "Open the app where the pill is too high - saving in 8 s", Toast.LENGTH_LONG).show();
        new Thread(() -> {
            try { Thread.sleep(8000); } catch (InterruptedException ignored) { }
            boolean ok = runSu("f=/sdcard/Download/netspeed_pill_dump_$(date +%H%M%S).txt; { date; "
                    + "echo '== focus'; dumpsys window | grep -E 'mCurrentFocus|mFocusedApp|imeControlTarget'; "
                    + "echo '== taskbar window'; dumpsys window windows | grep -i -A22 'Window{.* Taskbar}'; "
                    + "echo '== navigation insets'; dumpsys window displays | grep -i -E 'type=(navigationBars|mandatorySystemGestures|tappableElement|ime) '; "
                    + "echo '== launcher taskbar state'; dumpsys activity service com.android.launcher3/com.android.quickstep.TouchInteractionService 2>&1 "
                    + "| grep -i -E 'taskbar|stash|handle|margin|translation|inset|isInApp|transient|ime' | head -n 250; "
                    + "echo '== module log'; for x in $(ls -t /data/adb/lspd/log/modules_* /data/adb/lspd/log/verbose_* 2>/dev/null | head -n 2); do echo $x; grep -F '[nav]' $x | tail -n 60; done; "
                    + "logcat -d 2>/dev/null | grep -F '[nav]' | tail -n 40; "
                    + "} > $f 2>&1; chmod 666 $f");
            runOnUiThread(() -> Toast.makeText(this, ok ? "Saved: Download/netspeed_pill_dump_*.txt - send it to me"
                    : "Couldn't save (is root granted?)", Toast.LENGTH_LONG).show());
        }).start();
    }

    private static boolean runSu(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void restartSystemUi() {
        new Thread(() -> {
            String err = null;
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "killall com.android.systemui"});
                if (p.waitFor() != 0) err = "Root command failed (exit " + p.exitValue() + ")";
            } catch (Exception e) {
                err = "Root not available: " + e.getMessage();
            }
            final String msg = err;
            runOnUiThread(() -> {
                if (msg != null) Toast.makeText(this, msg + ". Grant root to this app in ReSukiSU, or reboot.",
                        Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private boolean isDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
