package com.netspeed.xposed;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.LauncherApps;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;

import de.robv.android.xposed.XposedBridge;

/**
 * System UI side of "double tap on the back": while the screen is on (lock screen included) it
 * listens to the motion sensors, and a confirmed double tap opens the chosen scan shortcut.
 * Settings come from {@link Cfg}; the screen is configured in {@link BackTapActivity}.
 */
final class BackTap implements BackTapDetector.Listener {
    private static final String TAG = "NetSpeedXposed: [backtap] ";
    private static BackTap sInst;

    static synchronized void start(Context ctx, ClassLoader systemUiLoader) {
        if (sInst != null) return;
        try {
            Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
            sInst = new BackTap(app, systemUiLoader);
            sInst.begin();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "start failed: " + t);
        }
    }

    private final Context app;
    private final ClassLoader loader;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BackTapRunner runner;
    private final PowerManager pm;
    private boolean logged;
    private int lastTestReq;
    private long lastListenReport;
    private double tokens = 6;
    private long tokenT = android.os.SystemClock.elapsedRealtime();

    private BackTap(Context app, ClassLoader loader) {
        this.app = app;
        this.loader = loader;
        this.pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
        this.lastTestReq = Cfg.i(Cfg.BT_TESTREQ, 0);
        this.runner = new BackTapRunner(app);
        runner.det.listener = this;
    }

    private void begin() {
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        app.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                main.post(BackTap.this::sync);
            }
        }, f);
        main.post(tick);
        XposedBridge.log(TAG + "ready");
        report("status", "System UI service started");
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            sync();
            int req = Cfg.i(Cfg.BT_TESTREQ, 0);
            if (req != lastTestReq) { // the settings screen asked for a test launch
                lastTestReq = req;
                fire(true);
            }
            main.postDelayed(this, 2000);
        }
    };

    /** Listens only while the feature is on, the screen is on and the settings screen isn't testing. */
    private void sync() {
        try {
            boolean testing = Cfg.i(Cfg.BT_TEST_UNTIL, 0) > System.currentTimeMillis() / 1000;
            boolean want = Cfg.b(Cfg.BT_ON, Cfg.D_BT_ON) && pm.isInteractive() && !testing;
            if (want) {
                runner.det.verbose = Cfg.b(Cfg.BT_DEBUG, Cfg.D_BT_DEBUG);
                int sens = Cfg.i(Cfg.BT_SENS, Cfg.D_BT_SENS);
                runner.det.configure(BackTapDetector.thrForSens(sens), Cfg.i(Cfg.BT_SIGN, Cfg.D_BT_SIGN),
                        Cfg.b(Cfg.BT_FLAT, Cfg.D_BT_FLAT));
                if (!runner.isRunning()) {
                    boolean ok = runner.start();
                    if (!logged) {
                        logged = true;
                        XposedBridge.log(TAG + (ok ? "listening (" + runner.sensorInfo() + ")" : "no accelerometer"));
                    }
                    long now = android.os.SystemClock.elapsedRealtime();
                    if (!ok || now - lastListenReport > 600_000) {
                        lastListenReport = now;
                        report("listen", ok ? "listening (" + runner.sensorInfo() + ")" : "NO ACCELEROMETER");
                    }
                }
            } else if (runner.isRunning()) {
                runner.stop();
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "sync failed: " + t);
        }
    }

    // ---- detector callbacks (sensor thread)

    @Override
    public void onDoubleTap() {
        main.post(this::fire);
    }

    /** What the detector decided about each knock, for the settings screen (at most ~1 line per 1.2 s). */
    @Override
    public void onLog(String line) {
        long now = android.os.SystemClock.elapsedRealtime();
        tokens = Math.min(20, tokens + (now - tokenT) / 300.0);
        tokenT = now;
        if (tokens < 1) return;
        tokens -= 1;
        report("status", line);
    }

    @Override public void onKnock(float peak, int sign) { }

    // ---- launching

    private void fire() {
        fire(false);
    }

    private void fire(boolean test) {
        try {
            if (!test && !Cfg.b(Cfg.BT_ON, Cfg.D_BT_ON)) return;
            String pkg = Cfg.s(Cfg.BT_PKG);
            String scid = Cfg.s(Cfg.BT_SCID);
            report("status", (test ? "test launch" : "double tap detected")
                    + (pkg.isEmpty() ? " - but nothing chosen" : ""));
            if (pkg.isEmpty()) return;
            if (!test && Cfg.b(Cfg.BT_HAPTIC, Cfg.D_BT_HAPTIC)) buzz();

            if (Cfg.b(Cfg.BT_OWN, Cfg.D_BT_OWN)) { // NetSpeed's own scanner; it shows over the lock screen
                Intent so = new Intent().setComponent(new ComponentName("com.netspeed.xposed",
                        "com.netspeed.xposed.ScanActivity"));
                so.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                app.startActivity(so);
                report("status", "own scanner opened (pays with " + pkg + ")");
                return;
            }

            KeyguardManager km = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
            boolean locked = km != null && km.isKeyguardLocked();

            if (!scid.isEmpty()) { // a shortcut from the home screen
                Runnable go = () -> {
                    try {
                        LauncherApps la = (LauncherApps) app.getSystemService(Context.LAUNCHER_APPS_SERVICE);
                        la.startShortcut(pkg, scid, null, null, Process.myUserHandle());
                        report("status", "home-screen shortcut started: " + Cfg.s(Cfg.BT_LABEL));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "startShortcut failed: " + t);
                        report("status", "shortcut start failed (" + t.getClass().getSimpleName() + ": "
                                + t.getMessage() + ")" + (Cfg.s(Cfg.BT_URI).isEmpty() ? "" : " - trying with root"));
                        askAppForRoot();
                    }
                };
                if (locked && dismissKeyguardThen(go)) {
                    report("status", "locked: asked for unlock, then start the shortcut");
                } else {
                    go.run();
                }
                return;
            }

            Intent in = null;
            String uri = Cfg.s(Cfg.BT_URI);
            if (!uri.isEmpty()) {
                try {
                    in = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "bad intent: " + t);
                }
            }
            if (in == null) in = app.getPackageManager().getLaunchIntentForPackage(pkg);
            if (in == null) return;
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

            if (!Cfg.b(Cfg.BT_ROOT, Cfg.D_BT_ROOT)) {
                try {
                    // On the lock screen ask for the unlock first (fingerprint / PIN), then open the app.
                    if (locked && viaActivityStarter(in)) {
                        report("status", "locked: asked for unlock, then start " + pkg);
                        return;
                    }
                    app.startActivity(in);
                    report("status", "normal start accepted: " + pkg);
                    return;
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "direct launch failed, asking the app to do it with root: " + t);
                    report("status", "normal start failed (" + t.getClass().getSimpleName() + ") - asking the app for a root start");
                }
            }
            askAppForRoot();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "launch failed: " + t);
            report("status", "launch failed: " + t);
        }
    }

    private void askAppForRoot() {
        if (Cfg.s(Cfg.BT_URI).isEmpty()) return;
        Intent b = new Intent(LaunchReceiver.ACTION);
        b.setComponent(new ComponentName("com.netspeed.xposed", "com.netspeed.xposed.LaunchReceiver"));
        b.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        app.sendBroadcast(b);
    }

    /** Shows the unlock prompt and runs r once the phone is unlocked. */
    private boolean dismissKeyguardThen(Runnable r) {
        try {
            Class<?> dep = Class.forName("com.android.systemui.Dependency", false, loader);
            Class<?> starterCls = Class.forName("com.android.systemui.plugins.ActivityStarter", false, loader);
            Object starter = dep.getMethod("get", Class.class).invoke(null, starterCls);
            if (starter == null) return false;
            for (java.lang.reflect.Method m : starterCls.getMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (m.getName().equals("executeRunnableDismissingKeyguard") && pt.length == 5
                        && pt[0] == Runnable.class) {
                    m.invoke(starter, r, null, false, false, false);
                    return true;
                }
            }
            for (java.lang.reflect.Method m : starterCls.getMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (m.getName().equals("postQSRunnableDismissingKeyguard") && pt.length >= 1
                        && pt[0] == Runnable.class) {
                    Object[] args = new Object[pt.length];
                    args[0] = r;
                    m.invoke(starter, args);
                    return true;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "keyguard runnable helper unavailable: " + t);
        }
        return false;
    }

    /** System UI's own "start this and dismiss the keyguard" helper (shows the unlock prompt first). */
    private boolean viaActivityStarter(Intent in) {
        try {
            Class<?> dep = Class.forName("com.android.systemui.Dependency", false, loader);
            Class<?> starterCls = Class.forName("com.android.systemui.plugins.ActivityStarter", false, loader);
            Object starter = dep.getMethod("get", Class.class).invoke(null, starterCls);
            if (starter == null) return false;
            try {
                starterCls.getMethod("postStartActivityDismissingKeyguard", Intent.class, int.class)
                        .invoke(starter, in, 0);
                return true;
            } catch (NoSuchMethodException e) {
                starterCls.getMethod("startActivity", Intent.class, boolean.class).invoke(starter, in, true);
                return true;
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "keyguard helper unavailable: " + t);
            return false;
        }
    }

    /** Tells the settings app what happened (shown in its "System UI status" box). Off the main thread. */
    private void report(String kind, String msg) {
        new Thread(() -> {
            try {
                app.getContentResolver().call(Cfg.URI, kind, msg, null);
            } catch (Throwable ignored) { }
        }).start();
    }

    private void buzz() {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK));
        } catch (Throwable ignored) { }
    }
}
