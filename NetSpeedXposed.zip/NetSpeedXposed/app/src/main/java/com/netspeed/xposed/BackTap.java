package com.netspeed.xposed;

import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.LauncherApps;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/**
 * System UI side of "double press the power button": the phone's own gesture (Settings > System >
 * Gestures > quick open camera) is caught right where System UI would open the camera, and the
 * chosen scanner is opened instead. Settings come from {@link Cfg}; the screen is configured in
 * {@link BackTapActivity}.
 */
final class BackTap {
    private static final String TAG = "NetSpeedXposed: [powerscan] ";
    private static BackTap sInst;

    static synchronized void start(Context ctx, ClassLoader systemUiLoader) {
        if (sInst != null) return;
        try {
            Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
            sInst = new BackTap(app, systemUiLoader);
            sInst.begin();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "start failed: " + t);
        }
    }

    private final Context app;
    private final ClassLoader loader;
    private final Handler main = new Handler(Looper.getMainLooper());
    private int lastTestReq;
    private long lastFire;

    private BackTap(Context app, ClassLoader loader) {
        this.app = app;
        this.loader = loader;
        this.lastTestReq = Cfg.i(Cfg.BT_TESTREQ, 0);
    }

    private void begin() {
        int n = 0;
        n += hook("com.android.systemui.camera.CameraGestureHelper", "launchCamera");
        n += hook("com.android.systemui.statusbar.phone.CentralSurfacesImpl", "onCameraLaunchGestureDetected");
        main.post(tick);
        XposedBridge.log(TAG + "ready, hooked " + n + " camera launch point(s)");
        report("status", "System UI service started, " + n + " camera launch point(s) hooked");
    }

    /** Replaces System UI's "open the camera" by our scanner while the feature is on. */
    private int hook(String cls, String method) {
        try {
            Class<?> c = Class.forName(cls, false, loader);
            XposedBridge.hookAllMethods(c, method, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (!Cfg.b(Cfg.BT_ON, Cfg.D_BT_ON)) return;
                        if (Cfg.s(Cfg.BT_PKG).isEmpty()) return; // nothing chosen yet: leave the camera alone
                        Class<?> rt = ((java.lang.reflect.Method) p.method).getReturnType();
                        p.setResult(rt == boolean.class ? Boolean.TRUE : null);
                        main.post(() -> fire(false));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "hook failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "hooked " + cls + "#" + method);
            return 1;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "cannot hook " + cls + "#" + method + ": " + t);
            return 0;
        }
    }

    /** Watches for "Test launch" requests from the settings screen. */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                int req = Cfg.i(Cfg.BT_TESTREQ, 0);
                if (req != lastTestReq) {
                    lastTestReq = req;
                    fire(true);
                }
            } catch (Throwable ignored) { }
            main.postDelayed(this, 2000);
        }
    };

    // ---- launching

    private void fire(boolean test) {
        try {
            long now = android.os.SystemClock.elapsedRealtime();
            if (!test && now - lastFire < 1500) return; // both launch points can fire for one press
            lastFire = now;
            if (!test && !Cfg.b(Cfg.BT_ON, Cfg.D_BT_ON)) return;
            String pkg = Cfg.s(Cfg.BT_PKG);
            String scid = Cfg.s(Cfg.BT_SCID);
            report("status", (test ? "test launch" : "double press of the power button")
                    + (pkg.isEmpty() ? " - but nothing chosen" : ""));
            if (pkg.isEmpty()) return;
            if (!test && Cfg.b(Cfg.BT_HAPTIC, Cfg.D_BT_HAPTIC)) buzz();

            if (Cfg.b(Cfg.BT_OWN, Cfg.D_BT_OWN)) { // NetSpeed's own scanner; it shows over the lock screen
                Intent so = new Intent().setComponent(new ComponentName("com.netspeed.xposed",
                        "com.netspeed.xposed.ScanActivity"));
                so.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                app.startActivity(so);
                report("status", "own scanner opened (pays with " + pkg + ")");
                return;
            }

            KeyguardManager km = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
            boolean locked = km != null && km.isKeyguardLocked();

            if (!scid.isEmpty()) { // a shortcut from the home screen
                Runnable go = () -> {
                    try {
                        LauncherApps la = (LauncherApps) app.getSystemService(Context.LAUNCHER_APPS_SERVICE);
                        la.startShortcut(pkg, scid, null, null, Process.myUserHandle());
                        report("status", "home-screen shortcut started: " + Cfg.s(Cfg.BT_LABEL));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "startShortcut failed: " + t);
                        report("status", "shortcut start failed (" + t.getClass().getSimpleName() + ": "
                                + t.getMessage() + ")" + (Cfg.s(Cfg.BT_URI).isEmpty() ? "" : " - trying with root"));
                        askAppForRoot();
                    }
                };
                if (locked && dismissKeyguardThen(go)) {
                    report("status", "locked: asked for unlock, then start the shortcut");
                } else {
                    go.run();
                }
                return;
            }

            Intent in = null;
            String uri = Cfg.s(Cfg.BT_URI);
            if (!uri.isEmpty()) {
                try {
                    in = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "bad intent: " + t);
                }
            }
            if (in == null) in = app.getPackageManager().getLaunchIntentForPackage(pkg);
            if (in == null) return;
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

            if (!Cfg.b(Cfg.BT_ROOT, Cfg.D_BT_ROOT)) {
                try {
                    // On the lock screen ask for the unlock first (fingerprint / PIN), then open the app.
                    if (locked && viaActivityStarter(in)) {
                        report("status", "locked: asked for unlock, then start " + pkg);
                        return;
                    }
                    app.startActivity(in);
                    report("status", "normal start accepted: " + pkg);
                    return;
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "direct launch failed, asking the app to do it with root: " + t);
                    report("status", "normal start failed (" + t.getClass().getSimpleName() + ") - asking the app for a root start");
                }
            }
            askAppForRoot();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "launch failed: " + t);
            report("status", "launch failed: " + t);
        }
    }

    private void askAppForRoot() {
        if (Cfg.s(Cfg.BT_URI).isEmpty()) return;
        Intent b = new Intent(LaunchReceiver.ACTION);
        b.setComponent(new ComponentName("com.netspeed.xposed", "com.netspeed.xposed.LaunchReceiver"));
        b.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        app.sendBroadcast(b);
    }

    /** Shows the unlock prompt and runs r once the phone is unlocked. */
    private boolean dismissKeyguardThen(Runnable r) {
        try {
            Class<?> dep = Class.forName("com.android.systemui.Dependency", false, loader);
            Class<?> starterCls = Class.forName("com.android.systemui.plugins.ActivityStarter", false, loader);
            Object starter = dep.getMethod("get", Class.class).invoke(null, starterCls);
            if (starter == null) return false;
            for (java.lang.reflect.Method m : starterCls.getMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (m.getName().equals("executeRunnableDismissingKeyguard") && pt.length == 5
                        && pt[0] == Runnable.class) {
                    m.invoke(starter, r, null, false, false, false);
                    return true;
                }
            }
            for (java.lang.reflect.Method m : starterCls.getMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (m.getName().equals("postQSRunnableDismissingKeyguard") && pt.length >= 1
                        && pt[0] == Runnable.class) {
                    Object[] args = new Object[pt.length];
                    args[0] = r;
                    m.invoke(starter, args);
                    return true;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "keyguard runnable helper unavailable: " + t);
        }
        return false;
    }

    /** System UI's own "start this and dismiss the keyguard" helper (shows the unlock prompt first). */
    private boolean viaActivityStarter(Intent in) {
        try {
            Class<?> dep = Class.forName("com.android.systemui.Dependency", false, loader);
            Class<?> starterCls = Class.forName("com.android.systemui.plugins.ActivityStarter", false, loader);
            Object starter = dep.getMethod("get", Class.class).invoke(null, starterCls);
            if (starter == null) return false;
            try {
                starterCls.getMethod("postStartActivityDismissingKeyguard", Intent.class, int.class)
                        .invoke(starter, in, 0);
                return true;
            } catch (NoSuchMethodException e) {
                starterCls.getMethod("startActivity", Intent.class, boolean.class).invoke(starter, in, true);
                return true;
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "keyguard helper unavailable: " + t);
            return false;
        }
    }

    /** Tells the settings app what happened (shown in its "System UI status" box). Off the main thread. */
    private void report(String kind, String msg) {
        new Thread(() -> {
            try {
                app.getContentResolver().call(Cfg.URI, kind, msg, null);
            } catch (Throwable ignored) { }
        }).start();
    }

    private void buzz() {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK));
        } catch (Throwable ignored) { }
    }
}
