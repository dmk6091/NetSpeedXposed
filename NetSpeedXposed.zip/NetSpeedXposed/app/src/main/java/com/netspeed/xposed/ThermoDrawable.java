package com.netspeed.xposed;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Small thermometer: outlined tube in the text colour, bulb + mercury in the heat colour. */
final class ThermoDrawable extends Drawable {
    private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint heat = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final int w, h;
    private final float level;   // 0..1 how full the tube is

    ThermoDrawable(int lineColor, int heatColor, float level, int widthPx, int heightPx) {
        outline.setStyle(Paint.Style.STROKE);
        outline.setColor(lineColor);
        heat.setColor(heatColor);
        heat.setStrokeCap(Paint.Cap.ROUND);
        this.level = Math.max(0.15f, Math.min(1f, level));
        w = widthPx;
        h = heightPx;
        setBounds(0, 0, w, h);
    }

    @Override
    public void draw(Canvas c) {
        float l = getBounds().left, t = getBounds().top, bw = getBounds().width(), bh = getBounds().height();
        float cx = l + bw / 2f;
        float bulbR = bw * 0.36f, bulbY = t + bh - bulbR - 0.5f;
        float tubeW = bw * 0.34f, tubeTop = t + 0.5f;
        outline.setStrokeWidth(Math.max(1f, bw * 0.12f));
        r.set(cx - tubeW / 2f, tubeTop, cx + tubeW / 2f, bulbY);
        c.drawRoundRect(r, tubeW / 2f, tubeW / 2f, outline);
        c.drawCircle(cx, bulbY, bulbR, heat);
        heat.setStrokeWidth(tubeW * 0.55f);
        float fillTop = bulbY - (bulbY - tubeTop - tubeW * 0.3f) * level;
        c.drawLine(cx, bulbY, cx, fillTop, heat);
    }

    @Override public int getIntrinsicWidth() { return w; }
    @Override public int getIntrinsicHeight() { return h; }
    @Override public void setAlpha(int a) { outline.setAlpha(a); heat.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { outline.setColorFilter(cf); heat.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
