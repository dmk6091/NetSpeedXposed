package com.netspeed.xposed;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Settings app: puts every NetSpeed switch and slider on the "Status bar icons" page, as the ROM's
 * own preference rows. Values are read from and written to the NetSpeed settings provider.
 */
final class SettingsStatusBar {
    private static final String TAG = "NetSpeedXposed: [sbsettings] ";
    private static final Set<String> SEEN = new HashSet<>();
    private static final Set<String> TUNER_FIRST = new HashSet<>();
    private static final Set<Integer> TUNER_ACTS = new HashSet<>();

    private SettingsStatusBar() {}

    private static final android.os.Handler MAIN = new android.os.Handler(android.os.Looper.getMainLooper());

    /** Called for every preference page that resumes; the page can fill in late, so look again shortly after. */
    static void maybe(final Object frag, final ClassLoader cl) { maybe(frag, cl, false); }

    static void maybe(final Object frag, final ClassLoader cl, final boolean force) {
        check(frag, cl, true, force);
        long[] later = {500, 1500, 3500};
        for (long d : later) {
            MAIN.postDelayed(new Runnable() {
                @Override public void run() { check(frag, cl, false, force); }
            }, d);
        }
    }

    /** Titles of every row on the page (including inside categories). */
    private static void titles(Object group, Set<String> out, int depth) {
        if (depth > 3) return;
        try {
            int c = (Integer) XposedHelpers.callMethod(group, "getPreferenceCount");
            for (int i = 0; i < c; i++) {
                Object pr = XposedHelpers.callMethod(group, "getPreference", i);
                CharSequence t = (CharSequence) XposedHelpers.callMethod(pr, "getTitle");
                if (t != null) out.add(t.toString());
                if (pr.getClass().getName().contains("PreferenceCategory")
                        || pr.getClass().getName().contains("PreferenceGroup")
                        || pr.getClass().getName().contains("PreferenceScreen")) titles(pr, out, depth + 1);
            }
        } catch (Throwable ignored) { }
    }

    private static void check(Object frag, ClassLoader cl, boolean log, boolean force) {
        try {
            Class<?> pf = XposedHelpers.findClassIfExists("androidx.preference.PreferenceFragmentCompat", cl);
            Class<?> pf2 = XposedHelpers.findClassIfExists("androidx.preference.PreferenceFragment", cl);
            if ((pf == null || !pf.isInstance(frag)) && (pf2 == null || !pf2.isInstance(frag))) {
                if (log && SEEN.add(frag.getClass().getName())) {
                    StringBuilder ch = new StringBuilder();
                    for (Class<?> k = frag.getClass(); k != null; k = k.getSuperclass()) ch.append(k.getName()).append(" > ");
                    XposedBridge.log(TAG + "non-preference page " + ch);
                }
                return;
            }
            Object screen = XposedHelpers.callMethod(frag, "getPreferenceScreen");
            if (screen == null) return;
            String cn = frag.getClass().getName();
            CharSequence st = null, at = null;
            try { st = (CharSequence) XposedHelpers.callMethod(screen, "getTitle"); } catch (Throwable ignored) { }
            try {
                Object act = XposedHelpers.callMethod(frag, "getActivity");
                if (act != null) at = ((android.app.Activity) act).getTitle();
            } catch (Throwable ignored) { }
            Set<String> tt = new HashSet<>();
            titles(screen, tt, 0);
            if (log && SEEN.add(cn)) {
                String first = tt.toString();
                XposedBridge.log(TAG + "page " + cn + " screenTitle=" + st + " activityTitle=" + at + " rows=" + tt.size()
                        + " " + (first.length() > 300 ? first.substring(0, 300) : first));
            }
            int hits = 0;
            for (String k : new String[]{"VoLTE", "VoNR", "VoWiFi", "Hotspot", "Wifi Standard", "Mobile data", "Roaming indicator"})
                if (tt.contains(k)) hits++;
            // Lunaris: Settings > Singularity > Status bar > Icons
            String sts = String.valueOf(st);
            boolean lunarisIcons = cn.startsWith("org.lunaris")
                    && ("icons".equalsIgnoreCase(sts) || "status bar icons".equalsIgnoreCase(sts));
            boolean tunerSb = cn.contains(".tuner.") && String.valueOf(st).toLowerCase().contains("status bar");
            boolean match = lunarisIcons || tunerSb || hits >= 3 || (cn.startsWith("org.lunaris") && cn.toLowerCase().contains("icon")) || cn.toLowerCase().contains("statusbaricon")
                    || "status bar icons".equalsIgnoreCase(String.valueOf(st))
                    || "status bar icons".equalsIgnoreCase(String.valueOf(at));
            if (force) match = true;
            if (!match) return;
            if (XposedHelpers.callMethod(screen, "findPreference", "ns_marker") != null) return;
            inject(frag, screen, cl);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "failed: " + t);
        }
    }

    private static Map<String, String> readAll(Context ctx) {
        Map<String, String> m = new HashMap<>();
        try (Cursor c = ctx.getContentResolver().query(Cfg.URI, null, null, null, null)) {
            if (c != null) while (c.moveToNext()) m.put(c.getString(0), c.getString(1));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "can't read settings: " + t);
        }
        return m;
    }

    private static void write(final Context ctx, final String key, final Object value) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ContentValues v = new ContentValues();
                    if (value instanceof Boolean) v.put(key, (Boolean) value);
                    else v.put(key, ((Number) value).intValue());
                    ctx.getContentResolver().update(Cfg.URI, v, null, null);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "write failed: " + t);
                }
            }
        }).start();
    }

    private static Object listener(ClassLoader cl, final Context ctx, final String key) throws Throwable {
        Class<?> li = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceChangeListener", cl);
        return Proxy.newProxyInstance(cl, new Class<?>[]{li}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method m, Object[] a) {
                if (m.getName().equals("onPreferenceChange")) {
                    try { write(ctx, key, a[1]); } catch (Throwable ignored) { }
                    return Boolean.TRUE;
                }
                return null;
            }
        });
    }

    private static void inject(Object frag, Object screen, ClassLoader cl) throws Throwable {
        Context ctx = actOf(frag);
        Map<String, String> cur = readAll(ctx);
        Class<?> prefC = XposedHelpers.findClass("androidx.preference.Preference", cl);
        Class<?> catC = XposedHelpers.findClass("androidx.preference.PreferenceCategory", cl);
        Class<?> swC = XposedHelpers.findClassIfExists("androidx.preference.SwitchPreferenceCompat", cl);
        if (swC == null) swC = XposedHelpers.findClassIfExists("androidx.preference.SwitchPreference", cl);
        Class<?> sbC = XposedHelpers.findClassIfExists("androidx.preference.SeekBarPreference", cl);

        // marker (invisible) so the rows are added once
        Object marker = make(prefC, ctx);
        XposedHelpers.callMethod(marker, "setKey", "ns_marker");
        XposedHelpers.callMethod(marker, "setVisible", false);
        XposedHelpers.callMethod(screen, "addPreference", marker);

        Object top = make(catC, ctx);
        XposedHelpers.callMethod(top, "setTitle", (CharSequence) "NetSpeed status bar");
        XposedHelpers.callMethod(screen, "addPreference", top);
        Object openRow = make(prefC, ctx);
        XposedHelpers.callMethod(openRow, "setTitle", (CharSequence) "Open the NetSpeed app");
        XposedHelpers.callMethod(openRow, "setSummary", (CharSequence) "Restart System UI, update, tower tools, token");
        final Object frag0 = frag;
        Class<?> cli = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceClickListener", cl);
        XposedHelpers.callMethod(openRow, "setOnPreferenceClickListener", Proxy.newProxyInstance(cl, new Class<?>[]{cli},
                new InvocationHandler() {
                    @Override public Object invoke(Object p, Method m, Object[] a) {
                        if (m.getName().equals("onPreferenceClick")) {
                            try {
                                android.app.Activity act = actOf(frag0);
                                android.content.Intent i = new android.content.Intent();
                                i.setClassName("com.netspeed.xposed", "com.netspeed.xposed.SettingsActivity");
                                act.startActivity(i);
                            } catch (Throwable t) { XposedBridge.log(TAG + "open app failed: " + t); }
                            return Boolean.TRUE;
                        }
                        return null;
                    }
                }));
        XposedHelpers.callMethod(top, "addPreference", openRow);

        Object group = top;
        int n = 0;
        List<Object[]> items = SettingsCatalog.items();
        for (Object[] it : items) {
            String kind = (String) it[0];
            if (kind.equals("sec")) {
                group = make(catC, ctx);
                XposedHelpers.callMethod(group, "setTitle", (CharSequence) ("NetSpeed · " + it[1]));
                XposedHelpers.callMethod(screen, "addPreference", group);
                continue;
            }
            try {
                if (kind.equals("T")) {
                    String key = (String) it[3];
                    boolean def = (Boolean) it[4];
                    Object p = make(swC, ctx);
                    XposedHelpers.callMethod(group, "addPreference", p);   // attach first, then configure
                    XposedHelpers.callMethod(p, "setPersistent", false);
                    XposedHelpers.callMethod(p, "setKey", "ns_" + key);
                    XposedHelpers.callMethod(p, "setTitle", (CharSequence) it[1]);
                    if (it[2] != null) XposedHelpers.callMethod(p, "setSummary", (CharSequence) it[2]);
                    String v = cur.get(key);
                    boolean on = v == null ? def : Boolean.parseBoolean(v);
                    XposedHelpers.callMethod(p, "setChecked", on);
                    XposedHelpers.callMethod(p, "setOnPreferenceChangeListener", listener(cl, ctx, key));
                } else {
                    String key = (String) it[3];
                    int def = (Integer) it[4], min = (Integer) it[5], max = (Integer) it[6];
                    Object p = null;
                    try { if (sbC != null) p = make(sbC, ctx); } catch (Throwable ignored) { }
                    if (p == null) {   // no usable SeekBarPreference here: a row that opens a slider dialog
                        int val0 = def;
                        try { if (cur.get(key) != null) val0 = Integer.parseInt(cur.get(key)); } catch (NumberFormatException ignored) { }
                        dialogSlider(frag, group, prefC, cl, ctx, key, (String) it[1], (String) it[2], min, max,
                                Math.max(min, Math.min(max, val0)));
                        n++;
                        continue;
                    }
                    XposedHelpers.callMethod(group, "addPreference", p);
                    XposedHelpers.callMethod(p, "setPersistent", false);
                    XposedHelpers.callMethod(p, "setKey", "ns_" + key);
                    XposedHelpers.callMethod(p, "setTitle", (CharSequence) (it[1] + " (" + it[2] + ")"));
                    try { XposedHelpers.callMethod(p, "setMin", min); } catch (Throwable ignored) { }
                    XposedHelpers.callMethod(p, "setMax", max);
                    try { XposedHelpers.callMethod(p, "setShowSeekBarValue", true); } catch (Throwable ignored) { }
                    int val = def;
                    try { if (cur.get(key) != null) val = Integer.parseInt(cur.get(key)); } catch (NumberFormatException ignored) { }
                    XposedHelpers.callMethod(p, "setValue", Math.max(min, Math.min(max, val)));
                    XposedHelpers.callMethod(p, "setOnPreferenceChangeListener", listener(cl, ctx, key));
                }
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "row " + it[1] + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "added " + n + " NetSpeed rows");
    }

    /** New preference using whichever constructor the host app still has (R8 strips unused ones). */
    private static Object make(Class<?> c, Context ctx) throws Throwable {
        if (c == null) throw new ClassNotFoundException("preference class");
        Throwable last = null;
        try { return c.getConstructor(Context.class).newInstance(ctx); } catch (Throwable t) { last = t; }
        try { return c.getConstructor(Context.class, android.util.AttributeSet.class).newInstance(ctx, null); } catch (Throwable t) { last = t; }
        try { return c.getConstructor(Context.class, android.util.AttributeSet.class, int.class).newInstance(ctx, null, 0); } catch (Throwable t) { last = t; }
        try { return c.getConstructor(Context.class, android.util.AttributeSet.class, int.class, int.class).newInstance(ctx, null, 0, 0); } catch (Throwable t) { last = t; }
        for (java.lang.reflect.Constructor<?> k : c.getDeclaredConstructors()) {
            Class<?>[] pt = k.getParameterTypes();
            if (pt.length == 0 || pt[0] != Context.class) continue;
            Object[] a = new Object[pt.length];
            a[0] = ctx;
            for (int i = 1; i < pt.length; i++) a[i] = pt[i] == int.class ? 0 : null;
            try { k.setAccessible(true); return k.newInstance(a); } catch (Throwable t) { last = t; }
        }
        throw last;
    }

    private static void dialogSlider(final Object frag, Object group, Class<?> prefC, ClassLoader cl, final Context ctx,
                                     final String key, final String title, final String unit, final int min, final int max,
                                     int start) throws Throwable {
        final Object row = make(prefC, ctx);
        XposedHelpers.callMethod(group, "addPreference", row);
        XposedHelpers.callMethod(row, "setPersistent", false);
        XposedHelpers.callMethod(row, "setKey", "ns_" + key);
        XposedHelpers.callMethod(row, "setTitle", (CharSequence) title);
        final int[] value = {start};
        XposedHelpers.callMethod(row, "setSummary", (CharSequence) (start + " " + unit));
        Class<?> cli = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceClickListener", cl);
        XposedHelpers.callMethod(row, "setOnPreferenceClickListener", Proxy.newProxyInstance(cl, new Class<?>[]{cli},
                new InvocationHandler() {
                    @Override public Object invoke(Object pr, Method m, Object[] a) {
                        if (!m.getName().equals("onPreferenceClick")) return null;
                        try {
                            android.app.Activity act = actOf(frag);
                            final android.widget.TextView tv = new android.widget.TextView(act);
                            tv.setGravity(android.view.Gravity.CENTER);
                            final android.widget.SeekBar sb = new android.widget.SeekBar(act);
                            sb.setMax(max - min);
                            sb.setProgress(value[0] - min);
                            tv.setText(value[0] + " " + unit);
                            sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                                @Override public void onProgressChanged(android.widget.SeekBar s, int pg, boolean u) { tv.setText((pg + min) + " " + unit); }
                                @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
                                @Override public void onStopTrackingTouch(android.widget.SeekBar s) { }
                            });
                            android.widget.LinearLayout ll = new android.widget.LinearLayout(act);
                            ll.setOrientation(android.widget.LinearLayout.VERTICAL);
                            int pad = (int) (20 * act.getResources().getDisplayMetrics().density);
                            ll.setPadding(pad, pad, pad, 0);
                            ll.addView(tv);
                            ll.addView(sb);
                            new android.app.AlertDialog.Builder(act).setTitle(title).setView(ll)
                                    .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                                        @Override public void onClick(android.content.DialogInterface d, int w) {
                                            value[0] = sb.getProgress() + min;
                                            try { XposedHelpers.callMethod(row, "setSummary", (CharSequence) (value[0] + " " + unit)); } catch (Throwable ignored) { }
                                            write(ctx, key, value[0]);
                                        }
                                    })
                                    .setNegativeButton(android.R.string.cancel, null).show();
                        } catch (Throwable t) { XposedBridge.log(TAG + "slider dialog failed: " + t); }
                        return Boolean.TRUE;
                    }
                }));
    }

    /** System UI: the "Status bar icons" page is System UI Tuner (TunerActivity), not a Settings page. */
    static void installSystemUi(final ClassLoader cl) {
        de.robv.android.xposed.XC_MethodHook h = new de.robv.android.xposed.XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object act = XposedHelpers.callMethod(p.thisObject, "getActivity");
                    if (act == null || !act.getClass().getName().toLowerCase().contains("tuner")) return;
                    android.content.Intent in = ((android.app.Activity) act).getIntent();
                    String action = in == null ? null : in.getAction();
                    XposedBridge.log(TAG + "tuner fragment " + p.thisObject.getClass().getName() + " action=" + action);
                    // Settings > Status bar > Icons launches the tuner with this action: put the rows on the
                    // first page it shows (not on pages opened from inside it).
                    String id = System.identityHashCode(act) + "/" + System.identityHashCode(p.thisObject);
                    boolean force = false;
                    if ("com.android.settings.action.STATUS_BAR_TUNER".equals(action)) {
                        if (TUNER_FIRST.contains(id)) force = true;          // same page resumed again
                        else if (TUNER_ACTS.add(System.identityHashCode(act))) { TUNER_FIRST.add(id); force = true; }
                    }
                    maybe(p.thisObject, cl, force);
                } catch (Throwable ignored) { }
            }
        };
        try {
            XposedHelpers.findAndHookMethod(android.app.Fragment.class, "onResume", h);
        } catch (Throwable t) { XposedBridge.log(TAG + "tuner hook (framework fragment) failed: " + t); }
        try {
            Class<?> f = XposedHelpers.findClassIfExists("androidx.fragment.app.Fragment", cl);
            if (f != null) XposedHelpers.findAndHookMethod(f, "onResume", h);
        } catch (Throwable t) { XposedBridge.log(TAG + "tuner hook (androidx fragment) failed: " + t); }
        try {
            XposedHelpers.findAndHookMethod(android.app.Activity.class, "onResume", new de.robv.android.xposed.XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    XposedBridge.log(TAG + "System UI activity " + p.thisObject.getClass().getName());
                }
            });
        } catch (Throwable ignored) { }
        // Framework Fragment/Activity.onResume can be inlined in the boot image and never reach a hook,
        // so also hook System UI's own TunerActivity and find its page from there.
        try {
            Class<?> ta = XposedHelpers.findClassIfExists("com.android.systemui.tuner.TunerActivity", cl);
            if (ta == null) XposedBridge.log(TAG + "TunerActivity class not found");
            else XposedBridge.hookAllMethods(ta, "onCreate", new de.robv.android.xposed.XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    final android.app.Activity act = (android.app.Activity) p.thisObject;
                    android.content.Intent in = act.getIntent();
                    final String action = in == null ? null : in.getAction();
                    XposedBridge.log(TAG + "TunerActivity created action=" + action);
                    if (!"com.android.settings.action.STATUS_BAR_TUNER".equals(action)) return;
                    for (long d : new long[]{200, 800, 2000}) {
                        MAIN.postDelayed(new Runnable() {
                            @Override public void run() { tunerPage(act, cl); }
                        }, d);
                    }
                }
            });
        } catch (Throwable t) { XposedBridge.log(TAG + "TunerActivity hook failed: " + t); }
        String proc = "?";
        try { proc = android.app.Application.getProcessName(); } catch (Throwable ignored) { }
        XposedBridge.log(TAG + "System UI tuner hook installed in " + proc);
    }

    /** The page currently shown by the tuner opened from Settings > Status bar > Icons. */
    private static void tunerPage(android.app.Activity act, ClassLoader cl) {
        try {
            if (act.isFinishing() || act.isDestroyed()) return;
            java.util.List<Object> frags = new java.util.ArrayList<>();
            try { frags.addAll(act.getFragmentManager().getFragments()); } catch (Throwable ignored) { }
            try {
                Object sfm = XposedHelpers.callMethod(act, "getSupportFragmentManager");
                frags.addAll((java.util.List<?>) XposedHelpers.callMethod(sfm, "getFragments"));
            } catch (Throwable ignored) { }
            StringBuilder names = new StringBuilder();
            for (Object f : frags) names.append(f.getClass().getName()).append(' ');
            XposedBridge.log(TAG + "tuner fragments: " + names);
            // the page isn't a fragment we can see: take the preference screen from its list's adapter
            Object vscreen = screenFromViews(act.getWindow().getDecorView(), cl, 0);
            if (vscreen != null) {
                if (XposedHelpers.callMethod(vscreen, "findPreference", "ns_marker") != null) return;
                XposedBridge.log(TAG + "tuner screen from adapter: " + vscreen.getClass().getName());
                inject(act, vscreen, cl);
                return;
            }
            for (Object f : frags) {
                Object screen;
                try { screen = XposedHelpers.callMethod(f, "getPreferenceScreen"); } catch (Throwable t) { continue; }
                if (screen == null) continue;
                check(f, cl, true, true);
                return;   // only the first page
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "tuner page failed: " + t);
        }
    }

    private static android.app.Activity actOf(Object o) {
        if (o instanceof android.app.Activity) return (android.app.Activity) o;
        return (android.app.Activity) XposedHelpers.callMethod(o, "getActivity");
    }

    private static final StringBuilder VIEWS = new StringBuilder();

    /** Finds a preference list (RecyclerView with androidx PreferenceGroupAdapter) and returns its PreferenceGroup. */
    private static Object screenFromViews(android.view.View v, ClassLoader cl, int depth) {
        if (depth == 0) VIEWS.setLength(0);
        if (depth < 14 && VIEWS.length() < 1500) VIEWS.append(v.getClass().getSimpleName()).append(depth).append(' ');
        try {
            Object ad = null;
            try { ad = XposedHelpers.callMethod(v, "getAdapter"); } catch (Throwable ignored) { }
            if (ad != null) {
                Class<?> grp = XposedHelpers.findClassIfExists("androidx.preference.PreferenceGroup", cl);
                if (grp != null) {
                    for (Class<?> k = ad.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
                        for (java.lang.reflect.Field f : k.getDeclaredFields()) {
                            if (!grp.isAssignableFrom(f.getType()) && f.getType() != Object.class) continue;
                            f.setAccessible(true);
                            Object g = f.get(ad);
                            if (g != null && grp.isInstance(g)) return g;
                        }
                    }
                }
                XposedBridge.log(TAG + "list adapter without a preference group: " + ad.getClass().getName());
            }
        } catch (Throwable t) { XposedBridge.log(TAG + "adapter scan failed: " + t); }
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup vg = (android.view.ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                Object r = screenFromViews(vg.getChildAt(i), cl, depth + 1);
                if (r != null) return r;
            }
        }
        if (depth == 0) XposedBridge.log(TAG + "tuner views: " + VIEWS);
        return null;
    }
}
