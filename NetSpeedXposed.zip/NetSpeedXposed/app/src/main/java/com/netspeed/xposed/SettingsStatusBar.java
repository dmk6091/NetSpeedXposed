package com.netspeed.xposed;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Settings app: puts every NetSpeed switch and slider on the "Status bar icons" page, as the ROM's
 * own preference rows. Values are read from and written to the NetSpeed settings provider.
 */
final class SettingsStatusBar {
    private static final String TAG = "NetSpeedXposed: [sbsettings] ";
    private static final Set<String> SEEN = new HashSet<>();

    private SettingsStatusBar() {}

    /** Called for every preference page that resumes; acts only on the status bar icons page. */
    static void maybe(Object frag, ClassLoader cl) {
        try {
            Class<?> pf = XposedHelpers.findClass("androidx.preference.PreferenceFragmentCompat", cl);
            if (!pf.isInstance(frag)) return;
            Object screen = XposedHelpers.callMethod(frag, "getPreferenceScreen");
            if (screen == null) return;
            String cn = frag.getClass().getName();
            CharSequence st = null, at = null;
            try { st = (CharSequence) XposedHelpers.callMethod(screen, "getTitle"); } catch (Throwable ignored) { }
            try {
                Object act = XposedHelpers.callMethod(frag, "getActivity");
                if (act != null) at = ((android.app.Activity) act).getTitle();
            } catch (Throwable ignored) { }
            if (SEEN.add(cn)) XposedBridge.log(TAG + "page " + cn + " screenTitle=" + st + " activityTitle=" + at);
            boolean match = cn.toLowerCase().contains("statusbaricon")
                    || "status bar icons".equalsIgnoreCase(String.valueOf(st))
                    || "status bar icons".equalsIgnoreCase(String.valueOf(at));
            if (!match) return;
            if (XposedHelpers.callMethod(screen, "findPreference", "ns_marker") != null) return;
            inject(frag, screen, cl);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "failed: " + t);
        }
    }

    private static Map<String, String> readAll(Context ctx) {
        Map<String, String> m = new HashMap<>();
        try (Cursor c = ctx.getContentResolver().query(Cfg.URI, null, null, null, null)) {
            if (c != null) while (c.moveToNext()) m.put(c.getString(0), c.getString(1));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "can't read settings: " + t);
        }
        return m;
    }

    private static void write(final Context ctx, final String key, final Object value) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ContentValues v = new ContentValues();
                    if (value instanceof Boolean) v.put(key, (Boolean) value);
                    else v.put(key, ((Number) value).intValue());
                    ctx.getContentResolver().update(Cfg.URI, v, null, null);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "write failed: " + t);
                }
            }
        }).start();
    }

    private static Object listener(ClassLoader cl, final Context ctx, final String key) throws Throwable {
        Class<?> li = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceChangeListener", cl);
        return Proxy.newProxyInstance(cl, new Class<?>[]{li}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method m, Object[] a) {
                if (m.getName().equals("onPreferenceChange")) {
                    try { write(ctx, key, a[1]); } catch (Throwable ignored) { }
                    return Boolean.TRUE;
                }
                return null;
            }
        });
    }

    private static void inject(Object frag, Object screen, ClassLoader cl) throws Throwable {
        Context ctx = (Context) XposedHelpers.callMethod(frag, "getContext");
        Map<String, String> cur = readAll(ctx);
        Class<?> prefC = XposedHelpers.findClass("androidx.preference.Preference", cl);
        Class<?> catC = XposedHelpers.findClass("androidx.preference.PreferenceCategory", cl);
        Class<?> swC = XposedHelpers.findClass("androidx.preference.SwitchPreferenceCompat", cl);
        Class<?> sbC = XposedHelpers.findClass("androidx.preference.SeekBarPreference", cl);

        // marker (invisible) so the rows are added once
        Object marker = prefC.getConstructor(Context.class).newInstance(ctx);
        XposedHelpers.callMethod(marker, "setKey", "ns_marker");
        XposedHelpers.callMethod(marker, "setVisible", false);
        XposedHelpers.callMethod(screen, "addPreference", marker);

        Object top = catC.getConstructor(Context.class).newInstance(ctx);
        XposedHelpers.callMethod(top, "setTitle", (CharSequence) "NetSpeed status bar");
        XposedHelpers.callMethod(screen, "addPreference", top);
        Object openRow = prefC.getConstructor(Context.class).newInstance(ctx);
        XposedHelpers.callMethod(openRow, "setTitle", (CharSequence) "Open the NetSpeed app");
        XposedHelpers.callMethod(openRow, "setSummary", (CharSequence) "Restart System UI, update, tower tools, token");
        final Object frag0 = frag;
        Class<?> cli = XposedHelpers.findClass("androidx.preference.Preference$OnPreferenceClickListener", cl);
        XposedHelpers.callMethod(openRow, "setOnPreferenceClickListener", Proxy.newProxyInstance(cl, new Class<?>[]{cli},
                new InvocationHandler() {
                    @Override public Object invoke(Object p, Method m, Object[] a) {
                        if (m.getName().equals("onPreferenceClick")) {
                            try {
                                android.app.Activity act = (android.app.Activity) XposedHelpers.callMethod(frag0, "getActivity");
                                android.content.Intent i = new android.content.Intent();
                                i.setClassName("com.netspeed.xposed", "com.netspeed.xposed.SettingsActivity");
                                act.startActivity(i);
                            } catch (Throwable t) { XposedBridge.log(TAG + "open app failed: " + t); }
                            return Boolean.TRUE;
                        }
                        return null;
                    }
                }));
        XposedHelpers.callMethod(top, "addPreference", openRow);

        Object group = top;
        int n = 0;
        List<Object[]> items = SettingsCatalog.items();
        for (Object[] it : items) {
            String kind = (String) it[0];
            if (kind.equals("sec")) {
                group = catC.getConstructor(Context.class).newInstance(ctx);
                XposedHelpers.callMethod(group, "setTitle", (CharSequence) ("NetSpeed · " + it[1]));
                XposedHelpers.callMethod(screen, "addPreference", group);
                continue;
            }
            try {
                if (kind.equals("T")) {
                    String key = (String) it[3];
                    boolean def = (Boolean) it[4];
                    Object p = swC.getConstructor(Context.class).newInstance(ctx);
                    XposedHelpers.callMethod(group, "addPreference", p);   // attach first, then configure
                    XposedHelpers.callMethod(p, "setPersistent", false);
                    XposedHelpers.callMethod(p, "setKey", "ns_" + key);
                    XposedHelpers.callMethod(p, "setTitle", (CharSequence) it[1]);
                    if (it[2] != null) XposedHelpers.callMethod(p, "setSummary", (CharSequence) it[2]);
                    String v = cur.get(key);
                    boolean on = v == null ? def : Boolean.parseBoolean(v);
                    XposedHelpers.callMethod(p, "setChecked", on);
                    XposedHelpers.callMethod(p, "setOnPreferenceChangeListener", listener(cl, ctx, key));
                } else {
                    String key = (String) it[3];
                    int def = (Integer) it[4], min = (Integer) it[5], max = (Integer) it[6];
                    Object p = sbC.getConstructor(Context.class).newInstance(ctx);
                    XposedHelpers.callMethod(group, "addPreference", p);
                    XposedHelpers.callMethod(p, "setPersistent", false);
                    XposedHelpers.callMethod(p, "setKey", "ns_" + key);
                    XposedHelpers.callMethod(p, "setTitle", (CharSequence) (it[1] + " (" + it[2] + ")"));
                    try { XposedHelpers.callMethod(p, "setMin", min); } catch (Throwable ignored) { }
                    XposedHelpers.callMethod(p, "setMax", max);
                    try { XposedHelpers.callMethod(p, "setShowSeekBarValue", true); } catch (Throwable ignored) { }
                    int val = def;
                    try { if (cur.get(key) != null) val = Integer.parseInt(cur.get(key)); } catch (NumberFormatException ignored) { }
                    XposedHelpers.callMethod(p, "setValue", Math.max(min, Math.min(max, val)));
                    XposedHelpers.callMethod(p, "setOnPreferenceChangeListener", listener(cl, ctx, key));
                }
                n++;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "row " + it[1] + " failed: " + t);
            }
        }
        XposedBridge.log(TAG + "added " + n + " NetSpeed rows");
    }
}
