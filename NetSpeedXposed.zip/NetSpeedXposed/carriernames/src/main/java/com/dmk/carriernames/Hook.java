package com.dmk.carriernames;

import android.content.Context;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;

import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Phone services: the carrier name Android hands to the lock screen, quick settings, shade and Settings
 * is decided in ServiceStateTracker.notifySpnDisplayUpdate(CarrierDisplayNameData). When you're on
 * another state's network (roaming flag, a different circle, or a different network name), the name
 * becomes "SIM name · network name", e.g. "Jio · IND airtel", "BSNL · Dolphin". At home nothing changes.
 */
public class Hook implements IXposedHookLoadPackage {
    private static final String TAG = "CarrierNames: ";
    private static Object prefs;   // XSharedPreferences (via reflection: the compile stub doesn't have it)
    private static boolean logged;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.phone".equals(lp.packageName)) return;
        try {
            Class<?> sst = XposedHelpers.findClass("com.android.internal.telephony.ServiceStateTracker", lp.classLoader);
            int n = XposedBridge.hookAllMethods(sst, "notifySpnDisplayUpdate", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (!enabled() || p.args.length == 0 || p.args[0] == null) return;
                        rewrite(p.thisObject, p.args[0]);
                    } catch (Throwable t) {
                        if (!logged) { logged = true; XposedBridge.log(TAG + "skipped: " + t); }
                    }
                }
            }).size();
            XposedBridge.log(TAG + (n > 0 ? "hooked carrier name (" + n + ")" : "notifySpnDisplayUpdate not found on this ROM"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + "not hooked: " + t);
        }
    }

    private static boolean enabled() {
        try {
            if (prefs == null) {
                Class<?> c = Class.forName("de.robv.android.xposed.XSharedPreferences");
                prefs = c.getConstructor(String.class, String.class).newInstance("com.dmk.carriernames", "prefs");
            }
            if ((Boolean) XposedHelpers.callMethod(prefs, "hasFileChanged")) XposedHelpers.callMethod(prefs, "reload");
            return (Boolean) XposedHelpers.callMethod(prefs, "getBoolean", "on", true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static String str(Object o, String field) {
        try {
            Object v = XposedHelpers.getObjectField(o, field);
            return v == null ? "" : v.toString().trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static void setBool(Object o, String name, boolean v) {
        try {
            java.lang.reflect.Field f = XposedHelpers.findField(o.getClass(), name);
            f.setBoolean(o, v);
        } catch (Throwable ignored) { }
    }

    private static String norm(String v) {
        return v == null ? "" : v.toLowerCase(Locale.US).replaceAll("[^a-z]", "").replace("ind", "");
    }

    private static void rewrite(Object tracker, Object data) {
        String spn = str(data, "mSpn"), plmn = str(data, "mPlmn");
        ServiceState ss = (ServiceState) XposedHelpers.getObjectField(tracker, "mSS");
        Object phone = XposedHelpers.getObjectField(tracker, "mPhone");
        Context ctx = (Context) XposedHelpers.callMethod(phone, "getContext");
        int sub = (Integer) XposedHelpers.callMethod(phone, "getSubId");
        TelephonyManager tm = ctx.getSystemService(TelephonyManager.class).createForSubscriptionId(sub);

        String simNum = tm.getSimOperator(), simName = tm.getSimOperatorName();
        String netNum = ss == null ? null : ss.getOperatorNumeric();
        String netName = ss == null ? null : ss.getOperatorAlphaLong();
        if (netName == null || netName.trim().isEmpty()) netName = ss == null ? null : ss.getOperatorAlphaShort();
        if (netName == null || netName.trim().isEmpty()) netName = plmn;
        String home = !spn.isEmpty() ? spn : simName;
        if (home == null || home.trim().isEmpty() || netName == null || netName.trim().isEmpty()) return;
        home = home.trim();
        netName = netName.trim();

        boolean roaming = ss != null && ss.getRoaming();
        boolean otherCircle = Circles.roamCircle(simNum, netNum) != null;
        String a = norm(home), b = norm(netName);
        boolean otherName = !a.isEmpty() && !b.isEmpty() && !a.contains(b) && !b.contains(a);
        if (!(roaming || otherCircle || otherName)) return;      // at home: leave Android's name alone
        if (home.contains(" · ")) return;                          // already rewritten

        String both = home + " · " + netName;
        XposedHelpers.setObjectField(data, "mSpn", both);
        try { XposedHelpers.setObjectField(data, "mDataSpn", both); } catch (Throwable ignored) { }
        setBool(data, "mShowSpn", true);
        setBool(data, "mShowPlmn", false);
    }
}
