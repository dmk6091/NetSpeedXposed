package com.dmk.carriernames;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** On / off switch. The phone service reads it through LSPosed's shared preferences. */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp;
        try {
            //noinspection deprecation
            sp = getSharedPreferences("prefs", MODE_WORLD_READABLE);   // LSPosed makes this readable to the hook
        } catch (SecurityException e) {
            sp = getSharedPreferences("prefs", MODE_PRIVATE);
        }
        final SharedPreferences prefs = sp;
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(pad, pad * 2, pad, pad);
        Switch sw = new Switch(this);
        sw.setText("Show the network's name when in another state");
        sw.setTextSize(18);
        sw.setChecked(prefs.getBoolean("on", true));
        sw.setOnCheckedChangeListener((v, on) -> prefs.edit().putBoolean("on", on).apply());
        l.addView(sw);
        TextView t = new TextView(this);
        t.setTextSize(15);
        t.setPadding(0, pad, 0, 0);
        t.setText("At home the carrier name stays as Android shows it (e.g. \"Jio\"). On another state's network it "
                + "shows both: your SIM's operator, then the network's own name, e.g. \"Jio · IND airtel\" or "
                + "\"BSNL · Dolphin\". Lock screen, quick settings, notification shade and Settings all use it.\n\n"
                + "Needs LSPosed with \"Phone services\" ticked. After switching on or off, reboot (or toggle "
                + "airplane mode) to refresh the name.");
        l.addView(t);
        setContentView(l);
    }
}
