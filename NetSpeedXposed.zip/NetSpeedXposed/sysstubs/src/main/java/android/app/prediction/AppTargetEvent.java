package android.app.prediction;

public final class AppTargetEvent {
    public static final int ACTION_LAUNCH = 1;
    public static final int ACTION_DISMISS = 2;
    public static final int ACTION_PIN = 3;
    public static final int ACTION_UNPIN = 4;
    public AppTarget getTarget() { throw new RuntimeException("stub"); }
    public String getLaunchLocation() { throw new RuntimeException("stub"); }
    public int getAction() { throw new RuntimeException("stub"); }
}
