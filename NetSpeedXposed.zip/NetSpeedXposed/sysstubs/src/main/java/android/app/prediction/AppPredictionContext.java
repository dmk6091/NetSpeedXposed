package android.app.prediction;

import android.os.Bundle;

public final class AppPredictionContext {
    public int getPredictedTargetCount() { throw new RuntimeException("stub"); }
    public String getUiSurface() { throw new RuntimeException("stub"); }
    public String getPackageName() { throw new RuntimeException("stub"); }
    public Bundle getExtras() { throw new RuntimeException("stub"); }
}
