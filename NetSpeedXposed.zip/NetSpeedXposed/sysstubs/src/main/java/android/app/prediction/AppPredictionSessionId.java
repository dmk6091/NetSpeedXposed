package android.app.prediction;

public final class AppPredictionSessionId {
}
