package android.app.prediction;

public final class AppTargetId {
    public AppTargetId(String id) { throw new RuntimeException("stub"); }
    public String getId() { throw new RuntimeException("stub"); }
}
